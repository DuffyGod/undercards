#!/usr/bin/env python3
"""Recover added-file snapshots from a shared-thread response; never execute them."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from dataclasses import dataclass, field
import json
from pathlib import Path
import re
import sys


HUNK = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?:.*)$")
BAD_NAME = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
RESERVED = {"CON", "PRN", "AUX", "NUL"} | {
    f"{prefix}{number}" for prefix in ("COM", "LPT") for number in range(1, 10)
}


@dataclass
class Entry:
    index: int
    turn: int
    item: int
    change: int
    path: str
    diff: str

    def source(self) -> dict:
        return {
            "entry_index": self.index,
            "turn_index": self.turn,
            "item_index": self.item,
            "change_index": self.change,
            "json_path": (
                f"$.turns[{self.turn}].items[{self.item}].changes[{self.change}]"
            ),
            "source_path": self.path,
        }


@dataclass
class Creation:
    text: str
    lines: list[str]
    newline: str
    final_newline: bool


@dataclass
class Hunk:
    old_start: int
    old_count: int
    new_start: int
    new_count: int
    body: list[tuple[str, str]] = field(default_factory=list)
    omitted_final_context: bool = False

    @property
    def before(self) -> list[str]:
        return [text for kind, text in self.body if kind in " -"]

    @property
    def after(self) -> list[str]:
        return [text for kind, text in self.body if kind in " +"]


@dataclass
class Track:
    entry: Entry
    filename: str
    initial: Creation
    current_lines: list[str]
    applied: list[int] = field(default_factory=list)
    omitted_context: list[int] = field(default_factory=list)
    pending: list[int] = field(default_factory=list)

    def current_text(self) -> str:
        # No unseen final newline is invented. The response may have trimmed it.
        return self.initial.newline.join(self.current_lines) + (
            self.initial.newline if self.initial.final_newline else ""
        )


def entries_from(data: dict) -> list[Entry]:
    entries = []
    for turn_index, turn in enumerate(data["turns"]):
        for item_index, item in enumerate(turn["items"]):
            if item.get("type") != "fileChange":
                continue
            if item.get("status") != "completed":
                raise ValueError("Encountered a non-completed fileChange record")
            for change_index, change in enumerate(item["changes"]):
                path, diff = change["path"], change["diff"]
                if not isinstance(path, str) or not isinstance(diff, str):
                    raise ValueError("File paths and diffs must be strings")
                validate_filename(path)
                entries.append(
                    Entry(len(entries), turn_index, item_index, change_index, path, diff)
                )
    return entries


def validate_filename(name: str) -> None:
    if (
        not name
        or name in {".", ".."}
        or BAD_NAME.search(name)
        or name != name.rstrip(" .")
        or name.split(".", 1)[0].upper() in RESERVED
    ):
        raise ValueError(f"Unsafe or non-basename source path: {name!r}")


def creation_from(diff: str) -> Creation | None:
    """Recognize only the headerless, all-addition form actually used by this export."""
    if not diff:
        return None
    parts = diff.split("\n")
    final_newline = parts[-1] == ""
    if final_newline:
        parts.pop()
    if not parts or any(not line.startswith("+") for line in parts):
        return None
    raw_lines = [line[1:] for line in parts]
    text = "\n".join(raw_lines) + ("\n" if final_newline else "")
    newline = "\r\n" if "\r\n" in diff else "\n"
    lines = [line.removesuffix("\r") for line in raw_lines]
    return Creation(text, lines, newline, final_newline)


def parse_patch(diff: str) -> list[Hunk]:
    lines = diff.replace("\r\n", "\n").split("\n")
    if lines and lines[-1] == "":
        lines.pop()  # Split sentinel, not a source-code line.
    hunks: list[Hunk] = []
    for line in lines:
        match = HUNK.fullmatch(line)
        if match:
            old_start, old_count, new_start, new_count = match.groups()
            hunks.append(
                Hunk(
                    int(old_start), int(old_count) if old_count is not None else 1,
                    int(new_start), int(new_count) if new_count is not None else 1,
                )
            )
        elif line == r"\ No newline at end of file":
            continue
        elif hunks and line and line[0] in " +-":
            hunks[-1].body.append((line[0], line[1:]))
        else:
            raise ValueError("Unsupported or malformed diff line")
    if not hunks:
        raise ValueError("No unified-diff hunk headers")
    for index, hunk in enumerate(hunks):
        missing_old = hunk.old_count - len(hunk.before)
        missing_new = hunk.new_count - len(hunk.after)
        if missing_old == missing_new == 0:
            continue
        if index == len(hunks) - 1 and missing_old == missing_new == 1:
            # Observed export artifact: one final context row is omitted. Apply
            # only visible, exactly matched rows; retain all unshown base text.
            hunk.omitted_final_context = True
        else:
            raise ValueError("Hunk body lengths disagree with their headers")
    return hunks


def apply_patch_exact(before: list[str], hunks: list[Hunk]) -> list[str] | None:
    cursor = 0
    result: list[str] = []
    for hunk in hunks:
        position = hunk.old_start if hunk.old_count == 0 else hunk.old_start - 1
        old_lines = hunk.before
        if position < cursor or position > len(before):
            return None
        if before[position:position + len(old_lines)] != old_lines:
            return None
        result.extend(before[cursor:position])
        result.extend(hunk.after)
        cursor = position + len(old_lines)
    result.extend(before[cursor:])
    return result


def allocate_filenames(entries: list[Entry], creations: dict[int, Creation]) -> dict[int, str]:
    counts = Counter(entry.path.casefold() for entry in entries if entry.index in creations)
    reserved = {entry.path.casefold() for entry in entries}
    used: set[str] = set()
    names: dict[int, str] = {}
    for entry in entries:
        if entry.index not in creations:
            continue
        candidate = entry.path
        if counts[candidate.casefold()] > 1:
            path = Path(entry.path)
            candidate = f"{path.stem}__e{entry.index:06d}{path.suffix}"
            number = 2
            while candidate.casefold() in reserved or candidate.casefold() in used:
                candidate = f"{path.stem}__e{entry.index:06d}_{number}{path.suffix}"
                number += 1
        if candidate.casefold() in used:
            raise ValueError("Output filename collision")
        used.add(candidate.casefold())
        names[entry.index] = candidate
    return names


def recover(data: dict) -> tuple[list[Track], list[dict], dict]:
    entries = entries_from(data)
    creations = {
        entry.index: creation
        for entry in entries
        if (creation := creation_from(entry.diff)) is not None
    }
    filenames = allocate_filenames(entries, creations)
    tracks: list[Track] = []
    by_name: dict[str, list[Track]] = defaultdict(list)
    events: list[dict] = []
    for entry in entries:
        event = entry.source()
        if entry.index in creations:
            creation = creations[entry.index]
            # Independent prefix removal catches accidental whitespace loss.
            if creation.text != re.sub(r"(?m)^\+", "", entry.diff):
                raise AssertionError("Creation extraction changed source text")
            track = Track(entry, filenames[entry.index], creation, creation.lines.copy())
            tracks.append(track)
            by_name[entry.path].append(track)
            event.update(status="created", track=entry.index)
        elif not by_name[entry.path]:
            event.update(status="no_created_base")
        else:
            candidates = by_name[entry.path]
            try:
                hunks = parse_patch(entry.diff)
                matches = [
                    (track, result)
                    for track in candidates
                    if (result := apply_patch_exact(track.current_lines, hunks)) is not None
                ]
                if len(matches) == 1:
                    track, track.current_lines = matches[0]
                    track.applied.append(entry.index)
                    if any(hunk.omitted_final_context for hunk in hunks):
                        track.omitted_context.append(entry.index)
                    event.update(
                        status="applied", track=track.entry.index,
                        omitted_final_context=any(h.omitted_final_context for h in hunks),
                    )
                else:
                    event.update(
                        status="ambiguous" if matches else "context_mismatch",
                        candidates=[track.entry.index for track in candidates],
                        matching_tracks=[track.entry.index for track, _ in matches],
                    )
            except ValueError as error:
                event.update(
                    status="unsupported_patch", reason=str(error),
                    candidates=[track.entry.index for track in candidates],
                )
            if event["status"] != "applied":
                for track in candidates:
                    track.pending.append(entry.index)
                event["patch_file"] = f"unapplied/e{entry.index:06d}__{entry.path}.diff"
                event["raw_diff"] = entry.diff
        events.append(event)
    if not tracks:
        raise ValueError("No added-file snapshots were found")
    statuses = Counter(event["status"] for event in events)
    summary = {
        "turns": len(data["turns"]),
        "file_change_entries": len(entries),
        "creation_snapshots": len(tracks),
        "distinct_creation_filenames": len({track.entry.path for track in tracks}),
        "applied_patches": statuses["applied"],
        "patches_without_created_base": statuses["no_created_base"],
        "unapplied_patches": sum(
            statuses[name] for name in ("ambiguous", "context_mismatch", "unsupported_patch")
        ),
        "unapplied_by_reason": {
            name: statuses[name]
            for name in ("ambiguous", "context_mismatch", "unsupported_patch")
        },
        "snapshots_without_unresolved_patch_candidates": sum(not track.pending for track in tracks),
        "applied_patches_with_omitted_final_context": sum(len(t.omitted_context) for t in tracks),
        "initial_utf8_bytes": sum(len(t.initial.text.encode("utf-8")) for t in tracks),
    }
    return tracks, events, summary


def export(input_path: Path, output: Path, data: dict, tracks: list[Track],
           events: list[dict], summary: dict) -> None:
    if output.exists():
        raise FileExistsError(f"Output already exists; choose a new --output: {output}")
    output.mkdir(parents=True, exist_ok=False)
    (output / "initial").mkdir()
    (output / "latest").mkdir()
    files = []
    for track in tracks:
        initial_path = Path("initial") / track.filename
        latest_path = Path("latest") / track.filename
        (output / initial_path).write_bytes(track.initial.text.encode("utf-8"))
        (output / latest_path).write_bytes(track.current_text().encode("utf-8"))
        files.append({
            **track.entry.source(),
            "initial_file": initial_path.as_posix(),
            "latest_file": latest_path.as_posix(),
            "initial_lines": len(track.initial.lines),
            "applied_patch_entries": track.applied,
            "unresolved_patch_candidates": track.pending,
            "omitted_final_context_entries": track.omitted_context,
        })
    manifest_events = []
    for event in events:
        saved = {key: value for key, value in event.items() if key != "raw_diff"}
        if "patch_file" in event:
            patch_path = output / event["patch_file"]
            patch_path.parent.mkdir(exist_ok=True)
            patch_path.write_bytes(event["raw_diff"].encode("utf-8"))
        manifest_events.append(saved)
    manifest = {
        "source": str(input_path),
        "source_title": data.get("title"),
        "indices_are_zero_based": True,
        "summary": summary,
        "files": files,
        "events": manifest_events,
    }
    (output / "manifest.json").write_bytes(
        (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    )
    readme = f"""# 新增文件还原结果

来源：`{input_path}`

- 新增记录快照：{summary['creation_snapshots']} 份，涉及 {summary['distinct_creation_filenames']} 种文件名。
- `initial/`：按新增记录逐行去掉一个 `+`，保留原文字、缩进和空行。
- `latest/`：按事件顺序回放能唯一匹配的后续补丁，共成功应用 {summary['applied_patches']} 条。
- `unapplied/`：{summary['unapplied_patches']} 条无法确定归属或不能精确匹配的后续补丁原文。
- `manifest.json`：每份快照的来源索引、应用过的补丁、待核对事件及统计。

## 使用范围

响应里的 path 只有文件名，缺少原目录。同名新增记录分别保存，文件名中的 `__eNNNNNN` 是从零开始的修改条目索引，不能当成原目录或直接合并覆盖。

`latest/` 是可确认回放后的版本，不保证就是原项目最终版。请检查 manifest 的 `unresolved_patch_candidates`；为非空的快照保留了待核对记录。没有新增基础的 {summary['patches_without_created_base']} 条修改只在清单中记录，未伪造文件。

共有 {summary['applied_patches_with_omitted_final_context']} 条已应用补丁存在响应省略最后一行共同上下文的现象：脚本只匹配并替换实际给出的行，保留未展示的原内容，不猜测缺失行。

原响应可能已裁去文件末尾换行；脚本保留能从新增 diff 得到的文本，不补猜原始 EOF 换行。所有文件用 UTF-8 写出。脚本不会导入或执行还原出的代码，也不会改动输入 JSON 或已有目录。
"""
    (output / "README.md").write_bytes(readme.encode("utf-8"))
    # Check physical writes, encoding and the untouched creation snapshots.
    for track in tracks:
        assert (output / "initial" / track.filename).read_bytes() == track.initial.text.encode("utf-8")
        assert (output / "latest" / track.filename).read_bytes() == track.current_text().encode("utf-8")
    for event in events:
        if "patch_file" in event:
            assert (output / event["patch_file"]).read_bytes() == event["raw_diff"].encode("utf-8")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path(__file__).with_name("response.json"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--dry-run", action="store_true", help="Analyze without writing any files")
    args = parser.parse_args(argv)
    input_path = args.input.resolve(strict=True)
    output = (args.output or input_path.parent / "restored-added-files").resolve()
    data = json.loads(input_path.read_text(encoding="utf-8-sig"))
    tracks, events, summary = recover(data)
    if not args.dry_run:
        export(input_path, output, data, tracks, events, summary)
    print(json.dumps({"dry_run": args.dry_run, "output": str(output), **summary},
                     ensure_ascii=True, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError) as error:
        print(f"Recovery failed: {error}", file=sys.stderr)
        raise SystemExit(1)
