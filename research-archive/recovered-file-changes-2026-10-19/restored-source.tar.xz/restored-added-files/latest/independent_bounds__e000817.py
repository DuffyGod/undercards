"""Small complete reply enumeration, with no imports from the game engine.

One observed enemy and one paid threat; no income/draw/second turn. This
enumerates face, combat, optional silence-kill and ordering independently.
The saved full engine's search, PV and objective are not read as premises.
"""
from dataclasses import dataclass, replace
from functools import lru_cache
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()


@dataclass(frozen=True)
class State:
    hero: int
    own_attack: int
    own_hp: int
    dust: bool
    enemy_attack: int
    enemy_hp: int
    armor: bool
    dodge: int
    ready: bool
    headshot: bool
    own_armor: bool = False
    damaged_bonus: int = 0
    own_max_hp: int = 0
    enemy_cash: int = 0
    held: bool = True
    gems: int = 0
    native_spell: int = 0


def attack(s):
    return s.own_attack + (s.damaged_bonus if 0 < s.own_hp < s.own_max_hp else 0)


def packet(s, damage):
    if s.enemy_hp <= 0: return s
    if s.dodge: return replace(s, dodge=s.dodge-1)
    return replace(s, enemy_hp=max(0, s.enemy_hp-max(0, damage-int(s.armor))))


@lru_cache(None)
def endpoints(s):
    if s.hero <= 0: return (s,)
    out = {s}  # enemy may finish its turn without using cards or attacking
    if s.enemy_hp > 0 and s.ready:
        out.update(endpoints(replace(s, hero=max(0, s.hero-s.enemy_attack), ready=False)))
        if s.own_hp > 0:
            child = packet(replace(s, own_hp=max(0, s.own_hp-max(0,s.enemy_attack-int(s.own_armor))), ready=False), attack(s))
            if child.own_hp == 0 and s.dust:
                child = packet(replace(child, dust=False), s.own_attack)
            out.update(endpoints(child))
    if s.headshot and s.enemy_cash>=6:
        if s.own_hp > 0:
            out.update(endpoints(replace(s, own_hp=0, dust=False, headshot=False,enemy_cash=s.enemy_cash-6)))
        if s.enemy_hp > 0:
            out.update(endpoints(replace(s, enemy_hp=0, armor=False, dodge=0, headshot=False,enemy_cash=s.enemy_cash-6)))
    if s.gems and s.enemy_cash>=1:
        spent=replace(s,gems=s.gems-1,enemy_cash=s.enemy_cash-1)
        out.update(endpoints(replace(spent,hero=max(0,s.hero-1))))
        if s.own_hp>0:
            hit=replace(spent,own_hp=max(0,s.own_hp-max(0,1-int(s.own_armor))))
            if hit.own_hp==0 and s.dust:hit=packet(replace(hit,dust=False),s.own_attack)
            out.update(endpoints(hit))
        if s.enemy_hp>0:out.update(endpoints(packet(spent,1)))
        # Damage to the caster's30HP hero cannot be lethal here and changes
        # none of these predicates/callbacks. Spending with no relevant effect
        # has this exact same projection, so include that option as well.
        out.update(endpoints(spent))
    if s.native_spell:
        cost={76:3,79:1,81:0,96:3}[s.native_spell]
        if s.enemy_cash>=cost:
            spent=replace(s,native_spell=0,enemy_cash=s.enemy_cash-cost)
            if s.native_spell==76:
                out.update(endpoints(replace(spent,enemy_attack=s.enemy_attack+1,enemy_hp=s.enemy_hp+1)
                    if s.enemy_hp>0 else spent))
            elif s.native_spell==79:
                if s.own_hp>0:out.update(endpoints(replace(spent,dust=False,own_armor=False,damaged_bonus=0)))
                if s.enemy_hp>0:out.update(endpoints(spent))
            elif s.native_spell==81:
                # Both gain1; no other enemy spell, and the only held own fee
                # already fits10 cash. Cash still changes exactly on this side.
                out.update(endpoints(replace(spent,enemy_cash=spent.enemy_cash+1)))
            elif s.own_hp>0:
                hit=replace(spent,own_hp=max(0,s.own_hp-max(0,4-int(s.own_armor))))
                if hit.own_hp==0 and s.dust:hit=packet(replace(hit,dust=False),s.own_attack)
                out.update(endpoints(hit))
    return tuple(out)


def solve(raw, card, body_attack=4, body_health=1):
    scene = raw['input']; enemy = scene['enemy_bodies'][0]; cid = card['id']
    assert cid in (110,270,443,8,20,292,534)
    headshot = 100 in scene['opponent_hand_ids']
    assert scene['opponent_hand_ids'] in ([],[100],[76],[79],[81],[96],[79,598],[598,79]) or set(scene['opponent_hand_ids'])=={598}
    held = State(scene['own_player_hp'],0,0,False,enemy['attack'],enemy['health'],
        enemy.get('armor',False),enemy.get('dodge',0),True,headshot,enemy_cash=scene['opponent_gold_before_response'],
        gems=scene['opponent_hand_ids'].count(598),
        native_spell=next((i for i in scene['opponent_hand_ids'] if i in (76,79,81,96)),0))
    def own_trade(s):
        child=packet(replace(s,own_hp=max(0,s.own_hp-max(0,s.enemy_attack-int(s.own_armor)))),attack(s))
        if child.own_hp==0 and s.dust:child=packet(replace(child,dust=False),s.own_attack)
        return child
    def own_actions(s):
        actions=[s]
        if s.hero<=0:return actions
        if not s.held:
            if s.own_hp>0 and s.enemy_hp>0:actions.append(own_trade(s))
            return actions
        # With one physical card and initial10 cash, holding retains its full
        # fee; no income, draw or other expenditure is needed to deploy later.
        if s.enemy_hp<=0:return actions  # already clear, no heal in these cards
        deployed=replace(s,own_attack=card['attack'],own_hp=card['health'],held=False,
            dust=cid==110 and not scene.get('hand_silenced',[False])[0],
            own_armor=cid==534,damaged_bonus=3 if cid==534 else 0,own_max_hp=card['health'])
        if cid==443:
            cost=enemy['current_card_cost']
            assert cost==enemy['base_cost']=={270:3,14:5}[enemy['card_id']]
            deployed=packet(deployed,4+cost//3);actions.append(deployed)
            if deployed.enemy_hp>0:actions.append(own_trade(deployed))
        elif cid==8:
            actions.append(replace(deployed,enemy_attack=1,own_hp=card['health']+max(0,s.enemy_attack-1)))
        elif cid==20:
            # Face2 cannot win against30; body trade arithmetic is unchanged.
            actions.extend([deployed,packet(deployed,2)])
        elif cid==292:actions.append(replace(deployed,own_hp=card['health']-5))
        elif cid==534:actions.extend([deployed,own_trade(deployed)])
        else:actions.append(deployed)
        return actions
    actions=own_actions(held)
    def goal(state, name):
        alive=state.hero>0
        clear=state.enemy_hp<=0
        body=state.own_hp>=body_health and state.own_hp>0 and attack(state)>=body_attack
        return alive and {'clear':clear,'focal4_1':body,'clear_or_focal4_1':clear or body}[name]
    result={}
    horizon=scene['horizon']
    def first_reply_value(s,name):
        def leaf(t):return (t.hero,) if name=='hp' else (int(goal(t,name)),t.hero)
        if s.hero<=0 or horizon=='enemy_attack':return leaf(s)
        if horizon=='next_own_attack':return max(leaf(t) for t in own_actions(s))
        assert horizon=='next_enemy_attack'
        return max(min(leaf(u) for u in endpoints(replace(t,ready=True,
            enemy_cash=t.enemy_cash+scene['next_opponent_gold_income']))) for t in own_actions(s))
    for name in ('hp','clear','focal4_1','clear_or_focal4_1'):
        vector=max(min(first_reply_value(s,name) for s in endpoints(a)) for a in actions)
        if name=='hp':
            hp=vector[0]
            result[name]=dict(hp=hp,feasible=hp>0)
        else:
            success,hp=vector
            result[name]=dict(hp=hp if success else None,feasible=bool(success))
    return result


def main():
    source={c['id']:c for c in json.loads((HERE/'native-snapshot.json').read_text())['cards']}
    assert (source[14]['cost'],source[14]['attack'],source[14]['health'])==(5,4,5)
    assert (source[110]['attack'],source[110]['health'],source[110]['effect_readable']) == \
        (13,1,'Dust: Deal its ATK as DMG to all enemy monsters.')
    assert source[270]['effect_readable']==''
    assert source[100]['cost']==6 and source[100]['effect_readable']=='Silence and kill a monster.'
    assert source[598]['cost']==1 and source[598]['effect_readable']=='Deal 1 DMG.'
    for cid,cost,text in [(76,3,'Give all ally monsters ATK +1/HP +1.'),(79,1,'Silence a monster.'),
            (81,0,'Both players earn 1 GOLD.'),(96,3,'Deal 4 DMG to an enemy monster.')]:
        assert source[cid]['cost']==cost and source[cid]['effect_readable']==text
    assert source[443]['effect_readable']=='Haste. Magic: Deal 4 DMG to a monster. Deal 1 extra DMG for every 3 GOLD it costs.'
    assert source[8]['effect_readable']=="Magic: Set an enemy monster's ATK to 1 and gain HP equal to the amount of ATK decreased."
    assert source[20]['effect_readable']=='Magic: Deal DMG 2.'
    assert source[292]['effect_readable']=='Magic: Deal 5 DMG to this.'
    assert source[534]['effect_readable']=='Armor. Haste. This has +3 ATK while damaged.'
    index=json.loads((HERE/'index.json').read_text());checks=[]
    for row in index['rows']:
        if row['context'].startswith('card') and row['card_id'] not in (110,270,443,8,20,292,534): continue
        path=HERE/row['artifact'];raw=json.loads(path.read_text());expected=solve(raw,source[row['card_id']])
        for name,bound in expected.items():
            actual=row['scores'][name]
            assert actual['known'] and actual['guaranteed_player_hp']==bound['hp'] and actual['feasible']==bound['feasible'], (row['context'],name,bound,actual)
            checks.append(dict(context=row['context'],task=name,**bound,raw_sha256=sha(path)))
    reference=HERE/'generated-thrashing-reference.json'
    if reference.exists():
        raw=json.loads(reference.read_text());expected=solve(raw,source[270])
        for name,bound in expected.items():
            actual=raw['results'][name]
            assert actual['known'] and actual['guaranteed_player_hp']==bound['hp'] and actual['feasible']==bound['feasible']
            checks.append(dict(context='generated-thrashing-reference',task=name,**bound,raw_sha256=sha(reference)))
    horizon_path=HERE/'horizon-transfer.json'
    horizon_checks=[]
    if horizon_path.exists():
        for row in json.loads(horizon_path.read_text())['rows']:
            path=HERE/row['artifact'];raw=json.loads(path.read_text());expected=solve(raw,source[row['card_id']])
            for name,actual in row['scores'].items():
                bound=expected[name]
                assert actual['known'] and actual['guaranteed_player_hp']==bound['hp'] and actual['feasible']==bound['feasible'],(row,name,bound)
                horizon_checks.append(dict(card_id=row['card_id'],horizon=row['horizon'],reply=row['reply'],task=name,**bound,raw_sha256=sha(path)))
    frontier_path=HERE/'resistance-frontier.json';frontier_checks=[]
    if frontier_path.exists():
        for row in json.loads(frontier_path.read_text())['rows']:
            path=HERE/row['artifact'];raw=json.loads(path.read_text())
            bound=solve(raw,source[row['card_id']],row['body_attack'],row['body_health'])['clear_or_focal4_1']
            assert row['known'] and row['hp']==bound['hp'] and row['feasible']==bound['feasible'],(row,bound)
            frontier_checks.append(dict(card_id=row['card_id'],reply=row['reply'],body_attack=row['body_attack'],
                body_health=row['body_health'],**bound,raw_sha256=sha(path)))
    answer_path=HERE/'native-spell-answers.json';answer_checks=[];unknown_answers=[]
    if answer_path.exists():
        for row in json.loads(answer_path.read_text())['rows']:
            path=HERE/row['artifact'];raw=json.loads(path.read_text())
            if any(not v['known'] for v in row['scores'].values()):
                # Toriel's changed ATK/maxHP under nonlethal Silence has no
                # verified reset rule. Do not silently assume a reset here.
                assert row['card_id']==8 and row['spell_id']==79 and row['affordable']
                unknown_answers.append(dict(card_id=8,spell_id=79,raw_sha256=sha(path)))
                continue
            expected=solve(raw,source[row['card_id']])
            for name,actual in row['scores'].items():
                bound=expected[name]
                assert actual['guaranteed_player_hp']==bound['hp'] and actual['feasible']==bound['feasible'],(row,name,bound)
                answer_checks.append(dict(card_id=row['card_id'],spell_id=row['spell_id'],enemy_cash=row['enemy_cash'],
                    task=name,**bound,raw_sha256=sha(path)))
    combo_path=HERE/'combo-answers.json';combo_checks=[];combo_unknown=[]
    if combo_path.exists():
        for row in json.loads(combo_path.read_text())['rows']:
            path=HERE/row['artifact'];raw=json.loads(path.read_text())
            if any(not v['known'] for v in row['scores'].values()):
                assert row['card_id']==8
                combo_unknown.append(dict(card_id=8,enemy_cash=row['enemy_cash'],raw_sha256=sha(path)))
                continue
            expected=solve(raw,source[row['card_id']])
            for name,actual in row['scores'].items():
                bound=expected[name]
                assert actual['guaranteed_player_hp']==bound['hp'] and actual['feasible']==bound['feasible'],(row,name,bound)
                combo_checks.append(dict(card_id=row['card_id'],enemy_cash=row['enemy_cash'],hand_ids=row['hand_ids'],
                    task=name,**bound,raw_sha256=sha(path)))
    report=dict(passed=True,imports_production_model=False,matching_cells=len(checks),checks=checks,
        horizon_matching_cells=len(horizon_checks),horizon_checks=horizon_checks,
        frontier_matching_cells=len(frontier_checks),frontier_checks=frontier_checks,
        native_spell_matching_cells=len(answer_checks),native_spell_checks=answer_checks,
        native_spell_unknown_contexts=unknown_answers,
        combo_matching_cells=len(combo_checks),combo_checks=combo_checks,combo_unknown_contexts=combo_unknown,
        reply_states=endpoints.cache_info().currsize,builder_sha256=sha(Path(__file__)),
        source_snapshot_sha256=sha(HERE/'native-snapshot.json'),
        packet_thresholds=dict(unprotected=13+13,armor=12+12,one_dodge=0+13),
        scope='Exact one-enemy independent reply enumeration for seven mechanisms, eleven counterfactuals and six cards across deadlines/reply payment. Not independent validation of all78 compiled candidates.')
    (HERE/'independent-bounds.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(passed=True,cells=len(checks),horizon_cells=len(horizon_checks),frontier_cells=len(frontier_checks),
        native_spell_cells=len(answer_checks),combo_cells=len(combo_checks),states=endpoints.cache_info().currsize)))


if __name__=='__main__': main()