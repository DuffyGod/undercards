"""Decision counterexamples for one policy with acceptable alternative outcomes."""
import copy
from dataclasses import replace
import unittest
from unittest.mock import patch

import alternative_goal_score as alt
import conditional_card_score as score


def scene(cid=110, **changes):
    by = {c['id']: c for c in score.score_cards.load_cards()}
    data = dict(hand_ids=[cid], hand_costs=[by[cid]['cost']], hand_base_costs=[by[cid]['cost']],
        gold_before_play=10, own_player_hp=15, own_player_max_hp=30, enemy_player_hp=30, enemy_player_max_hp=30,
        own_deck_ids=[], opponent_deck_ids=[], opponent_hand_ids=[], opponent_hand_known=True,
        opponent_gold_before_response=0, max_plays='all_physical', horizon='enemy_attack', node_limit=20000,
        physical_slots=True, front_slot_map=[0, 1, 2, 3], front_missing_policy='fizzle',
        enemy_bodies=[dict(card_id=270, attack=4, health=5, max_health=5,
            current_card_cost=3, base_cost=3, silenced=True, slot=1)])
    return dict(data, **changes)


def task():
    return dict(kind='any', clauses=[dict(constraints=dict(max_enemy_living_count=0)),
        dict(body_scope='focal', constraints=dict(min_own_body_attack=4, min_own_body_health=1))])


class AlternativeGoalTests(unittest.TestCase):
    def test_neither_arm_guaranteed_but_one_policy_guarantees_union(self):
        data = scene()
        for clause in task()['clauses']:
            value = score.task_score(data, dict(kind='joint', **clause), focal_index=0)
            self.assertTrue(value['known']); self.assertFalse(value['feasible'])
        result = alt.evaluate(data, task(), focal_index=0)
        self.assertTrue(result['known']); self.assertTrue(result['feasible'])
        self.assertEqual(result['guaranteed_player_hp'], 11)
        self.assertFalse(result['each_clause_individually_guaranteed'])

    def test_equal_pure_hp_can_have_different_punishment_resistance(self):
        data = scene(270)
        self.assertEqual(score.task_score(data, dict(kind='hp'))['guaranteed_player_hp'], 11)
        value = alt.evaluate(data, task(), focal_index=0)
        self.assertTrue(value['known']); self.assertFalse(value['feasible'])
        self.assertIsNone(value['guaranteed_player_hp'])

    def test_real_silence_kill_payment_threshold(self):
        for cash, feasible in ((5, True), (6, False)):
            result = alt.evaluate(scene(opponent_hand_ids=[100], opponent_hand_costs=[6],
                opponent_hand_base_costs=[6], opponent_gold_before_response=cash), task(), focal_index=0)
            self.assertTrue(result['known']); self.assertEqual(result['feasible'], feasible)

    def test_two_damage_packets_have_exact_hp_threshold(self):
        for health, feasible in ((26, True), (27, False)):
            data = scene(); data['enemy_bodies'][0].update(health=health, max_health=health)
            result = alt.evaluate(data, task(), focal_index=0)
            self.assertTrue(result['known']); self.assertEqual(result['feasible'], feasible)

    def test_armor_and_dodge_change_packet_thresholds(self):
        for status, low in [('armor', 24), ('dodge', 13)]:
            for health in (low, low + 1):
                data = scene(); data['enemy_bodies'][0].update(health=health, max_health=health,
                    **{status: True if status == 'armor' else 1})
                result = alt.evaluate(data, task(), focal_index=0)
                self.assertTrue(result['known']); self.assertEqual(result['feasible'], health == low)

    def test_alpha_beta_exhaustive_full_vector_agree(self):
        a = alt.evaluate(scene(), task(), focal_index=0)
        b = alt.evaluate(scene(search_algorithm='exhaustive'), task(), focal_index=0)
        self.assertEqual(tuple(a['search']['objective_vector']), tuple(b['search']['objective_vector']))

    def test_budget_unknown_and_death_are_not_infeasible_score_zero(self):
        value = alt.evaluate(scene(node_limit=1), task(), focal_index=0)
        self.assertFalse(value['known']); self.assertIsNone(value['feasible'])
        self.assertIsNone(value['guaranteed_player_hp'])
        value = alt.evaluate(scene(own_player_hp=1), task(), focal_index=0)
        self.assertTrue(value['known']); self.assertFalse(value['feasible'])
        self.assertIsNone(value['guaranteed_player_hp'])

    def test_same_body_and_focal_identity_cannot_be_stitched(self):
        data = scene(gold_before_play=0, ally_bodies_before_play=[
            dict(card_id=270, attack=9, health=1, max_health=1, slot=0, ready=False),
            dict(card_id=270, attack=3, health=9, max_health=9, slot=2, ready=False)])
        goal = task(); goal['clauses'][1] = dict(body_scope='board',
            constraints=dict(min_own_body_attack=4, min_own_body_health=8))
        value = alt.evaluate(data, goal, focal_index=0)
        self.assertTrue(value['known']); self.assertFalse(value['feasible'])
        value = alt.evaluate(data, task(), focal_index=0)
        self.assertTrue(value['known']); self.assertFalse(value['feasible'])

    def test_focal_and_lineage_are_distinct_at_predicate(self):
        engine = alt.PhysicalAlternativeSearch(score.score_cards.load_cards(), scene(),
            clauses=alt.normalize(task()), focal_index=0)
        root = engine.root()
        deployed = next(child for action, child in engine.deploys(root) if action['kind'] == 'deploy')
        unit = next(u for u in deployed.own if u.key == 'hand:0')
        descendant = replace(deployed, own=(replace(unit, key='hand:0:dust:0'),))
        bounds = (('min_own_body_attack', 4), ('min_own_body_health', 1))
        self.assertFalse(engine.clause_satisfied(descendant, ('focal', bounds)))
        self.assertTrue(engine.clause_satisfied(descendant, ('lineage', bounds)))

    def test_unknown_mechanic_cannot_be_hidden_by_easy_clause(self):
        data = scene(27)
        value = alt.evaluate(data, dict(kind='any', clauses=[
            dict(constraints=dict(min_own_player_hp=1)), dict(constraints=dict(max_enemy_living_count=0))]))
        self.assertFalse(value['known'])

    def test_input_and_load_guards(self):
        cases = [dict(kind='any', clauses=[]), dict(kind='any', clauses=[{}]),
            dict(kind='any', clauses=[dict(constraints={}), task()['clauses'][0]]),
            dict(kind='any', clauses=[dict(constraints=dict(min_own_player_hp=True)), task()['clauses'][0]])]
        for bad in cases:
            with self.assertRaises(ValueError): alt.evaluate(scene(), bad, focal_index=0)
        with self.assertRaises(ValueError): alt.evaluate(scene(), task())
        with self.assertRaises(ValueError): alt.evaluate(scene(), task(), focal_index=True)
        with patch.object(alt, 'LOADED_SOURCES', {}):
            with self.assertRaises(RuntimeError): alt.evaluate(scene(), task(), focal_index=0)


if __name__ == '__main__':
    unittest.main()