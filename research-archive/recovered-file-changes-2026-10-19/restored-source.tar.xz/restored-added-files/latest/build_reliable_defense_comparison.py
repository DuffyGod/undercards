"""Deliver conditional winners and exact budget thresholds, not body volume."""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path

import certify_low_fee_rescue as certificate
import evaluate_situation
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/reliable-defense-v01'


def hand_scene():
    return dict(hand_ids=[1,1,990,438,108,96,598], own_player_hp=3, own_player_max_hp=30,
        enemy_player_hp=30, max_plays=3, ally_bodies_before_play=[],
        enemy_bodies=[dict(card_id=15,attack=6,health=5),dict(card_id=2,attack=2,health=3)],
        opponent_hand_ids=[96],opponent_gold_before_response=3,
        condition_known_state={'last_turn_gold_spent_on_spells':1},horizon='enemy_attack',
        objectives=['survive','purpose'],purpose_constraints={'min_own_player_hp':3,'max_enemy_living_count':0},
        own_deck_ids=[],own_fatigue_next=1,next_natural_draw_count=0)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    cards=score_cards.load_cards()
    certificates=[]
    for panel in certificate.PANELS:
        result=certificate.certify(panel,cards=cards)
        (OUT/(panel+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        certificates.append(dict(panel=panel,buckets=result['buckets'],minimum_payment=result['certified_minimum_monster_payment_for_survival']))
    thresholds=[]
    interventions=[('need_true',True,5,0),('need_false',False,5,0),
                   ('enemy_health_plus_one',True,6,0),('attack_plus_one_recovers_threshold',True,6,1)]
    for name,need,health,attack in interventions:
        current=copy.deepcopy(cards)
        if attack: next(c for c in current if c['id']==438)['attack']+=attack
        data=hand_scene()
        data['enemy_bodies'][0]['health']=health
        data['enemy_bodies'][0]['max_health']=health
        data['condition_known_state']['last_turn_gold_spent_on_spells']=int(need)
        rows=[]
        for gold in range(9):
            actual=dict(data,gold_before_play=gold)
            result=paid.evaluate(actual,current)
            if not result['complete_in_declared_scope']: raise AssertionError(result['unknown'])
            rows.append(dict(gold=gold,input=actual,result=result))
        intact=next((r['gold'] for r in rows if r['result']['objectives'][0]['metrics']['own_player_hp']==3),None)
        cleared=next((r['gold'] for r in rows if r['result']['objectives'][1]['purpose_guaranteed']),None)
        expected=7 if (need and health<=5+attack) else 8
        if intact!=3 or cleared!=expected: raise AssertionError((name,intact,cleared,expected))
        record=dict(intervention=name,input_scope=data,joint_goal_directly_minimized=True,min_gold_for_intact_hp=intact,
                    min_gold_for_intact_hp_and_cleared_board=cleared,rows=rows)
        (OUT/(name+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
        thresholds.append({k:v for k,v in record.items() if k!='rows'})
        print(json.dumps(dict(intervention=name,min_intact=intact,min_clear=cleared)),flush=True)
    # Freeze before/after evidence rather than overwrite the independent failure
    # capture. Previous-silence probe now supplies the newly expressible fact.
    previous=json.loads((HERE/'experiments/board-standard-v01/paid-review-probes-v2.json').read_text())
    corrections=[]
    for probe in previous['probes']:
        data=copy.deepcopy(probe['input'])
        if probe['id']=='previous_silence_not_representable':
            data['ally_bodies_before_play'][0]['silenced']=True
        result=paid.evaluate(data,cards)
        corrections.append(dict(id=probe['id'],before_source_hashes=previous['source_hashes'],
            before=probe['actual'],corrected_input=data,after=result))
    (OUT/'independent-counterexamples-before-after.json').write_text(json.dumps(corrections,ensure_ascii=False,indent=2)+'\n')
    direct=dict(hand_scene(),gold_before_play=7)
    current={k:copy.deepcopy(direct[k]) for k in ('hand_ids','gold_before_play','own_player_hp',
        'enemy_player_hp','ally_bodies_before_play','enemy_bodies','opponent_gold_before_response')}
    current.update(role='midrange',own_turn=5,condition_state=direct['condition_known_state'],
        callback_state={'own_player_max_hp':30},response_weights={'enemy_face':1},
        paid_board_scenario={k:direct[k] for k in ('max_plays','horizon','objectives',
            'opponent_hand_ids','own_deck_ids','own_fatigue_next','next_natural_draw_count','purpose_constraints')})
    api=evaluate_situation.evaluate(current,cards=cards)
    direct_result=paid.evaluate(direct,cards)
    normalize=lambda x:json.loads(json.dumps(x))
    if normalize(api['paid_board_tactics'])!=normalize(direct_result): raise AssertionError('Public API differs from standalone search')
    (OUT/'current.input.json').write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n')
    (OUT/'current.result.json').write_text(json.dumps(api,ensure_ascii=False,indent=2)+'\n')
    record=dict(snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        source_hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in
            ('board_tactics.py','paid_board_tactics.py','certify_low_fee_rescue.py','build_reliable_defense_comparison.py','evaluate_situation.py')},
        full_low_fee_certificates=certificates,known_hand_budget_thresholds=thresholds,
        api_matches_standalone=True,
        scope='0/1G complete-pool source bounds; higher-cost thresholds concern one complete declared hand, never whole-pool champions.')
    (OUT/'manifest.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(output=str(OUT),api_matches_standalone=True)),flush=True)


if __name__=='__main__':main()