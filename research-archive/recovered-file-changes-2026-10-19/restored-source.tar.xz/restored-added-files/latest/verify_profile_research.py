"""Reproduce new local evidence; do not repeat unchanged tactical regression."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import card_profile_queue as q
import card_profile_catalog as catalog
import profile_comparisons as comparison
import verify_research_integration as previous

HERE=Path(__file__).resolve().parent
OUT=HERE/'research-runs/card-profiles-v01'


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    checks=[]
    commands=[['profile_comparisons.py'],['research-runs/card-profiles-v01/high_cost_probe.py'],
        ['research-runs/card-profiles-v01/basic_body_comparisons.py'],
        ['research-runs/card-profiles-v01/basic_penalty_sequences.py'],
        ['research-runs/card-profiles-v01/build_high_cost_expansion.py'],
        ['research-runs/card-profiles-v01/build_mid_cost_expansion.py'],
        ['research-runs/card-profiles-v01/build_low_cost_expansion.py']]
    for argv in commands:
        if not (HERE/argv[0]).exists():continue
        r=subprocess.run([sys.executable,*argv],cwd=HERE,capture_output=True,text=True)
        checks.append(dict(command=argv,exit_code=r.returncode,output=(r.stdout+r.stderr)[-5000:],source_sha256=digest(HERE/argv[0])))
        if r.returncode:raise RuntimeError(checks[-1])
    cov=catalog.build();assert cov['source_bound']==cov['llm_source_question_candidates']==671
    d=catalog.read('catalog.json')
    for row in d['profiles'].values():
        assert row['global_rating'] is None and row['empirical_frequency'] is None
        for candidate in row['mechanism_candidates']:
            assert candidate['profile']['printed_effect']==row['card']['effect_readable']
    checks.append(dict(check='all671 exact source + no invented Gold/frequency',passed=True))
    source={c['id']:c for c in catalog.score_cards.load_cards()}
    for name in ('low-cost-expansion.json','mid-cost-expansion.json','high-cost-expansion.json'):
        doc=catalog.read(name)
        for r in doc['profiles']:
            assert r['card']==source[r['card_id']]
            alt=r['same_cost_alternative'];aid=alt['card_id']
            assert source[aid]['cost']==r['card']['cost']
            if 'card' in alt:assert alt['card']==source[aid]
            if 'effect' in alt:assert alt['effect']==source[aid]['effect_readable']
            for dep in r.get('dependencies',[]):
                if isinstance(dep,dict) and 'id' in dep:assert dep==source[dep['id']]
        checks.append(dict(check=name+' source/fullcard+same-cost alternatives',cards=len(doc['profiles']),passed=True))
    low=catalog.read('low-cost-expansion.json')
    old=catalog.read('low-before-main-review/low-cost-verification.json')
    refreshed=dict(old,builder_sha256=digest(OUT/'build_low_cost_expansion.py'),
        main_revalidation='Current source,20same-cost alternatives and executed probes rechecked; old source receipt retained under low-before-main-review.',
        current_report_sha256=digest(OUT/'low-cost-expansion.json'))
    (OUT/'low-cost-verification.json').write_text(json.dumps(refreshed,ensure_ascii=False,indent=2)+'\n')
    state=json.loads((OUT/'example-scenario.json').read_text())
    cmd=[sys.executable,'profile_comparisons.py','--scenario','research-runs/card-profiles-v01/example-scenario.json']
    process=subprocess.run(cmd,cwd=HERE,capture_output=True,text=True);assert process.returncode==0
    standalone=comparison.evaluate(state['enemy'],state['cash']);assert json.loads(process.stdout)==standalone
    assert [r['max_immediate_kills'] for r in standalone['purpose_summaries']]==[4,4,3]
    bad_inputs=[([{'card_id':1,'attack':0,'health':4}],13),([{'attack':3,'health':3,'armor':True}],13),
        ([{'attack':1,'health':0}],13),([{'attack':1,'health':1}]*5,13),([],True)]
    for enemy,cash in bad_inputs:
        try:comparison.evaluate(enemy,cash)
        except ValueError:continue
        raise AssertionError('unsupported input not rejected')
    checks.append(dict(check='public CLI=standalone,4Rock4/4/3,5scope rejections',passed=True))
    assert catalog.break_even(3,2)==.4 and catalog.break_even(1,0)==0
    try:catalog.break_even(0,0)
    except ValueError:pass
    else:raise AssertionError('undefined threshold accepted')
    # A source self-reference is legal; a fabricated ID is not. This matters
    # for Loop/source-copy families, not just a synthetic validator fixture.
    m=json.loads((OUT/'deepseek-v05/manifest.json').read_text())
    task=next(t for t in m['tasks'] if 563 in t['requested_ids'])
    raw=json.loads((OUT/'deepseek-v05'/f"{task['id']}.json").read_text())['attempts'][0]['data']
    valid,errors=q.validate(raw,task);assert 563 in {r['card_id'] for r in valid}
    altered=json.loads(json.dumps(raw));row=next(r for r in altered['profiles'] if r['card_id']==563);row['references']=[999999]
    valid,errors=q.validate(altered,task);assert 563 not in {r['card_id'] for r in valid} and '563:reference ID' in errors
    checks.append(dict(check='source self-reference allowed; fabricated reference rejected; common-unit threshold algebra',passed=True))
    prior=json.loads((HERE/'experiments/current-integration-verification.json').read_text())['runs']
    tested=next(r for r in reversed(prior) if r.get('tests_executed') and r.get('passed'))
    current=previous.regression_sources();differences=[k for k in current if current[k]!=tested['source_hashes'].get(k)]
    core_differences=[k for k in differences if k!='verify_research_integration.py']
    assert tested['passed'] and not core_differences
    prior_audit=previous.audit();assert prior_audit['all_bound_sources_current']
    report=dict(version='card-profile-research-verification-0.1.0',finished_at_utc=datetime.now(timezone.utc).isoformat(),
        verification_source_sha256=digest(__file__),checks=checks,coverage=cov,
        prior_core=dict(test_count=tested['test_count'],passed=tested['passed'],fresh_regression_executed=False,
            current_recursive_source_files=len(current),core_differences_since_test=core_differences,
            historical_runner_only_difference=differences,
            note='Profile-local checks compared with latest passed tactical regression sources. Historical379/395-run receipts are retained; paid0.21 added dynamic-state mechanisms and has its own417-test regression.'),
        old_active_artifact_audit=dict(count=len(prior_audit['artifacts']),errors=prior_audit['errors']),
        source_bindings={n:digest(OUT/n) for n in ('catalog.json','coverage.json','conditional-comparison.json',
            'basic-body-comparison.json','basic-penalty-sequences.json','high-cost-review.json','mid-cost-expansion.json') if (OUT/n).exists()},
        interpretation='Local arithmetic/identity/protocol evidence only. No full game or server verification, no calibrated Gold.',passed=True)
    (OUT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(passed=True,coverage=cov,core_matches_latest_passed_regression=True,active_reports_bound=len(prior_audit['artifacts'])),ensure_ascii=False))


if __name__=='__main__':main()