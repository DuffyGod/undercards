"""Cheap negative clear-goal certificate, never a scalar card valuation.

Enumerate every current own action, then fix one legal opponent strategy:
stop attacking and casting. In the next own attack phase, each eligible unit
can deal at most its ATK once. With no live extra damage/death/end callbacks,
insufficient total damage proves a remaining enemy. This one counterstrategy
can disprove a universal clear guarantee without searching every reply.
"""
import hashlib
from pathlib import Path
import paid_board_tactics as paid
import score_cards
import board_tactics as board


def prove(data,cards=None):
    cards=score_cards.load_cards() if cards is None else cards
    engine=paid.PaidSearch(cards,data);root=engine.root()
    if engine.horizon!='next_own_attack':raise ValueError('Next own attack horizon required')
    if engine.next_max_plays:
        return dict(bound_complete=False, unknown=['No-future-Play certificate cannot cover future own payment/actions'], any_policy_can_guarantee_clear=None)
    if engine.unknown or any(spec['unknown'] for _,spec in engine.hand+engine.enemy_hand):
        return dict(bound_complete=False,unknown=['Source mechanics for this counterstrategy remain unclosed'])
    seen=set();leaves=[];unknown=[]
    def visit(state):
        if state in seen:return
        seen.add(state)
        if len(seen)>engine.node_limit:raise paid.UnknownMechanic('Current-action certificate state budget exhausted')
        if engine.terminal(state):
            if state.own_hp<=0:return
            raise paid.UnknownMechanic('Current action already ends game; attack-budget certificate does not apply')
        reply=engine.boundary(state)
        endpoint=engine.boundary(reply)  # One legal response: no cast, no attack.
        if endpoint.phase!=2 or engine.terminal(endpoint):
            raise paid.UnknownMechanic('Counterstrategy does not reach a live next own attack phase')
        living=[u for u in endpoint.own if u.health>0]
        if any(u.dust or u.end or u.before_attack_face for u in living):
            raise paid.UnknownMechanic('Live future callback can invalidate the simple attack-damage bound')
        if any(u.damaged_attack_bonus for u in living):
            raise paid.UnknownMechanic('Damaged ATK can increase inside future combat/events; simple damage bound is unverified')
        attack=sum(board.effective_attack(u,endpoint,'own') for u in living if u.ready and not u.attacked and not u.paralyze_owner_starts_remaining)
        health=sum(u.health for u in endpoint.enemy if u.health>0)
        if attack>=health:
            raise paid.UnknownMechanic('Attack budget cannot exclude a successful clear; this bound is insufficient')
        leaves.append(dict(eligible_attack_upper=attack,enemy_health_required=health))
        for _,child in list(engine.attacks(state))+list(engine.deploys(state)):visit(child)
    try:visit(root)
    except paid.UnknownMechanic as error:unknown.append(str(error))
    complete=not unknown and bool(leaves)
    here=Path(__file__).resolve().parent
    return dict(bound_complete=complete,unknown=unknown,
        any_policy_can_guarantee_clear=False if complete else None,
        counterstrategy='Enemy ends its turn without optional attacks or casts, for every current own route.',
        current_own_states=len(seen),checked_endpoints=len(leaves),
        max_eligible_attack_upper=max((x['eligible_attack_upper'] for x in leaves),default=None),
        min_enemy_health_required=min((x['enemy_health_required'] for x in leaves),default=None),
        endpoint_bounds=leaves,input=data,
        source_hashes={f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in
            ('prove_idle_reply_bound.py','paid_board_tactics.py','queued_delay.py','board_tactics.py')},
        limitations=['Negative sufficient bound for the declared no-future-Play attack window only.',
            'Insufficient bound or unknown mechanics yield unknown, never false guarantee or zero card value.',
            'No empirical response likelihood is assigned; one legal counterstrategy disproves a universal clear goal.'])


def extend_guaranteed_hp(data,current_record,cards=None):
    """Keep a searched HP bound when this future window cannot change HP."""
    cards=score_cards.load_cards() if cards is None else cards
    ignored={'horizon','next_natural_draw_count','objectives','node_limit'}
    comparable=lambda d:{k:v for k,v in d.items() if k not in ignored}
    result=current_record['result']
    if comparable(data)!=comparable(current_record['input']) or current_record['input']['horizon']!='enemy_attack':
        raise ValueError('Current record must search the same physical observations')
    if not result['complete_in_declared_scope']:return dict(hp_invariance_proved=False)
    engine=paid.PaidSearch(cards,data);root=engine.root()
    if engine.horizon!='next_own_attack':raise ValueError('Next own attack horizon required')
    if engine.next_max_plays:return dict(hp_invariance_proved=False)
    if any(spec['unknown'] or spec.get('start') or spec.get('end') or spec.get('dust') or spec.get('before_attack_face')
           or (spec.get('magic') and spec['magic'][0] in (*paid.DRAW_MAGIC_KINDS,'summon','summon_many')) for _,spec in engine.hand):
        return dict(hp_invariance_proved=False)
    if any(u.start or u.end or u.dust or u.before_attack_face for u in root.own+root.enemy):
        return dict(hp_invariance_proved=False)
    if engine.natural_draw:
        if root.own_deck is None or len(root.own_deck)<engine.natural_draw:return dict(hp_invariance_proved=False)
        if any(engine.hand[i][0]['effect_readable'].strip() for i in root.own_deck[:engine.natural_draw]):
            return dict(hp_invariance_proved=False)
    value=next(r['metrics']['own_player_hp'] for r in result['objectives'] if r['objective']=='guaranteed_hp')
    return dict(hp_invariance_proved=True,guaranteed_hp_at_next_own_attack=value,
        reason='No future own Play, live player-HP callbacks, draw fatigue or drawn-card effect; ordinary monster combat changes monster HP only.',
        full_future_vector_optimized=False)