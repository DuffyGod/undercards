import copy
import unittest
import action_outcomes as actions
import evaluate_situation as situation
import joint_window_quote as joint
import score_cards as base


def probe(hand,cash=10,hp=30,enemies=None):
    return dict(hand_ids=hand,role='midrange',own_turn=5,gold_before_play=cash,
        opponent_gold_before_response=0,own_player_hp=hp,enemy_player_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[] if enemies is None else enemies,
        condition_state={'last_turn_gold_spent_on_spells':0},response_weights={'enemy_face':1})


class IntegratedWindowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards=base.load_cards();cls.by_id={c['id']:c for c in cls.cards};cls.ref,_=base.make_reference(cls.cards)

    def test_two_play_rescue_requires_shared_cash_and_both_actions(self):
        data=probe([96,438],7,5,[dict(attack=6,health=6),dict(attack=3,health=3)])
        r=situation.evaluate(data,self.ref,self.cards)
        self.assertTrue(all(w['death_probability']==1 for w in r['action_windows']))
        best=r['deployment_routes']['best_known_survival_route']
        self.assertEqual(best['death_probability'],0)
        self.assertEqual(best['actual_paid_gold'],7)
        self.assertEqual(len(best['steps']),2)
        data['gold_before_play']=6
        x=situation.evaluate(data,self.ref,self.cards)
        self.assertEqual(x['deployment_routes']['best_known_survival_route']['death_probability'],1)

    def test_spell_and_monster_share_scale_but_real_cash_is_unscaled(self):
        r=situation.evaluate(probe([81,15]),self.ref,self.cards)
        spell,monster=r['finite_window_quotes']
        self.assertEqual(spell['scale'],monster['scale'])
        self.assertEqual(spell['model_gold'],1)

    def test_turn_end_precedes_reply_and_attack_disables_no_attack_effect(self):
        data=probe([509],10,5,[dict(attack=7,health=5)])
        data['callback_state']={'own_player_max_hp':30}
        ctx,_=situation.make_state(data)
        r=actions.evaluate(self.by_id[509],ctx,self.ref)
        self.assertTrue(r['window_known'])
        self.assertEqual(r['recommended_action'],'delay')
        wait=next(a for a in r['actions'] if a['action_id']=='delay')
        self.assertEqual(wait['paths'][0]['after_turn_end']['own_player_hp'],8)
        self.assertEqual(wait['death_probability'],0)
        attack=next(a for a in r['actions'] if a['current_action']=='attack_monster')
        self.assertEqual(attack['death_probability'],1)

    def test_random_callback_is_chance_and_never_selected_best_target(self):
        data=probe([197],10,5,[dict(attack=7,health=4),dict(attack=0,health=4)])
        data['callback_state']={'turn_end_random_target_weights':[dict(target_id=0,weight=.25),dict(target_id=1,weight=.75)]}
        ctx,_=situation.make_state(data)
        r=actions.evaluate(self.by_id[197],ctx,self.ref)
        delay=next(a for a in r['actions'] if a['action_id']=='delay')
        self.assertTrue(delay['outcome_known'])
        self.assertEqual(len(delay['paths']),2)
        self.assertAlmostEqual(sum(p['probability'] for p in delay['paths']),1)
        self.assertEqual(delay['death_probability'],.75)
        ctx['callback_state']={}
        missing=actions.evaluate(self.by_id[197],ctx,self.ref)
        self.assertFalse(missing['window_known'])
        self.assertIsNone(missing['recommended_action'])

    def test_cash_callback_is_not_scaled_as_body(self):
        data=probe([404]);data['response_weights']={'none':1}
        ctx,_=situation.make_state(data)
        quote=joint.evaluate(self.by_id[404],ctx,self.ref,scale=.4)
        blank=dict(self.by_id[404],effect_readable='')
        control=joint.evaluate(blank,ctx,self.ref,scale=.4)
        self.assertTrue(quote['pricing_supported'])
        self.assertAlmostEqual(quote['gross_model_gold']-control['gross_model_gold'],1)
        self.assertAlmostEqual(quote['ordinary_body_model_gold']+quote['magic_keywords_increment_model_gold'],quote['gross_model_gold'])

    def test_dust_cash_uses_the_same_actual_death_path_and_real_gold_unit(self):
        data=probe([138],10,30,[dict(attack=7,health=7)])
        data['response_weights']={'enemy_contact':1}
        ctx,_=situation.make_state(data)
        cash=joint.evaluate(self.by_id[138],ctx,self.ref,scale=.4)
        blank=joint.evaluate(dict(self.by_id[138],effect_readable=''),ctx,self.ref,scale=.4)
        self.assertTrue(cash['pricing_supported'])
        self.assertAlmostEqual(cash['gross_model_gold']-blank['gross_model_gold'],2)
        window=actions.evaluate(self.by_id[138],ctx,self.ref)
        raw=window['actions'][0]['paths'][0]['after_later_attack']['state']
        self.assertEqual(raw['own_callback_cash_delta'],2)
        self.assertEqual(len([e for e in raw['log'] if e['event']=='actual_dust_cash']),1)

    def test_paid_silence_disables_later_actual_dust(self):
        data=probe([138],10,30,[dict(attack=7,health=6)])
        data['opponent_gold_before_response']=3;data['response_weights']={'silence':1}
        ctx,_=situation.make_state(data)
        window=actions.evaluate(self.by_id[138],ctx,self.ref)
        raw=copy.deepcopy(window['actions'][0]['paths'][0]['after_reply']['state'])
        self.assertTrue(raw['actor']['silenced'])
        before_hp=raw['actor']['health']
        import combat_increment as combat
        combat.trade(raw,0)
        actions._dust_event(raw,before_hp,'next_own')
        self.assertEqual(raw.get('own_callback_cash_delta',0),0)

    def test_lesser_dog_saving_matches_actual_death_not_independent_probability(self):
        data=probe([43],6,30,[dict(attack=7,health=7)])
        data['response_weights']={'enemy_contact':1}
        data['dust_timing']=dict(horizon=7,origin_turn=5,discount_rate=0,branches=[dict(
            event='ordinary_death',probability=.1,event_turn=5,
            hand_at_event=[dict(cost=3,use_turn=6)],initial_gold=0,
            payment_windows=[dict(turn=6,income=3,max_plays=1)]),dict(event='none',probability=.9)])
        ctx,_=situation.make_state(data)
        quote=joint.evaluate(self.by_id[43],ctx,self.ref,scale=.4)
        blank=joint.evaluate(dict(self.by_id[43],effect_readable=''),ctx,self.ref,scale=.4)
        self.assertTrue(quote['pricing_supported'])
        self.assertAlmostEqual(quote['gross_model_gold']-blank['gross_model_gold'],1)
        # The .1 belongs to an old hypothetical lifecycle distribution, not a
        # second independent trigger chance on this certain contact death.
        ctx['dust_timing']['branches'][0]['event_turn']=6
        missing=joint.evaluate(self.by_id[43],ctx,self.ref,scale=.4)
        self.assertFalse(missing['pricing_supported'])
        self.assertIsNone(missing['gross_model_gold'])

    def test_current_card_costs_are_observed_per_physical_copy(self):
        data=probe([438,438],6,30,[dict(attack=1,health=1)])
        data['hand_costs']=[2,4]
        result=situation.evaluate(data,self.ref,self.cards)
        pairs=[r for r in result['deployment_routes']['routes'] if len(r['steps'])==2]
        self.assertTrue(pairs)
        self.assertTrue(all(r['actual_paid_gold']==6 and r['gold_remaining']==0 for r in pairs))

    def test_optional_self_kill_is_visible_but_does_not_block_safe_committed_quote(self):
        data=probe([672],8,2,[dict(attack=0,health=3)])
        data['response_weights']={'none':1}
        ctx,_=situation.make_state(data)
        quote=joint.evaluate(self.by_id[672],ctx,self.ref,scale=.7,include_trace=True)
        actual=quote['worlds']['actual_card']
        self.assertTrue(actual['terminal_candidate_present'])
        self.assertEqual(actual['best']['death_probability'],0)
        self.assertTrue(quote['pricing_supported'])
        self.assertFalse(quote['terminal_requires_separate_outcome_evaluation'])

    def test_full_hand_waiting_burn_is_once_and_has_public_prior(self):
        import decision_timing
        data=probe([15]*7);data['response_weights']={'none':1}
        ctx,_=situation.make_state(data)
        r=decision_timing.evaluate(self.by_id[15],ctx,self.ref,.7,
            {'next_draw_option_value_model_gold':.6})
        now=r['now']['paths'][0]['endpoint'];wait=r['wait']['paths'][0]['endpoint']
        self.assertEqual(now['burned_natural_draws'],0)
        self.assertEqual(wait['burned_natural_draws'],1)
        self.assertEqual(wait['capacity_loss_model_gold'],.6)
        self.assertEqual(r['draw_option_prior_source'],'caller')

    def test_magic_draw_retained_options_use_the_same_declared_gold_prior(self):
        data=probe([243]);data['response_weights']={'none':1}
        ctx,_=situation.make_state(data)
        draw=joint.evaluate(self.by_id[243],ctx,self.ref,.4)
        blank=joint.evaluate(dict(self.by_id[243],effect_readable=''),ctx,self.ref,.4)
        self.assertTrue(draw['pricing_supported'])
        self.assertAlmostEqual(draw['gross_model_gold']-blank['gross_model_gold'],.6)

    def test_optional_magic_draw_conserves_deck_when_extra_card_burns(self):
        data=probe([44]*7);data['response_weights']={'none':1}
        ctx,_=situation.make_state(data)
        window=actions.evaluate(self.by_id[44],ctx,self.ref)
        chosen=window['actions'][window['selected_action_index']]
        record=chosen['magic_selection'][0]
        self.assertEqual(record['chosen_amount'],0)
        self.assertEqual(record['players'][0]['kept'],0)
        self.assertEqual(record['players'][0]['deck_after'],20)

    def test_bilateral_fatigue_hp_is_counted_once_not_as_a_second_draw_fee(self):
        data=probe([199]);data['response_weights']={'none':1}
        ctx,_=situation.make_state(data)
        ctx['draw_state_assumptions']['own_deck_available']=0
        ctx['draw_state_assumptions']['own_fatigue_next']=1
        quote=joint.evaluate(self.by_id[199],ctx,self.ref,.4)
        blank=joint.evaluate(dict(self.by_id[199],effect_readable=''),ctx,self.ref,.4)
        self.assertTrue(quote['pricing_supported'])
        self.assertAlmostEqual(quote['gross_model_gold']-blank['gross_model_gold'],-.4*.3*5-2*.553125)

    def test_attack_conversion_sets_zero_attack_to_one_without_free_hp(self):
        data=probe([8],20,enemies=[dict(attack=0,health=3)])
        data['response_weights']={'none':1};ctx,_=situation.make_state(data)
        result=actions.evaluate(self.by_id[8],ctx,self.ref)
        after=result['actions'][0]['paths'][0]['after_current']['state']
        self.assertEqual(after['enemies'][0]['attack'],1)
        self.assertEqual(after['actor']['health'],4)

    def test_known_next_draw_fatigue_precedes_a_would_be_winning_attack(self):
        data=probe([15],10,1);data['enemy_player_hp']=1;data['response_weights']={'none':1}
        data['draw_state']={'own_deck_available':0,'own_fatigue_next':1}
        result=situation.evaluate(data,self.ref,self.cards)
        action=result['action_windows'][0]
        self.assertTrue(action['window_known'])
        self.assertEqual(action['death_probability'],1)
        self.assertEqual(action['defeat_probability'],0)
        self.assertEqual(result['hand_survival']['hold_death_probability'],1)
        self.assertEqual(result['timing_decisions'][0]['now']['death_probability'],1)

    def test_chance_paths_share_reply_mass_without_becoming_missing_events(self):
        import decision_timing
        data=probe([197],10,5,[dict(attack=7,health=4),dict(attack=0,health=4)])
        data['callback_state']={'turn_end_random_target_weights':[dict(target_id=0,weight=.25),dict(target_id=1,weight=.75)]}
        ctx,_=situation.make_state(data)
        result=decision_timing.evaluate(self.by_id[197],ctx,self.ref,.7)
        delay=next(a for a in result['now_actions'] if a['action_id']=='delay')
        self.assertTrue(delay['complete'])
        self.assertEqual(delay['death_probability'],.75)

    def test_paid_spell_and_ready_attacks_share_one_opponent_turn_budget(self):
        data=probe([438,582],8,8,[dict(attack=6,health=6),dict(attack=3,health=3)])
        data.update(opponent_gold_before_response=3,condition_state={'last_turn_gold_spent_on_spells':1},
            response_weights={'silence_then_enemy_face':1})
        result=situation.evaluate(data,self.ref,self.cards)
        haste,taunt=result['action_windows']
        self.assertEqual(haste['death_probability'],0)
        self.assertEqual(taunt['death_probability'],1)
        data['opponent_gold_before_response']=2
        low=situation.evaluate(data,self.ref,self.cards)
        self.assertEqual(low['action_windows'][1]['death_probability'],0)
        raw=result['action_windows'][1]['actions'][0]['paths'][0]['after_reply']['state']
        self.assertEqual(raw['enemy_gold'],0)
        self.assertEqual(raw['own_player_hp'],0)

    def test_modified_existing_ally_does_not_become_known_after_projection(self):
        data=probe([314]);data['response_weights']={'silence':1};data['opponent_gold_before_response']=3
        data['ally_bodies_before_play']=[dict(attack=2,health=3)]
        ctx,_=situation.make_state(data)
        result=actions.evaluate(self.by_id[314],ctx,self.ref)
        self.assertTrue(result['window_known'])
        # Candidate is selected by this declared silence policy, leaving ally
        # modifiers intact. Remove candidate after its current action, and the
        # same metadata cannot be reset as if the ally were an ordinary body.
        raw=copy.deepcopy(result['actions'][0]['paths'][0]['after_current']['state'])
        raw['actor']['health']=0
        with self.assertRaisesRegex(ValueError,'stat-modified'):
            actions._reply(raw,'silence',ctx)


if __name__=='__main__':unittest.main()