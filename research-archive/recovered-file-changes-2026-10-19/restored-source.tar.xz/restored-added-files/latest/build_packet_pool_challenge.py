"""Falsify selected-subset recommendations with missing real3G alternatives."""
import hashlib
import json
from pathlib import Path

import build_damage_packet_comparison as fixture
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/damage-packet-v01'


def main():
    cards=score_cards.load_cards();by={c['id']:c for c in cards}
    assert (by[53]['cost'],by[53]['attack'],by[53]['health'])==(3,5,5)
    assert by[53]['effect_readable']=='Turn end: Lose 1 ATK. If this has 0 ATK, kill this.'
    assert (by[9]['cost'],by[9]['attack'],by[9]['effect_readable'])==(3,3,'Charge.')
    assert by[22]['cost']==3 and by[22]['effect_readable']=='Magic: Heal 4 HP.'
    rows=[]
    for hp in (3,5):
        for cid in (9,22,53,56,187,377):
            d=fixture.fixture(cid,hp);d['hand_base_costs']=[3]
            r=paid.evaluate(d,cards);ex=paid.evaluate(dict(d,search_algorithm='exhaustive'),cards)
            assert r['complete_in_declared_scope'] and ex['complete_in_declared_scope']
            assert [o['objective_vector'] for o in r['objectives']]==[o['objective_vector'] for o in ex['objectives']]
            # Maximum native body health is an identified upper bound here;
            # none of these six has a health buff or a summoning callback.
            bound=fixture.body_bound(d,cards)
            rows.append(dict(enemy_hp=hp,card_id=cid,name=by[cid]['name'],input=d,result=r,
                guaranteed_player_hp=r['objectives'][0]['metrics']['own_player_hp'],
                guaranteed_same_body_hp=bound['bound'],body_bound=bound,exhaustive_full_vector_equal=True))
    def get(cid,hp,key):return next(r[key] for r in rows if r['card_id']==cid and r['enemy_hp']==hp)
    assert (get(53,3,'guaranteed_player_hp'),get(53,3,'guaranteed_same_body_hp'))==(12,2)
    assert (get(53,5,'guaranteed_player_hp'),get(53,5,'guaranteed_same_body_hp'))==(11,1)
    assert get(187,5,'guaranteed_same_body_hp')==2
    assert get(9,3,'guaranteed_player_hp')==15
    assert get(22,3,'guaranteed_player_hp')==15
    saturation=[]
    for cid in (9,22):
        d=fixture.fixture(cid);d['own_player_hp']=27
        r=paid.evaluate(d,cards);assert r['complete_in_declared_scope']
        hp=r['objectives'][0]['metrics']['own_player_hp'];assert hp==(27 if cid==9 else 26)
        saturation.append(dict(card_id=cid,input=d,guaranteed_player_hp=hp,result=r))
    # Prove the Napstablook3/4HP target window without damage/search routines.
    # Opponent has at most3 damage in its first turn: observed1ATK and two
    # 1G/1DMG copies. End0 leaves4ATK; body5 survives and face4 wins at next
    # own start. Face-only enemy reply gives the matching12HP upper witness.
    independent=dict(deployment_attack=5,first_own_end_loss=1,next_attack=5-1,
        native_body_hp=5,first_reply_damage_budget=1+2*1,
        simultaneous_lower_bounds=dict(player_hp=15-(1+2),body_hp=5-(1+2)),
        feasible_common_policy='Deploy once; pass current end; at next own attack hit enemy hero3/4HP with4ATK.',
        player_upper_witness='Enemy first1ATK face and both1G Gems face force player<=12; no healing.',
        body_upper_witness='Enemy first1ATK body and both1G Gems body force body<=2; no health buff.',
        window_failure='Enemy5HP exceeds4ATK, so second enemy response becomes reachable; four1damage total can leave1HP.',
        scope='Literal no-Taunt/no-callback observed actor and fixed paid hand; not a server trace.')
    assert independent['simultaneous_lower_bounds']==dict(player_hp=12,body_hp=2)
    record=dict(rows=rows,healing_saturation=saturation,independent_napstablook_bounds=independent,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('build_packet_pool_challenge.py','build_damage_packet_comparison.py','paid_board_tactics.py','board_tactics.py')},
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        limits=['Each reported optimum is a separate full objective; only the explicit Nap policy proves both its lower bounds together.',
            'These are six actual equal3G alternatives; all106 scan retains '+str(json.loads((OUT/'pool-comparison.json').read_text())['summary']['unknown'])+' unclosed candidates.',
            'Healing uses actual missingHP/max30; earliest-turn/meta frequency not invented.'])
    (OUT/'pool-challenge.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    lines=['# 全池扫描暴露遗漏替代，再做独立窗口验证','',
        '不能把Ranger在最初三个候选中保命最好当成3G冠军。全106来源扫描给出Ice Cap/Shyren15HP，以及Napstablook的短期大身体。','',
        '| 条件 | 卡牌 | 玩家HP保证 | 同一活体HP保证 |','|---|---|---:|---:|']
    for r in rows:lines.append(f"| 敌{r['enemy_hp']}HP | {r['name']} | {r['guaranteed_player_hp']} | {r['guaranteed_same_body_hp']} |")
    lines+=['','敌3/4HP时Napstablook当前End后4ATK，首敌最多3伤使本体至少2HP、玩家至少12HP；同一固定下一己打脸策略即可保证终结和这两个下界。敌全打玩家给12HP上界，全打身体给2HP上界。这段证明不调用搜索/伤害原语。','',
        '敌仅提高到5HP，4攻不再终结，第二敌回应真实到达；Napstablook体保证降到1，而Candy仍2。不能把5/5当永久身材，或把晚期窗口统一折扣。','',
        '己27/30HP时Shyren只能实际治3；玩家保证26，Ice Cap当下致胜保27。原15/30HP下两者都15，所以满血附近的治疗饱和改变偏好。','',
        '正文两列通常独立优化，不能拼成一个策略；只有明示的Nap下界使用同一政策证明。所有新根的完整向量另与穷举一致。']
    (OUT/'pool-challenge.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps([{k:r[k] for k in ('enemy_hp','card_id','guaranteed_player_hp','guaranteed_same_body_hp')} for r in rows]))


if __name__=='__main__':main()