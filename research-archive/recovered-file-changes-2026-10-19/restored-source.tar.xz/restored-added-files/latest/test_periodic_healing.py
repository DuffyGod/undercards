"""Owner-end healing, real protection and adverse healing/silence interactions."""
import copy
from dataclasses import replace
import unittest

import board_tactics as b
import paid_board_tactics as p
import score_cards
import conditional_card_score as score
import build_conditional_scores as cases


class PeriodicHealingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def engine(self,**changes):
        data=dict(hand_ids=[107],gold_before_play=3,own_player_hp=10,own_player_max_hp=30,
            enemy_player_hp=30,enemy_player_max_hp=30,enemy_bodies=[],opponent_hand_known=True,
            opponent_hand_ids=[],max_plays=1,next_max_plays=0,next_natural_draw_count=0,
            horizon='next_enemy_attack',next_opponent_gold_income=0,next_opponent_natural_draw_count=0)
        data.update(changes);e=p.PaidSearch(self.cards,data);return e,e.root()

    def test_exact_generic_registry_not_keyword_substrings(self):
        spec=b.compile_card(dict(effect_readable='Turn end: Heal 7 HP to all allies.'))
        self.assertEqual(spec['end'],('heal_all_allies',7));self.assertFalse(spec['unknown'])
        self.assertTrue(b.compile_card(dict(effect_readable='Turn end: Heal 7 HP to all allies. Dust: Draw a card.'))['unknown'])

    def test_owner_end_only_and_actual_source_survival(self):
        e,s=self.engine();s=next(e.deploys(s))[1]
        self.assertEqual(s.own_hp,10)
        s=e.boundary(s);self.assertEqual((s.phase,s.own_hp),(1,12))
        s=e.boundary(s);self.assertEqual((s.phase,s.own_hp),(2,12))
        s=e.boundary(s);self.assertEqual((s.phase,s.own_hp),(3,14))
        s=e.boundary(s);self.assertEqual(s.own_hp,14)
        self.assertEqual(s.current_paid_gold,3)

    def test_player_and_body_caps_and_damaged_attack_reversal(self):
        e,s=self.engine(own_player_hp=29,ally_bodies_before_play=[dict(card_id=534,attack=5,health=4,max_health=5)])
        s=next(e.deploys(s))[1];self.assertEqual(b.effective_attack(s.own[0],s,'own'),5)
        s=e.boundary(s)
        self.assertEqual((s.own_hp,s.own[0].health,s.own[0].max_health),(30,5,5))
        self.assertEqual((s.own[0].attack,b.effective_attack(s.own[0],s,'own')),(2,2))

    def test_omitted_observed_maximum_is_not_a_healing_cap(self):
        e,s=self.engine(ally_bodies_before_play=[dict(card_id=2,attack=1,health=1)])
        s=next(e.deploys(s))[1]
        with self.assertRaisesRegex(p.UnknownMechanic,'maximum HP'):e.boundary(s)

    def test_dead_bodies_and_dead_player_never_revive(self):
        e,s=self.engine(ally_bodies_before_play=[dict(card_id=2,attack=1,health=1,max_health=1)])
        s=next(e.deploys(s))[1];s=replace(s,own=(replace(s.own[0],health=0),s.own[1]))
        self.assertEqual(e.boundary(s).own[0].health,0)
        self.assertEqual(e.boundary(replace(s,own_hp=0)).own_hp,0)

    def test_enemy_owner_heals_enemy_not_us(self):
        e,s=self.engine(hand_ids=[],enemy_player_hp=20,enemy_bodies=[dict(card_id=107,attack=3,health=2,max_health=3)])
        s=e.boundary(s);self.assertEqual(s.enemy_hp,20)
        s=e.boundary(s);self.assertEqual((s.enemy_hp,s.own_hp,s.enemy[0].health),(22,10,3))

    def test_allies_player_semantic_counterfactual_and_unknown(self):
        e,s=self.engine(allies_include_player=False);s=next(e.deploys(s))[1]
        self.assertEqual(e.boundary(s).own_hp,10)
        e,s=self.engine(allies_include_player='unknown');s=next(e.deploys(s))[1]
        with self.assertRaisesRegex(p.UnknownMechanic,'player inclusion'):e.boundary(s)
        e,s=self.engine(allies_include_player='unknown',own_player_hp=30);s=next(e.deploys(s))[1]
        self.assertEqual(e.boundary(s).own_hp,30)

    def test_healing_and_end_death_order_does_not_invent_a_free_trigger(self):
        e,s=self.engine(ally_bodies_before_play=[dict(card_id=2,attack=1,health=1,max_health=1)])
        s=next(e.deploys(s))[1]
        # Synthetic combination exercises the generic order guard; it is not
        # claimed to be a native full card. Decline can kill before source heal.
        dying=replace(s.own[0],end=('decline',1),dust=('damage_all_monsters',4))
        s=replace(s,own=(dying,s.own[1]))
        with self.assertRaisesRegex(p.UnknownMechanic,'callback order'):e.boundary(s)

    def test_one_gem_retain_response_separates_win_and_body_guarantees(self):
        cfg=dict(scene=cases.scene3(),candidate_ids=[107],include_delay=False,
            tasks={'body3_2':dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=3,min_own_body_health=2))})
        cfg['scene'].update(opponent_hand_ids=[598],opponent_gold_before_response=1)
        r=score.compare(cfg,self.cards)['rows'][0]['scores']
        self.assertEqual(r['hp']['guaranteed_player_hp'],16)
        self.assertEqual(r['win']['guaranteed_player_hp'],15)
        self.assertEqual(r['body3_2']['guaranteed_player_hp'],16)
        cfg['scene']['enemy_player_hp']=30
        r=score.compare(cfg,self.cards)['rows'][0]['scores']
        self.assertFalse(r['body3_2']['feasible'])

    def test_single_enemy_silence_and_automatic_allies_have_distinct_targets(self):
        e,s=self.engine(hand_ids=[144],ally_bodies_before_play=[dict(card_id=187,attack=2,health=4,max_health=6,taunt=True)],
            enemy_bodies=[dict(card_id=187,attack=2,health=4,max_health=6,taunt=True)])
        a,z=next(e.deploys(s));self.assertEqual(a['magic_target'],('enemy',0))
        self.assertTrue(z.own[0].taunt);self.assertFalse(z.enemy[0].taunt)
        e,s=self.engine(hand_ids=[390],ally_bodies_before_play=[dict(card_id=187,attack=2,health=4,max_health=6,
            taunt=True,transparency=True)],enemy_bodies=[dict(card_id=187,attack=2,health=4,max_health=6,taunt=True)])
        a,z=next(e.deploys(s));self.assertTrue(z.enemy[0].taunt)
        self.assertFalse(z.own[0].taunt);self.assertFalse(z.own[0].transparency)
        self.assertFalse(z.own[1].silenced)

    def test_silence_modified_unknown_and_dt_immunity(self):
        e,s=self.engine(hand_ids=[390],ally_bodies_before_play=[dict(card_id=187,attack=2,health=4,max_health=5)])
        with self.assertRaisesRegex(p.UnknownMechanic,'modified body'):next(e.deploys(s))
        dt=next(c for c in self.cards if c['card_type']=='monster' and c['rarity'] in ('DT','DETERMINATION'))
        u=p.PaidUnit('dt',dt['id'],99,90,100,taunt=True,max_health_known=False)
        self.assertEqual(e.silence(u),u)


if __name__=='__main__':unittest.main()