"""Independent arithmetic bounds for one declared native Bench-hand family.

No damage, payment, draw, board objective or search primitive enters the bound.
The tactical evaluator is called only afterwards to falsify its prediction.
This proves a small rule-conditional family, not all cards or server semantics.
"""
import copy
import hashlib
import json
from pathlib import Path
import re

import current_draw_policy
import score_cards
import test_current_draw_policy

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/current-draw-challenge-v01'


def source_facts(cards):
    by={c['id']:c for c in cards}
    assert by[243]['effect_readable']=='Magic: Draw a card.'
    assert by[196]['effect_readable']==by[15]['effect_readable']==''
    heal=re.fullmatch(r'Magic: Heal (\d+) HP\.',by[22]['effect_readable'])
    damage=re.fullmatch(r'Deal (\d+) DMG to an enemy monster\.',by[96]['effect_readable'])
    assert heal and damage
    assert all(not by[cid].get('base_statuses') for cid in (243,196,22,15))
    assert by[196]['cost']==0
    assert all(by[cid]['card_type']=='monster' and by[cid]['health']>0 for cid in (243,196,22,15))
    assert by[96]['card_type']=='spell'
    return dict(draw_price=by[243]['cost'],heal_price=by[22]['cost'],heal=int(heal[1]),
        removal_price=by[96]['cost'],removal_damage=int(damage[1]),
        raw_sources={str(cid):{k:by[cid].get(k) for k in ('name','cost','card_type','effect_readable','base_statuses')}
                     for cid in (243,196,22,96,15)})


def bounds(cash,hp,maximum,enemy_attack,enemy_health,facts):
    # The sole current draw is exactly one; the unseen second identity cannot
    # be deployed. None of the fresh own bodies has Taunt/Haste/Charge or an
    # own-hero callback. The enemy can face once whenever it remains alive.
    heal_payable=cash>=facts['draw_price']+facts['heal_price']
    remove_payable=cash>=facts['draw_price']+facts['removal_price']
    healed=min(maximum,hp+facts['heal']) if heal_payable else hp
    heal_world=max(0,healed-enemy_attack)
    removal_world=hp if remove_payable and enemy_health<=facts['removal_damage'] else max(0,hp-enemy_attack)
    return dict(per_order_exact_hp=[heal_world,removal_world],guaranteed_hp_bounds=[min(heal_world,removal_world)]*2,
        common_strategy='Deploy Bench when payable, optionally Tiny; after the retained identity, pay the useful revealed card if affordable, then end.',
        upper_witness='Enemy always attacks the hero when alive. In heal-first, at most the single actually held heal applies; in removal-first, no healer has been drawn. One physical Bench cannot draw twice.',
        lower_witness='That same observation policy realizes the stated HP: enemy damage is at most its one attack; lethal removal leaves no enemy action. Fresh-body attacks and unobserved library copies are never credited.',
        heal_payable=heal_payable,removal_payable=remove_payable,
        interpretation='Source-literal and fresh-permission conditional scalar proof; enemy face is a common observable counterstrategy, so this bound does not require enemy hidden-order knowledge.')


def main():
    cards=score_cards.load_cards();facts=source_facts(cards);rows=[]
    for name,cash,hp,attack,health in [('baseline',8,7,6,4),('cash_minus_one',7,7,6,4),
        ('enemy_attack_minus_one',8,7,5,4),('target_hp_plus_one',8,7,6,5),
        ('healing_cap_saturation',8,29,6,4),('low_hp',8,3,6,4)]:
        data=test_current_draw_policy.fixture(cash)
        for panel in data['panels']:
            panel['own_player_hp']=hp
            panel['enemy_bodies'][0].update(attack=attack,health=health)
        proof=bounds(cash,hp,30,attack,health,facts)
        actual=current_draw_policy.evaluate(copy.deepcopy(data),cards)
        assert actual['complete_in_declared_scope'],actual['unknown']
        assert actual['metrics']['own_player_hp']==proof['guaranteed_hp_bounds'][0],name
        oracle_hp=[p['result']['metrics']['own_player_hp'] for p in actual['perfect_information_oracles']]
        assert oracle_hp==proof['per_order_exact_hp'],(name,oracle_hp,proof)
        rows.append(dict(case=name,input=data,independent_bound=proof,result=actual,scalar_bounds_equal=True))
    document=dict(method='Arithmetic feasible policy and common enemy counterstrategy, before consulting tactical search.',
        source_facts=facts,cases=rows,source_binding=current_draw_policy.source_binding(cards),
        source_hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in
            ('prove_current_draw_hand_bounds.py','test_current_draw_policy.py')},
        limitations=['Only Bench/Tiny with one observed plain enemy, 7HP-family interventions and known two-card Shy/P composition.',
            'Literal healing/removal/fresh-permission rules remain conditional on source interpretation, not verified server behavior.',
            'The shared fixture is input only; the mathematical bound never invokes the shared mechanism primitives.'])
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'independent-hand-bounds.json').write_text(json.dumps(document,ensure_ascii=False,indent=2)+'\n')
    print([(r['case'],r['independent_bound']['guaranteed_hp_bounds']) for r in rows])


if __name__=='__main__':main()