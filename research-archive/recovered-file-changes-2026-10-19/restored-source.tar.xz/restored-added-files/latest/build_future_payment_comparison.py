"""Shared-endpoint hand scores and cash/timing counterfacts."""
import copy
import hashlib
import json
from pathlib import Path
import build_delay_history_comparison as prior
import evaluate_situation
import paid_board_tactics as paid
import prove_idle_future_reply
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/future-payment-v01'


def scenario(hp=3, future=2, income=5):
    data=prior.scene(hp=hp,spell=True,horizon='next_own_attack')
    data.update(next_max_plays=future,next_own_gold_income=income,
        current_turn_gold_spent_on_spells=0,objectives=['guaranteed_hp'],node_limit=200000)
    return data


def main():
    cards=score_cards.load_cards();OUT.mkdir(exist_ok=True)
    cases=[]
    for hp,future,income in ((3,0,5),(3,1,5),(3,2,0),(3,2,1),(3,2,2),(3,2,5),
                             (10,0,5),(10,2,5),(28,2,5)):
        data=scenario(hp,future,income);result=paid.evaluate(data,cards)
        if not result['complete_in_declared_scope']:raise AssertionError(result['unknown'])
        cases.append(dict(initial_hp=hp,future_play_limit=future,next_income=income,input=data,result=result))
        v=result['objectives'][0]
        print(hp,future,income,v['metrics']['own_player_hp'],
            v['principal_variation'][0].get('card_id'),flush=True)
    forced=[]
    for income in (0,2):
        data=scenario(income=income);engine=paid.PaidSearch(cards,data);root=engine.root()
        rows=[]
        for action,child in engine.deploys(root):
            result=engine.solve(child,'guaranteed_hp')
            if not result['search_complete']:raise AssertionError(result.get('unknown'))
            rows.append(dict(first_hand_index=action['hand_index'],card_id=action['card_id'],
                name=engine.by[action['card_id']]['name'],action=action,result=result))
        hold=engine.solve(engine.boundary(root),'guaranteed_hp')
        if not hold['search_complete']:raise AssertionError(hold.get('unknown'))
        best={}
        for row in rows:
            cid=row['card_id']
            if cid not in best or tuple(row['result']['objective_vector'])>tuple(best[cid]['result']['objective_vector']):
                best[cid]=row
        scores=[dict(card_id=cid,name=best[cid]['name'],guaranteed_hp=best[cid]['result']['metrics']['own_player_hp'],
            optimal_first_action=best[cid]['action']) for cid in prior.HAND]
        forced.append(dict(next_income=income,input=data,candidates=rows,scores_by_card=scores,wait_result=hold))
        print('forced',income,[(r['name'],r['guaranteed_hp']) for r in scores],flush=True)
    # Cross-card threshold on the same physical hand: a paid damage card can
    # finish a target a Haste attacker leaves for the following own turn.
    spell_hand=[]
    for future in (0,1):
        data=scenario(hp=10,future=future)
        data.update(hand_ids=[96,438],hand_base_costs=[3,4],
            purpose_constraints={'min_own_player_hp':3,'max_enemy_living_count':0},
            objectives=['guaranteed_hp','purpose'])
        result=paid.evaluate(data,cards)
        if not result['complete_in_declared_scope']:raise AssertionError(result['unknown'])
        spell_hand.append(dict(input=data,result=result))
    data=scenario(income=5)
    current={k:copy.deepcopy(data[k]) for k in ('hand_ids','gold_before_play','own_player_hp',
        'enemy_player_hp','ally_bodies_before_play','enemy_bodies','opponent_gold_before_response')}
    params=('hand_base_costs','own_dustpile_monsters','opponent_hand_ids','max_plays','horizon','objectives',
        'purpose_constraints','own_deck_ids','own_fatigue_next','next_natural_draw_count',
        'next_max_plays','next_own_gold_income','current_turn_gold_spent_on_spells')
    current.update(role='midrange',own_turn=4,condition_state=data['condition_known_state'],
        callback_state={'own_player_max_hp':30},response_weights={'enemy_face':1},
        paid_board_scenario={k:data[k] for k in params})
    api=evaluate_situation.evaluate(current,cards=cards)
    direct=paid.evaluate(data,cards)
    if json.loads(json.dumps(api['paid_board_tactics']))!=json.loads(json.dumps(direct)):
        raise AssertionError('Common API differs from direct future payment')
    (OUT/'current.input.json').write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n')
    (OUT/'current.result.json').write_text(json.dumps(api,ensure_ascii=False,indent=2)+'\n')
    bound_data=scenario();bound_data.update(max_plays=4,objectives=['purpose'])
    bound=prove_idle_future_reply.prove_damage_bound(bound_data,cards)
    if not bound['bound_complete']:raise AssertionError(bound['unknown'])
    record=dict(version='future-physical-payment-comparison-0.1.0',cases=cases,
        forced_first_card_scores=forced,spell_hand_clear_threshold=spell_hand,
        multi_current_play_clear_bound=bound,api_matches_standalone=True,
        source_hashes={f:hashlib.sha256((HERE/f).read_bytes()).hexdigest() for f in
            ('paid_board_tactics.py','board_tactics.py','queued_delay.py','evaluate_situation.py',
             'prove_idle_reply_bound.py','prove_idle_future_reply.py','build_future_payment_comparison.py',
             'build_delay_history_comparison.py')},
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        limitations=['A declared known seven-card hand, not a full-pool ranking or calibrated deck inclusion value.',
            'Current and next turn Play limits are explicit search restrictions. Next income 0/1/2 are cash interventions, not normal turn-income frequencies.',
            'Normal income is supplied rather than inferred; 5G is consistent with a normal first-player fifth own turn.',
            'Next end-turn endpoint precedes the following enemy reply; healthy endpoint HP does not guarantee survival of that reply.',
            'Whole-menu four-current/two-future minimax and exact idle enumeration exhausted 200000 states; these failures remain separate raw artifacts.'])
    (OUT/'comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()