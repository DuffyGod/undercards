"""Declared next-own income/natural draw before any next-own card or attack."""
import copy
import combat_increment as combat
import draw_options
import score_cards as base

VERSION='next-own-income-draw-0.1.0'


def advance(raw,origin,income,draw_count,released_before_draw):
    state=copy.deepcopy(raw)
    state['_deadline_income_received']=0.
    if combat.terminal(state):return state,[]
    state['_deadline_income_received']=income
    if 'own_gold' in state:state['own_gold']+=income
    inputs=origin['draw_state_assumptions']
    hand=(state.get('own_hand_size',origin['hand_size_before_play']-1) if released_before_draw else origin['hand_size_before_play'])
    deck=state.get('own_deck_available',inputs['own_deck_available'])
    fatigue=state.get('own_fatigue_next',inputs['own_fatigue_next'])
    row=draw_options.draw_ledger(draw_count,dict(hand_size=hand,deck_available=deck,fatigue_next=fatigue,
        player_hp=state['own_player_hp'],design_prior=True),net_option_value=0,hp_model_gold=0)
    unknown=[u for u in row['unknown'] if 'terminal/survival effects are unmodeled' not in u]
    if unknown:return state,unknown
    damage=min(state['own_player_hp'],row['fatigue_damage'])
    state['own_player_hp']-=damage;state['hp_delta']-=damage
    state.update(own_hand_size=row['hand_after'],own_deck_available=row['deck_after'],own_fatigue_next=row['fatigue_next_after'])
    state['_deadline_natural_draw']=row
    p=base.role_parameters(origin['role'])
    option=origin.get('next_draw_option_value_model_gold',p['draw_value']*p['future_draw_use'])
    state['retained_natural_draw_options_model_gold']=row['kept']*option
    state['log'].append(dict(event='next_own_income_and_natural_draw',income=income,draw=row))
    return state,[]