import copy
import unittest

import build_current_draw_api as probes
import current_draw_policy
import evaluate_situation


class CurrentDrawAPITests(unittest.TestCase):
    def test_paid_observed_branches_and_root_physical_prices_reach_api(self):
        data=probes.fixture();r=evaluate_situation.evaluate(data);c=r['current_draw_policy']
        self.assertTrue(c['complete_in_declared_scope'],c['unknown'])
        self.assertEqual(c,current_draw_policy.evaluate(c['input']))
        self.assertEqual(c['metrics']['own_player_hp'],5)
        self.assertEqual(r['authoritative_tactical_recommendation']['source'],'current_draw_policy')
        self.assertEqual([p['result']['principal_variation'][0]['card_id']
                          for p in c['observation_policy']['panel_payoffs']],[22,96])
        data['hand_costs']=[6,0]
        modified=evaluate_situation.evaluate(data)
        self.assertEqual(modified['current_draw_policy']['metrics']['own_player_hp'],1)

    def test_budget_failure_withdraws_all_legacy_and_new_recommendations(self):
        data=probes.fixture();data['current_draw_scenario']['node_limit']=1
        r=evaluate_situation.evaluate(data)
        self.assertFalse(r['authoritative_tactical_recommendation']['complete'])
        self.assertFalse(r['authoritative_tactical_recommendation']['policies'])
        self.assertIsNone(r['current_draw_policy']['observation_policy'])
        self.assertIsNone(r['hand_survival']['best_known_death_reducing_hand_index'])
        self.assertFalse(r['hand_survival']['known_death_reducing_hand_indexes'])
        self.assertIsNone(r['deployment_routes']['best_known_survival_route'])
        self.assertTrue(all(w.get('recommended_action') is None for w in r['action_windows']))

    def test_scope_and_parameters_cannot_override_public_observations(self):
        data=probes.fixture();data['current_draw_scenario']['own_player_hp']=100
        with self.assertRaisesRegex(ValueError,'current_draw_scenario'):evaluate_situation.evaluate(data)
        data=probes.fixture();data['future_draw_scenario']=copy.deepcopy(data['current_draw_scenario'])
        with self.assertRaises(ValueError):evaluate_situation.evaluate(data)

    def test_same_body_purpose_is_available_after_observed_draws(self):
        for cash,expected in ((8,False),(11,True)):
            data=probes.fixture();data.update(hand_ids=[44,196],hand_costs=[8,0],gold_before_play=cash)
            data['current_draw_scenario'].update(objective='purpose',
                purpose_constraints=dict(min_own_player_hp=1,min_own_body_attack=4,min_own_body_health=3))
            r=evaluate_situation.evaluate(data);c=r['current_draw_policy']
            self.assertTrue(c['complete_in_declared_scope'],c['unknown'])
            self.assertEqual(bool(c['objective_vector'][0]),expected)
            self.assertIsNone(r['authoritative_tactical_recommendation']['guaranteed_hp'])


if __name__=='__main__':unittest.main()