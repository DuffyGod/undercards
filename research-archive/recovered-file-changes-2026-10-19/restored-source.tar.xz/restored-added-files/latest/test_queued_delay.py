import copy
from dataclasses import replace
import unittest
import paid_board_tactics as paid
import score_cards


class QueuedDelayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.cards=score_cards.load_cards()

    def scene(self,n=3,**changes):
        data=dict(hand_ids=[580],hand_base_costs=[3],gold_before_play=3,own_player_hp=3,
            own_player_max_hp=30,enemy_player_hp=30,max_plays=1,horizon='enemy_attack',
            objectives=['guaranteed_hp'],enemy_bodies=[dict(card_id=15,attack=6,health=5)],
            own_dustpile_monsters=[dict(card_id=108,current_cost=6,base_cost=6) for _ in range(n)])
        return dict(data,**changes)

    def result(self,data,cards=None):
        result=paid.evaluate(data,cards or self.cards)
        self.assertTrue(result['complete_in_declared_scope'],result['unknown'])
        return result['objectives'][0]

    def test_actual_dust_threshold_changes_protection_and_paid_reply(self):
        for n,hp in ((2,3),(3,8)):
            self.assertEqual(self.result(self.scene(n))['metrics']['own_player_hp'],hp)
        two=[dict(card_id=15,attack=6,health=5),dict(card_id=2,attack=2,health=3)]
        self.assertEqual(self.result(self.scene(enemy_bodies=two))['metrics']['own_player_hp'],6)
        self.assertEqual(self.result(self.scene(opponent_hand_ids=[96],opponent_gold_before_response=3))['metrics']['own_player_hp'],2)
        self.assertEqual(self.result(self.scene(enemy_bodies=two,opponent_hand_ids=[96],opponent_gold_before_response=3))['metrics']['own_player_hp'],0)

    def test_source_dies_before_end_but_play_queue_still_heals_once(self):
        engine=paid.PaidSearch(self.cards,self.scene(hand_ids=[580,598,598,598],
            hand_base_costs=[3,1,1,1],gold_before_play=6,max_plays=4))
        state=next(s for a,s in engine.deploys(engine.root()) if a.get('card_id')==580)
        for _ in range(3):
            state=next(s for a,s in engine.casts(state,'own') if a['targets']==[('own',0)])
        self.assertEqual(state.own[0].health,0)
        self.assertEqual(len(state.queued_delays),1)
        result=engine.solve(state,'guaranteed_hp')
        self.assertTrue(result['search_complete'],result.get('unknown'))
        self.assertEqual(result['metrics']['own_player_hp'],2)
        self.assertEqual(result['delay_accounting']['healed_hp'],5)
        self.assertEqual(result['delay_accounting']['pending_count'],0)

    def test_ordinary_summon_does_not_enqueue_delay(self):
        cards=copy.deepcopy(self.cards)
        next(c for c in cards if c['id']==3)['effect_readable']='Magic: Summon a Totemic Guard [#580].'
        r=self.result(self.scene(hand_ids=[3]),cards)
        self.assertEqual(r['metrics']['own_player_hp'],3)
        self.assertEqual(r['delay_accounting']['healed_hp'],0)

    def test_summon_adapter_preserves_recursive_dust_callback_guard(self):
        cards=copy.deepcopy(self.cards)
        next(c for c in cards if c['id']==3)['effect_readable']='Magic: Summon a Rock [#108].'
        next(c for c in cards if c['id']==108)['effect_readable']='Taunt. Dust: Summon a Burgerpants [#30].'
        r=paid.evaluate(self.scene(hand_ids=[3]),cards)
        self.assertFalse(r['complete_in_declared_scope'])
        self.assertTrue(any('recursive death queue' in u for u in r['unknown']))

    def test_missing_dust_and_disagreeing_cost_filters_remain_unknown(self):
        missing=self.scene();missing.pop('own_dustpile_monsters')
        altered=self.scene(own_dustpile_monsters=[dict(card_id=108,current_cost=3,base_cost=6)]*3)
        for data in (missing,altered):
            r=paid.evaluate(data,self.cards)
            self.assertFalse(r['complete_in_declared_scope'])
            self.assertTrue(any('cost filter/history' in u for u in r['unknown']))

    def test_current_cost_equal_printed_does_not_prove_base_cost(self):
        data=self.scene(0,hand_ids=[580,550,550,550]);data.pop('hand_base_costs')
        engine=paid.PaidSearch(self.cards,data)
        state=replace(engine.root(),hand=(1,2,3),plays=1)
        self.assertIsNone(engine.delay_gate(state,{'threshold':3,'cost':6}))

    def test_uniform_cost_axes_cannot_hide_cross_zone_disagreement(self):
        data=self.scene(hand_ids=[580,20,20,20],hand_costs=[3,6,6,6],
            hand_base_costs=[3,4,4,4],own_dustpile_monsters=[dict(card_id=108,current_cost=5,base_cost=6)]*3)
        r=paid.evaluate(data,self.cards)
        self.assertFalse(r['complete_in_declared_scope'])
        self.assertTrue(any('cost filter/history' in u for u in r['unknown']))

    def test_current_base_agreement_does_not_rule_out_printed_cost_filter(self):
        r=paid.evaluate(self.scene(own_dustpile_monsters=[dict(card_id=550,current_cost=6,base_cost=6)]*3),self.cards)
        self.assertFalse(r['complete_in_declared_scope'])
        self.assertTrue(any('current/base/printed' in u for u in r['unknown']))

    def test_changed_condition_timing_and_silence_are_not_guessed(self):
        data=self.scene(0,hand_ids=[580,108,108,108],hand_base_costs=[3,6,6,6],gold_before_play=9,max_plays=2)
        engine=paid.PaidSearch(self.cards,data)
        state=next(s for a,s in engine.deploys(engine.root()) if a.get('card_id')==580)
        state=next(s for a,s in engine.deploys(state) if a.get('card_id')==108)
        r=engine.solve(state,'guaranteed_hp')
        self.assertFalse(r['search_complete'])
        self.assertIn('condition changed',r['unknown'][0])
        r=paid.evaluate(self.scene(hand_ids=[580,79],hand_base_costs=[3,1],gold_before_play=4,max_plays=2),self.cards)
        self.assertFalse(r['complete_in_declared_scope'])
        self.assertTrue(any('Silence of already queued' in u for u in r['unknown']))

    def test_turn_end_queue_order_is_not_silently_assumed(self):
        r=paid.evaluate(self.scene(ally_bodies_before_play=[dict(card_id=30,attack=4,health=3,ready=False)]),self.cards)
        self.assertFalse(r['complete_in_declared_scope'])
        self.assertTrue(any('Turn end callback order' in u for u in r['unknown']))

    def test_hand_silence_observation_removes_taunt_and_never_queues(self):
        r=self.result(self.scene(hand_silenced=[True]))
        self.assertEqual(r['metrics']['own_player_hp'],0)
        self.assertEqual(r['delay_accounting']['healed_hp'],0)

    def test_healing_caps_and_does_not_repeat_next_owner_end(self):
        r=self.result(self.scene(own_player_hp=28,horizon='next_own_attack',
            own_deck_ids=[196],next_natural_draw_count=1))
        self.assertEqual(r['metrics']['own_player_hp'],30)
        self.assertEqual(r['delay_accounting']['healed_hp'],2)
        self.assertEqual(r['draw_accounting']['remaining_known_deck'],0)

    def test_zero_summon_payment_is_not_zero_dust_card_cost(self):
        engine=paid.PaidSearch(self.cards,self.scene(0,hand_ids=[],hand_base_costs=[]))
        card=engine.by[108]
        unit=engine.unit(card,engine.compile_summoned(card),'free_summon',cost=0)
        before=replace(engine.root(),own=(unit,))
        after=engine.deaths(before,replace(before,own=(replace(unit,health=0),)))
        self.assertEqual(unit.cost,0)
        self.assertEqual(after.own_dust_costs,((6,6,6),))
        self.assertTrue(engine.delay_gate(after,{'threshold':1,'cost':6}))


if __name__=='__main__':unittest.main()