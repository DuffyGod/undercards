"""An actual held defender changes windows; its HP is not the candidate's HP."""
import hashlib
import json
from pathlib import Path

import build_packet_timing as timing
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/damage-packet-v01'


def main():
    cards=score_cards.load_cards();rows=[]
    baseline=timing.scenario(187,True)
    baseline.update(hand_ids=[1],hand_base_costs=[1],objectives=['guaranteed_hp'],enemy_player_hp=30)
    b=paid.evaluate(baseline,cards);assert b['complete_in_declared_scope']
    assert b['objectives'][0]['metrics']['own_player_hp']==13
    for cid,attack,health in ((187,2,4),(22,2,4),(53,4,3)):
        d=timing.scenario(cid,True);d.update(enemy_player_hp=30,objectives=['guaranteed_hp','purpose'],purpose_constraints=dict(
            min_own_player_hp=13,min_own_body_attack=attack,min_own_body_health=health))
        r=paid.evaluate(d,cards);assert r['complete_in_declared_scope'],r['unknown']
        rows.append(dict(card_id=cid,input=d,result=r,player_hp=r['objectives'][0]['metrics']['own_player_hp'],
            joint_purpose=r['objectives'][1]['purpose_guaranteed'],
            player_hp_increment_over_dummy_only=r['objectives'][0]['metrics']['own_player_hp']-13))
    assert [r['player_hp'] for r in rows]==[13,17,13]
    assert [r['joint_purpose'] for r in rows]==[True,False,True]
    # Candidate absent: no remaining >=2ATK body exists (Dummy0/Tiny1 only).
    d=dict(baseline,objectives=['purpose'],purpose_constraints=dict(min_own_player_hp=1,min_own_body_attack=2,min_own_body_health=2))
    absent=paid.evaluate(d,cards);assert absent['complete_in_declared_scope']
    assert absent['objectives'][0]['purpose_guaranteed'] is False
    independent=dict(
        dummy_hp=4,monster_damage_instances=[1,1,1],gem_damage_instances=[1,1],
        baseline_hp_bounds=[13,13],
        baseline_lower='If Dummy survives, only two spell face hits are possible; if it dies, at least4 of the5 total damage was spent on it, leaving at most1 face damage.',
        baseline_upper='Both Gems target our player, all three monster attacks forced into Dummy. Player loses2, Dummy survives1.',
        candy_common_policy='Play actual Dummy1 now; pay actual Candy3 after natural draw/income at own next start; do not attack with fresh Candy.',
        candy_joint_lower=dict(player_hp=13,same_body_attack=2,same_body_hp=4),
        candy_body_upper='Keep both Gems until Candy is actually played, then pay1+1 to hit it twice. Native6HP ends4; monster attacks go into Dummy.',
        opportunity='Without candidate, the13HP protection is already supplied by Dummy; Candy adds a usable body, not additional13HP.',
        scope='Three1ATK monster attack instances and two1G/1DMG spells in declared two-response window; no callbacks/status/payload multipliers.')
    out=dict(baseline_input=baseline,baseline_result=b,without_candidate_body_result=absent,cases=rows,
        independent_bounds=independent,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('build_packet_hand_structure.py','build_packet_timing.py','paid_board_tactics.py','board_tactics.py')},
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        limits=['Same physical1G defender background, actual price/income/draw capacity; no free setup or average synergy points.',
            'Guarantees are conditional on declared known hand/deck/replies; no carrying-frequency or calibrated Gold.',
            'PlayerHP-only optimum need not win. A available immediate win has priority in actual win-first selection.',
            'Other unknown3G candidates still block a whole-pool champion.'])
    (OUT/'hand-structure.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    lines=['# 手里有防守牌，如何改变携带窗口与贡献','',
        '沿用自然抽牌/实际后续付款场景，但敌玩家设为30HP，明确研究防守与发展而非放弃现成致胜。背景手牌是确实持有的Dummy1G。单持Dummy时玩家HP精确保证13：Taunt4HP吸收最多三个普通1伤，两个1G法术最多造成2脸伤。若敌用法术毁掉Dummy，则至少4总伤投在它身上，仅剩至多1脸伤。双方上下界一致；没有引用核心原语先证明这段。','',
        '| 同一个Dummy背景 | 玩家HP最优 | 相对Dummy单持HP增量 | 独立联合目的 |', '|---|---:|---:|---|',
        '| Candy Dish | 13 | 0 | 玩家≥13且同体≥2ATK/4HP：true |',
        '| Shyren | 17 | +4 | 玩家≥13且同体≥2ATK/4HP：false |',
        '| Napstablook | 13 | 0 | 玩家≥13且同体≥4ATK/3HP：true |','',
        'Candy的一个共同策略是当前付Dummy1，下一己开始真实自然抽牌和赚6后付Candy3。敌三个普通攻击被Taunt吸收；即使两个法术都打后来的6HP Candy，仍留4HP。该策略同时保证玩家13和体4，不能把13全归Candy。移除候选后仍保13HP，但没有≥2ATK身体。','',
        'Shyren用于治疗可增4HP，却无法承诺4HP体；Candy适合厚身体用途。Napstablook晚出后本次己End5→4ATK，防守背景让它保持≥3HP，适合单体4/3站场目的；无背景或早出不能沿用这个结论。每个目的仍独立搜索，HP17不等于胜率高或优于现在能获胜的Ice Cap。','',
        '持有成本应落在手牌槽、当前遗漏的行动、真实部署/现金/防守窗口。不同手牌结构可弥补风险，但要支付它，比较同一背景，并扣其已有贡献。没有通用“等待每回合扣XGold”或固定配合加分。']
    (OUT/'hand-structure.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps([{k:r[k] for k in ('card_id','player_hp','joint_purpose','player_hp_increment_over_dummy_only')} for r in rows]))


if __name__=='__main__':main()