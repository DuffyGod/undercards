"""Legal25-card own main-list components, not a complete deck-vs-deck match.

Keep24 background copies in fixed order; insert the same-cost focal slot at
held, next natural draw, and outside-window positions. Public-known library
is explicit, never presented as a hidden-information policy or real opening.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path

import board_tactics as board
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/deck-components-v01'
COPY_LIMITS={'BASE':3,'COMMON':3,'RARE':3,'EPIC':2,'LEGENDARY':1,'DT':1,'DETERMINATION':1}


def validate_main_list(ids,cards):
    if len(ids)!=25:raise ValueError('Exactly25 physical main-list copies required')
    by={c['id']:c for c in cards}
    for cid,count in Counter(ids).items():
        if cid not in by:raise ValueError('Unknown card ID')
        c=by[cid]
        if c['pool_category']!='ordinary_non_token' or c['card_type']!='monster':
            raise ValueError('This no-SOUL research list admits ordinary monster main cards only')
        if c['rarity'] not in COPY_LIMITS or count>COPY_LIMITS[c['rarity']]:
            raise ValueError('Source-rarity main-list copy limit exceeded')
        if board.compile_card(c)['unknown']:raise ValueError('Unimplemented complete source in selected list')
    return True


def scenario(focal,position,cards):
    #24 real background copies; none is assumed drawn before physical start.
    ids=[196,1,2,602,175,9,377,6]*3
    ids.insert(position,focal);validate_main_list(ids,cards)
    by={c['id']:c for c in cards}
    d=dict(hand_ids=ids[:3],hand_base_costs=[by[c]['cost'] for c in ids[:3]],
        own_deck_ids=ids[3:],gold_before_play=3,next_own_gold_income=3,
        own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
        enemy_bodies=[dict(card_id=15,attack=3,health=3,max_health=5,current_card_cost=5,base_cost=5)],
        opponent_hand_ids=[598,598],opponent_hand_known=True,opponent_gold_before_response=2,
        opponent_deck_ids=[],next_opponent_natural_draw_count=0,next_opponent_gold_income=0,
        next_natural_draw_count=1,max_plays='all_physical',next_max_plays='all_physical',
        horizon='next_enemy_attack',node_limit=60000,objectives=['guaranteed_hp','purpose'],
        purpose_constraints=dict(min_own_player_hp=1,min_own_body_attack=2,min_own_body_health=3))
    return ids,d


def main():
    cards=score_cards.load_cards();rows=[]
    for position in (0,3,10):
        for cid in (187,22,53):
            ids,data=scenario(cid,position,cards)
            a=paid.evaluate(data,cards);x=paid.evaluate(dict(data,search_algorithm='exhaustive'),cards)
            complete=a['complete_in_declared_scope']
            verified=complete and x['complete_in_declared_scope']
            if verified:assert [r['objective_vector'] for r in a['objectives']]==[r['objective_vector'] for r in x['objectives']]
            rows.append(dict(card_id=cid,focal_position=position,main_list_ids=ids,
                main_list_shape_legal=True,input=data,result=a,complete=complete,
                full_vectors_equal=True if verified else None,exhaustive_result=x,
                verification_scope='full vector comparison' if verified else 'exhaustive crosscheck unresolved; retain actual budget/mechanism failure',
                player_hp=a['objectives'][0]['metrics']['own_player_hp'] if complete else None,
                body23=a['objectives'][1]['purpose_guaranteed'] if complete else None))
            print(json.dumps({k:rows[-1][k] for k in ('card_id','focal_position','complete','player_hp','body23')}),flush=True)
    outside=[r for r in rows if r['focal_position']==10]
    if all(r['complete'] for r in outside):
        assert len({json.dumps([o['objective_vector'] for o in r['result']['objectives']]) for r in outside})==1
    # Meaningful input checks: generated spell cannot be a main-card slot,
    # and source EPIC's2-copy cap cannot be silently treated as common3.
    invalid=[([196]*25,'copy'),([196,1,2,602,175,9,377,6]*3+[598],'token/spell'),
        ([196,1,2,602,175,9,377]*3+[53]*3+[6],'epic3')]
    for ids,label in invalid:
        try:validate_main_list(ids,cards)
        except ValueError:continue
        raise AssertionError('Invalid main list accepted: '+label)
    OUT.mkdir(parents=True,exist_ok=True)
    record=dict(cases=rows,stage='legal-main-list-components-in-declared-two-response-subgame',
        whole_match_simulated=False,hidden_information_policy=False,empirical_win_probability=None,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('deck_component_challenge.py','board_tactics.py','paid_board_tactics.py','alpha_beta_search.py')},
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        assumptions=['Own25-card monster main list and rarity copy limits follow stored rules; all selected source text is implemented in this subgame.',
            'Initial3 held copies and their known order are a declared warm-start checkpoint, not a verified starting-hand/mulligan/initiative rule.',
            'Current gold3, next income3, one own natural draw and no enemy added draw/income are explicit controlled window facts.',
            'Enemy Gems are observed generated held spells; they are not placed in either legal initial main list.',
            'Same24 background copies/order and one3G focal slot. No uniform shuffle frequency or real matchup probability is inferred.',
            'All physical copies still require actual drawing, slot capacity and payment. The outside-window slot is not counted as a currently held option.',
            'This is a local component challenge from a legal own list. No complete enemy list, match driver, Soul/artifacts or win-rate tournament.'])
    (OUT/'comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    lines=['# 合法主牌表中的单槽组件挑战','',
        '在全程对战之前，先把候选放入真实25张怪物主牌表（稀有度副本限制），保持24张背景副本及顺序，只替换一个3G槽。当前3张手牌、下一己自然抽1、当前3G/下次收入3G；这些是声明中途检查点，不称标准起手。敌观察Aaron3/3与两张实际生成Gem1G，直到第二敌回应。','',
        '| 槽位置 | 候选 | 玩家HP保证 | 同体≥2攻/3血 | 完整向量与穷举 |', '|---|---|---:|---|---|']
    for r in rows:lines.append(f"| {r['focal_position']} | {r['card_id']} | {r['player_hp']} | {r['body23']} | {r['full_vectors_equal']} |")
    lines+=['','位置0现在持有、3下一自然抽牌才到手、10在这个窗口不可到手。库里的候选不免费成为可选动作；不因不能及时到手而强迫无效出场。完整库、初始手、合法副本、实际抽牌与付款路径均保存；后两列各自优化，不拼成一个保证。','',
        '这把“同一卡位替代”和“从合法主牌表产生到手窗口”连接起来。仍没有全程卡组对战、隐藏信息策略或真实胜率；不知道实际局面/到手频率时保留条件结果。未闭合或超预算行不能填0或写成失败卡。TOKEN/法术主牌与EPIC超额副本拒绝检查另执行。']
    (OUT/'comparison.md').write_text('\n'.join(lines)+'\n')


if __name__=='__main__':main()