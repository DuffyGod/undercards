# 墓地条件、Delay与不同对战目的

2026-10-12。公共入口0.9.0，付费搜索核0.3.0。此次把此前只能来源推演的条件治疗接入实际行动搜索；下面的数值是声明窗口里的物理保证，不是实战频率或通用Gold价格。

## 完整3G桶的条件最优

已纳入全部106张普通3G候选，绑定候选、引用产品及Lost Soul语义池共149来源；以其他候选生命上界与Totemic实际可行搜索共同闭合目标。

共同条件：我3/30HP、空场、3G、唯一候选且印刷/current/base费用均3，身材/状态为无修改源值、非Generated、能力活跃、至多一Play。己墓地恰好三张无修改Rock6，库中恰好无修改Tiny Froggit，无自然抽牌；本回合及上回合无此前己Play/spell。敌玩家30HP、敌手完全为空、无新怪物部署，无SOUL/神器/附魔。更早历史未知，但不能改变已固定区域、源身材或引入未列出的活动对象。

| 敌场 | 全3G桶最优保证HP | 唯一达到者 | 其他候选上界 |
|---|---:|---|---:|
| 6/5 | **8** | Totemic Guard | ≤7 |
| 6/5＋2/3 | **6** | Totemic Guard | ≤3 |

单敌治疗至8后必须撞Taunt；双敌可先用6攻杀来源，再用2攻打脸，因此保证6。102张无活跃玩家增血链；其余包括Shyren、Water Cooler以及Crystal Cheese→Lost Papyrus的间接治疗，都分别限制上界或给致死回应。生成治疗产品也没有被漏作零：是否真正Summon/Play、是否能强迫对手触发Dust逐项核查。[完整来源证明](three-cost-upper-bound-review.md)保留逐卡区间和未知，`three-cost-one_attack/two_attacks.json`附实际搜索及来源校验。

这不是106张整卡状态完整模拟，也不包括有敌法术时的全桶冠军。无buff、空敌手、单Play和墓地条件不可省略：更耐打的Totemic可能挡完两攻；非空敌手可能被Hand Receptionist免费召唤。证书遇到候选、引用产品、语义池、源快照或规则变化会拒绝沿用。

## 已实现的通用机制

怪物完整数值模板 `Delay: If you have N+ C-COST monsters in your hand or dustpile, heal H HP to you.` 及怪物无条件Delay治疗。参数来自源文字，执行没有卡名/ID分支。Play产生独立队列事件；来源提前死亡不撤队列，普通Summon不产生Delay，真正执行后消费一次。玩家已死不继续执行治疗。法术中的Delay仍需独立接入，没有自动当作立即治疗。

墓地输入 `own_dustpile_monsters` 是己方实际怪物对象，接受 `card_id/current_cost/base_cost`，缺少事实保持未知，空牌库不推断墓地为空。普通死亡更新成本记录，重复实体分别计数；召唤支付0不是卡牌COST0。已修改对象跨区保留费用缺裁定，新增记录保留未知。

未选定运行时费用过滤：手牌、墓地分别比较current/base/通常印刷费用，共九种组合；也比较Play入队与回末检查结果。只有相关解释一致才执行。手牌当前费恰等于印刷费不证明基础费没改：不提供`hand_base_costs`时仍未知。手/墓地字段的互相补偿、费用变化造成的检查时点分歧、队列源后来沉默，以及Delay与活跃Turn end竞争均阻止确定评分。这里消除的是列出的裁定分歧，不冒充服务器独立验证。

手牌可逐物理副本声明 `hand_silenced`；出场前已沉默的普通怪物不发动能力、不保留关键词。DT不能声明被沉默。手中已改过的ATK/HP仍不支持：本报告明确使用源身材和观察到的费用。

## 同一七张手牌的可比较结果

手牌固定：Totemic Guard、Shyren、Candy Dish、Dummy、Kawkaw、Tiny Bookshelf、Toriel。共同余额8G，至多一个当前Play，出场与已有友军攻击可交错；双方玩家最大生命30，敌玩家30HP。敌场6/5＋2/3，两个Need已知成立。己方牌库有已知Tiny Froggit；下一攻击回合面板会实际自然抽它。墓地费用均明确观察到为三无修改Rock的current/base/印刷6，第一行减少一个。没有SOUL/神器/附魔、敌怪新部署或未来己方Play。

各首出保留同一完整手牌和余额，枚举所有Magic目标、已有友军先攻击的顺序，以及最坏敌施法/攻击交错。表中是直接`guaranteed_hp`目标，不将胜负优先路线的HP列当独立下界。

| 改动 / 初始生命 | Totemic | Shyren | Candy Dish | Dummy | Kawkaw | Tiny Bookshelf | Toriel |
|---|---:|---:|---:|---:|---:|---:|---:|
| 墓地只有两个6费，3HP，无解牌 | 1 | 0 | 0 | 1 | 1 | 3 | 0 |
| 墓地三个6费，3HP，无解牌 | **6** | 0 | 0 | 1 | 1 | 3 | 0 |
| 同上，敌Punishment＋3G | 0 | 0 | 0 | 0 | 1 | **1** | 0 |
| 10HP，无解牌 | **13** | 6 | 2 | 8 | 8 | 10 | 7 |
| 10HP，付费Punishment | 7 | 6 | 2 | 2 | 8 | **8** | 7 |
| 28HP，无解牌 | 28 | 22 | 20 | 26 | 26 | **28** | 25 |
| 28HP，付费Punishment | 22 | 22 | 20 | 20 | 26 | **26** | 25 |

粗体是该手牌内公开字典序选出的首出；不能扩展为对应费用全池冠军。第一行到第二行仅改变墓地计数，主推荐从Tiny Bookshelf转成Totemic。第二行到第三行仅加实际可支付解牌，又转回来。28HP的治疗最多兑现2HP，双敌最坏顺序还会产生2脸伤，所以Totemic最终28，不能机械地加上5。

单敌版本：无解牌时Totemic条件假/真为3/8HP；条件真但有Punishment时为2HP。双敌有Punishment时治疗至8后被6＋2打脸致死，说明治疗保险没有自动变成惩罚抗性。

## 时窗和目的会改变同一手牌的选择

加入己方已就绪5/5 Aaron，它可先与敌6/5同死；同一3HP/墓地条件下：

- 只到敌攻击窗结束，Totemic可保证8HP，但敌2/3可以停止攻击，不能保证清场。
- 到下一己方攻击回合，未被解掉的Totemic可再攻击2/3；无解牌时能保证8HP并清场。队列不在第二次己方回末重复治疗。
- 有Punishment时，最大保证HP路线仍选Totemic并保证6HP，却不能保证清场；联合“至少3HP且敌存活数0”改选Tiny Bookshelf，保证3HP并清场。目标合取直接搜索，没有拼接两条路线。

另一个控制目的：我10HP、敌12/5＋2/3、敌Punishment＋3G。只最大化HP时Tiny Bookshelf保证8HP，但敌残留14攻击。目的改为“至少7HP且敌残留攻击≤3”，同一手牌改选Toriel：将12攻降至1，最坏7HP、敌残留3攻。多留1HP与减少后续敌场压力是不同目标；当前没有经过实战校准的权重把它们折成Gold。

## 完整当前手牌组合与低成本反例证明

同一3HP/8G七张手牌、墓地三Rock、敌6/5＋2/3及Punishment，放开至多四个当前Play后，精确搜索保证 **12HP**：Totemic3G、Shyren3G、Dummy1G、Kawkaw1G；Shyren治玩家4，Totemic回末治5，Kawkaw把Dummy变1/7 Taunt并麻痹它。两道盾使敌人不能在消耗一次4伤法术和一次攻击后都被清除，故没有剩余攻击能打脸。已兑现的玩家治疗不随来源死亡撤回。这个组合无法由各单牌保命分直接相加得到。

把同一输入扩到下一己方攻击回合，完整向量搜索在20万、50万状态两次耗尽；失败记录保留，没有输出假最优。效率检查据此改用充分反例：遍历所有当前己方路线，给每条路线同一个合法回应“敌不攻击、不施法”。到下一攻击回合，能攻击的己方单位总伤害上界至多7，敌总生命至少8；没有额外伤害/死亡回调或未来Play，因此至少一敌活着。`prove_idle_reply_bound.py`在795个当前状态内证明**不能保证联合清场**。不够用的上界或未知机制返回unknown，不把它们当失败。

这一后续窗口也没有玩家HP回调、疲劳或有能力的自然抽牌，怪物战斗只改变怪物HP。因此已搜索的当前12HP保证可保持到下一攻击终点。这只解决HP分量和联合目标真假，**没有优化完整未来残值向量**，不隐藏原搜索失败，也不赋予某个敌回应发生概率。`multi-play-goal-resolution.json`保存当前搜索、反例上界和HP不变量；初次/提高预算的失败记录单独保留。

## 通用数值反事实

只把Totemic源模板治疗H从5改到4/6，其他卡、输入及代码不变：

| 初始HP，双敌无解牌 | H=4 | H=5 | H=6 | 实际边际 |
|---|---:|---:|---:|---|
| 3 | 5 | 6 | 7 | 每增加1治疗，保证HP增加1 |
| 10 | 12 | 13 | 14 | 同一通用机制，不限低血量 |
| 28 | 28 | 28 | 28 | 都只实际治疗2，受30HP上限约束 |

反事实是明确标注的合成源数值修改，不能沿用旧源证书。来源提前死亡的真实路径为Totemic→Crystal Shard指自己→回末，队列仍治疗5；沉默路径、区域费用字段互相补偿与未知历史则保留unknown。[独立审查](rule-review.md)记录采用与阻断理由，旧探针hash冻结；其两轴“已改费Demon Flowey”路径在加入印刷第三轴后已改为unknown，旧结果不作为现行可靠输入。

## 效率检查及下一缺口

这一轮产生了三种可用变化：此前来源推演的Delay进入可执行搜索；墓地阈值、真实解牌、治疗上限改变了推荐；已有友军与下一攻击回合让保命/清场/控制目的产生明确分歧。没有为旧Gold报价加一个“条件奖励分”，也没把子智能体一致当验证。传统Need、真实付款、Draw/疲劳、死亡与攻击顺序的相关回归继续通过。

场景已加入健康生命、非空库、已有场面、下一自然Draw和攻击回合；仍缺真实场景频率、未知敌手、未来己方Play/收入、SOUL/神器、多数触发与被修改手牌身材。需要把这些真实时机接回已有共同绝对终点的等待/付款模块。位置、显式触发召唤物Magic、Chessboard及Lesser Dog完整兑现仍是实质缺口，不能以本页代替通用构筑评价。

## 复算

```sh
python analysis/monster-value-heuristic/certify_three_fee_rescue.py --panel two_attacks --output /tmp/three-cost-certificate.json
python analysis/monster-value-heuristic/build_delay_history_comparison.py
python analysis/monster-value-heuristic/build_multi_play_goal_resolution.py
python analysis/monster-value-heuristic/evaluate_situation.py --input analysis/monster-value-heuristic/experiments/delay-history-v01/current.input.json --output /tmp/delay-current-result.json
```

`comparison.json`保存全部物理手牌、首出反事实及策略；`current.input/result.json`通过公共API和独立核逐字段对照。以前费用比较目录是此前源码版本的冻结证据，不要求其旧hash等于本轮新源码。本轮verification记录现行源hash与复算；测试通过只证明声明范围内的程序行为，不是服务器规则或实战价值校准。