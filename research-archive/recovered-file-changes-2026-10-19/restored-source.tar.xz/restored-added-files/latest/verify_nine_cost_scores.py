"""Verify current 9G/observation scores, independent bounds and real replay."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import conditional_card_score as score
import score_cards
import verify_research_integration as integration

HERE=Path(__file__).resolve().parent
RUN=HERE/'research-runs/nine-cost-v01'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    bindings=score.source_bindings(Path(__file__));artifacts={}
    for folder,builder in (('nine-cost-v01','build_nine_cost_scores.py'),
            ('frontier-observations-v01','build_frontier_observation_probes.py')):
        out=HERE/'experiments'/folder;index=json.loads((out/'index.json').read_text())
        assert index['source_hashes']==score.source_bindings(HERE/builder) and index['source_stable_during_run']
        for item in index['cases']:
            path=out/item['artifact'];record=json.loads(path.read_text());name=item['case']
            assert sha(path)==index['artifact_hashes'][item['artifact']]
            assert record['source_hashes']==score.source_bindings() and record['source_stable_during_run']
            assert record['config']==json.loads((out/(name+'.input.json')).read_text())
            source=out/(name+'.cards.json')
            cards=json.loads(source.read_text()) if source.exists() else score_cards.load_cards()
            digest=hashlib.sha256(score.canonical(sorted(cards,key=lambda c:c['id'])).encode()).hexdigest()
            assert digest==record['actual_cards_canonical_sha256']
            artifacts[folder,name]=record
        view=json.loads((out/'view-provenance.json').read_text())
        assert view['output_sha256']==sha(out/'score-explorer.html')
        assert view['source_hashes']=={'build_conditional_score_view.py':sha(HERE/'build_conditional_score_view.py')}
    # Check the independent proof domain, not just agreement of output numbers.
    for (folder,name),record in artifacts.items():
        scene=record['config']['scene']
        assert scene['own_player_hp']==15 and scene['enemy_player_hp']==30
        if name.startswith('four-hp') or name.startswith('right-'):
            expected_hp=3 if name.startswith('four-hp3') else 2
            assert len(scene['enemy_bodies'])==4 and not scene['opponent_hand_ids']
            assert all(b['card_id']==270 and b['attack']==4 and b['health']==expected_hp
                and b['max_health']==4 for b in scene['enemy_bodies'])
        if name.startswith('fatigue1-'):
            assert scene['own_deck_ids']==scene['opponent_deck_ids']==[]
            assert scene['own_fatigue_next']==scene['opponent_fatigue_next']==1
            assert scene['opponent_hand_ids']==[598,598] and scene['opponent_gold_before_response']==2
            assert len(scene['enemy_bodies'])==1 and scene['enemy_bodies'][0]['health']==4
    subprocess.run([sys.executable,str(RUN/'independent_bounds.py')],cwd=HERE,capture_output=True,text=True,check=True)
    independent=json.loads((RUN/'independent-bounds.json').read_text())
    assert independent['script_sha256']==sha(RUN/'independent_bounds.py')
    assert independent['no_production_module_imports'] and len(independent['checks'])==41
    cli=[]
    out=HERE/'experiments/nine-cost-v01'
    for name in ('four-hp3-threshold3','robot-punishment-decay96'):
        target=RUN/(name+'.cli.json')
        command=[sys.executable,str(HERE/'conditional_card_score.py'),'--input',str(out/(name+'.input.json')),
            '--cards-source',str(out/(name+'.cards.json')),'--output',str(target)]
        done=subprocess.run(command,cwd=HERE,capture_output=True,text=True,check=True)
        assert json.loads(target.read_text())==artifacts['nine-cost-v01',name]
        cli.append(dict(case=name,actual_alternative_source_cli_complete_json_equal=True,output_sha256=sha(target)))
    receipt=json.loads((RUN/'selective-regression.json').read_text())
    assert receipt['passed'] and receipt['source_unchanged_during_run']
    assert receipt['source_hashes']==integration.regression_sources()
    assert all(sha(HERE/name)==digest for name,digest in receipt['source_hashes'].items())
    assert bindings==score.source_bindings(Path(__file__))
    for folder in ('nine-cost-v01','frontier-observations-v01'):
        subset=[r for r in independent['checks'] if (folder,r['case']) in artifacts]
        index=json.loads((HERE/'experiments'/folder/'index.json').read_text())
        result=dict(source_hashes=bindings,source_stable_during_run=True,cases=len(index['cases']),
            candidate_context_rows=index['candidate_context_rows'],independent_bounds_sha256=sha(RUN/'independent-bounds.json'),
            independent_values=len(subset),complete_vector_checks=len(index['full_vector_checks']),
            alternative_source_actual_cli=cli if folder=='nine-cost-v01' else [],
            regression=dict(actual_tests=receipt['test_count'],seconds=receipt['runner_seconds'],
                source_identical_baseline_tests=sum(m['test_count'] for m in receipt['reused_unchanged']),
                current_source_coverage=receipt['current_source_test_coverage'],receipt_sha256=sha(RUN/'selective-regression.json')),
            limits=['Declared finite-window guarantees only; no real scene frequencies, server layout evidence, global Gold or whole-pool champion.'])
        (HERE/'experiments'/folder/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(artifacts=len(artifacts),independent_values=41,alternative_cli=2,
        actual_tests=receipt['test_count'],current_coverage=receipt['current_source_test_coverage'])))


if __name__=='__main__':main()