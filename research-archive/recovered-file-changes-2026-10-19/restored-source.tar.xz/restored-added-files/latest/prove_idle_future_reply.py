"""Exact future-action counterstrategy, not a whole-match optimality claim.

Fix enemy's legal idle reply, enumerate ALL own actions in the declared two
turns. If none meet the conjunction, this one strategy refutes a guarantee.
Finding a winning own route only makes this particular counterstrategy fail.
"""
from functools import lru_cache
import hashlib
from pathlib import Path
import re
import board_tactics as board
import finite_conditions
import paid_board_tactics as paid
import score_cards


def prove_damage_bound(data, cards=None):
    """Sufficient bound when all future Plays add zero attack/damage capacity.

    Each existing eligible attacker can deal at most its ATK once. Ordinary
    new bodies cannot attack this turn. Healing, enemy ATK reduction, a new
    source's own ATK buff, and buff+Paralyze cannot increase that upper bound.
    Reject every other future effect, including spells, speed and callbacks.
    """
    cards=score_cards.load_cards() if cards is None else cards
    engine=paid.PaidSearch(cards,data);root=engine.root()
    if engine.horizon!='next_own_attack' or not engine.next_max_plays:
        raise ValueError('Future own Play window required')
    if not engine.purpose or engine.purpose.get('max_enemy_living_count')!=0:
        raise ValueError('Conjunction must require clearing every enemy monster')
    unknown=list(engine.unknown);seen=set();leaves=[];checked_cards=set()
    allowed={'heal_any','toriel','self_atk_taunt','buff_paralyze','draw'}

    def future_capacity(endpoint):
        potential=set(endpoint.hand)
        # Only inspect additional library identities if a reachable future
        # Magic can draw. This is a safe overapproximation, not free deployment.
        future_draw=any(engine.hand_spec(*engine.hand[i],endpoint).get('magic',()) and
               engine.hand_spec(*engine.hand[i],endpoint)['magic'][0] in paid.DRAW_MAGIC_KINDS for i in potential)
        if future_draw:
            if endpoint.own_deck is None:
                raise paid.UnknownMechanic('Future draw identity unknown for damage bound')
            potential.update(endpoint.own_deck)
        for i in potential:
            c,cached=engine.hand[i];spec=engine.hand_spec(c,cached,endpoint)
            checked_cards.add(c['id'])
            need=finite_conditions.parse_need(c.get('effect_readable',''))
            if future_draw and need and need['kind'].startswith('deck_'):
                raise paid.UnknownMechanic('Future draw can change a deck Need and its hidden damage branch')
            if c['card_type']!='monster' or spec['unknown']:
                raise paid.UnknownMechanic('Future card '+str(c['id'])+' lacks a closed zero-additional-damage proof')
            magic=spec.get('magic')
            if spec['statuses']['speed'] or spec.get('dust') or spec.get('start') or spec.get('end') or spec.get('before_attack_face') or (magic and magic[0] not in allowed):
                raise paid.UnknownMechanic('Future card '+str(c['id'])+' can add damage/attack or has unbounded callbacks')
            if i in (endpoint.own_deck or ()) and re.search(r'\bTurbo\b|(?:After|When|Whenever).*draw|in (?:your )?hand',c.get('effect_readable',''),re.I):
                raise paid.UnknownMechanic('Future draw/hand callback is outside the damage bound')

    def visit(s):
        if s in seen:return
        seen.add(s)
        if len(seen)>engine.node_limit:raise paid.UnknownMechanic('Current route damage-bound state budget exhausted')
        if engine.terminal(s):
            if s.own_hp<=0:return
            raise paid.UnknownMechanic('A current route ends game; nonterminal damage bound insufficient')
        endpoint=engine.boundary(engine.boundary(s))
        if endpoint.phase!=2 or engine.terminal(endpoint):
            raise paid.UnknownMechanic('Idle reply does not reach a live own future phase')
        living=[u for u in endpoint.own if u.health>0]
        if any(u.dust or u.end or u.before_attack_face for u in living):
            raise paid.UnknownMechanic('Existing future callback can invalidate the attack bound')
        if any(u.damaged_attack_bonus for u in living):
            raise paid.UnknownMechanic('Damaged ATK can increase inside future combat/events; simple damage bound is unverified')
        future_capacity(endpoint)
        attack=sum(board.effective_attack(u,endpoint,'own') for u in living if u.ready and not u.attacked and not u.paralyze_owner_starts_remaining)
        health=sum(u.health for u in endpoint.enemy if u.health>0)
        if attack>=health:raise paid.UnknownMechanic('Damage bound is insufficient to refute clear')
        leaves.append((attack,health))
        for _,child in list(engine.attacks(s))+list(engine.deploys(s)):visit(child)

    if not unknown:
        try:visit(root)
        except paid.UnknownMechanic as error:unknown.append(str(error))
    complete=not unknown and bool(leaves)
    here=Path(__file__).resolve().parent
    return dict(bound_complete=complete,unknown=unknown,
        any_policy_can_guarantee_purpose=False if complete else None,
        counterstrategy='Enemy ends without optional attacks/casts; future Plays add zero to the proved damage upper bound.',
        current_own_states=len(seen),checked_endpoints=len(leaves),checked_future_card_ids=sorted(checked_cards),
        max_eligible_attack_upper=max((a for a,h in leaves),default=None),
        min_enemy_health_required=min((h for a,h in leaves),default=None),input=data,
        source_hashes={f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in
            ('prove_idle_future_reply.py','paid_board_tactics.py','queued_delay.py','board_tactics.py')},
        limitations=['Sufficient negative damage bound for the full declared future-Play menu, not an HP optimum.',
            'Unpaid ordinary new bodies are never credited as attackers; every potentially drawn identity is checked when future draw exists.',
            'Speed, direct damage, spells or live extra callbacks make this particular bound unknown, not a negative guarantee.'])


def prove(data, cards=None):
    cards=score_cards.load_cards() if cards is None else cards
    engine=paid.PaidSearch(cards,data); root=engine.root()
    if engine.horizon != 'next_own_attack' or not engine.purpose:
        raise ValueError('Explicit next-turn conjunctive purpose required')
    unknown=list(engine.unknown);counts={0:0,1:0,2:0,3:0}; endpoints=0
    witness=[]

    @lru_cache(maxsize=None)
    def visit(s):
        nonlocal endpoints
        counts[s.phase]+=1
        if sum(counts.values())>engine.node_limit:
            raise paid.UnknownMechanic('Idle future counterstrategy state budget exhausted')
        if engine.terminal(s) or s.phase==3:
            endpoints+=1
            return bool(engine.objective(s,'purpose')[0])
        if s.phase==1:
            return visit(engine.boundary(s))  # Legal stop: no optional attack or cast.
        actions=[(dict(kind='end_turn',phase=s.phase),engine.boundary(s))]
        actions.extend(engine.attacks(s));actions.extend(engine.deploys(s))
        for action,child in actions:
            if visit(child):
                witness.append(action)
                return True
        return False

    possible=None
    if not unknown:
        try: possible=visit(root)
        except paid.UnknownMechanic as error: unknown.append(str(error))
    complete=not unknown and possible is not None
    here=Path(__file__).resolve().parent
    return dict(bound_complete=complete and not possible,unknown=unknown,
        any_policy_can_guarantee_purpose=False if complete and not possible else None,
        own_route_satisfies_purpose_against_idle=possible if complete else None,
        counterstrategy='Enemy ends its turn without optional attacks or casts, for every own route.',
        purpose_constraints=engine.purpose,visited_states=sum(counts.values()),
        phase_states=counts,checked_terminal_states=endpoints,
        witness_against_idle=list(reversed(witness)) if possible else [],input=data,
        source_hashes={f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in
            ('prove_idle_future_reply.py','paid_board_tactics.py','queued_delay.py','board_tactics.py')},
        limitations=['Exact declared own actions, payment, draw and callbacks against ONE legal enemy strategy.',
            'Negative result refutes the conjunction. A positive route against idle cannot establish a guarantee against other replies.',
            'Unknown or budget exhaustion withdraw the bound. No probabilities or scalar card values.'])