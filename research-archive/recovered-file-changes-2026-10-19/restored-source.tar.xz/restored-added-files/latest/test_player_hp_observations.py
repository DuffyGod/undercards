import unittest
import paid_board_tactics as paid


class PlayerHpObservationTests(unittest.TestCase):
    def test_omitted_maximum_is_disclosed_and_changes_a_real_heal_decision(self):
        data=dict(hand_ids=[22],gold_before_play=3,own_player_hp=3,max_plays=1,
            enemy_bodies=[dict(card_id=15,attack=6,health=5)],
            horizon='enemy_attack',objectives=['guaranteed_hp'])
        assumed=paid.evaluate(data)
        self.assertTrue(assumed['complete_in_declared_scope'])
        self.assertEqual(assumed['player_hp_caps']['own']['input_assumption'],'maximum_equals_current_hp')
        self.assertEqual(assumed['objectives'][0]['metrics']['own_player_hp'],0)
        observed=paid.evaluate(dict(data,own_player_max_hp=30))
        self.assertEqual(observed['objectives'][0]['metrics']['own_player_hp'],1)
        self.assertTrue(observed['player_hp_caps']['own']['explicitly_supplied'])
        self.assertIsNone(observed['player_hp_caps']['own']['input_assumption'])

    def test_direct_transition_cannot_play_healing_after_lethal_self_damage(self):
        engine=paid.PaidSearch(paid.score_cards.load_cards(),dict(hand_ids=[598,22],gold_before_play=4,
            own_player_hp=1,own_player_max_hp=30,max_plays=2,
            ally_bodies_before_play=[dict(card_id=2,attack=2,health=3)]))
        dead=next(s for a,s in engine.casts(engine.root(),'own') if a['targets']==[('own_player',None)])
        self.assertEqual(dead.own_hp,0)
        self.assertEqual(list(engine.deploys(dead)),[])
        self.assertEqual(list(engine.casts(dead,'own')),[])
        self.assertEqual(list(engine.attacks(dead)),[])
        self.assertEqual(engine.draw(dead,1),dead)


if __name__=='__main__':unittest.main()