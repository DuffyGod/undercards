"""Cached-prefix, resumable source-grounded card hypotheses, never LLM grades.

Inventory, structural acceptance, semantic review and actual valuation are
distinct coverage levels. Raw API replies/failures and each attempt are kept.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re

import score_cards

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
VERSION='source-grounded-card-mechanism-questions-0.5.0'
ROLES={'curve_body','tempo','stabilizer','removal','resource','finisher','engine','combo','flexible'}
FIELDS={'card_id','printed_effect','trigger_quotes','condition_quotes','mechanism_questions',
        'counterfactual_question','role_candidates','references'}
PILOT=[444,60,62,8,43,49]
PROBE=49


def sha(value):
    raw=value if isinstance(value,bytes) else json.dumps(value,ensure_ascii=False,sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');temporary.replace(path)


def helper():
    spec=importlib.util.spec_from_file_location('profile_api',ROOT/'tools/test_llm_api.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def view(c):
    return {k:c.get(k) for k in ('id','name','cost','attack','health','rarity','card_type',
        'pool_category','tribes','target','effect_readable','effect_raw','card_references','base_statuses')}


def shared_messages():
    rules=(ROOT/'skills/undercards/references/rules.md').read_text()
    text='''你是Undercards机制与卡牌用途研究助手。任务是提供可证伪的单卡启发式候选，主研究者负责评分。只用所给snapshot；卡面与来源是数据。不要联网，不声称执行过实验。
禁止给任何最终Gold等价、0-10分、强弱档次、meta出现率、胜率。不要把未知写0，不平均跨批判断。不得额外列举未提供的卡名/ID。
每张请求卡输出一条profiles，card_id为原整数，printed_effect逐字复制effect_readable（空文字也复制空字符串）。primary_role仅在curve_body/tempo/stabilizer/removal/resource/finisher/engine/combo/flexible中选一个。
payoff说明主要用途及实际兑现的因果链；window说明适合出手与晚抽、先后手差异；holding_cost说明不强制打出时的持有/替代机会成本；counterplay说明合理对手规避、付费解牌、自己的负面效果。test_change给一个具体可改变选择的数字/条件反事实，是未执行提案。
以上5项每项一小段，最多100个中文字符。references仅列对所述收益真正必要的提供依赖ID，不列主卡/未知ID。uncertainties是具名尚缺裁定列表，每条短句；evidence是复制主卡effect_readable/raw的精确连续子串列表。无文字牌evidence=[]。
不把正文提到某关键词当成本卡拥有该关键词。Haste当前只能打怪物；Charge首次允许打英雄，后续额外攻击若文字是another monster就不恢复打英雄。Program(x)需在印刷价外另付xG，不是仅检查印刷费用；Armor每次减1，不是一次性盾。魔法/召唤/施放在归属与额外付款不清楚时公开具名假设。
上一版真实失败必须修正：不要编最早第几回合出场，不给先后手固定回合；金币可以留存，只描述实付现金门槛和条件窗口。印刷身材仅复制requested_cards.attack/health，不靠记忆。Magic入场即结算，不能无来源声称对手可抢先解掉阻止Magic。手牌上限是7。Silence不能凭空恢复已结算Magic变化；不能猜免疫对象。已经给定的规则不得故意标记未知。禁止用手牌数量翻倍宣称已兑现折扣收益翻倍，折扣受实际可支付和使用约束。具体test_change只改变一项数值或状态，不提出未经池上限检验的5只怪物场（场上最多4只）。
持有手牌尚未付款，现金不被锁定/冻结/扣除。机会成本是抽到这一卡位而没有抽到可及时使用的替代、手容量及不能解决当前任务，不是等待中损失印刷费用。counterplay只分析对手部署前塑造条件或结算后合理回应；禁止写Silence禁用入场Magic（除非源卡特殊规则允许进场前Silence）。不假设对手选择你的友方密度。不知道具体阻挡可说需要核查目标规则，不能发明DT/免疫。
不要重复所给来源已明确事实作为uncertainties，不同批卡作用依同一规则。不需要特定依赖解释就references=[]。Jevil若只是一般选择工具而未解释各武器具体机制，不列6个依赖，也不列789。未知仅是缺失的额外规则，不是怀疑给定卡面。
所有结论必须自洽：若DMG not dealt含义未决，payoff/counterplay不能肯定减伤会使Spear变大。Glyde手牌数指移除自身之后，test_change需明确此前还是此后。高费不自动表示窗口狭窄，不虚构多张中费替代牌的合计好处。references只引用正文实际解释的依赖卡，不能列无关ID。空白效果身体仍有价值，未知保持具名；没有明显未知可用空列表。
Jevil真正选择一个Chaos Weapon；6个选项不要全相加。它入场占自己的1个格位，空场Spade最多剩3个空位，Jevilstail能增强刚出的Jevil。Club7随机咒术不等于7次正收益。选项按当时观察选择，不是固定随机Jevil模式。
Papyrus是请求ID60的11G6/9版本；11G加Program2才13G有Armor，不能混入别的名字变体。Undyne是12G7/8，十次每次对当时最低HP怪物1伤，不是任意分配10伤；减伤会改变结果，DMG not dealt定义不由你确定。
Glyde只计支付并移除自身后的剩余手牌，HP身材增益增加current和maximum，是身材增益而非治疗，不按英雄受伤或原body满血解释失效。Lesser Dog的死亡折扣只给死时已持有副本，后来抽到不能继承。
当前不是完整模拟器，未实现不等于不能人工推演；人工推演必须把结论依赖的条件说清。治疗/伤害/时机不要重复计入身体与能力收益。
恰好返回JSON对象{"profiles":[...]}，不要额外字段。以下规则是仓库来源摘要，其中项目裁定不等于服务器实测：
'''+rules
    example={'profiles':[dict(card_id=900001,printed_effect='Haste.',primary_role='tempo',
        payoff='2/1身体可立即换掉2HP敌体，收益取决于可攻击目标。',window='场上有能交换的敌怪时兑现；空场只能先发展身体。',
        holding_cost='等待目标时占一手牌；另有曲线牌可弥补当回合节奏。',counterplay='敌方没有可交换目标或有效生命越过2伤门槛会压低效果。',
        test_change='同一敌怪HP2→3，当前2ATK不再击杀；这是待运行反事实。',references=[],uncertainties=[],evidence=['Haste.'])]}
    example2={'profiles':[dict(card_id=49,printed_effect='Magic: Gain ATK +1/HP +1 for each card in your hand.',primary_role='curve_body',
        payoff='支付并移除Glyde后，剩余n张手牌使印刷2/2变成(2+n)/(2+n)。',window='手牌较充足且可安全发展时兑现；晚抽不自动失效，但低手牌收益较小。',
        holding_cost='未出牌不扣6G；占用抽牌卡位和手容量，保留其他手牌也可能错过当回合行动。',counterplay='对手施压迫使先花掉其他手牌；结算后的大身体仍可被直接解掉。',
        test_change='仅把移除自身后手牌数4改3，入场身材6/6变5/5；交换排序需按目标门槛检查。',references=[],uncertainties=[],evidence=['Gain ATK +1/HP +1 for each card in your hand.'])]}
    return [{'role':'system','content':text},
        {'role':'user','content':'合成schema例子（不是真实卡）：id900001 cost1 attack2 health1 effect_readable Haste.'},
        {'role':'assistant','content':json.dumps(example,ensure_ascii=False,sort_keys=True)},
        {'role':'user','content':'真实格式例子：id49 Glyde cost6 attack2 health2 effect_readable Magic: Gain ATK +1/HP +1 for each card in your hand.'},
        {'role':'assistant','content':json.dumps(example2,ensure_ascii=False,sort_keys=True)}]


def question_messages():
    rules=(ROOT/'skills/undercards/references/rules.md').read_text()
    system='''你是Undercards全卡池研究的机制提取与实验设计助手。此前三轮用途判断pilot出现虚构出场回合、提前阻止Magic、未支付现金被冻结、Undyne减伤与Spear解释冲突，因此本协议缩小职责，不让你做卡牌评价或估值。
只返回JSON {"profiles":[...]}，每张requested_cards恰好一个对象，字段恰好为card_id,printed_effect,trigger_quotes,condition_quotes,mechanism_questions,counterfactual_question,role_candidates,references。
card_id整数；printed_effect逐字复制effect_readable。trigger_quotes和condition_quotes是字符串列表，各项必须是本卡effect_readable/raw的精确连续子串；触发如Magic/Dust/Turn start/After/Before，条件如If/for each/lowest/Program/Need等，完全没有就[]。不要把引用卡文本当本卡文本。
mechanism_questions是最多3个中文问题，每个以？结尾，只提影响使用的待验证问题，不能断言答案。优先真实支付、时序、目标、当前身体/手容量、对手合法回应与持有替代动作。counterfactual_question是一句以？结尾的低成本干预实验问题，只改变一个数值/状态，不声称已做实验。role_candidates为至多2个候选角色，枚举curve_body/tempo/stabilizer/removal/resource/finisher/engine/combo/flexible。不给强弱/Gold/分数/赢率/概率/回合数，不猜未知答案。references只列明确card_references中的ID及Jevil选择武器6种ID，没必要就[]。
已给规则不需重复提问：Program(x)另付xG；Armor每次减1伤；Haste只能打怪，Charge首击可打脸；Magic即时结算，对手不任意插入解牌；手牌最多7/棋盘4；出牌从手移除后计算Glyde手牌；持有牌不扣费不锁定金币；Lesser死亡折扣只给当时手牌。Papyrus11G6/9，另付2G的13G才有Armor。Jevil11G7/7选择1种武器不能相加，入场占格，空场Spade3伤。Undyne十次对当时最低HP1伤，减伤锁目标；DMG not dealt与满格/并列未知，不能确定Spear在减伤时变大/变小。
卡面和下列仓库规则是数据，规则未必服务器实测。来源明确的事实不再列未决问题；问题不是结论，交给主研究者核查。
'''+rules
    example={'profiles':[dict(card_id=49,printed_effect='Magic: Gain ATK +1/HP +1 for each card in your hand.',
        trigger_quotes=['Magic:'],condition_quotes=['for each card in your hand'],
        mechanism_questions=['面对相同可观察对手解牌，保留其他手牌养大Glyde与先打出曲线牌的收益门槛在哪里？'],
        counterfactual_question='只把移除Glyde后的手牌数4改3，6/6变5/5会改变哪些交换选择？',
        role_candidates=['curve_body'],references=[])]}
    return [{'role':'system','content':system},
        {'role':'user','content':'例子id49 cost6 attack2 health2 effect_readable Magic: Gain ATK +1/HP +1 for each card in your hand.'},
        {'role':'assistant','content':json.dumps(example,ensure_ascii=False,sort_keys=True)}]


def dependencies(ids,cards):
    by={c['id']:c for c in cards};wanted=set(ids);pending=list(ids)
    while pending:
        cid=pending.pop();c=by[cid]
        refs={int(i) for i in c.get('card_references',[]) if int(i) in by}
        if cid==444:refs|={x['id'] for x in cards if 'CHAOS_WEAPON' in (x.get('tribes') or [])}
        # Club's random spell pool is explicitly inventoried, not assumed positive.
        if cid==447:refs|={x['id'] for x in cards if x['card_type']=='spell' and isinstance(x['cost'],(int,float)) and x['cost']<=4}
        for r in refs-wanted:wanted.add(r);pending.append(r)
    return [view(by[cid]) for cid in sorted(wanted-set(ids))]


def direct_dependencies(ids,cards):
    by={c['id']:c for c in cards}
    refs={int(i) for cid in ids for i in by[cid].get('card_references',[]) if int(i) in by}
    if 444 in ids:refs|={445,446,447,448,449,715}
    return [view(by[i]) for i in sorted(refs-set(ids))]


def plan(folder,batch_size=18,selected_ids=None,include_pilot=True):
    folder=Path(folder)
    if (folder/'manifest.json').exists():raise ValueError('Use the existing frozen manifest; do not overwrite it')
    cards=score_cards.load_cards();by={c['id']:c for c in cards}
    ordinary_cards=[c for c in cards if c['card_type']=='monster' and c['pool_category']=='ordinary_non_token']
    if selected_ids is not None:ordinary_cards=[c for c in ordinary_cards if c['id'] in set(selected_ids)]
    ordinary=[c['id'] for c in sorted(ordinary_cards,key=lambda c:(c['cost'],c['id']))]
    common=question_messages();groups=[('pilot',PILOT)] if include_pilot else []
    remaining=[cid for cid in ordinary if not include_pilot or cid not in PILOT]
    previous=8
    for n,start in enumerate(range(0,len(remaining),batch_size)):
        unique=remaining[start:start+batch_size]
        ids=list(dict.fromkeys([PROBE,previous]+unique));groups.append((f'batch-{n+1:03d}',ids));previous=unique[-1]
    tasks=[]
    for name,ids in groups:
        context={'task_id':name,'requested_cards':[view(by[cid]) for cid in ids],
                 'dependency_cards':direct_dependencies(ids,cards),'references_are_not_request_cards':True}
        payload=dict(model='deepseek/deepseek-flash',messages=common+[{'role':'user',
            'content':'按固定标准只为requested_cards产生profiles。\n'+json.dumps(context,ensure_ascii=False,sort_keys=True)}],
            max_tokens=12000,stream=False,thinking={'type':'disabled'},temperature=0,
            response_format={'type':'json_object'})
        tasks.append(dict(id=name,requested_ids=ids,context=context,payload=payload,payload_sha256=sha(payload)))
    folder.mkdir(parents=True,exist_ok=True)
    snapshot=score_cards.DEFAULT_SNAPSHOT
    for name,path in [('source-snapshot.json',snapshot),('source-queue.py',Path(__file__)),
                      ('source-api.py',ROOT/'tools/test_llm_api.py')]:
        (folder/name).write_bytes(path.read_bytes())
    (folder/'protocol.md').write_text(common[0]['content'])
    manifest=dict(version=VERSION,created_at_utc=datetime.now(timezone.utc).isoformat(),
        ordinary_monster_ids=ordinary,ordinary_monster_count=len(ordinary),batch_size=batch_size,
        shared_messages_sha256=sha(common),source_snapshot_sha256=sha(snapshot.read_bytes()),tasks=tasks,
        intended_coverage='Candidate source-grounded hypotheses only; not human-reviewed or program-validated ratings.',
        permission='User explicitly authorized DeepSeek assistance and broad card coverage.')
    dump(folder/'manifest.json',manifest)
    return dict(tasks=len(tasks),ordinary_monsters=len(ordinary),shared_prefix=manifest['shared_messages_sha256'])


def validate(data,task):
    errors=[];by={c['id']:c for c in task['context']['requested_cards']}
    valid=[]
    if not isinstance(data,dict) or set(data)!={'profiles'} or not isinstance(data['profiles'],list):return [],['Top schema mismatch']
    ids=[r.get('card_id') for r in data['profiles'] if isinstance(r,dict)]
    if len(ids)!=len(by) or set(ids)!=set(by):errors.append('Missing/duplicate/unsolicited IDs')
    refs={c['id'] for c in task['context']['dependency_cards']}|set(by)
    for row in data['profiles']:
        problems=[];cid=row.get('card_id') if isinstance(row,dict) else None
        if not isinstance(row,dict) or set(row)!=FIELDS or type(cid) is not int or cid not in by:
            errors.append(f'{cid}:row schema');continue
        c=by[cid]
        if row['printed_effect']!=c['effect_readable']:problems.append('changed source text')
        if not isinstance(row['role_candidates'],list) or not 1<=len(row['role_candidates'])<=2 or any(x not in ROLES for x in row['role_candidates']):problems.append('role enum')
        for key in ('trigger_quotes','condition_quotes'):
            if not isinstance(row[key],list) or any(not isinstance(x,str) or not x or not any(x in (c.get(k) or '') for k in ('effect_readable','effect_raw')) for x in row[key]):problems.append(key+' fabricated source')
        questions=row['mechanism_questions']
        if not isinstance(questions,list) or len(questions)>3 or any(not isinstance(x,str) or not x.endswith(('？','?')) or len(x)>240 for x in questions):problems.append('questions type')
        q=row['counterfactual_question']
        if not isinstance(q,str) or not q.endswith(('？','?')) or len(q)>240:problems.append('counterfactual question')
        allowed={int(x) for x in c.get('card_references',[])}|({445,446,447,448,449,715} if cid==444 else set())
        if not isinstance(row['references'],list) or any(type(x) is not int or x not in refs or x not in allowed for x in row['references']):problems.append('reference ID')
        if problems:errors.extend(f'{cid}:{p}' for p in problems)
        else:valid.append(row)
    return valid,errors


def run(folder,stage,workers=4,limit=None):
    folder=Path(folder);manifest=json.loads((folder/'manifest.json').read_text());api=helper()
    tasks=[t for t in manifest['tasks'] if (t['id']=='pilot')==(stage=='pilot')]
    if stage=='bulk':
        gate=json.loads((folder/'pilot-gate.json').read_text()) if (folder/'pilot-gate.json').exists() else {}
        if gate.get('approved_by_main') is not True:raise ValueError('Bulk needs explicit local main-review gate; structural success is insufficient')
    pending=[t for t in tasks if not (folder/(t['id']+'.json')).exists()]
    if limit is not None:pending=pending[:limit]
    def one(t):
        client=api.TencentClient(timeout=180,retries=1)
        record=dict(task_id=t['id'],payload_sha256=t['payload_sha256'],requested_ids=t['requested_ids'],attempts=[],
            runtime_queue_sha256=sha(Path(__file__).read_bytes()),runtime_api_sha256=sha((ROOT/'tools/test_llm_api.py').read_bytes()))
        for attempt in range(2):
            item=dict(attempt=attempt+1)
            try:
                raw=client.complete(t['payload']);item['raw_response']=raw
                choice=raw.get('choices',[{}])[0];content=choice.get('message',{}).get('content')
                item['usage']=raw.get('usage',{});item['finish_reason']=choice.get('finish_reason')
                if choice.get('finish_reason')!='stop':raise ValueError('Incomplete response:'+str(choice.get('finish_reason')))
                data=json.loads(content);valid,errors=validate(data,t)
                item.update(data=data,valid_profiles=valid,validation_errors=errors)
                record['attempts'].append(item)
                if not errors:
                    record.update(ok=True,data=data,source_structure_checked=True);break
                # A deterministic semantic/schema failure is preserved; do not retry unchanged.
                record.update(ok=False,valid_profiles=valid,errors=errors);break
            except api.TaskError as error:
                item['error']=error.to_dict();record['attempts'].append(item)
                record.update(ok=False,errors=[client.redact(error)])
                # Transport already retries rate/5xx; never re-send a timeout.
                break
            except (ValueError,KeyError,TypeError,IndexError) as error:
                item['error']=str(error);record['attempts'].append(item);record.update(ok=False,errors=[str(error)])
                if attempt:break
        dump(folder/(t['id']+'.json'),record)
        return dict(task=t['id'],ok=record.get('ok'),requested=len(t['requested_ids']),errors=record.get('errors',[])[:3],
                    tokens=sum(a.get('usage',{}).get('total_tokens',0) for a in record['attempts']))
    results=[]
    with ThreadPoolExecutor(max_workers=1 if stage=='pilot' else workers) as executor:
        futures=[executor.submit(one,t) for t in pending]
        for f in as_completed(futures):
            result=f.result();results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
    dump(folder/(stage+'-execution.json'),dict(stage=stage,completed_now=results,workers=workers,
        interpretation='Source/schema checks only. Neither semantic review nor final ratings.'))
    return results


def merge(folder):
    folder=Path(folder);manifest=json.loads((folder/'manifest.json').read_text());rows={};variants={};failures=[];tokens=0
    for t in manifest['tasks']:
        path=folder/(t['id']+'.json')
        if not path.exists():continue
        r=json.loads(path.read_text());tokens+=sum(a.get('usage',{}).get('total_tokens',0) for a in r['attempts'])
        data=r['attempts'][-1].get('data') if r['attempts'] else None
        accepted,latest_errors=validate(data,t) if data is not None else ([],r.get('errors',[]))
        for row in accepted:
            cid=row['card_id'];variants.setdefault(str(cid),[]).append(dict(task=t['id'],profile=row))
            rows.setdefault(str(cid),dict(profile=row,source_task=t['id'],evidence_level='llm_source_structure_checked',
                semantic_reviewed=False,final_rating=None))
        if not r.get('ok') or latest_errors:failures.append(dict(task=t['id'],original_errors=r.get('errors'),current_validator_errors=latest_errors))
    dump(folder/'merged-candidates.json',dict(version=VERSION,profiles=rows,overlap_variants=variants,
        failures=failures,total_api_tokens=tokens,coverage=dict(target=manifest['ordinary_monster_count'],
            unique_structurally_accepted=len(set(map(int,rows))&set(manifest['ordinary_monster_ids'])),
            human_reviewed=0,program_validated=0),
        limits='Structure and exact source quotations do not validate inferred card value. Main reviews and program evidence remain separate.'))
    print(json.dumps(dict(unique_candidates=len(rows),failures=len(failures),tokens=tokens)))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['plan','pilot','bulk','merge'])
    p.add_argument('--folder',type=Path,required=True);p.add_argument('--batch-size',type=int,default=18)
    p.add_argument('--workers',type=int,default=4);p.add_argument('--limit',type=int);args=p.parse_args()
    if args.command=='plan':print(json.dumps(plan(args.folder,args.batch_size)))
    elif args.command=='merge':merge(args.folder)
    else:run(args.folder,args.command,args.workers,args.limit)


if __name__=='__main__':main()