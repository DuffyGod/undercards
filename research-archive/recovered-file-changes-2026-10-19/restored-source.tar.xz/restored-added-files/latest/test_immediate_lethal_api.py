import copy
import unittest

import build_immediate_lethal_api as comparison
import certify_immediate_lethal as certificate
import evaluate_situation
import paid_board_tactics as paid
import score_cards


class ImmediateVictoryAPITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def test_independent_evidence_does_not_complete_failed_tactical_search(self):
        data,scene=comparison.fixture()
        result=evaluate_situation.evaluate(data,cards=self.cards)
        self.assertEqual(result['paid_board_tactics'],paid.evaluate(scene,self.cards))
        self.assertEqual(result['immediate_victory_certificate_attempts'],
                         certificate.certify_available(scene,self.cards))
        self.assertEqual(len(result['certified_immediate_victory_options']),1)
        p=result['certified_immediate_victory_options'][0]
        self.assertEqual((p['policy_own_player_hp'],p['witness_action']['paid_gold']),(10,4))
        self.assertFalse(p['whole_hand_optimum_certified'])
        full=result['authoritative_tactical_recommendation']
        self.assertFalse(full['complete']);self.assertFalse(full['policies'])
        self.assertIsNone(result['paid_board_tactics']['objectives'][0]['metrics'])

    def test_threshold_price_and_dust_counterfacts_withdraw_only_certificate(self):
        original,_=comparison.fixture()
        variants=[dict(copy.deepcopy(original),own_player_hp=11),
                  dict(copy.deepcopy(original),hand_costs=[5,10]),
                  dict(copy.deepcopy(original),enemy_bodies=[dict(card_id=583,attack=3,health=1,max_health=3)])]
        for data in variants:
            with self.subTest(data=data):
                result=evaluate_situation.evaluate(data,cards=self.cards)
                self.assertFalse(result['certified_immediate_victory_options'])
                self.assertEqual(len(result['immediate_victory_certificate_attempts']),1)
                self.assertTrue(result['immediate_victory_certificate_attempts'][0]['unknown'])

    def test_no_known_paid_scope_does_not_apply_certificate_to_other_protocols(self):
        data,_=comparison.fixture()
        data.pop('paid_board_scenario')
        data['enemy_bodies']=[]
        result=evaluate_situation.evaluate(data,cards=self.cards)
        self.assertIsNone(result['immediate_victory_certificate_attempts'])
        self.assertIsNone(result['certified_immediate_victory_options'])


if __name__=='__main__':unittest.main()