"""Physical identity, immutable keywords, actual payment and narrow semantics."""
import copy
import unittest
from unittest.mock import patch

import conditional_card_score as score
import paid_board_tactics as paid
import score_cards
import targeted_hand_magic as hand


class TargetedHandTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def data(self,ids=(33,43),cash=10,**changes):
        data=dict(hand_ids=list(ids),gold_before_play=cash,own_player_hp=15,own_player_max_hp=30,
            enemy_player_hp=30,enemy_player_max_hp=30,opponent_hand_ids=[],opponent_hand_known=True,
            own_deck_ids=[],opponent_deck_ids=[],max_plays='all_physical',horizon='enemy_attack',
            targeted_hand_empty='fizzle',targeted_hand_choice='eligible_targets')
        data.update(changes);return data

    def play(self,engine,state,index,**filters):
        return next((a,s) for a,s in engine.deploys(state) if a['kind']=='deploy' and a['hand_index']==index
            and all(a.get(k)==v for k,v in filters.items()))

    def test_complete_source_templates_cover_four_native_cards_only(self):
        matched=[c['id'] for c in self.cards if hand.parse(c)]
        self.assertEqual(matched,[33,253,406,436])
        for cid in matched:
            source=next(c for c in self.cards if c['id']==cid)
            self.assertIsNone(hand.parse(dict(source,effect_readable=source['effect_readable']+' Draw a card.')))

    def test_target_indexes_do_not_shift_when_caster_leaves_and_branches_are_immutable(self):
        e=hand.TargetedHandSearch(self.cards,self.data(ids=(196,406,196),cash=4));root=e.root()
        branches=[(a,s) for a,s in e.deploys(root) if a['hand_index']==1]
        self.assertEqual({a['hand_target_index'] for a,s in branches},{0,2})
        self.assertEqual(len({s for a,s in branches}),2);self.assertEqual(root.own_hand_buffs,())
        for a,s in branches:
            self.assertEqual(s.hand,(0,2));self.assertEqual(s.own_hand_buffs,((a['hand_target_index'],2,2),))
            self.assertEqual(s.current_paid_gold,4)

    def test_granted_haste_moves_to_exact_paid_copy_and_never_attacks_face_fresh(self):
        e=hand.TargetedHandSearch(self.cards,self.data(enemy_bodies=[dict(card_id=196,attack=0,health=1,max_health=1)]));s=e.root()
        _,s=self.play(e,s,0);self.assertEqual(s.own_hand_keywords,((1,False,True),))
        _,s=self.play(e,s,1);dog=next(u for u in s.own if u.key=='hand:1')
        self.assertEqual((dog.attack,dog.health,dog.ready),(6,5,1));self.assertEqual(s.current_paid_gold,10)
        self.assertEqual(s.own_hand_keywords,());attacks=[(a,ch) for a,ch in e.attacks(s) if a['attacker']==dog.key]
        self.assertTrue(attacks);self.assertTrue(all(a['target']!='face' for a,ch in attacks))
        self.assertEqual(next(u for u in attacks[0][1].own if u.key==dog.key).ready,0)

    def test_taunt_and_numeric_buffs_are_paid_then_transferred_once(self):
        e=hand.TargetedHandSearch(self.cards,self.data(ids=(253,43),cash=9));s=e.root()
        _,s=self.play(e,s,0);_,s=self.play(e,s,1);dog=s.own[-1]
        self.assertEqual((dog.attack,dog.health,dog.max_health,dog.taunt),(6,6,6,True))
        self.assertEqual(s.own_hand_keywords,());self.assertEqual(s.own_hand_buffs,())
        self.assertEqual((s.gold,s.current_paid_gold),(0,9))

    def test_later_drawn_copy_does_not_inherit_keywords_or_numeric_buff(self):
        e=hand.TargetedHandSearch(self.cards,self.data(cash=16,own_deck_ids=[43]));s=e.root()
        _,s=self.play(e,s,0);s=e.draw(s,1);self.assertEqual(s.hand,(1,2))
        _,later=self.play(e,s,2);new=next(u for u in later.own if u.key=='hand:2')
        self.assertEqual((new.attack,new.health,new.ready),(5,5,0))
        _,original=self.play(e,s,1);old=next(u for u in original.own if u.key=='hand:1')
        self.assertEqual((old.attack,old.health,old.ready),(6,5,1))

    def test_haste_target_reads_prior_grant_and_native_silence(self):
        e=hand.TargetedHandSearch(self.cards,self.data(ids=(33,436,43),cash=13));s=e.root()
        _,s=self.play(e,s,0,hand_target_index=2);_,s=self.play(e,s,1,hand_target_index=2)
        self.assertEqual(dict((j,(a,h)) for j,a,h in s.own_hand_buffs)[2],(2,0))
        silent=hand.TargetedHandSearch(self.cards,self.data(ids=(436,509),cash=8,hand_silenced=[False,True]))
        a,s=self.play(silent,silent.root(),0);self.assertTrue(a['magic_fizzled'])

    def test_granted_keywords_can_be_added_after_native_hand_silence(self):
        e=hand.TargetedHandSearch(self.cards,self.data(hand_silenced=[False,True]));s=e.root()
        _,s=self.play(e,s,0);_,s=self.play(e,s,1);dog=s.own[-1]
        self.assertEqual(dog.ready,1);self.assertIsNone(dog.dust)

    def test_dual_tribe_held_copy_has_two_distinct_options(self):
        e=hand.TargetedHandSearch(self.cards,self.data(ids=(33,33),cash=8));r=e.root()
        choices=[(a,s) for a,s in e.deploys(r) if a['hand_index']==0]
        self.assertEqual({a['hand_option'] for a,s in choices},{0,1});self.assertEqual(len({s for a,s in choices}),2)

    def test_enemy_buff_state_and_keyword_transfer_are_separate(self):
        e=hand.TargetedHandSearch(self.cards,self.data(ids=(),cash=0,opponent_hand_ids=[253,43],
            opponent_gold_before_response=9));s=e.boundary(e.root())
        _,s=self.play(e,s,0);self.assertEqual(s.own_hand_keywords,());self.assertEqual(s.enemy_hand_keywords,((1,True,False),))
        _,s=self.play(e,s,1);self.assertTrue(s.enemy[-1].taunt)
        self.assertEqual(s.enemy[-1].attack,6);self.assertEqual(s.enemy_first_paid_gold,9)

    def test_actual_positions_preserved_in_physical_adapter(self):
        d=self.data(ids=(253,43),cash=9,physical_slots=True,front_slot_map=[0,1,2,3])
        e=hand.TargetedPhysicalHandSearch(self.cards,d);_,s=self.play(e,e.root(),0)
        _,s=self.play(e,s,1);self.assertEqual([u.slot for u in s.own],[0,1]);self.assertTrue(s.own[-1].taunt)

    def test_zero_targets_and_two_options_require_explicit_interpretations(self):
        for changes in (dict(ids=(406,),cash=4,targeted_hand_empty='unknown'),
                        dict(targeted_hand_choice='unknown')):
            e=hand.TargetedHandSearch(self.cards,self.data(**changes))
            with self.assertRaises(paid.UnknownMechanic):list(e.deploys(e.root()))

    def test_unknown_tribe_and_charge_target_fail_closed(self):
        changed=copy.deepcopy(self.cards);next(c for c in changed if c['id']==253)['effect_raw']='no raw tribe'
        e=hand.TargetedHandSearch(changed,self.data(ids=(253,43),cash=9))
        with self.assertRaises(paid.UnknownMechanic):list(e.deploys(e.root()))
        altered=copy.deepcopy(self.cards);next(c for c in altered if c['id']==196)['effect_readable']='Charge.'
        e=hand.TargetedHandSearch(altered,self.data(ids=(436,196),cash=3))
        with self.assertRaises(paid.UnknownMechanic):list(e.deploys(e.root()))

    def test_draw_complete_new_helper_is_not_misclassified_as_held_callback(self):
        e=hand.TargetedHandSearch(self.cards,self.data(ids=(),cash=4,own_deck_ids=[406]))
        s=e.draw(e.root(),1)
        self.assertEqual(s.hand,(0,));self.assertEqual(s.own_deck,())
        a,s=self.play(e,s,0);self.assertTrue(a['magic_fizzled'])
        self.assertEqual(s.current_paid_gold,4)

    def test_taunt_haste_and_surviving_body_have_different_purpose_scores(self):
        enemy=[dict(card_id=15,attack=6,health=5,max_health=5,ready=True)]
        goal=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=6,min_own_body_health=1))
        outcomes=[]
        for helper in (33,253,406):
            data=self.data(ids=(helper,43),cash=10,enemy_bodies=enemy)
            hp=hand.evaluate(data,dict(kind='hp'),cards=self.cards,focal_index=1)
            body=hand.evaluate(data,goal,cards=self.cards,focal_index=1)
            self.assertTrue(hp['known'] and body['known']);outcomes.append((hp['guaranteed_player_hp'],body['feasible']))
        self.assertEqual(outcomes,[(15,False),(15,False),(9,True)])

    def test_source_binding_and_budget_unknown_are_not_guessed_scores(self):
        with patch.object(hand,'LOADED_SOURCES',{}):
            with self.assertRaises(RuntimeError):hand.evaluate(self.data(),dict(kind='hp'),cards=self.cards)
        value=hand.evaluate(self.data(node_limit=1),dict(kind='hp'),cards=self.cards)
        self.assertFalse(value['known']);self.assertIsNone(value['guaranteed_player_hp'])


if __name__=='__main__':unittest.main()