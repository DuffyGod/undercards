import copy
import unittest

import carry_option as option


def tree(probability=.2,hand=1,draw=0):
    edge=lambda child,p:dict(child_id=child,probability=p,cards_from_deck=draw,other_plays=0,foregone_value_model_gold=0.)
    return dict(root_id='now',initial_hand_size=hand,last_deployment_own_turn=5,
        draw_option_value_model_gold=.6,nodes=[
            dict(id='now',own_turn=4,transitions=[edge('good',probability),edge('bad',1-probability)]),
            dict(id='good',own_turn=5),dict(id='bad',own_turn=5)])


def quotes(values,cost=8):
    def quote(node,hand):
        value=values[node['id']]
        return dict(legal=True,known=value is not None,net_model_gold=value,paid_gold=cost,
            unknown=['Unmodeled mechanism'] if value is None else [])
    return quote


class CarryOptionTests(unittest.TestCase):
    def test_bad_timing_does_not_force_play_or_charge_mana(self):
        r=option.evaluate(tree(0),quotes({'now':-4,'good':5,'bad':-3}))
        self.assertEqual(r['option_value_model_gold'],0)
        self.assertEqual(r['expected_actual_mana_paid'],0)
        self.assertEqual(r['unused_probability'],1)

    def test_observe_future_before_play_but_not_before_current_choice(self):
        r=option.evaluate(tree(.1),quotes({'now':2,'good':10,'bad':-3}))
        self.assertEqual(r['option_value_model_gold'],2)
        self.assertEqual(r['root_known_action'],'deploy')
        # A clairvoyant policy would wait only on the good branch and claim 2.8.
        self.assertNotAlmostEqual(r['option_value_model_gold'],.1*10+.9*2)

    def test_usage_rate_and_actual_cost_are_only_realized_at_good_entry(self):
        r=option.evaluate(tree(.2),quotes({'now':-4,'good':5,'bad':-3}))
        self.assertAlmostEqual(r['option_value_model_gold'],1)
        self.assertAlmostEqual(r['deployed_probability'],.2)
        self.assertAlmostEqual(r['expected_actual_mana_paid'],1.6)
        self.assertAlmostEqual(r['mean_deployment_own_turn_when_used'],5)

    def test_full_hand_crowding_once_can_make_carrying_net_negative(self):
        r=option.evaluate(tree(0,7,1),quotes({'now':-4,'good':5,'bad':-3}))
        self.assertAlmostEqual(r['option_value_model_gold'],-.6)
        self.assertEqual(r['expected_actual_mana_paid'],0)

    def test_reference_empty_slot_is_not_restored_on_every_wait(self):
        s=tree(0,7,1);s['last_deployment_own_turn']=6
        for n in s['nodes'][1:]:
            n['transitions']=[dict(child_id='last',probability=1,cards_from_deck=1,other_plays=0,foregone_value_model_gold=0)]
        s['nodes'].append(dict(id='last',own_turn=6))
        r=option.evaluate(s,quotes({'now':-4,'good':5,'bad':-3,'last':-3}))
        self.assertAlmostEqual(r['option_value_model_gold'],-.6)
        self.assertEqual(next(p for p in r['policy'] if p['node_id']=='last')['empty_reference_hand_size'],7)

    def test_zero_probability_unknown_does_not_destroy_known_policy(self):
        r=option.evaluate(tree(0),quotes({'now':-4,'good':None,'bad':-3}))
        self.assertTrue(r['pricing_supported'])
        self.assertEqual(r['unknown'],[])
        r=option.evaluate(tree(.2),quotes({'now':-4,'good':None,'bad':-3}))
        self.assertFalse(r['pricing_supported'])
        self.assertEqual(r['value_bounds_model_gold'],[0.,None])

    def test_expiry_is_absolute_and_missing_future_is_not_zero(self):
        s=tree();s['nodes'][-1]['own_turn']=6
        with self.assertRaises(ValueError):option.evaluate(s,quotes({}))
        s=tree();s['nodes'][0]['transitions']=[]
        with self.assertRaises(ValueError):option.evaluate(s,quotes({}))

    def test_invalid_probabilities_and_common_plays_are_rejected(self):
        s=tree();s['nodes'][0]['transitions'][0]['probability']=.9
        with self.assertRaises(ValueError):option.evaluate(s,quotes({}))
        s=tree();s['nodes'][0]['transitions'][0]['other_plays']=1
        with self.assertRaises(ValueError):option.evaluate(s,quotes({'now':-4,'good':5,'bad':-3}))

    def test_discount_is_applied_to_future_payoff_on_same_unit(self):
        s=tree(1);s['discount_rate_per_turn']=.25
        r=option.evaluate(s,quotes({'now':-4,'good':5,'bad':-3}))
        self.assertAlmostEqual(r['option_value_model_gold'],4)
        self.assertEqual(r['expected_actual_mana_paid'],8)

    def test_optional_draw_is_reselected_after_future_capacity_displacement(self):
        def quote(n,h):
            if n['id']!='now':return quotes({'good':-3,'bad':-3},1)(n,h)
            return dict(legal=True,known=True,net_model_gold=.2,paid_gold=1,actions=[
                dict(action_id='draw',net_model_gold=.2,post_hand_size=7,paid_gold=1),
                dict(action_id='skip_draw',net_model_gold=-.1,post_hand_size=6,paid_gold=1)])
        r=option.evaluate(tree(.2,7,1),quote)
        self.assertAlmostEqual(r['option_value_model_gold'],-.1)
        self.assertEqual(next(p for p in r['policy'] if p['node_id']=='now')['selected_deployment_action_id'],'skip_draw')


if __name__=='__main__':unittest.main()