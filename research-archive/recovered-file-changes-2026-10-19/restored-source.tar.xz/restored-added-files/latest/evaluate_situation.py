"""Evaluate one declared current monster hand: quotes, coverage, action risk.

Input balances/boards/HP are observations supplied by the caller, not sampled
from synthetic deck priors. Future Dust hands remain unknown unless provided.
"""
from __future__ import annotations
import argparse
import copy
import json
import math
from pathlib import Path

import action_outcomes
import combat_increment as combat
import context_value as ledger
import deployment_timing as timing
import heuristic_contexts as contexts
import opportunity_fit as opportunities
import score_cards as base
import unified_value as unified
import board_response
import deployment_routes
import decision_timing
import joint_window_quote
import lifecycle_outcomes
import spell_window
import turn_start_draw
import construction_value
import finite_timing_window
import board_tactics
import paid_board_tactics
import hidden_reply_policy

VERSION='current-situation-evaluation-0.16.0'
REQUIRED={'hand_ids','role','own_turn','gold_before_play','opponent_gold_before_response',
          'own_player_hp','enemy_player_hp','ally_bodies_before_play','enemy_bodies'}
OPTIONAL={'condition_state','response_weights','profile','dust_timing','context_id','useful_threshold',
          'lifecycle_scenario','max_current_plays','timing_scenario','callback_state','hand_costs','draw_state',
          'construction_scenario','absolute_timing_scenario','board_tactics_scenario','paid_board_scenario',
          'hidden_reply_scenario'}


def make_state(data):
    if not isinstance(data,dict) or not REQUIRED<=set(data) or not set(data)<=REQUIRED|OPTIONAL:
        raise ValueError('Required current fields: '+', '.join(sorted(REQUIRED)))
    hand=data['hand_ids']
    if not isinstance(hand,list) or not 1<=len(hand)<=7 or any(type(cid) is not int for cid in hand):
        raise ValueError('A known hand needs one to seven card IDs; duplicate copies are allowed')
    if data['role'] not in contexts.ROLES or type(data['own_turn']) is not int or data['own_turn']<1:
        raise ValueError('Declare a supported role and positive own-turn index')
    p=unified.normalize_profile(data.get('profile'))
    phase=max((t for t in contexts.PHASES if t<=data['own_turn']),default=min(contexts.PHASES))
    state=copy.deepcopy(next(s for s in contexts.make_contexts()
                    if s['role']==data['role'] and s['own_turn']==phase and s['joint_resource_state']=='reserved'))
    for key in REQUIRED-{'hand_ids'}:
        state[key]=copy.deepcopy(data[key])
    if 'board_tactics_scenario' in data or 'paid_board_scenario' in data or 'hidden_reply_scenario' in data:
        # The old fixed-response kernels cannot interpret readiness/history.
        # Keep original observations in input and pass them verbatim to the
        # tactical kernel; expose the metadata omitted from legacy diagnostics.
        metadata={'ready','attack_permission','attacked','max_health','card_id','cost','name','paralyze_owner_starts_remaining','silenced','current_card_cost','base_cost','transparency'}
        omitted=[]
        for side in ('ally_bodies_before_play','enemy_bodies'):
            for i,unit in enumerate(state[side]):
                if not isinstance(unit,dict): continue
                dropped={k:unit.pop(k) for k in list(unit) if k in metadata}
                if dropped:omitted.append(dict(side=side,index=i,metadata=dropped))
        state['legacy_board_metadata_omitted']=omitted
    if type(state['own_player_hp']) not in (int,float) or not math.isfinite(state['own_player_hp']) or state['own_player_hp']<=0:
        raise ValueError('Initial own player HP must be positive finite')
    if type(state['enemy_player_hp']) not in (int,float) or not math.isfinite(state['enemy_player_hp']) or state['enemy_player_hp']<=0:
        raise ValueError('Initial enemy player HP must be positive finite')
    if not all(isinstance(state[k],list) for k in ('ally_bodies_before_play','enemy_bodies')):
        raise ValueError('Supply current monster body lists')
    ally,enemy=len(state['ally_bodies_before_play']),len(state['enemy_bodies'])
    for unit in state['ally_bodies_before_play']+state['enemy_bodies']:
        if not isinstance(unit,dict) or not {'attack','health'}<=set(unit):
            raise ValueError('Observed bodies need attack and health')
        for key in ('attack','health'):
            if type(unit[key]) not in (int,float) or not math.isfinite(unit[key]) or unit[key]<0 or (key=='health' and unit[key]==0):
                raise ValueError('Observed bodies must be live with finite nonnegative attack')
    state.update(context_id=data.get('context_id','declared-current-situation'),weight=1.,
        gold_budget_source='declared_observed_balance',
        cumulative_base_gold_cap=contexts.cumulative_base_gold(state['own_turn'],p['second_player']),
        hand_size_before_play=len(hand),hand_size_after_play=len(hand)-1,
        ally_count_before_play=ally,ally_count_after_play=ally+int(ally<4),
        ally_empty_slots_before_play=4-ally,ally_empty_slots_after_play=max(0,3-ally),
        enemy_count=enemy,enemy_empty_slots=4-enemy,other_monster_count=ally+enemy,
        second_player=p['second_player'],enemy_attack_limit=p['enemy_attack_limit'],
        include_action_terminal_boundary=True,
        reply_policy='allied_board',
        condition_state=copy.deepcopy(data.get('condition_state',{})),
        death_event_hand_costs=[],actually_used_mask=[],
        draw_state_assumptions=copy.deepcopy(p['draw_state_assumptions']))
    if 'draw_state' in data:
        allowed=set(ledger.DEFAULT_DRAW_STATE)-{'opponent_net_option_value'}
        if not isinstance(data['draw_state'],dict) or not set(data['draw_state'])<=allowed:
            raise ValueError('Observed draw_state fields: '+', '.join(sorted(allowed)))
        state['draw_state_assumptions'].update(copy.deepcopy(data['draw_state']))
    upcoming=data.get('timing_scenario',{})
    if not isinstance(upcoming,dict):raise ValueError('timing_scenario must be an object')
    state.update(resolve_next_own_start=True,
        next_income=upcoming.get('next_income',contexts.base_income(state['own_turn']+1,p['second_player'])),
        next_draw_count=upcoming.get('next_draw_count',1))
    if 'next_draw_option_value_model_gold' in upcoming:
        state['next_draw_option_value_model_gold']=upcoming['next_draw_option_value_model_gold']
    weights=data.get('response_weights',combat.RESPONSE_WEIGHTS[state['role']])
    combat.validate_window(0,1,state['enemy_bodies'],{},state['opponent_gold_before_response'],state['role'],weights,
                           state['own_player_hp'],state['enemy_player_hp'])
    state['growth_response_weights']=copy.deepcopy(weights)
    if 'callback_state' in data:
        permitted={'own_player_max_hp','enemy_player_max_hp','own_deck_available','own_fatigue_next','turn_end_random_target_weights'}
        if not isinstance(data['callback_state'],dict) or not set(data['callback_state'])<=permitted:
            raise ValueError('Supported callback observations: '+', '.join(sorted(permitted)))
        state['callback_state']=copy.deepcopy(data['callback_state'])
    window=state['resource_use_window']
    window.update(death_event_own_turn=state['own_turn'],first_own_turn=state['own_turn']+1,
                  last_own_turn=state['own_turn']+2,assumed_carry_gold=0)
    window['base_income_in_window']=sum(contexts.base_income(t,p['second_player']) for t in range(state['own_turn']+1,state['own_turn']+3))
    window['available_gold_assumption']=window['base_income_in_window']
    if ally<4:
        contexts.validate_context(state)
    elif ally==4 and enemy<=4:
        # No fifth monster can deploy. Spells remain legal on a full board.
        for key in ('gold_before_play','opponent_gold_before_response'):
            if type(state[key]) not in (int,float) or not math.isfinite(state[key]) or state[key]<0:
                raise ValueError('Observed balances must be finite and nonnegative')
    else:
        raise ValueError('Boards have at most four monsters each')
    if 'dust_timing' in data:
        state['dust_timing']=copy.deepcopy(data['dust_timing'])
    else:
        prepared=timing.dust_context(state,state,p)
        if prepared is None:
            # Current input has no future usage evidence: keep it unknown even
            # if a caller chooses legacy full-pool reproducibility parameters.
            prepared=timing.dust_context(state,state,unified.normalize_profile())
        for branch in prepared['branches']:
            if branch['event']=='ordinary_death':
                branch.pop('hand_at_event',None)
                branch.pop('payment_windows',None)
                branch.pop('initial_gold',None)
        state['dust_timing']=prepared
    state['assumptions']=[
        'Current hand, boards, player HP and balances are caller observations; not server-verified.',
        'Gold observations may include non-base income; no artificial cumulative-base cap is imposed on supplied balances.',
        'Current action routes cover at most two known plays under an explicitly restricted order; proactive existing allied attacks remain unsearched.',
        'Response weights/order and future draw priors are declared model scenarios, not measured opponent frequencies.',
        'Before own turn 3, earliest phase event priors are extrapolated design assumptions, not validated early-game risks.',
        'Future Dust hand/payment plan is unknown unless dust_timing is supplied; it is not an empty-hand zero assumption.']
    return state,p


def evaluate(data,reference=None,cards=None):
    cards=base.load_cards() if cards is None else cards
    by_id={c['id']:c for c in cards}
    state,profile=make_state(data)
    try:
        hand=[copy.deepcopy(by_id[cid]) for cid in data['hand_ids']]
    except KeyError as exc:
        raise ValueError('Unknown card ID: '+str(exc)) from exc
    if 'hand_costs' in data:
        costs=data['hand_costs']
        if not isinstance(costs,list) or len(costs)!=len(hand) or any(type(v) not in (int,float) or not math.isfinite(v) or v<0 for v in costs):
            raise ValueError('Current hand_costs must match hand indexes with finite nonnegative costs')
        for card,cost in zip(hand,costs):
            card['snapshot_printed_cost']=card['cost'];card['cost']=cost
    if any(c['card_type'] not in ('monster','spell') or (c['card_type']=='monster' and c['health']<=0) for c in hand):
        raise ValueError('Hand entries must be spells or live monster cards')
    if reference is None:
        reference,_=base.make_reference(cards)
    normalization=joint_window_quote.make_normalization(reference,profile,reply_policy='allied_board',resolve_next_own_start=True)
    scale=normalization['scale']
    state['utility_scale']=scale
    # Preserve the old ledger as an explicitly labeled comparison. A mixed
    # hand must never pass a spell through the monster-body pricing path.
    if all(c['card_type']=='monster' for c in hand) and len(state['ally_bodies_before_play'])<4:
        coverage=opportunities.hand_coverage(hand,[state],reference,data.get('useful_threshold',0))
        card_quotes=coverage['rows'][0]['actions']
    else:
        card_quotes=[dict(hand_index=i,card_id=c['id'],name=c['name'],pricing_supported=False,
            gross_model_gold=None,net_model_gold=None,unsupported=['Legacy monster ledger does not compare mixed/full-board hands']) for i,c in enumerate(hand)]
        coverage=dict(rows=[dict(actions=card_quotes)],no_effective_action_weight_bounds=[0,1],
            scope='Legacy monster ledger unavailable for this hand; use finite_window_quotes and action routes')
    effect_realizations=[]
    for i,card in enumerate(hand):
        if card['card_type']=='spell':
            continue
        modules,unsupported=ledger.parse(card)
        evaluated=[]
        for branch in contexts.enumerate_choice_branches(modules):
            try:
                result=ledger.evaluate_branch(card,state,[modules[j] for j in branch['selected_module_indexes']],
                                              reference,quote_only=True)
                evaluated.append(result)
            except ValueError as exc:
                unsupported.append(str(exc))
        best=max(evaluated,key=lambda r:r['gross_model_gold']) if evaluated else None
        rows=[row for row in best['ledger'] if row['term'].startswith('dust_timing_')] if best else []
        effect_realizations.append(dict(hand_index=i,card_id=card['id'],name=card['name'],
            dust_realization=rows,unknown=sorted(set(unsupported)),
            scope='Declared effect realization only; unknown full-card pricing is not repaired by known effect terms.'))
    window_results=[dict(hand_index=i,
                         **(spell_window.evaluate if c['card_type']=='spell' else action_outcomes.evaluate)(c,state,reference,state['growth_response_weights']))
                    for i,c in enumerate(hand)]
    hold_paths=[]
    for event,weight in state['growth_response_weights'].items():
        if not weight:
            continue
        held=combat.state(0,0,state['enemy_bodies'],{},state['opponent_gold_before_response'],
                          state['own_player_hp'],state['enemy_player_hp'],state['enemy_attack_limit'])
        held['external_allies']=copy.deepcopy(state['ally_bodies_before_play'])
        try:
            board_response.reply(held,event)
            held,start_unknown=turn_start_draw.advance(held,state,state['next_income'],state['next_draw_count'],False)
            if start_unknown:raise ValueError('; '.join(start_unknown))
            hold_paths.append(dict(event=event,weight=weight,own_player_hp=held['own_player_hp'],
                                   own_player_dead=held['own_player_hp']<=0,log=held['log'],unknown=None))
        except ValueError as exc:
            hold_paths.append(dict(event=event,weight=weight,own_player_hp=None,own_player_dead=None,unknown=str(exc)))
    hold_known=all(p['unknown'] is None for p in hold_paths)
    hold_death=sum(path['weight']*path['own_player_dead'] for path in hold_paths) if hold_known else None
    legal_known=[w for w in window_results if w['deployment_legal_now'] and w['window_known']]
    legal_unknown=[w for w in window_results if w['deployment_legal_now'] and not w['window_known']]
    known_best=min(([hold_death] if hold_known else [1.])+[w['death_probability'] for w in legal_known])
    reducing=[w for w in legal_known if hold_known and w['death_probability']<hold_death]
    best=min(reducing,key=lambda w:(w['death_probability'],-w['defeat_probability'],
                                   hand[w['hand_index']]['cost'],w['hand_index'])) if reducing else None
    survival=dict(hold_death_probability=hold_death,hold_paths=hold_paths,
        lowest_death_probability_bounds=[0. if legal_unknown or not hold_known else known_best,known_best],
        known_death_reducing_hand_indexes=[w['hand_index'] for w in reducing],
        best_known_death_reducing_hand_index=best['hand_index'] if best else None,
        unknown_legal_action_hand_indexes=[w['hand_index'] for w in legal_unknown],
        scope='Survival axis only; compare one affordable deployment or hold under the same declared opponent response. No general recommendation to hold in safe states; known rescue ties prefer lower cost.')
    finite_quotes=[]
    for i,c in enumerate(hand):
        quote=(spell_window.evaluate(c,state,reference,state['growth_response_weights'],scale=scale) if c['card_type']=='spell'
            else joint_window_quote.evaluate(c,state,reference,scale=scale,weights=state['growth_response_weights']))
        finite_quotes.append(dict(hand_index=i,**quote))
    finite_actions=[]
    for i,(card,quote,window) in enumerate(zip(hand,finite_quotes,window_results)):
        net=quote.get('model_gold') if card['card_type']=='spell' else quote.get('net_margin_model_gold')
        supported=net is not None and (quote.get('window_known',True) if card['card_type']=='spell' else quote['pricing_supported'])
        finite_actions.append(dict(hand_index=i,card_id=card['id'],name=card['name'],
            deployment_legal_now=window['deployment_legal_now'],pricing_supported=supported,
            net_model_gold=net if supported else None))
    threshold=data.get('useful_threshold',0.)
    if type(threshold) not in (int,float) or not math.isfinite(threshold):
        raise ValueError('Useful threshold must be finite')
    useful=[a['hand_index'] for a in finite_actions if a['deployment_legal_now'] and a['pricing_supported'] and a['net_model_gold']>threshold]
    uncertain=[a['hand_index'] for a in finite_actions if a['deployment_legal_now'] and not a['pricing_supported']]
    finite_coverage=dict(actions=finite_actions,known_useful_hand_indexes=useful,
        unknown_legal_hand_indexes=uncertain,no_effective_action_bounds=[not bool(useful or uncertain),not bool(useful)],
        useful_threshold=threshold,scope='One current play on the common finite-window scale; survival and two-play routes are separate axes.')
    routes=deployment_routes.evaluate(hand,state,reference,state['growth_response_weights'],data.get('max_current_plays',2))
    lifecycle=[dict(hand_index=i,**lifecycle_outcomes.evaluate(c,state,reference,data.get('lifecycle_scenario')))
               for i,c in enumerate(hand) if c['card_type']=='monster' and lifecycle_outcomes.compile_effects(c)[0]]
    timing_decisions=[dict(hand_index=i,**decision_timing.evaluate(c,state,reference,scale,data.get('timing_scenario')))
                      for i,c in enumerate(hand) if c['card_type']=='monster']
    construction=None
    absolute_timing=None
    if 'absolute_timing_scenario' in data:
        future=copy.deepcopy(data['absolute_timing_scenario'])
        allowed={'horizon_tick','response_mode','responses','responses_by_tick','natural_draw_count',
            'draw_option_value_model_gold','random_target_policy','random_no_target_policy'}
        if not isinstance(future,dict) or not set(future)<=allowed or 'horizon_tick' not in future:
            raise ValueError('Declare horizon_tick and supported absolute timing parameters')
        scene=dict(own_turn=state['own_turn'],role=state['role'],second_player=profile['second_player'],
            gold_before_play=state['gold_before_play'],opponent_gold=state['opponent_gold_before_response'],
            own_player_hp=state['own_player_hp'],enemy_player_hp=state['enemy_player_hp'],
            enemy_bodies=copy.deepcopy(state['enemy_bodies']),initial_hand_size=len(hand),
            condition_state=copy.deepcopy(state['condition_state']),
            responses=copy.deepcopy(state['growth_response_weights']))
        for key in ('own_deck_available','own_fatigue_next','opponent_hand_size',
                    'opponent_deck_available','opponent_fatigue_next'):
            scene[key]=state['draw_state_assumptions'][key]
        scene.update({k:v for k,v in state.get('callback_state',{}).items()
                      if k in ('own_player_max_hp','own_deck_available','own_fatigue_next')})
        scene.update(future)
        absolute_timing=[]
        for i,card in enumerate(hand):
            if card['card_type']!='monster' or state['ally_bodies_before_play']:
                absolute_timing.append(dict(hand_index=i,card_id=card['id'],pricing_supported=False,
                    absolute_endpoint_option_model_gold=None,
                    unknown=['Absolute timing subgame currently requires one candidate monster and no pre-existing allies']))
            else:
                absolute_timing.append(dict(hand_index=i,**finite_timing_window.evaluate(card,reference,scale,scene)))
    if 'construction_scenario' in data:
        scenario=copy.deepcopy(data['construction_scenario'])
        if not isinstance(scenario,dict):raise ValueError('Construction scenario must be an object')
        replacement_ids=scenario.get('replacement_ids',[])
        if not isinstance(replacement_ids,list) or any(type(i) is not int or i not in by_id for i in replacement_ids):
            raise ValueError('Replacement IDs must identify existing cards')
        scenario.setdefault('initial_hand_size',len(hand))
        parameters=base.role_parameters(state['role'])
        scenario.setdefault('draw_option_value_model_gold',parameters['draw_value']*parameters['future_draw_use'])
        # Each already-drawn copy is a separate single-slot counterfactual;
        # different current costs must not be merged by card ID.
        candidates=[dict(c,construction_option_key='hand-'+str(i)) for i,c in enumerate(hand)]
        extras=[dict(by_id[i],construction_option_key='replacement-'+str(i)) for i in dict.fromkeys(replacement_ids)]
        construction=construction_value.evaluate_cards(candidates+extras,reference,scale,scenario,make_state,state)
        construction['replacement_comparisons']=construction_value.compare(construction,
            [c['construction_option_key'] for c in candidates],
            [c['construction_option_key'] for c in extras])
    board_result=None
    if 'board_tactics_scenario' in data:
        params=copy.deepcopy(data['board_tactics_scenario'])
        permitted={'horizon','max_plays','objectives','node_limit'}
        if not isinstance(params,dict) or not set(params)<=permitted:
            raise ValueError('Supported board_tactics_scenario fields: '+', '.join(sorted(permitted)))
        if any(c['card_type']!='monster' for c in hand):
            board_result=dict(complete_in_declared_scope=False,unknown=['Tactical current-play search currently accepts monster hands; spells require complete action adapters'])
        else:
            scene={k:copy.deepcopy(data[k]) for k in ('hand_ids','ally_bodies_before_play','enemy_bodies','own_player_hp',
                                                     'enemy_player_hp','gold_before_play','opponent_gold_before_response')}
            scene['hand_costs']=[c['cost'] for c in hand]
            for side in ('own','enemy'):
                key=side+'_player_max_hp'
                if key in data.get('callback_state',{}):scene[key]=data['callback_state'][key]
            scene.update(params)
            board_result=board_tactics.evaluate(scene,cards)
    paid_result=None
    hidden_result=None
    if 'paid_board_scenario' in data and 'hidden_reply_scenario' in data:
        raise ValueError('Choose a declared known paid hand or hidden_reply_scenario for the authoritative tactical scope')
    if 'paid_board_scenario' in data:
        params=copy.deepcopy(data['paid_board_scenario'])
        permitted={'horizon','max_plays','objectives','node_limit','opponent_hand_ids','opponent_hand_costs',
                   'own_deck_ids','own_fatigue_next','next_natural_draw_count','start_draw_order',
                   'purpose_constraints','own_dustpile_monsters','hand_base_costs','hand_silenced',
                   'next_max_plays','next_own_gold_income','current_turn_gold_spent_on_spells',
                   'next_opponent_gold_income','next_opponent_natural_draw_count','first_opponent_natural_draw_count',
                   'opponent_deck_ids','opponent_fatigue_next','opponent_condition_known_state','search_algorithm',
                   'opponent_hand_base_costs','paralyze_reapplication','hp_certificate_prefix'}
        if not isinstance(params,dict) or not set(params)<=permitted:
            raise ValueError('Supported paid_board_scenario fields: '+', '.join(sorted(permitted)))
        scene={k:copy.deepcopy(data[k]) for k in ('hand_ids','ally_bodies_before_play','enemy_bodies','own_player_hp',
                                                 'enemy_player_hp','gold_before_play','opponent_gold_before_response')}
        scene['hand_costs']=[c['cost'] for c in hand]
        scene['condition_known_state']=copy.deepcopy(data.get('condition_state',{}))
        for side in ('own','enemy'):
            key=side+'_player_max_hp'
            if key in data.get('callback_state',{}):scene[key]=data['callback_state'][key]
        scene.update(params)
        paid_result=paid_board_tactics.evaluate(scene,cards)
        # Fixed-response probabilities do not use the declared physical enemy
        # hand. Preserve their evidence but withdraw their recommendation even
        # when the paid menu is unclosed; unknown is not fallback proof.
        survival['legacy_best_known_death_reducing_hand_index']=survival['best_known_death_reducing_hand_index']
        survival['best_known_death_reducing_hand_index']=None
        survival['diagnostic_only']=True
        survival['superseded_by']='paid_board_tactics'
        survival['scope']='Fixed-response diagnostic only; physical paid replies determine the current tactical recommendation.'
        routes['diagnostic_only']=True
        routes['superseded_by']='paid_board_tactics'
    if 'hidden_reply_scenario' in data:
        params=copy.deepcopy(data['hidden_reply_scenario'])
        permitted={'opponent_hands','panel_names','objective','node_limit','horizon','max_plays',
            'hand_base_costs','hand_silenced','own_dustpile_monsters','current_turn_gold_spent_on_spells',
            'own_deck_ids','own_fatigue_next','start_draw_order','paralyze_reapplication',
            'purpose_constraints','search_algorithm','opponent_condition_known_state',
            'first_opponent_natural_draw_count','opponent_fatigue_next'}
        if not isinstance(params,dict) or set(params)-permitted:
            raise ValueError('Supported hidden_reply_scenario fields: '+', '.join(sorted(permitted)))
        hands=params.pop('opponent_hands',None)
        if not isinstance(hands,list) or len(hands)<2 or any(not isinstance(h,dict) or
            'ids' not in h or set(h)-{'ids','costs','base_costs','deck_ids'} for h in hands):
            raise ValueError('At least two opponent_hands with ids and optional costs/base_costs/deck_ids required')
        config={k:params.pop(k) for k in ('panel_names','objective','node_limit') if k in params}
        scene={k:copy.deepcopy(data[k]) for k in ('hand_ids','ally_bodies_before_play','enemy_bodies',
            'own_player_hp','enemy_player_hp','gold_before_play','opponent_gold_before_response')}
        scene.update(hand_costs=[c['cost'] for c in hand],
            condition_known_state=copy.deepcopy(data.get('condition_state',{})),horizon='enemy_attack')
        for side in ('own','enemy'):
            key=side+'_player_max_hp'
            if key in data.get('callback_state',{}):scene[key]=data['callback_state'][key]
        scene.update(params)
        panels=[]
        for observation in hands:
            panel=copy.deepcopy(scene);panel['opponent_hand_ids']=observation['ids']
            for short,key in (('costs','opponent_hand_costs'),('base_costs','opponent_hand_base_costs'),
                              ('deck_ids','opponent_deck_ids')):
                if short in observation:panel[key]=observation[short]
            panels.append(panel)
        hidden_result=hidden_reply_policy.evaluate(dict(config,panels=panels),cards)
        survival['legacy_best_known_death_reducing_hand_index']=survival['best_known_death_reducing_hand_index']
        survival.update(best_known_death_reducing_hand_index=None,diagnostic_only=True,
            superseded_by='hidden_reply_policy',scope='Shared current policy over declared possible enemy hands.')
        routes.update(diagnostic_only=True,superseded_by='hidden_reply_policy')
    recommendation=(dict(source='paid_board_tactics',complete=paid_result['complete_in_declared_scope'],
        policies=paid_result['recommendations'],unknown=paid_result['unknown']) if paid_result is not None else None)
    if hidden_result is not None:
        complete=hidden_result['complete_in_declared_scope']
        prefix=hidden_result['common_own_prefix']
        recommendation=dict(source='hidden_reply_policy',complete=complete,scope=hidden_result['scope'],
            guaranteed_survival=hidden_result['metrics']['own_player_hp']>0 if complete else None,
            policies=[dict(objective=hidden_result['objective'],first_action=prefix[0] if prefix else None,
                policy=prefix)] if complete else [],unknown=hidden_result['unknown'])
    return dict(version=VERSION,ledger_version=ledger.VERSION,combat_version=combat.VERSION,
                input=copy.deepcopy(data),declared_current_state=state,profile=profile,
                card_quotes=card_quotes,hand_coverage=coverage,
                legacy_quote_scope='Root-F ledger comparison; use finite_window_quotes for response-sensitive body quotes where closed.',
                common_window_normalization={k:v for k,v in normalization.items() if k not in ('panel','_cache')},finite_window_quotes=finite_quotes,
                finite_hand_coverage=finite_coverage,
                deployment_routes=routes,lifecycle_outcomes=lifecycle,timing_decisions=timing_decisions,
                construction_options=construction,
                absolute_timing_options=absolute_timing,
                board_tactics=board_result,
                paid_board_tactics=paid_result,
                hidden_reply_policy=hidden_result,
                authoritative_tactical_recommendation=recommendation,
                action_windows=window_results,hand_survival=survival,
        effect_realizations=effect_realizations,scope=state['assumptions']+([
            'Legacy quotes/reply kernels omit explicit readiness and attack history; tactical searches retain the original observations. Paid-response recommendations use paid_board_tactics, not legacy synthetic penalties.']
            if state.get('legacy_board_metadata_omitted') else []))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    result=evaluate(json.loads(args.input.read_text(encoding='utf-8')))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    summary=dict(cards=len(result['card_quotes']),
        quoted=sum(row['pricing_supported'] for row in result['finite_hand_coverage']['actions']),
        no_effective_resource_action_bounds=result['finite_hand_coverage']['no_effective_action_bounds'],
        single_card_death_probability_bounds=result['hand_survival']['lowest_death_probability_bounds'],
        route_death_probability_bounds=result['deployment_routes']['lowest_death_probability_bounds'],
        best_known_route=result['deployment_routes']['best_known_survival_route'],
        known_rescue_hand_indexes=result['hand_survival']['known_death_reducing_hand_indexes'])
    if result['construction_options'] is not None:
        construction=result['construction_options']
        summary['conditional_construction']=dict(
            options=[{k:c.get(k) for k in ('option_key','card_id','option_value_model_gold',
                'value_bounds_model_gold','unused_probability','expected_actual_mana_paid')} for c in construction['cards']],
            replacements=construction['replacement_comparisons'])
    if result['absolute_timing_options'] is not None:
        summary['absolute_timing']=[dict(hand_index=r['hand_index'],card_id=r['card_id'],
            value_model_gold=r['absolute_endpoint_option_model_gold'],
            root_action=r.get('actual',{}).get('root_action_id')) for r in result['absolute_timing_options']]
    if result['board_tactics'] is not None:
        board=result['board_tactics']
        summary['board_tactics']=dict(complete=board['complete_in_declared_scope'],unknown=board.get('unknown'),
            body_hp_caps=board['body_hp_caps'],
            policies=[dict(objective=r['objective'],metrics=r['metrics']) for r in board.get('objectives',[])])
    if result['paid_board_tactics'] is not None:
        for key in ('single_card_death_probability_bounds','route_death_probability_bounds',
                    'best_known_route','known_rescue_hand_indexes'):
            summary.pop(key,None)
        board=result['paid_board_tactics']
        summary['paid_board_tactics']=dict(complete=board['complete_in_declared_scope'],unknown=board.get('unknown'),
            player_hp_caps=board['player_hp_caps'],body_hp_caps=board['body_hp_caps'],
            policies=[dict(objective=r['objective'],metrics=r['metrics'],draw_accounting=r.get('draw_accounting'))
                      for r in board.get('objectives',[])])
        if 'hp_optimum_certificate' in board:
            certificate=board['hp_optimum_certificate']
            summary['paid_board_tactics']['hp_certificate']=dict(
                exact=certificate['hp_optimum_certified'],
                guaranteed_hp_bounds=certificate['guaranteed_hp_bounds'],
                request_prefix=certificate.get('request_prefix'),
                full_future_vector_optimized=False)
        summary['authoritative_tactical_recommendation']=result['authoritative_tactical_recommendation']
    if result['hidden_reply_policy'] is not None:
        for key in ('single_card_death_probability_bounds','route_death_probability_bounds',
                    'best_known_route','known_rescue_hand_indexes'):
            summary.pop(key,None)
        hidden=result['hidden_reply_policy']
        summary['hidden_reply_policy']=dict(complete=hidden['complete_in_declared_scope'],
            player_hp_caps=hidden['player_hp_caps'],body_hp_caps=hidden['body_hp_caps'],
            metrics=hidden['metrics'],common_own_prefix=hidden['common_own_prefix'],unknown=hidden['unknown'],
            oracle_minimum_vector=hidden['oracle_minimum_vector'])
        summary['authoritative_tactical_recommendation']=result['authoritative_tactical_recommendation']
    print(json.dumps(summary))


if __name__=='__main__':
    main()