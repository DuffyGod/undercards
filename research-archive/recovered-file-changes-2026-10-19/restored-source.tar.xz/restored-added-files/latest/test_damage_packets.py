"""Source-generic packets, ownership, conservative ordering and paid roles."""
import copy
from dataclasses import replace
import unittest

import board_tactics as board
import paid_board_tactics as paid
import score_cards
import build_damage_packet_comparison as report
import build_damage_packet_api as api
import evaluate_situation


class DamagePacketTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards=score_cards.load_cards();cls.result=report.build()
        cls.rows={r['case']:r for r in cls.result['cases']}

    def engine(self,cid=56):
        e=paid.PaidSearch(self.cards,dict(hand_ids=[cid],gold_before_play=7))
        return e,e.unit(*e.hand[0],'body')

    def test_source_template_not_identity_and_full_text(self):
        c=dict(id=99999,effect_readable='Can only take up to 2 DMG at a time.')
        self.assertEqual(board.compile_card(c)['damage_cap'],2)
        self.assertFalse(board.compile_card(c)['unknown'])
        c['effect_readable']+=' Dust: Draw a card.'
        self.assertTrue(board.compile_card(c)['unknown'])
        c['effect_readable']='Armor. This takes +4 DMG from enemy monsters and spells.'
        self.assertEqual(board.compile_card(c)['enemy_damage_bonus'],4)

    def test_packet_split_changes_health_with_constant_total(self):
        e,u=self.engine();one=e.hurt_unit(u,6,source=None)
        two=e.hurt_unit(e.hurt_unit(u,3,source=None),3,source=None)
        self.assertEqual((one.health,two.health),(2,0))
        v=u
        for _ in range(4):v=e.hurt_unit(v,1,source=None)
        self.assertEqual(v.health,1)

    def test_cap_order_physical_agreement_and_ambiguity(self):
        e,u=self.engine();u=replace(u,armor=True)
        self.assertEqual(e.hurt_unit(u,2,source=None).health,4)
        with self.assertRaisesRegex(paid.UnknownMechanic,'modifier order'):
            e.hurt_unit(u,8,source=None)
        # Fatal in all candidate interpretations is the same physical state.
        self.assertEqual(e.hurt_unit(replace(u,health=1),8,source=None).health,0)

    def test_cap_dodge_does_not_reset_between_instances(self):
        e,u=self.engine();u=replace(u,dodge=1)
        u=e.hurt_unit(u,8,source=None)
        self.assertEqual((u.health,u.dodge),(5,0))
        self.assertEqual(e.hurt_unit(u,8,source=None).health,2)
        self.assertEqual(e.hurt_unit(u,0,source=None),u)

    def test_enemy_monster_ownership_and_spell_scope(self):
        e,u=self.engine(840)
        source=replace(u,key='caster')
        self.assertEqual(e.hurt_unit(u,4,source=source,source_is_enemy=True).health,4)
        self.assertEqual(e.hurt_unit(u,4,source=source,source_is_enemy=False).health,6)
        self.assertEqual(e.hurt_unit(u,8,source=None,source_is_enemy=True).health,0)
        with self.assertRaisesRegex(paid.UnknownMechanic,'source interpretation'):
            e.hurt_unit(u,4,source=None,source_is_enemy=False)
        with self.assertRaisesRegex(paid.UnknownMechanic,'source ownership'):
            e.hurt_unit(u,4,source=None)
        with self.assertRaisesRegex(paid.UnknownMechanic,'Zero incoming'):
            e.hurt_unit(u,0,source=source,source_is_enemy=True)

    def test_silence_removes_cap_and_negative_bonus_without_healing(self):
        for cid in (56,840):
            e,u=self.engine(cid);u=replace(u,health=2)
            cleaned=e.silence(u)
            self.assertIsNone(cleaned.damage_cap);self.assertEqual(cleaned.enemy_damage_bonus,0)
            self.assertFalse(cleaned.armor);self.assertEqual(cleaned.health,2)
            self.assertEqual(e.hurt_unit(cleaned,8,source=None).health,0)

    def test_source_free_hurt_cannot_silently_ignore_new_abilities(self):
        e,u=self.engine()
        with self.assertRaisesRegex(ValueError,'source ownership'):board.hurt(u,8)

    def test_combat_both_sides_retain_source_ownership(self):
        e=paid.PaidSearch(self.cards,dict(hand_ids=[],max_plays=0,
            ally_bodies_before_play=[dict(card_id=840,attack=8,health=9,max_health=9,ready=True)],
            enemy_bodies=[dict(card_id=840,attack=8,health=9,max_health=9)]))
        a,s=next((a,s) for a,s in e.attacks(e.root()) if a['target']!='face')
        self.assertEqual((s.own[0].health,s.enemy[0].health),(0,0))

    def test_spell_and_magic_friend_enemy_and_self_paths(self):
        # Same body in two sides; same owned caster has genuinely different
        # ownership relative to each selected target, not active-phase guessing.
        d=dict(hand_ids=[20],gold_before_play=4,max_plays=1,
            ally_bodies_before_play=[dict(card_id=840,attack=8,health=9,max_health=9,ready=False)],
            enemy_bodies=[dict(card_id=840,attack=8,health=9,max_health=9)])
        e=paid.PaidSearch(self.cards,d);out=list(e.deploys(e.root()))
        own=next(s for a,s in out if a['magic_target']==('own',0))
        enemy=next(s for a,s in out if a['magic_target']==('enemy',0))
        self.assertEqual((own.own[0].health,enemy.enemy[0].health),(8,6))
        card,spec=e.hand[0];u=e.unit(card,dict(spec,damage_cap=3),'caster')
        root=replace(e.root(),own=e.root().own+(u,))
        after=e.magic(root,0,u,dict(spec,magic=('self_damage',8)))[0][1]
        self.assertEqual(after.own[-1].health,u.health-3)

    def test_dust_is_monster_damage_and_preserves_real_owner(self):
        e=paid.PaidSearch(self.cards,dict(hand_ids=[],max_plays=0,
            ally_bodies_before_play=[dict(card_id=583,attack=3,health=1,max_health=3),
                dict(card_id=840,attack=8,health=9,max_health=9)],
            enemy_bodies=[dict(card_id=840,attack=8,health=9,max_health=9)]))
        before=e.root();after=replace(before,own=(replace(before.own[0],health=0),before.own[1]))
        after=e.deaths(before,after)
        self.assertEqual((after.own[1].health,after.enemy[0].health),(8,6))

    def test_purpose_changes_best_candidate_and_independent_bounds_match(self):
        summary=self.result['role_summary']
        self.assertEqual([x['guaranteed_player_hp'] for x in summary],[11,11,12])
        self.assertEqual([x['guaranteed_same_body_hp'] for x in summary],[1,2,0])
        self.assertEqual([x['body_hp'] for x in self.result['paid_packet_examples']],[2,0,2,1,2,0])
        self.assertTrue(all(x['actual_payment']==4 for x in self.result['paid_packet_examples']))

    def test_unknown_scope_suppresses_recommendations_and_metrics(self):
        for name in self.result['unknown_cases']:
            r=self.rows[name]['result'];self.assertFalse(r['recommendations'])
            self.assertTrue(all(o['metrics'] is None for o in r['objectives']))

    def test_card_can_remain_held_without_payment(self):
        for cid in report.COHORT:
            r=self.rows[f'own-cash2-held-{cid}']['result']
            self.assertTrue(r['complete_in_declared_scope'])
            self.assertFalse(r['objectives'][1]['purpose_guaranteed'])
            self.assertFalse(any(a['kind']=='deploy' for a in r['objectives'][0]['principal_variation']))

    def test_projection_drops_the_ability_and_discloses_omission(self):
        c=next(x for x in self.cards if x['id']==56)
        e=board.BoardSearch(self.cards,dict(hand_ids=[56]),projection=True)
        self.assertIsNone(e.hand[0][1]['damage_cap']);self.assertTrue(e.omitted)

    def test_common_api_retains_authoritative_metrics(self):
        for cid in (56,377):
            r=evaluate_situation.evaluate(api.api_fixture(cid))
            self.assertTrue(r['paid_board_tactics']['complete_in_declared_scope'])
            self.assertEqual(r['paid_board_tactics']['objectives'][0]['metrics']['own_player_hp'],11 if cid==56 else 12)
            self.assertIsNone(r['hand_survival']['best_known_death_reducing_hand_index'])
            self.assertTrue(r['deployment_routes']['diagnostic_only'])

    def test_cap_and_cost_reduction_cannot_pick_a_convenient_order(self):
        e,u=self.engine();source=e.unit(*e.hand[0],'source')
        u=replace(u,monster_damage_reduction=(4,1))
        with self.assertRaisesRegex(paid.UnknownMechanic,'needs current/base/printed'):
            e.hurt_unit(u,5,source=source)
        source=replace(source,base_cost=3)
        with self.assertRaisesRegex(paid.UnknownMechanic,'modifier order'):
            e.hurt_unit(u,5,source=source)
        self.assertEqual(e.hurt_unit(u,2,source=source).health,4)
        self.assertEqual({d for d,n in board.packet_outcomes(8,3,True,0,0,2)},{2,3})


if __name__=='__main__':unittest.main()