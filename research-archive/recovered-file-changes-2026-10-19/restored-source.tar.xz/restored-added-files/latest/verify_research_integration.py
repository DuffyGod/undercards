"""Persist one current-code regression run and active artifact source audit.

Frozen historical reports are deliberately outside this explicit active list.
Success checks implementation and provenance, not real-match validity.
"""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
MODULES = ['test_board_tactics','test_paid_board_tactics','test_second_enemy_reply',
    'test_first_enemy_draw','test_control_timing','test_single_dust_damage',
    'test_compound_magic','test_hand_cost_death','test_next_turn_payment',
    'test_draw_integration','test_turn_end_effects','test_player_hp_observations',
    'test_situation_evaluator','test_hand_hp_certificate','test_hidden_reply_policy',
    'test_hidden_choice_boundaries','test_new_mechanic_search','test_cost_damage_resistance',
    'test_transparency','test_generic_enemy_magic','test_hand_magic',
    'test_body_hp_observations','test_future_draw_policy','test_replacement_slots',
    'test_physical_play_scope','test_hand_buff_magic','test_full_heal_transfer',
    'test_conditional_magic','test_death_discount_resistance',
    'test_immediate_lethal_certificate','test_immediate_lethal_api',
    'test_physical_draw_magic','test_draw_magic_certificates','test_current_draw_policy',
    'test_current_draw_api','test_current_draw_comparison','test_single_body_purpose',
    'test_damage_packets','test_dynamic_attack','test_alpha_beta_search',
    'test_conditional_card_score','test_periodic_healing','test_physical_slot_score','test_hand_capacity_opportunity',
    'test_literal_magic_extensions','test_literal_magic_api',
    'test_rule_probe_score','test_choice_magic_extensions','test_dodge_decay','test_nine_cost_api',
    'test_targeted_hand_magic','test_targeted_hand_api','test_position_quotient_score','test_scalar_task_score',
    'test_presence_magic_probe','test_presence_magic_api','test_silenced_observations','test_cost_magic_probe','test_target_cost_api',
    'test_alternative_goal_score','test_control_spells','test_closed_menu_contract','test_loaded_sources','test_control_spell_api']
ACTIVE = ['paid-standing-v01/comparison.json','standing-objectives-v01/comparison.json',
    'body-hp-cap-v01/comparison.json','hand-magic-v01/comparison.json',
    'transparency-v01/comparison.json','cost-damage-v01/comparison.json',
    'hand-cost-death-v01/comparison.json','first-enemy-draw-v01/comparison.json',
    'control-dust-v01/comparison.json','compound-magic-v01/comparison.json',
    'hidden-reply-v01/comparison.json','hidden-choice-v01/comparison.json',
    'hidden-reply-v01/api-verification.json','second-reply-v01/api-verification.json',
    'future-draw-v01/comparison.json','future-draw-v01/api-verification.json',
    'replacement-slot-v01/comparison.json','physical-play-scope-v01/comparison.json',
    'hand-buff-v01/comparison.json','full-heal-transfer-v01/comparison.json',
    'conditional-magic-v01/comparison.json','conditional-challenge-v01/independent-challenge.json',
    'death-discount-resistance-v01/comparison.json','immediate-lethal-v01/comparison.json',
    'immediate-lethal-v01/api-verification.json','physical-draw-magic-v01/comparison.json',
    'physical-draw-magic-v01/api-verification.json','current-draw-challenge-v01/comparison.json',
    'current-draw-challenge-v01/api-verification.json','single-body-purpose-v01/comparison.json',
    'current-draw-challenge-v01/independent-challenge.json','current-draw-challenge-v01/independent-hand-bounds.json',
    'single-body-pool-v01/comparison.json','damage-packet-v01/comparison.json',
    'damage-packet-v01/api-verification.json',
    'damage-packet-v01/incremental-comparison.json','damage-packet-v01/pool-comparison.json',
    'damage-packet-v01/pool-challenge.json','damage-packet-v01/timing-comparison.json',
    'damage-packet-v01/hand-structure.json','damage-packet-v01/timing-api-verification.json',
    'damage-packet-v01/timing-exhaustive.json','damage-packet-v01/independent-hand-policy.json',
    'dynamic-body-v01/comparison.json','dynamic-body-v01/api-verification.json',
    'dynamic-body-v01/purpose-boundaries.json','dynamic-body-v01/independent-verification.json',
    'deck-components-v01/comparison.json']
FROZEN_SUBTREES = {'body-hp-cap-v01/comparison.json': {('frozen_012_review',)}}
HISTORICAL_PAID022_ACTIVE=tuple(ACTIVE)
# The old48 results were actually rerun under paid0.22. Keep their sources and
# outputs immutable rather than pretending every later mechanism reran them.
HISTORICAL_PAID022_ROOT=HERE/'research-runs/literal-magic-v01/before'
ACTIVE=['conditional-score-v01/index.json','conditional-score-v01/verification.json',
    'periodic-spatial-v01/index.json','periodic-spatial-v01/verification.json',
    'periodic-spatial-v01/context-switches.json','literal-magic-v01/comparison.json',
    'literal-magic-v01/api-verification.json']
HISTORICAL_PAID023_ACTIVE=tuple(ACTIVE)
HISTORICAL_PAID023_ROOT=HERE/'research-runs/nine-cost-v01/before'
ACTIVE=['nine-cost-v01/index.json','nine-cost-v01/verification.json',
    'frontier-observations-v01/index.json','frontier-observations-v01/verification.json']
HISTORICAL_PAID024_ACTIVE=tuple(ACTIVE)
HISTORICAL_PAID024_ROOT=HERE/'research-runs/targeted-hand-production-v01/before'
ACTIVE=['targeted-hand-production-v01/comparison.json','targeted-hand-production-v01/verification.json']
HISTORICAL_PAID025_ACTIVE=tuple(ACTIVE)
HISTORICAL_PAID025_ROOT=HERE/'research-runs/targeted-hand-production-v01'
ACTIVE=['presence-magic-production-v01/comparison.json','presence-magic-production-v01/verification.json']
HISTORICAL_PAID027_ACTIVE=tuple(ACTIVE)
HISTORICAL_PAID027_ROOT=HERE/'research-runs/presence-magic-production-v01'
ACTIVE=['control-spell-production-v01/comparison.json','control-spell-production-v01/verification.json']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def regression_sources():
    pending=[*MODULES,Path(__file__).stem]
    found={}
    while pending:
        name=pending.pop().split('.')[0]
        path=HERE/(name+'.py')
        if path.name in found or not path.is_file():continue
        found[path.name]=sha(path)
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node,ast.Import):pending.extend(a.name for a in node.names)
            elif isinstance(node,ast.ImportFrom) and node.module:pending.append(node.module)
    return found


def audit():
    checked, errors = [], []
    for name in ACTIVE:
        path=HERE/'experiments'/name
        if not path.exists():
            errors.append(dict(artifact=name,error='missing'))
            continue
        document=json.loads(path.read_text())
        bindings={}
        frozen=[]
        def visit(value,location=()):
            if location in FROZEN_SUBTREES.get(name,set()):
                frozen.append(list(location))
                return
            if isinstance(value,dict):
                for key,item in value.items():
                    if key in ('source_hashes','source_sha256') and isinstance(item,dict):
                        for source,expected in item.items():
                            bindings.setdefault(source,set()).add(expected)
                    else:visit(item,location+(key,))
            elif isinstance(value,list):
                for index,item in enumerate(value):visit(item,location+(index,))
        visit(document)
        for source,expected in bindings.items():
            target=HERE/source
            if not target.is_file():
                errors.append(dict(artifact=name,source=source,error='source_missing'))
            elif expected != {sha(target)}:
                errors.append(dict(artifact=name,source=source,error='source_hash_mismatch',
                                   expected=sorted(expected),actual=sha(target)))
        checked.append(dict(artifact=name,sha256=sha(path),bound_source_files=len(bindings),
                            frozen_historical_subtrees=frozen))
    return dict(artifacts=checked,errors=errors,all_bound_sources_current=not errors,
        historical_paid022_reports=dict(count=len(HISTORICAL_PAID022_ACTIVE),snapshot=str(HISTORICAL_PAID022_ROOT),
            current_source_audit=False,reason='Version-pinned evidence; current comparisons are explicitly listed separately.'),
        historical_paid023_reports=dict(count=len(HISTORICAL_PAID023_ACTIVE),snapshot=str(HISTORICAL_PAID023_ROOT),
            current_source_audit=False,reason='Version-pinned source, score and independent-verification archive; not re-labelled as current execution.'),
        historical_paid024_reports=dict(count=len(HISTORICAL_PAID024_ACTIVE),snapshot=str(HISTORICAL_PAID024_ROOT),
            current_source_audit=False,reason='Actual paid0.24 reports and original sources retained; new held-state fields are separately tested and reported.'),
        historical_paid025_reports=dict(count=len(HISTORICAL_PAID025_ACTIVE),snapshot=str(HISTORICAL_PAID025_ROOT),
            current_source_audit=False,reason='Exact reports/ and source/ retained under the frozen paid0.25 receipt; not re-labelled as new execution.'),
        historical_paid027_reports=dict(count=len(HISTORICAL_PAID027_ACTIVE),snapshot=str(HISTORICAL_PAID027_ROOT),
            current_source_audit=False,reason='Frozen paid0.27 source/ and reports/ retain actual executions. New control, status goals and input guarantees are separately validated.'),
        scope='Explicit active reports only; frozen historical snapshots are not rewritten or audited as current.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audit-only',action='store_true')
    args=parser.parse_args()
    command=[sys.executable,'-m','unittest',*MODULES]
    hashes=regression_sources()
    run=dict(started_at_utc=datetime.now(timezone.utc).isoformat(),source_hashes=hashes,
        command=command,tests_executed=not args.audit_only,
        source_binding_scope='Test modules, runner and recursively imported local Python sources; independent unrelated research helper edits do not invalidate this run.')
    if not args.audit_only:
        process=subprocess.run(command,cwd=HERE,capture_output=True,text=True)
        output=process.stdout+process.stderr
        match=re.search(r'Ran (\d+) tests in ([\d.]+)s',output)
        run.update(exit_code=process.returncode,output=output,
            test_count=int(match[1]) if match else None,
            runner_seconds=float(match[2]) if match else None,
            passed=process.returncode==0 and match is not None and int(match[1])>0)
        print(output,end='',flush=True)
    run['artifact_audit']=audit()
    run['finished_at_utc']=datetime.now(timezone.utc).isoformat()
    run['source_unchanged_during_run']=all(sha(HERE/name)==digest for name,digest in hashes.items())
    run['interpretation']='Regression and source binding evidence only; shared mechanism primitives are not server-rule or real-match validation.'
    path=HERE/'experiments/current-integration-verification.json'
    previous=json.loads(path.read_text()) if path.exists() else dict(runs=[])
    previous['runs'].append(run)
    path.write_text(json.dumps(previous,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(tests=run.get('test_count'),passed=run.get('passed'),
        artifact_hash_errors=run['artifact_audit']['errors'],
        source_unchanged=run['source_unchanged_during_run']),ensure_ascii=False),flush=True)
    if not run['source_unchanged_during_run'] or run['artifact_audit']['errors'] \
            or (not args.audit_only and not run.get('passed')):
        sys.exit(1)


if __name__=='__main__':main()