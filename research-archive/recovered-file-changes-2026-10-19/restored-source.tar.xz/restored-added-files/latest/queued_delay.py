"""Queued numerical Delay healing, with unresolved filters kept three-valued.

No choice of current/base COST or enqueue/end condition timing is invented.
Known cost records yield bounds; agreement permits execution, disagreement is
reported by the caller. A queue entry belongs to the Play event, not a unit's
continued existence. Ordinary Summon never creates one.
"""
from dataclasses import dataclass
import re


@dataclass(frozen=True)
class Delay:
    source_key: str
    heal: int
    threshold: int | None = None
    cost: int | None = None
    deployment_gate: bool | None = None


def parse(text):
    m=re.fullmatch(r'(?P<prefix>(?:(?:Taunt|Haste|Charge|Armor|Dodge \(\d+\))\.\s*)*)Delay: '
        r'If you have (\d+)\+ (\d+)-COST monsters in your hand or dustpile, heal (\d+) HP to you\.',text.strip())
    if m:
        return m['prefix'].strip(),dict(threshold=int(m[2]),cost=int(m[3]),heal=int(m[4]))
    m=re.fullmatch(r'(?P<prefix>(?:(?:Taunt|Haste|Charge|Armor|Dodge \(\d+\))\.\s*)*)Delay: Heal (\d+) HP to you\.',text.strip())
    if m: return m['prefix'].strip(),dict(heal=int(m[2]))
    return None


def axis_gate(records,threshold,cost,axis,dust_known):
    known=sum(r[axis]==cost for r in records if r[axis] is not None)
    uncertain=sum(r[axis] is None for r in records)
    if known>=threshold: return True
    if dust_known and known+uncertain<threshold: return False
    return None


def cost_gate(hand_records,dust_records,threshold,cost):
    # Current, runtime base and ordinary printed COST are distinct fields.
    # A common field across two zones is also unverified; compare all nine
    # combinations rather than allow one zone to compensate for the other.
    values=[]
    for hand_axis in (0,1,2):
        for dust_axis in (0,1,2):
            records=[(r[hand_axis],) for r in hand_records]
            records+=[] if dust_records is None else [(r[dust_axis],) for r in dust_records]
            values.append(axis_gate(records,threshold,cost,0,dust_records is not None))
    return values[0] if values[0] is not None and all(v==values[0] for v in values) else None