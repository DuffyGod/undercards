"""Observation, legality and conservative-guarantee invariants without labels."""
import copy
import unittest
from unittest.mock import patch

import current_draw_policy as current
import future_draw_policy as future
import paid_board_tactics as paid
import score_cards
import test_future_draw_policy


def fixture(cash=8):
    scene=dict(hand_ids=[243,196],own_deck_ids=[22,96],max_plays='all_physical',next_max_plays=0,
        gold_before_play=cash,own_player_hp=7,own_player_max_hp=30,enemy_player_hp=30,
        enemy_player_max_hp=30,enemy_bodies=[dict(card_id=15,attack=6,health=4,max_health=5)],
        ally_bodies_before_play=[],opponent_hand_ids=[],opponent_deck_ids=[],
        opponent_gold_before_response=0,own_fatigue_next=1,first_opponent_natural_draw_count=0,
        horizon='enemy_attack',objectives=['guaranteed_hp'],node_limit=10000)
    return dict(panels=[scene,dict(copy.deepcopy(scene),own_deck_ids=[96,22])],
        opponent_hand_known=True,node_limit=20000)


def matrix(result):
    return {current.action_key(r['shared_prefix']):
        [tuple(p['result']['objective_vector']) for p in r['panel_payoffs']]
        for r in result['per_prefix_payoffs']}


class CurrentDrawPolicyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def test_retained_draw_reveals_before_distinct_actual_paid_actions(self):
        r=current.evaluate(fixture(),self.cards)
        self.assertTrue(r['complete_in_declared_scope'],r['unknown'])
        self.assertEqual(r['metrics']['own_player_hp'],5)
        self.assertEqual(r['observation_policy']['adaptation_boundary'],'current_retained_draw')
        self.assertEqual(r['shared_prefix'][-1]['card_id'],243)
        self.assertEqual(r['shared_prefix'][-1]['paid_gold'],5)
        self.assertEqual(r['observation_policy']['observations'],
            [[dict(physical_index=2,card_id=22)],[dict(physical_index=2,card_id=96)]])
        branches=r['observation_policy']['panel_payoffs']
        self.assertEqual([p['result']['metrics']['own_player_hp'] for p in branches],[5,7])
        self.assertEqual([(p['result']['principal_variation'][0]['card_id'],
                           p['result']['principal_variation'][0]['paid_gold']) for p in branches],[(22,3),(96,3)])
        self.assertEqual(current.evaluate(fixture(7),self.cards)['metrics']['own_player_hp'],1)

    def test_full_prefix_matrix_matches_exhaustive_search(self):
        data=fixture();alpha=current.evaluate(data,self.cards)
        for p in data['panels']:p['search_algorithm']='exhaustive'
        exhaustive=current.evaluate(data,self.cards)
        self.assertTrue(exhaustive['complete_in_declared_scope'],exhaustive['unknown'])
        self.assertEqual(alpha['objective_vector'],exhaustive['objective_vector'])
        self.assertEqual(matrix(alpha),matrix(exhaustive))
        self.assertLessEqual(tuple(alpha['objective_vector']),tuple(alpha['oracle_minimum_vector']))

    def test_world_relabel_and_permutation_do_not_change_guarantee(self):
        data=fixture();original=current.evaluate(data,self.cards)
        data['panels'].reverse();data['panel_names']=['second','first']
        reversed_result=current.evaluate(data,self.cards)
        self.assertEqual(original['objective_vector'],reversed_result['objective_vector'])
        self.assertEqual(original['shared_prefix'],reversed_result['shared_prefix'])

    def test_without_current_draw_existing_future_protocol_stays_equal(self):
        data=test_future_draw_policy.fixture()
        old=future.evaluate(data,self.cards);new=current.evaluate(data,self.cards)
        self.assertTrue(old['complete_in_declared_scope']);self.assertTrue(new['complete_in_declared_scope'],new['unknown'])
        self.assertEqual(old['objective_vector'],new['objective_vector'])
        self.assertEqual(old['common_own_prefix'],new['shared_prefix'])

    def test_pre_reveal_action_mismatch_is_not_intersected(self):
        original=paid.PaidSearch.deploys
        def corrupted(engine,state):
            for action,child in original(engine,state):
                if state.phase==0 and engine.hand[engine.deck_indexes[0]][0]['id']==96 and action.get('card_id')==243:continue
                yield action,child
        with patch.object(paid.PaidSearch,'deploys',corrupted):result=current.evaluate(fixture(),self.cards)
        self.assertFalse(result['complete_in_declared_scope'])
        self.assertIn('cannot intersect',' '.join(result['unknown']))
        self.assertIsNone(result['observation_policy']);self.assertFalse(result['shared_prefix'])

    def test_prior_oracle_overstatement_remains_visible_without_current_draw(self):
        from build_future_draw_comparison import fixture as prior
        result=current.evaluate(prior(income=5,future_plays=2),self.cards)
        self.assertTrue(result['complete_in_declared_scope'],result['unknown'])
        self.assertEqual(result['objective_vector'][0],4)
        self.assertEqual(result['oracle_minimum_vector'][0],5)

    def test_unknown_and_budget_withdraw_every_policy(self):
        budget=fixture();budget['node_limit']=1
        unknown=fixture();unknown['panels'][0]['own_deck_ids']=[527,96];unknown['panels'][1]['own_deck_ids']=[96,527]
        for data in (budget,unknown):
            r=current.evaluate(data,self.cards)
            self.assertFalse(r['complete_in_declared_scope']);self.assertTrue(r['unknown'])
            for key in ('objective_vector','metrics','observation_policy','oracle_minimum_vector'):self.assertIsNone(r[key])
            for key in ('shared_prefix','per_prefix_payoffs','perfect_information_oracles'):self.assertFalse(r[key])

    def test_public_state_differences_duplicate_cards_or_no_reveal_future_are_rejected(self):
        invalid=[]
        data=fixture();data['panels'][1]['gold_before_play']=9;invalid.append(data)
        data=fixture();data['panels'][0]['own_deck_ids']=[22,22];invalid.append(data)
        data=fixture()
        for p in data['panels']:p.update(horizon='next_own_attack',next_natural_draw_count=0)
        invalid.append(data)
        data=fixture()
        for p in data['panels']:p['hand_ids']=[243]*7
        invalid.append(data)
        data=fixture()
        for p in data['panels']:p['soul']='KINDNESS'
        invalid.append(data)
        for data in invalid:
            with self.assertRaises(ValueError):current.evaluate(data,self.cards)


if __name__=='__main__':unittest.main()