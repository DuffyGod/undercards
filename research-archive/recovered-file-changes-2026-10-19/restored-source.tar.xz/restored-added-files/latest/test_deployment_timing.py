import copy
import unittest

import context_value as ledger
import deployment_timing as timing
import score_cards as base
import unified_value as unified


class DeploymentTimingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards={c['id']:c for c in base.load_cards()}
        cls.reference,_=base.make_reference(list(cls.cards.values()))

    def setUp(self):
        self.profile=unified.normalize_profile()
        self.state=next(s for s in unified.make_panel(self.profile)
                        if s['context_id']=='midrange-t3-reserved-pressured')

    def effect(self,cid,d):
        future,_=unified.forecast_context(self.state,d,self.profile)
        future['dust_timing']=timing.dust_context(self.state,future,self.profile)
        card=self.cards[cid]
        result=ledger.evaluate_branch(card,future,ledger.parse(card)[0],self.reference,quote_only=True)
        return next(r for r in result['ledger'] if r['term'].startswith('dust_timing_'))

    def test_wait_cannot_roll_deadline_or_death_prior(self):
        a=self.effect(43,0); b=self.effect(43,1); c=self.effect(43,2)
        self.assertGreater(a['model_gold'],b['model_gold'])
        self.assertEqual(c['model_gold'],0)
        self.assertEqual([x['trigger_probability'] for x in (a,b,c)],[.45,.45,.45])
        self.assertEqual(c['realization_probability'],0)

    def test_cash_at_deadline_still_realizes_but_discount_does_not(self):
        self.assertEqual(self.effect(43,2)['model_gold'],0)
        self.assertAlmostEqual(self.effect(138,2)['model_gold'],.9)
        self.assertEqual(self.effect(138,3)['model_gold'],0)

    def test_zero_cost_and_unused_hand_have_no_discount_savings(self):
        self.state.update(death_event_hand_costs=[0,5],actually_used_mask=[True,False])
        self.assertEqual(self.effect(43,0)['model_gold'],0)
        self.assertGreater(self.effect(138,0)['model_gold'],0)

    def test_policy_is_generic_and_weights_stay_complete(self):
        a=unified.score(self.cards[43],self.reference,include_rows=False)
        renamed=dict(self.cards[43],id=-543,name='Generic dust discount')
        b=unified.score(renamed,self.reference,include_rows=False)
        self.assertAlmostEqual(a['value_margin_model_gold'],b['value_margin_model_gold'])
        self.assertEqual(a['context_count'],72)
        self.assertAlmostEqual(a['weight_sum'],1)

    def test_cash_and_fixed_deadline_configs_validate_before_scoring(self):
        for changes in ({'enemy_attack_limit':True},{'enemy_attack_limit':5},
                        {'dust_timing_policy':{'horizon_extra_turns':-1,'event_delay_turns':0,'discount_rate':0}}):
            with self.assertRaises(ValueError):
                unified.normalize_profile(changes)

    def test_need_false_keeps_haste_body_and_unknown_future_is_not_copied(self):
        card=self.cards[438]
        modules,unknown=ledger.parse(card)
        self.assertFalse(unknown)
        # Condition schema comes from the finite predicate's declared field.
        self.state['condition_state']={'last_turn_gold_spent_on_spells':0}
        false=copy.deepcopy(self.state)
        false['condition_state']={'last_turn_gold_spent_on_spells':0}
        true=copy.deepcopy(self.state)
        true['condition_state']={'last_turn_gold_spent_on_spells':1}
        a=ledger.evaluate_branch(card,false,modules,self.reference,quote_only=True)
        b=ledger.evaluate_branch(card,true,modules,self.reference,quote_only=True)
        self.assertGreater(a['gross_model_gold'],0)
        self.assertGreater(b['gross_model_gold'],a['gross_model_gold'])
        self.assertFalse(a['activation_conditions'][0]['value'])
        future,_=unified.forecast_context(true,1,self.profile)
        with self.assertRaisesRegex(ValueError,'activation unknown'):
            ledger.evaluate_branch(card,future,modules,self.reference,quote_only=True)


if __name__=='__main__':
    unittest.main()