"""Publish exact independent-goal results without rewriting their raw inputs."""
import csv
import hashlib
import json
from pathlib import Path

import alternative_goal_score as alt
import conditional_card_score as score

HERE=Path(__file__).resolve().parent
RUN=HERE/'research-runs/alternative-goal-v01'
OUT=HERE/'experiments/alternative-goal-v01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')


def main():
    OUT.mkdir(exist_ok=True)
    index=read(RUN/'index.json');horizon=read(RUN/'horizon-transfer.json');frontier=read(RUN/'resistance-frontier.json')
    proof=read(RUN/'independent-bounds.json');cli=read(RUN/'cli-verification.json');reg=read(RUN/'regression.json')
    answers=read(RUN/'native-spell-answers.json');combo=read(RUN/'combo-answers.json')
    for doc in (index,horizon,frontier,answers,combo,cli,reg):
        for name,h in doc['source_hashes'].items():assert sha(HERE/name)==h,name
    assert proof['passed'] and cli['passed'] and reg['passed']
    assert (proof['matching_cells'],proof['horizon_matching_cells'],proof['frontier_matching_cells'])==(72,108,90)
    assert (proof['native_spell_matching_cells'],proof['combo_matching_cells'])==(106,30)
    assert reg['test_count']==11 and reg['current_source_test_coverage']==612
    native=[r for r in index['rows'] if r['context'].startswith('card')]
    flexible=[r['card_id'] for r in native if r['scores']['clear_or_focal4_1']['feasible'] and
        all(r['scores'][n]['known'] and not r['scores'][n]['feasible'] for n in ('clear','focal4_1'))]
    assert flexible==[20,110,292,534]
    comparisons=dict(source_hashes=score.source_bindings(Path(__file__)),version=alt.VERSION,
        general_comparison=index,horizon_transfer=horizon,resistance_frontier=frontier,
        native_spell_answers=answers,combo_answers=combo,
        union_only_feasible_ids=flexible, same_policy_required=True, goals_not_valued_as_additive_assets=True,
        general_native_known=71,general_native_compiled=78,
        global_rating=None,empirical_frequencies=None,real_match_accuracy_established=False)
    write(OUT/'comparison.json',comparisons)
    evidence=['index.json','horizon-transfer.json','resistance-frontier.json','independent-bounds.json',
        'native-spell-answers.json','combo-answers.json','combo-vector-checks.json',
        'native-spell-builder-at-execution.py','native-spell-answers.before-metadata-correction.json',
        'native-proof-first-failure.log','native-proof-second-failure.log','native-proof-third-failure.log',
        'cli-verification.json','regression.json','pilot-tests.log','pilot-corrected-tests.log']
    write(OUT/'verification.json',dict(passed=True,source_hashes=comparisons['source_hashes'],
        same_loaded_sources_checked=True,independent_numerical_cells=406,independent_reply_states=proof['reply_states'],
        full_vector_alpha_exhaustive_matches=index['full_vector_matches']+combo['full_vector_matches'],
        actual_final_protocol_queries=709,earlier_partial_observation_protocol_queries=360,
        final_protocol_breakdown=dict(general=360,generated_reference=4,real_cli=2,horizon=108,resistance=90,native_spells=108,combo=37),
        supplementary_tests=dict(actually_executed=11,source_identical_registered_reuse=601,
            total_registered_production_tests=601,total_with_supplementary_module=612,
            additional_module='test_alternative_goal_score',note='612 is source-bound coverage including the supplementary objective module, not a newly executed whole suite.'),
        evidence_sha256={n:sha(RUN/n) for n in evidence},
        limits=['The independent enumerator validates these406 cells, not all78 candidate mechanisms.',
            'More possible purposes do not yield an additive card price; selecting acceptable outcomes is the user decision.',
            'Source-bound finite decisions under declared reply menus, not server or empirical reliability.']))
    columns=['family','context','card_id','name','task','known','feasible','hp','body_attack','body_health','artifact']
    flat=[]
    for row in index['rows']:
        for name,cell in row['scores'].items():flat.append(dict(family='single-response',context=row['context'],card_id=row['card_id'],name=row['name'],task=name,
            known=cell['known'],feasible=cell['feasible'],hp=cell['guaranteed_player_hp'],artifact=row['artifact']))
    for row in horizon['rows']:
        for name,cell in row['scores'].items():flat.append(dict(family='deadline',context=row['horizon']+'-'+row['reply'],card_id=row['card_id'],task=name,
            known=cell['known'],feasible=cell['feasible'],hp=cell['guaranteed_player_hp'],artifact=row['artifact']))
    for row in frontier['rows']:flat.append(dict(family='punishment',context=row['reply'],**{k:row[k] for k in columns if k not in ('family','context')}))
    for family,document in [('native-spell',answers),('combo',combo)]:
        for row in document['rows']:
            for name,cell in row['scores'].items():
                context=('spell'+str(row['spell_id']) if family=='native-spell' else '-'.join(map(str,row['hand_ids'])))+'-cash'+str(row['enemy_cash'])
                flat.append(dict(family=family,context=context,card_id=row['card_id'],task=name,known=cell['known'],
                    feasible=cell['feasible'],hp=cell['guaranteed_player_hp'],artifact=row['artifact']))
    with (OUT/'scores.csv').open('w',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=columns);writer.writeheader();writer.writerows(flat)
    cards={c['id']:c for c in read(RUN/'native-snapshot.json')['cards']}
    data=dict(rows=frontier['rows'],cards={str(i):cards[i] for i in sorted({r['card_id'] for r in frontier['rows']})},
        comparison_sha256=sha(OUT/'comparison.json'),source_hashes=comparisons['source_hashes'])
    encoded=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<',r'\u003c').replace('>',r'\u003e').replace('&',r'\u0026')
    html=(OUT/'view-template.html').read_text().replace('__DATA__',encoded)
    (OUT/'resistance-explorer.html').write_text(html)
    write(OUT/'view-provenance.json',dict(html_sha256=sha(OUT/'resistance-explorer.html'),builder_sha256=sha(Path(__file__)),
        template_sha256=sha(OUT/'view-template.html'),comparison_sha256=sha(OUT/'comparison.json'),model_search_calls=0))
    print(json.dumps(dict(passed=True,independent_cells=406,csv_cells=len(flat),queries=709,union_only_ids=flexible)))


if __name__=='__main__':main()