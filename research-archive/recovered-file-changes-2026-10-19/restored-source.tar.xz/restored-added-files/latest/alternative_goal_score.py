"""One policy guaranteeing at least one explicitly acceptable terminal outcome.

For clauses C_i, solve max_own min_enemy (alive AND any C_i, hero HP, ties).
The opponent may select different satisfied clauses on different branches.
This is not max_i of the separately optimized clause scores.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path

import board_tactics as board
import conditional_card_score as score
from physical_slot_score import PhysicalGeometryMixin

VERSION = 'alternative-goal-score-0.2.0'
LOADED_SOURCES = score.source_bindings(Path(__file__))


def normalize(task):
    if not isinstance(task, dict) or set(task) != {'kind', 'clauses'} or task['kind'] != 'any':
        raise ValueError('Alternative goal requires kind=any and clauses')
    if not isinstance(task['clauses'], list) or len(task['clauses']) < 2:
        raise ValueError('At least two nonempty acceptable outcome clauses required')
    clauses = []
    for clause in task['clauses']:
        if not isinstance(clause, dict) or set(clause) - {'body_scope', 'constraints'}:
            raise ValueError('Clause fields: body_scope/constraints')
        scope, bounds = clause.get('body_scope', 'board'), clause.get('constraints')
        if scope not in ('board', 'focal', 'lineage'):
            raise ValueError('Clause scope board/focal/lineage required')
        if not isinstance(bounds, dict) or not bounds or set(bounds) - score.paid.PURPOSE_FIELDS:
            raise ValueError('Nonempty supported clause constraints required')
        for key, value in bounds.items():
            board.finite_number(value, key)
        if scope != 'board' and not score.paid.SINGLE_BODY_PURPOSE_FIELDS.intersection(bounds):
            raise ValueError('Focal/lineage scope requires same-body bounds')
        clauses.append((scope, tuple(sorted(bounds.items()))))
    return tuple(clauses)


class AlternativeSearch(score.TaskSearch):
    def __init__(self, cards, data, *, clauses, focal_index=None, delay_current=False):
        self.clauses = clauses
        super().__init__(cards, data, focal_index=focal_index, delay_current=delay_current)

    def clause_satisfied(self, state, clause):
        scope, pairs = clause
        m = board.metrics(state)
        if m['own_player_dead']:
            return False
        bounds = dict(pairs)
        if not all(m[k[4:]] >= v if k.startswith('min_') else m[k[4:]] <= v
                   for k, v in pairs if k not in score.paid.SINGLE_BODY_PURPOSE_FIELDS):
            return False
        body = {k: v for k, v in pairs if k in score.paid.SINGLE_BODY_PURPOSE_FIELDS}
        if not body:
            return True
        key = 'hand:' + str(self.focal_index)
        return any(u.health > 0 and (scope == 'board' or u.key == key or
                   (scope == 'lineage' and u.key.startswith(key + ':'))) and
                   all(self.purpose_body_value(u, state, k) >= v if k.startswith('min_')
                       else self.purpose_body_value(u, state, k) <= v
                       for k, v in body.items()) for u in state.own)

    def objective(self, state, mode):
        if mode != 'purpose':
            return super().objective(state, mode)
        satisfied = any(self.clause_satisfied(state, c) for c in self.clauses)
        return (int(satisfied), board.metrics(state)['own_player_hp']) + board.objective_vector(state, 'survive')

    def solve(self, root, mode):
        result = super().solve(root, mode)
        # The inherited replay needs a valid purpose object, but its dummy
        # constructor constraint never defines this search objective.
        result.pop('purpose_constraints', None)
        result['alternative_goal'] = [dict(body_scope=s, constraints=dict(b)) for s, b in self.clauses]
        result['each_clause_individually_guaranteed'] = False
        return result


class PhysicalAlternativeSearch(PhysicalGeometryMixin, AlternativeSearch):
    pass


def evaluate(data, task, *, cards=None, focal_index=None, delay_current=False):
    bindings = score.source_bindings(Path(__file__))
    if bindings != LOADED_SOURCES:
        raise RuntimeError('Loaded alternative-goal sources changed')
    cards = score.score_cards.load_cards() if cards is None else cards
    if not isinstance(cards, list) or any(not isinstance(c, dict) or type(c.get('id')) is not int for c in cards) \
            or len({c['id'] for c in cards}) != len(cards):
        raise ValueError('Unique integer card-source IDs required')
    digest = hashlib.sha256(score.canonical(cards).encode()).hexdigest()
    clauses = normalize(task)
    if focal_index is not None and (type(focal_index) is not int or
            not 0 <= focal_index < len(data.get('hand_ids', []))):
        raise ValueError('Focal index must name an initially held physical copy')
    if any(s != 'board' for s, _ in clauses) and focal_index is None:
        raise ValueError('Focal/lineage clauses require a physical focal index')
    if type(delay_current) is not bool or (delay_current and focal_index is None):
        raise ValueError('Delay is boolean and requires a physical focal copy')
    scene = copy.deepcopy(data)
    if type(scene.get('physical_slots', False)) is not bool:
        raise ValueError('physical_slots is boolean')
    if not scene.get('physical_slots') and {'front_slot_map', 'front_missing_policy'}.intersection(scene):
        raise ValueError('Geometry observations require physical_slots=true')
    scene.pop('objectives', None)
    scene['purpose_constraints'] = dict(min_own_player_hp=1)
    cls = PhysicalAlternativeSearch if scene.get('physical_slots') else AlternativeSearch
    engine = cls(cards, scene, clauses=clauses, focal_index=focal_index, delay_current=delay_current)
    root = engine.root()
    result = (engine.solve(root, 'purpose') if not engine.unknown else
              dict(search_complete=False, unknown=sorted(set(engine.unknown)), metrics=None, principal_variation=[]))
    known = result['search_complete']
    feasible = result['purpose_guaranteed'] if known else None
    value = dict(version=VERSION, known=known, feasible=feasible,
        guaranteed_player_hp=result['metrics']['own_player_hp'] if known and feasible else None,
        task=copy.deepcopy(task), focal_index=focal_index, delay_current=delay_current,
        search=result, unknown=result.get('unknown', []), source_hashes=bindings, cards_sha256=digest,
        input_sha256=hashlib.sha256(score.canonical(data).encode()).hexdigest(),
        same_policy_for_goal_and_hp=True, each_clause_individually_guaranteed=False,
        all_metrics_componentwise_guaranteed=False, production_rules_version=score.paid.VERSION,
        experimental_objective=True, geometry_quotient_used=False)
    if bindings != score.source_bindings(Path(__file__)) or digest != hashlib.sha256(score.canonical(cards).encode()).hexdigest():
        raise RuntimeError('Alternative goal source changed during evaluation')
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--cards-source', type=Path)
    args = parser.parse_args()
    payload = json.loads(args.input.read_text())
    cards = None
    if args.cards_source:
        raw = json.loads(args.cards_source.read_text())
        cards = raw.get('cards') if isinstance(raw, dict) else raw
    result = evaluate(payload['scene'], payload['task'], cards=cards,
        focal_index=payload.get('focal_index'), delay_current=payload.get('delay_current', False))
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


if __name__ == '__main__':
    main()