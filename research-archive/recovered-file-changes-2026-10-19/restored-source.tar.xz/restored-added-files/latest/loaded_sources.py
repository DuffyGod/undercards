"""Remember source bytes when core modules execute, not when a parent imports.

An already cached child must never acquire a new source certificate merely
because another entry point is imported after its file changed. Reloading a
changed core requires a fresh process. This is a development consistency guard,
not protection against an adversary modifying files during Python compilation.
"""
import hashlib
from pathlib import Path

_EXECUTED = {}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(module_name, filename):
    path = Path(filename).resolve()
    key = (module_name, str(path))
    value = digest(path)
    old = _EXECUTED.get(key)
    if old is not None and old != value:
        raise RuntimeError('Loaded source changed; start a fresh process: ' + path.name)
    _EXECUTED[key] = value


def verify():
    checked = {}
    for (_, filename), expected in tuple(_EXECUTED.items()):
        if filename not in checked:
            checked[filename] = digest(filename)
        actual = checked[filename]
        if actual != expected:
            raise RuntimeError('Loaded source differs from disk; start a fresh process: ' + Path(filename).name)


record(__name__, __file__)