# 2026-10-17：可恢复性检查点

此页优先于旧 `CONTINUATION.md` 中的下一步安排。用户最新要求：解释文件缺失、保存产物；有验证依据的结论不要重复计算。当前已停止扩大研究。

## 已知事实与不能确定的原因

- 本次启动时，工作区 HEAD、本地 main 和远端 main 都是 `1114448c4e8b611bf174289bcb47fd50cea52d3c`；此前的 paid0.32/API0.34 等新增源码、报告不在这个提交中，也未在当前可访问目录找到。
- 没有平台工作区生命周期日志，不能认定用户做了操作，也不能确定平台为何提供这个状态。
- 此前只在本地冻结文件、记录哈希，没有完成 Git 提交/推送或工作区外备份。哈希不能重建丢失的内容。聊天中的“已完成”也不是源码副本。
- 旧报告提到的 108 张支持、734 项检查等是历史陈述；对应后期产物当前不可用，不可宣称已恢复，也不要重新计算后冒充原来的验证。

## 当前保存了什么

`research-archive/information-policy-v01.zip` 是当前可访问内容的源码及证据包。外部 `.manifest.json` 记录每个文件的大小、SHA256 和整个 ZIP 的 SHA256；ZIP 内也包含文件清单。包含：

1. 当前 Git 跟踪的源码、规则快照、续作说明和早期证据归档；早期证据清单列出的 216 个文件也直接收录，恢复不依赖网络。
2. 本次新写的 `analysis/monster-value-heuristic/finite_game/`、`information_pressure.py`、测试，以及 `research-runs/information-policy-v01/` 全部输入、原始输出、独立复核、失败/拒绝记录和脚本。
3. 更新后的 `tools/verify_stage.py` 及归档/校验/恢复工具。没有包含 `.git`、环境凭据、密钥、Python 缓存。

这是当前可用内容的新检查点，**没有找回已缺失的后期旧版本**。新的有限信息集模块是独立工作，不是假装继承旧内核。

## 已有结论如何继续使用

- 旧阶段：优先使用 `stage-verification.json`、旧原始结果和其来源哈希；历史测试数量不等于现在完整模型的可靠率。
- 新阶段主证据：`research-runs/information-policy-v01/main/index.json` 和对应逐次原始查询；压力曲线在 `pressure/index.json` 及对应原始查询；独立反例/站场验证在 `review/`。
- `pilot-source/` 保留早期试验实际源码。早期试验与当前源码版本不同，不能重贴当前源码哈希。
- 已拒绝的跨 SOUL 输入保留为拒绝记录；Generated 敌手牌来源的不可见性仍是声明假设，并非已核实的服务器信息规则。有限短期包络不等于真实天梯分布。
- 只有输入/规则/程序依赖改变、发现实际冲突或新增功能时才重验受影响部分；不要为汇报重跑原结论，不要因文件缺失把研究悄悄归零。

## 怎样保存和恢复

**持久保存需要工作区之外的副本。** 当前 ZIP 和清单仍是本地文件；生成 ZIP 本身不保证云工作区未来保留。

本检查点的远端保存目标为 `origin` 的 `research/information-policy-v01-20261017` 分支：源码、原始证据、ZIP、清单、此页和恢复工具一起提交。仅本地 `git commit` 仍不保证换环境后可用；保存成功以推送后的远端提交 ID 及归档文件核对为准，具体提交号见交付消息。

新环境可以直接检出该分支，读取本页；Git 已跟踪的新源码及归档随分支恢复。需要展开早期被忽略的证据时使用原有 `tools/restore_stage_evidence.py`，它只恢复文件，不重新计算结论。

同时下载 `research-archive/information-policy-v01.zip` 和 `research-archive/information-policy-v01.manifest.json` 到本机或其他持久存储，保留独立第二份。ZIP 可用普通解压工具解开，即使 Python 工具本身也丢失，仍能取出内部恢复脚本。

校验归档（不会模拟卡牌，也不会调用 API）：

```sh
python tools/research_checkpoint.py verify
```

恢复到一个新目录，避免覆盖其他工作：

```sh
python tools/research_checkpoint.py restore --destination /workspace/undercards-restored
```

工具先检查整个归档及全部冲突，再写入；遇到不同内容的已有文件会退出。恢复后先读本页并核对已有证据，不默认重跑研究。

以后每次有实质变更，先更新说明与证据，再生成新归档并实际提交、推送或下载。`create` 会读取当前文件，不会计算研究结果：

```sh
python tools/research_checkpoint.py create
```

归档清单不是签名：它用于完整性检查，不能抵御 ZIP 和清单一起被恶意替换。