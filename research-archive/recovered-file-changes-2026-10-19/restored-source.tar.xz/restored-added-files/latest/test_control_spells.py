"""Haste permissions, shared payment and visible paralysis are distinct facts."""
import copy
import unittest

import alternative_goal_score as alt
import conditional_card_score as score
import paid_board_tactics as paid


def scene(**changes):
    return dict(dict(hand_ids=[77], hand_costs=[0], gold_before_play=0, max_plays=1,
        own_player_hp=1, own_player_max_hp=30, enemy_player_hp=30, enemy_player_max_hp=30,
        ally_bodies_before_play=[dict(card_id=270,attack=4,health=4,max_health=4,ready=False,attacked=False)],
        enemy_bodies=[dict(card_id=270,attack=4,health=4,max_health=4,ready=True)],
        opponent_hand_ids=[],opponent_hand_known=True,opponent_gold_before_response=0,
        horizon='enemy_attack',objectives=['guaranteed_hp']),**changes)


def prison(cash=3,horizon='next_own_attack'):
    data=scene(hand_ids=[],hand_costs=[],max_plays=0,own_player_hp=30,
        ally_bodies_before_play=[dict(card_id=15,attack=6,health=5,max_health=5,ready=False,attacked=False)],
        enemy_bodies=[dict(card_id=2,attack=2,health=3,max_health=3,ready=True)],
        opponent_hand_ids=[182],opponent_hand_costs=[3],opponent_hand_base_costs=[3],
        opponent_gold_before_response=cash,horizon=horizon)
    if horizon=='next_enemy_attack':data.update(next_opponent_gold_income=0,next_opponent_natural_draw_count=0)
    return data


class ControlSpellTests(unittest.TestCase):
    def test_full_literal_programs_only(self):
        self.assertEqual(paid.spell_spec(dict(effect_readable='Give an ally monster Haste.',card_type='spell'))['spell'][0]['kind'],'give_haste')
        self.assertEqual(paid.spell_spec(dict(effect_readable='Silence a monster. Paralyze it.',card_type='spell'))['spell'][0]['kind'],'silence_paralyze')
        for text in ('Give an ally monster Haste. Draw a card.','Silence a monster. Paralyze it. Draw a card.'):
            self.assertTrue(paid.spell_spec(dict(effect_readable=text,card_type='spell'))['unknown'])

    def test_fresh_haste_can_trade_and_save_life(self):
        result=paid.evaluate(scene())
        self.assertTrue(result['complete_in_declared_scope']);self.assertEqual(result['objectives'][0]['metrics']['own_player_hp'],1)
        self.assertEqual(result['objectives'][0]['metrics']['enemy_living_count'],0)

    def test_already_attacked_cannot_be_refreshed(self):
        data=scene();data['ally_bodies_before_play'][0]['attacked']=True
        result=paid.evaluate(data)
        self.assertTrue(result['complete_in_declared_scope']);self.assertEqual(result['objectives'][0]['metrics']['own_player_hp'],0)

    def test_missing_history_is_unknown_not_a_fresh_body(self):
        data=scene();data['ally_bodies_before_play'][0].pop('attacked')
        result=paid.evaluate(data)
        self.assertFalse(result['complete_in_declared_scope'])
        self.assertTrue(any('attacked history' in s for s in result['unknown']))

    def test_fresh_permission_is_monsters_only_and_exact_copy_consumed(self):
        e=paid.PaidSearch(score.score_cards.load_cards(),scene(enemy_player_hp=4));root=e.root()
        action,child=next(e.casts(root,'own'))
        self.assertEqual(action['targets'],[('own',0)]);self.assertEqual(action['paid_gold'],0)
        self.assertEqual(child.hand,());self.assertEqual(child.plays,1);self.assertEqual(child.own[0].ready,1)
        self.assertTrue(list(e.attacks(child)));self.assertFalse(any(a['target']=='face' for a,_ in e.attacks(child)))

    def test_existing_ordinary_permission_keeps_face(self):
        data=scene();data['ally_bodies_before_play'][0]['ready']=True
        e=paid.PaidSearch(score.score_cards.load_cards(),data);_,child=next(e.casts(e.root(),'own'))
        self.assertEqual(child.own[0].ready,2)
        self.assertTrue(any(a['target']=='face' for a,_ in e.attacks(child)))

    def test_haste_never_selects_enemy(self):
        e=paid.PaidSearch(score.score_cards.load_cards(),scene())
        self.assertTrue(all(all(side=='own' for side,_ in a['targets']) for a,_ in e.casts(e.root(),'own')))

    def test_paralyze_blocks_even_granted_haste(self):
        data=scene();data['ally_bodies_before_play'][0]['paralyze_owner_starts_remaining']=2
        e=paid.PaidSearch(score.score_cards.load_cards(),data);_,child=next(e.casts(e.root(),'own'))
        self.assertEqual(list(e.attacks(child)),[])

    def test_prison_payment_and_longer_window_change_real_hp(self):
        for cash,hp in ((2,28),(3,26)):
            result=paid.evaluate(prison(cash,'next_enemy_attack'))
            self.assertTrue(result['complete_in_declared_scope']);self.assertEqual(result['objectives'][0]['metrics']['own_player_hp'],hp)

    def test_big_body_can_be_control_locked(self):
        base=dict(kind='any',clauses=[dict(constraints=dict(max_enemy_living_count=0)),
            dict(constraints=dict(min_own_body_attack=6,min_own_body_health=3))])
        plain=alt.evaluate(prison(),base);self.assertTrue(plain['known']);self.assertTrue(plain['feasible'])
        self.assertEqual(plain['guaranteed_player_hp'],28)
        free=copy.deepcopy(base);free['clauses'][1]['constraints']['max_own_body_paralyze_starts_remaining']=0
        locked=alt.evaluate(prison(),free);self.assertTrue(locked['known']);self.assertFalse(locked['feasible'])
        self.assertIsNone(locked['guaranteed_player_hp'])
        affordable=alt.evaluate(prison(2),free);self.assertTrue(affordable['feasible']);self.assertEqual(affordable['guaranteed_player_hp'],28)

    def test_same_body_status_cannot_be_borrowed_from_another_ally(self):
        data=scene(hand_ids=[],hand_costs=[]);data['purpose_constraints']=dict(min_own_body_attack=6,
            min_own_body_health=3,max_own_body_paralyze_starts_remaining=0)
        data['ally_bodies_before_play']=[dict(card_id=15,attack=6,health=5,max_health=5,ready=False,paralyze_owner_starts_remaining=1),
            dict(card_id=2,attack=2,health=3,max_health=3,ready=False)]
        e=paid.PaidSearch(score.score_cards.load_cards(),data);self.assertEqual(e.purpose_body_witnesses(e.root()),[])

    def test_modified_silence_retains_unknown(self):
        data=prison();data['ally_bodies_before_play'][0]['attack']=8
        self.assertFalse(paid.evaluate(data)['complete_in_declared_scope'])

    def test_full_native_self_reflection_tail_stays_unknown(self):
        data=prison();data.update(opponent_hand_ids=[75],opponent_hand_costs=[4],opponent_gold_before_response=4)
        self.assertFalse(paid.evaluate(data)['complete_in_declared_scope'])

    def test_alpha_exhaustive_new_status_goal_agree(self):
        task=dict(kind='joint',constraints=dict(min_own_body_attack=6,min_own_body_health=3,
            max_own_body_paralyze_starts_remaining=0))
        a=score.task_score(prison(2),task);b=score.task_score(dict(prison(2),search_algorithm='exhaustive'),task)
        self.assertTrue(a['known']);self.assertTrue(b['known'])
        self.assertEqual(tuple(a['search']['objective_vector']),tuple(b['search']['objective_vector']))

    def dt_engine(self,clock=0,policy='unknown'):
        cards=score.score_cards.load_cards()
        fake=dict(next(c for c in cards if c['id']==270),id=990001,rarity='DT',attack=4,health=4)
        data=scene(hand_ids=[182],hand_costs=[3],gold_before_play=3,enemy_bodies=[],
            paralyze_reapplication=policy,ally_bodies_before_play=[dict(card_id=990001,attack=6,
                health=8,max_health=8,ready=False,attacked=False,paralyze_owner_starts_remaining=clock)])
        return paid.PaidSearch(cards+[fake],data)

    def test_dt_silence_immunity_does_not_make_paralyze_conditional(self):
        e=self.dt_engine();_,child=next(e.casts(e.root(),'own'));u=child.own[0]
        self.assertEqual((u.attack,u.health),(6,8));self.assertFalse(u.silenced)
        self.assertEqual(u.paralyze_owner_starts_remaining,2)

    def test_dt_existing_clock_keeps_original_reapplication_guard(self):
        e=self.dt_engine(1)
        with self.assertRaises(paid.UnknownMechanic):list(e.casts(e.root(),'own'))
        for policy,clock in [('refresh',2),('preserve',1)]:
            e=self.dt_engine(1,policy);_,child=next(e.casts(e.root(),'own'))
            self.assertEqual(child.own[0].paralyze_owner_starts_remaining,clock)


if __name__=='__main__':unittest.main()