"""Prototype counterexamples for identity, timing, payment and attack access."""
import copy
import unittest
import conditional_card_score as score
import paid_board_tactics as paid
import presence_magic_probe as probe
import score_cards


class PresenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def data(self,ids=(46,47),cash=12,**changes):
        by={c['id']:c for c in self.cards}
        data=dict(hand_ids=list(ids),hand_costs=[by[cid]['cost'] for cid in ids],hand_base_costs=[by[cid]['cost'] for cid in ids],
            gold_before_play=cash,own_player_hp=15,own_player_max_hp=30,
            enemy_player_hp=30,enemy_player_max_hp=30,opponent_hand_ids=[],opponent_hand_known=True,
            own_deck_ids=[],opponent_deck_ids=[],max_plays='all_physical',horizon='enemy_attack',
            enemy_bodies=[dict(card_id=270,attack=4,health=4,max_health=4,ready=True,current_card_cost=3,base_cost=3)],
            targeted_hand_empty='fizzle',targeted_hand_choice='eligible_targets')
        data.update(changes);return data

    def play(self,e,s,index,**filters):
        return next((a,ch) for a,ch in e.deploys(s) if a['kind']=='deploy' and a['hand_index']==index
            and all(a.get(k)==v for k,v in filters.items()))

    def test_three_complete_templates_and_unclosed_tail(self):
        matches=[c for c in self.cards if probe.parse(c)]
        self.assertEqual([c['id'] for c in matches],[46,47,116])
        for c in matches:self.assertIsNone(probe.parse(dict(c,effect_readable=c['effect_readable']+' Draw a card.')))

    def test_paid_order_controls_self_buff_and_false_condition_never_rechecks(self):
        e=probe.PresenceSearch(self.cards,self.data());root=e.root()
        _,s=self.play(e,root,0);a,s=self.play(e,s,1);dog=s.own[-1]
        self.assertTrue(a['magic_condition']['satisfied']);self.assertEqual((dog.attack,dog.health,dog.max_health,dog.taunt,dog.dodge),(8,8,8,True,1))
        self.assertEqual((s.gold,s.current_paid_gold),(0,12))
        a,other=self.play(e,root,1);self.assertFalse(a['magic_condition']['satisfied'])
        _,other=self.play(e,other,0);dog=next(u for u in other.own if u.key=='hand:1')
        self.assertEqual((dog.attack,dog.health,dog.taunt,dog.dodge),(6,5,False,0))

    def test_conditional_hand_buff_only_changes_remaining_physical_copies(self):
        e=probe.PresenceSearch(self.cards,self.data(ids=(47,46,43),cash=18));s=e.root()
        _,s=self.play(e,s,0);a,s=self.play(e,s,1)
        self.assertTrue(a['magic_condition']['satisfied']);self.assertEqual(s.hand,(2,));self.assertEqual(s.own_hand_buffs,((2,2,2),))
        _,s=self.play(e,s,2);dog=s.own[-1];self.assertEqual((dog.attack,dog.health),(7,7));self.assertEqual(s.current_paid_gold,18)

    def test_held_or_enemy_matching_identity_does_not_count_as_ally(self):
        e=probe.PresenceSearch(self.cards,self.data(enemy_bodies=[dict(card_id=46,attack=5,health=6,max_health=6)]))
        a,s=self.play(e,e.root(),1);self.assertFalse(a['magic_condition']['satisfied']);self.assertEqual(s.own[-1].attack,6)

    def test_silenced_living_identity_still_counts(self):
        e=probe.PresenceSearch(self.cards,self.data(ids=(47,),cash=6,
            ally_bodies_before_play=[dict(card_id=46,attack=5,health=6,max_health=6,silenced=True)]))
        a,s=self.play(e,e.root(),0);self.assertTrue(a['magic_condition']['satisfied']);self.assertTrue(s.own[-1].taunt)

    def test_actual_taunt_payment_opens_charge_and_order_is_not_continuous(self):
        e=probe.PresenceSearch(self.cards,self.data(ids=(1,116),cash=5,own_player_hp=1,enemy_player_hp=4));r=e.root()
        _,s=self.play(e,r,0);_,s=self.play(e,s,1);bird=s.own[-1]
        self.assertEqual(bird.ready,2);self.assertEqual(s.current_paid_gold,5)
        self.assertTrue(any(a['attacker']==bird.key and a['target']=='face' for a,ch in e.attacks(s)))
        _,s=self.play(e,r,1);_,s=self.play(e,s,0);bird=next(u for u in s.own if u.card_id==116)
        self.assertEqual(bird.ready,0)

    def test_transparent_taunt_condition_can_be_true_while_face_access_changes(self):
        outcomes=[]
        for transparent in (False,True):
            d=self.data(ids=(116,),cash=4,own_player_hp=1,enemy_player_hp=4,
                enemy_bodies=[dict(card_id=14,attack=4,health=5,max_health=5,taunt=True,transparency=transparent)])
            r=probe.evaluate(d,score.RESERVED['win'],cards=self.cards,focal_index=0)
            self.assertTrue(r['known']);outcomes.append(r['feasible'])
        self.assertEqual(outcomes,[False,True])
        missing=self.data(ids=(116,),cash=4,own_player_hp=1,enemy_player_hp=4,
            enemy_bodies=[dict(card_id=14,attack=4,health=5,max_health=5,taunt=True,transparency=False)])
        missing.pop('hand_base_costs')
        unknown=probe.evaluate(missing,score.RESERVED['win'],cards=self.cards,focal_index=0)
        self.assertFalse(unknown['known'])  # Preserve the genuine COST guard.

    def test_existing_held_haste_transfers_before_new_conditional_magic(self):
        e=probe.PresenceSearch(self.cards,self.data(ids=(33,46,47),cash=16));s=e.root()
        _,s=self.play(e,s,0,hand_target_index=2);_,s=self.play(e,s,1);_,s=self.play(e,s,2)
        # Endogeny added+1ATK as well as Haste; Dogaressa then adds+2.
        self.assertEqual((s.own[-1].attack,s.own[-1].health,s.own[-1].ready),(9,8,1));self.assertEqual(s.own_hand_keywords,())

    def test_inconsistent_raw_card_identity_is_unknown(self):
        cards=copy.deepcopy(self.cards);next(c for c in cards if c['id']==47)['effect_raw']='{{CARD:47|1}}'
        e=probe.PresenceSearch(cards,self.data())
        with self.assertRaises(paid.UnknownMechanic):list(e.deploys(e.root()))

    def test_dodge_punishment_and_complete_vectors(self):
        goal=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=8,min_own_body_health=8))
        for gems,expected in ((False,True),(True,False)):
            d=self.data(opponent_hand_ids=[598] if gems else [],opponent_gold_before_response=1 if gems else 0)
            a=probe.evaluate(d,goal,cards=self.cards,focal_index=1)
            b=probe.evaluate(dict(d,search_algorithm='exhaustive'),goal,cards=self.cards,focal_index=1)
            self.assertTrue(a['known'] and b['known']);self.assertEqual(a['feasible'],expected)
            self.assertEqual(tuple(a['search']['objective_vector']),tuple(b['search']['objective_vector']))


if __name__=='__main__':unittest.main()