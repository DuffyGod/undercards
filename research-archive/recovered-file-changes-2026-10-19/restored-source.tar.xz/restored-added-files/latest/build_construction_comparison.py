"""Observed opportunity trees, replacements, entry frontiers and counterfacts."""
import copy
import csv
import gzip
import hashlib
import json
from pathlib import Path

import construction_value as construction
import evaluate_situation as situation
import joint_window_quote as joint
import score_cards as base

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/construction-option-v01'


def observation(attack=None,turn=5,hand=1,cash=12,hp=30):
    return dict(hand_ids=[8]+[15]*(hand-1),role='midrange',own_turn=turn,gold_before_play=cash,
        opponent_gold_before_response=0,own_player_hp=hp,enemy_player_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[] if attack is None else [dict(attack=attack,health=8)],
        condition_state={'last_turn_gold_spent_on_spells':0},response_weights={'enemy_face':1})


def edge(child,p,draw=1,other=0):
    return dict(child_id=child,probability=p,cards_from_deck=draw,other_plays=other,foregone_value_model_gold=0.)


def binary(name,p=.2,hand=1,high=8,cash=12,other=0,now_attack=None):
    tree=dict(root_id='now',last_deployment_own_turn=6,initial_hand_size=hand,
        draw_option_value_model_gold=.6,discount_rate_per_turn=0.,nodes=[
            dict(id='now',own_turn=5,observation=observation(now_attack,5,hand),
                transitions=[edge('good',p,other=other),edge('bad',1-p,other=other)]),
            dict(id='good',own_turn=6,observation=observation(high,6,cash=cash)),
            dict(id='bad',own_turn=6,observation=observation(2,6,cash=cash))])
    if now_attack is not None:
        for n in tree['nodes'][1:]:n['observation']['own_player_hp']=30-now_attack
    return dict(name=name,scenario=tree)


def two_chances(correlated=False):
    tree=dict(root_id='now',last_deployment_own_turn=6,initial_hand_size=1,
        draw_option_value_model_gold=.6,discount_rate_per_turn=0.,nodes=[
            dict(id='now',own_turn=4,observation=observation(turn=4),transitions=[edge('good5',.2),edge('bad5',.8)]),
            dict(id='good5',own_turn=5,observation=observation(8,5),
                transitions=[edge('good6_after_good',1 if correlated else .2),edge('bad6_after_good',0 if correlated else .8)]),
            dict(id='bad5',own_turn=5,observation=observation(2,5),
                transitions=[edge('good6_after_bad',0 if correlated else .2),edge('bad6_after_bad',1 if correlated else .8)]),
            dict(id='good6_after_good',own_turn=6,observation=observation(8,6,hp=22)),
            dict(id='bad6_after_good',own_turn=6,observation=observation(2,6,hp=22)),
            dict(id='good6_after_bad',own_turn=6,observation=observation(8,6,hp=28)),
            dict(id='bad6_after_bad',own_turn=6,observation=observation(2,6,hp=28))])
    return dict(name='two_correlated' if correlated else 'two_independent',scenario=tree)


def cases():
    result=[binary('roomy_p00',0),binary('roomy_p04',.04),binary('roomy_p20'),binary('roomy_p40',.4),binary('roomy_p100',1),
        binary('full_p00',0,7),binary('full_p20',.2,7),binary('full_p40',.4,7),
        binary('full_background_play_p20',.2,7,other=1),binary('target_atk4_p20',high=4),
        binary('future_gold7_p20',cash=7),binary('moderate_now_p20',now_attack=6),two_chances(),two_chances(True)]
    last=binary('last_arrival_low')
    last['scenario'].update(root_id='bad',nodes=[last['scenario']['nodes'][-1]])
    result.append(last)
    discounted=binary('discount20_p20');discounted['scenario']['discount_rate_per_turn']=.2;result.append(discounted)
    silence=binary('paid_silence_p20')
    for n in silence['scenario']['nodes']:
        n['observation'].update(response_weights={'silence_then_enemy_face':1},opponent_gold_before_response=3)
    result.append(silence)
    return result


def quote_cache(result):
    records={(c['card_id'],n['node_id'],n['occupied_hand_size']):n['local_quote']
        for c in result['cards'] for n in c['policy']}
    return lambda card,node,h:records[(card['id'],node['id'],h)]


def condition_surface(by,reference,scale):
    rows=[]
    for role in ('aggro','control','combo','midrange'):
        for response in ('enemy_face','enemy_contact','silence_then_enemy_face'):
            for attack in (0,2,4,6,8,10,12):
                for hp in (2,4,8,12):
                    for cash in (7,8,12):
                        observed=observation(attack,6,cash=cash)
                        observed.update(role=role,response_weights={response:1},opponent_gold_before_response=3)
                        observed['enemy_bodies'][0]['health']=hp
                        tree=dict(root_id='seen',last_deployment_own_turn=6,initial_hand_size=1,
                            draw_option_value_model_gold=.6,nodes=[dict(id='seen',own_turn=6,observation=observed)])
                        result=construction.evaluate_cards([by[i] for i in (8,13,21,243,602,932)],reference,scale,tree,situation.make_state)
                        for c in result['cards']:
                            local=c['policy'][0]['local_quote'] if c['policy'] else {}
                            rows.append(dict(role=role,response=response,target_attack=attack,target_health=hp,
                                available_gold=cash,card_id=c['card_id'],name=c['name'],
                                deployment_legal=local.get('legal'),deployment_net=local.get('net_model_gold'),
                                observed_slot_option_value=c['option_value_model_gold'],pricing_supported=c['pricing_supported']))
    return rows


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    cards=base.load_cards();by={c['id']:c for c in cards};ref,_=base.make_reference(cards)
    norm=joint.make_normalization(ref,reply_policy='allied_board')
    pool=json.loads((HERE/'experiments/integrated-window-v02/monster-pool.json').read_text())
    ids=list(dict.fromkeys([r['card_id'] for r in pool['scores'] if r['pricing_supported']]+[43,438,582,307,385,81]))
    inputs=cases();results=[];rows=[];frontiers=[]
    for case in inputs:
        name,tree=case['name'],case['scenario']
        (OUT/(name+'.scenario.json')).write_text(json.dumps(tree,ensure_ascii=False,indent=2)+'\n')
        r=construction.evaluate_cards([by[i] for i in ids],ref,norm['scale'],tree,situation.make_state)
        r['case']=name;r['replacement_comparisons']=construction.compare(r,ids,[243,602,81])
        results.append(r)
        for c in r['cards']:
            row=dict(case=name,card_id=c['card_id'],name=c['name'],pricing_supported=c['pricing_supported'],
                carrying_option_net=c['option_value_model_gold'],known_lower=c['value_bounds_model_gold'][0],
                upper=c['value_bounds_model_gold'][1],deployed_probability=c.get('deployed_probability'),
                unused_probability=c.get('unused_probability'),actual_mana_paid=c.get('expected_actual_mana_paid'),
                holding_cost=c.get('expected_discounted_holding_cost_model_gold'),
                postdeploy_capacity_change=c.get('expected_discounted_postdeployment_capacity_change_model_gold'),
                root_known_action=c.get('root_known_action'))
            for rid,label in [(243,'bench'),(602,'rock_pet'),(81,'fortune')]:
                pair=next(p for p in r['replacement_comparisons'] if p['candidate_id']==c['card_id'] and p['replacement_id']==rid)
                row['advantage_vs_'+label]=pair['advantage_model_gold']
                row['prefer_over_'+label]=pair['worth_carrying_under_declared_scenario']
            rows.append(row)
        if name in ('roomy_p20','full_p20','full_background_play_p20','target_atk4_p20','future_gold7_p20','paid_silence_p20'):
            cached=quote_cache(r)
            for cid in [8,13,21,243,932]:
                for rid in [243,602,81]:
                    if cid==rid:continue
                    f=construction.mixture_frontier(tree,by[cid],by[rid],cached,'good')
                    frontiers.append(dict(case=name,**f))
    variants=[]
    for case in inputs:
        if case['name'] not in ('roomy_p20','full_p20','full_background_play_p20','future_gold7_p20'):continue
        tree=case['scenario'];r=next(r for r in results if r['case']==case['name'])
        originals={c['card_id']:c for c in r['cards']}
        for cid in [8,13,15,21,243,166,932,602]:
            for field,change in [('attack',1),('health',1),('cost',-1)]:
                card=copy.deepcopy(by[cid]);card[field]+=change
                after=construction.evaluate_cards([card],ref,norm['scale'],tree,situation.make_state)['cards'][0]
                before=originals[cid];known=before['pricing_supported'] and after['pricing_supported']
                variants.append(dict(case=case['name'],card_id=cid,name=card['name'],change=field,amount=change,
                    both_known=known,delta=after['option_value_model_gold']-before['option_value_model_gold'] if known else None,
                    deployed_before=before.get('deployed_probability'),deployed_after=after.get('deployed_probability')))
    surface=condition_surface(by,ref,norm['scale'])
    with (OUT/'deployment-condition-surface.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(surface[0]));writer.writeheader();writer.writerows(surface)
    sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in HERE.glob('*.py')}
    sources['snapshot.json']=hashlib.sha256(base.DEFAULT_SNAPSHOT.read_bytes()).hexdigest()
    summary=dict(version=construction.VERSION,scale=norm['scale'],source_sha256=sources,
        cases=len(inputs),cards=len(ids),rows=rows,frontiers=frontiers,numeric_counterfactuals=variants,
        deployment_condition_surface=surface,
        assumption='Synthetic conditional opportunity trees for already-drawn slots; no matchup frequency, deck occurrence or win-rate calibration.')
    (OUT/'comparison.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    with gzip.open(OUT/'option-traces.json.gz','wt',encoding='utf-8') as f:json.dump(results,f,ensure_ascii=False)
    with (OUT/'comparison.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    # A directly runnable current-entry example; background cards in scenario
    # observations declare counts, and are not automatically played for free.
    sample=observation();sample['construction_scenario']=copy.deepcopy(inputs[2]['scenario'])
    sample['construction_scenario']['replacement_ids']=[243,602]
    (OUT/'toriel-current.input.json').write_text(json.dumps(sample,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(cases=len(inputs),cards=len(ids),rows=len(rows),known=sum(r['pricing_supported'] for r in rows),
        frontiers=len(frontiers),condition_rows=len(surface),variants=len(variants),
        negative_variants=sum(v['delta'] is not None and v['delta'] < -1e-10 for v in variants))))


if __name__=='__main__':main()