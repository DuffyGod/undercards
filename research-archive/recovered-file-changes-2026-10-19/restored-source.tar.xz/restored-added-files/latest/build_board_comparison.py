"""Rebuild broad body diagnostics and strict tactical comparisons separately."""
from __future__ import annotations
import argparse
import collections
import copy
import csv
import gzip
import hashlib
import json
from pathlib import Path
import board_tactics as tactics
import board_pool_inventory as inventory
import score_cards as source

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/board-standard-v01'


def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def scenes():
    # Equal cases are a research panel, never estimated encounter frequencies.
    return [
        dict(id='empty_safe_12g',gold_before_play=12),
        dict(id='empty_curve_4g',gold_before_play=4),
        dict(id='empty_finish_3hp',gold_before_play=12,enemy_player_hp=3,horizon='enemy_attack'),
        dict(id='rock_3_3',gold_before_play=12,enemy_bodies=[dict(attack=3,health=3,cost=2,ready=True)]),
        dict(id='aaron_critical_6hp',gold_before_play=12,own_player_hp=6,enemy_bodies=[dict(attack=6,health=5,cost=5,ready=True)]),
        dict(id='ally_joint_exact_1g',gold_before_play=1,own_player_hp=6,
             ally_bodies_before_play=[dict(attack=3,health=2,cost=2,ready=True)],enemy_bodies=[dict(attack=6,health=5,cost=5,ready=True)],horizon='enemy_attack'),
        dict(id='two_attacker_8hp',gold_before_play=12,own_player_hp=8,enemy_bodies=[dict(attack=2,health=3,cost=2,ready=True),dict(attack=3,health=2,cost=2,ready=True)]),
        dict(id='taunt_plus_aaron',gold_before_play=12,own_player_hp=7,enemy_bodies=[dict(attack=0,health=4,cost=1,taunt=True,ready=True),dict(attack=6,health=5,cost=5,ready=True)]),
    ]


def row_for(card,scene,result,obj,kind):
    complete=result['complete_in_declared_scope'] and obj['search_complete']
    m=obj['metrics'] if complete else {}
    first=next((a.get('hand_index') for a in obj['principal_variation'] if a['kind']=='deploy'),None)
    return dict(card_id=card['id'],name=card['name'],cost=card['cost'],attack=card['attack'],health=card['health'],
        scene_id=scene['id'],objective=obj['objective'],evaluation_kind=kind,complete_in_declared_scope=complete,
        own_dead=m.get('own_player_dead'),enemy_defeated=m.get('enemy_player_defeated'),own_hp=m.get('own_player_hp'),
        enemy_hp=m.get('enemy_player_hp'),own_board_attack=m.get('own_board_attack'),enemy_board_attack=m.get('enemy_board_attack'),
        own_board_health=m.get('own_board_health'),enemy_board_health=m.get('enemy_board_health'),
        enemy_killed_printed_cost=m.get('enemy_killed_printed_cost'),own_lost_paid_or_declared_cost=m.get('own_lost_paid_or_declared_cost'),
        own_remaining_gold=m.get('own_remaining_gold'),played_card=first==0 if complete else None,
        known_feasible_policy_available=result['known_feasible_policy_available'],
        known_subset_policy_own_dead=obj['metrics'].get('own_player_dead') if obj['metrics'] else None,
        visited_states=obj['visited_states'],unknown=json.dumps(result['unknown']+obj.get('unknown',[]),ensure_ascii=False),
        omitted_effect_text=card['effect_readable'] if kind=='printed_body_projection' else '')


def body_profiles(cards,rows,out):
    targets=[c for c in cards if inventory.scope(c,inventory.families(c))[0] in ('standalone_board','mixed_board_resource_or_synergy')]
    compiled={c['id']:tactics.compile_card(c)['statuses'] for c in cards}
    def unit(c):
        f=compiled[c['id']]
        return tactics.Unit(str(c['id']),c['id'],c['attack'],c['health'],c['health'],c['cost'],f['taunt'],f['armor'],f['dodge'])
    targets=[(c,unit(c)) for c in targets]
    profiles=[]
    # Every pair is archived: denominators and thresholds can be independently
    # recomputed; the printed-target pool is not a metagame probability prior.
    with gzip.open(out/'body-exchange-pairs.csv.gz','wt',encoding='utf-8',newline='') as f:
        writer=csv.writer(f);writer.writerow(['card_id','target_id','attack_legal','target_killed','candidate_survived','candidate_hp_after','target_hp_after'])
        for c in cards:
            u=unit(c); counts=collections.defaultdict(collections.Counter)
            for other,v in targets:
                a,b=(tactics.hurt(u,v.attack),tactics.hurt(v,u.attack)) if u.attack>0 else (u,v)
                legal=u.attack>0
                writer.writerow([c['id'],other['id'],int(legal),int(legal and b.health<=0),int(a.health>0),a.health,b.health])
                key=str(other['cost'])
                counts[key]['n']+=1;counts[key]['kill']+=int(legal and b.health<=0)
                counts[key]['survive']+=int(a.health>0)
                counts[key]['kill_survive']+=int(legal and b.health<=0 and a.health>0)
            for cost,count in sorted(counts.items(),key=lambda kv:float(kv[0])):
                profiles.append(dict(card_id=c['id'],name=c['name'],cost=c['cost'],attack=c['attack'],health=c['health'],target_cost=float(cost),
                    target_count=count['n'],kill_fraction=count['kill']/count['n'],survive_fraction=count['survive']/count['n'],
                    kill_and_survive_fraction=count['kill_survive']/count['n'],scope='single_exchange_printed_body_only',
                    candidate_effect_omitted=c['effect_readable'],target_effects_omitted=True,encounter_probability_claimed=False))
    write_csv(out/'body-exchange-profiles.csv',profiles)
    return dict(candidate_count=len(cards),target_count=len(targets),pair_count=len(cards)*len(targets),cost_stratum_rows=len(profiles))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=OUT)
    args=parser.parse_args();out=args.out;out.mkdir(parents=True,exist_ok=True)
    all_cards=source.load_cards();cards=[c for c in all_cards if c['card_type']=='monster' and c['pool_category']=='ordinary_non_token']
    panel=scenes();defaults=dict(own_player_hp=30,enemy_player_hp=30,max_plays=1,node_limit=200000)
    (out/'tactical-scenes.json').write_text(json.dumps(dict(defaults=defaults,scenes=panel),ensure_ascii=False,indent=2)+'\n')
    projected=[];strict=[];observed=[];coverage=[]
    with gzip.open(out/'strict-tactical-traces.jsonl.gz','wt',encoding='utf-8') as traces:
        for c in cards:
            deploy_spec=tactics.compile_card(c)
            observed_spec=tactics.compile_card(c,observed=True)
            probe=tactics.evaluate(dict(defaults,hand_ids=[c['id']],gold_before_play=max(c['cost'],40),objectives=['race']),all_cards)
            coverage.append(dict(card_id=c['id'],name=c['name'],source_key=c['source_key'],source_line=c['source_line'],
                deploy_template_known=not bool(deploy_spec['unknown']),deploy_and_summoned_mechanics_known=probe['complete_in_declared_scope'],
                observed_remaining_template_known=not bool(observed_spec['unknown']),
                effect_readable=c['effect_readable'],unknown=probe['unknown']))
            for scene in panel:
                data=dict(defaults,**{k:v for k,v in scene.items() if k!='id'},hand_ids=[c['id']])
                result=tactics.evaluate(data,all_cards,projection=True)
                for obj in result['objectives']:projected.append(row_for(c,scene,result,obj,'printed_body_projection'))
                result=tactics.evaluate(data,all_cards)
                if result['complete_in_declared_scope']:
                    traces.write(json.dumps(dict(card_id=c['id'],scene_id=scene['id'],input=data,result=result),ensure_ascii=False)+'\n')
                if result['objectives']:
                    for obj in result['objectives']:strict.append(row_for(c,scene,result,obj,'strict_current_play'))
                else:
                    for mode in tactics.OBJECTIVES:
                        strict.append(row_for(c,scene,result,dict(objective=mode,search_complete=False,metrics=None,principal_variation=[],visited_states=0),'strict_current_play'))
            # Existing board observation: Magic is already reflected in stats;
            # do not claim this proves deploying the printed card is valuable.
            scene=dict(id='observed_ready_vs_aaron',gold_before_play=0,own_player_hp=30,enemy_player_hp=30,max_plays=0,
                       ally_bodies_before_play=[dict(card_id=c['id'],attack=c['attack'],health=c['health'],ready=True,attacked=False)],
                       enemy_bodies=[dict(attack=6,health=5,cost=5,ready=True)])
            result=tactics.evaluate({k:v for k,v in scene.items() if k!='id'},all_cards)
            if result['objectives']:
                for obj in result['objectives']:observed.append(row_for(c,scene,result,obj,'observed_ready_board'))
            else:
                for mode in tactics.OBJECTIVES:
                    observed.append(row_for(c,scene,result,dict(objective=mode,search_complete=False,metrics=None,principal_variation=[],visited_states=0),'observed_ready_board'))
            if len(coverage)%100==0:print(json.dumps(dict(completed_cards=len(coverage))),flush=True)
    for name,rows in [('body-tactical-panel.csv',projected),('strict-tactical-panel.csv',strict),('observed-board-panel.csv',observed)]:write_csv(out/name,rows)
    (out/'tactical-coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
    body=body_profiles(cards,projected,out)
    interventions=[]
    selected=[1,2,4,8,9,11,13,15,108,115,168,175,187,235,307,404,509,563,602,932]
    by={c['id']:c for c in all_cards}
    for cid in selected:
        for scene in panel:
            # Compare EXACTLY the same tactical priorities and target worlds;
            # numerical monotonicity is componentwise, not each scalar quote.
            data=dict(defaults,**{k:v for k,v in scene.items() if k!='id'},hand_ids=[cid],objectives=['survive','race','control'])
            baseline=tactics.evaluate(data,all_cards)
            for variable,delta in [('attack',1),('health',1),('cost',-1)]:
                if variable=='cost' and by[cid]['cost']==0:continue
                changed=copy.deepcopy(all_cards);next(c for c in changed if c['id']==cid)[variable]+=delta
                result=tactics.evaluate(data,changed)
                for a,b in zip(baseline['objectives'],result['objectives']):
                    known=baseline['complete_in_declared_scope'] and result['complete_in_declared_scope']
                    va=tuple(a.get('objective_vector',()));vb=tuple(b.get('objective_vector',()))
                    interventions.append(dict(card_id=cid,name=by[cid]['name'],scene_id=scene['id'],objective=a['objective'],
                        intervention=variable+str(delta),known=known,baseline_vector=json.dumps(va),changed_vector=json.dumps(vb),
                        tactical_order_change=(1 if vb>va else -1 if vb<va else 0) if known else None,
                        baseline_metrics=json.dumps(a['metrics']),changed_metrics=json.dumps(b['metrics'])))
    write_csv(out/'tactical-counterfactuals.csv',interventions)
    unknown_negative=[r for r in interventions if r['tactical_order_change']==-1]
    summary=dict(version=tactics.VERSION,ordinary_monsters=len(cards),scene_count=len(panel),objective_count=3,
        projected_rows=len(projected),projection_failures=sum(not r['complete_in_declared_scope'] for r in projected),
        strict_rows=len(strict),strict_closed_rows=sum(r['complete_in_declared_scope'] for r in strict),
        strict_closed_play_templates=sum(r['deploy_and_summoned_mechanics_known'] for r in coverage),
        observed_rows=len(observed),observed_closed_rows=sum(r['complete_in_declared_scope'] for r in observed),
        observed_supported_card_count=sum(r['observed_remaining_template_known'] for r in coverage),
        observed_runtime_closed_card_count=len({r['card_id'] for r in observed if r['complete_in_declared_scope']}),
        single_exchange_body_profiles=body,counterfactual_rows=len(interventions),
        positive_counterfactuals=sum(r['tactical_order_change']==1 for r in interventions),
        equal_counterfactuals=sum(r['tactical_order_change']==0 for r in interventions),
        negative_counterfactuals=len(unknown_negative),
        limitations=tactics.LIMITATIONS,card_snapshot_sha256=hashlib.sha256(Path(source.DEFAULT_SNAPSHOT).read_bytes()).hexdigest(),
        source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE/'board_tactics.py',Path(__file__),HERE/'board_pool_inventory.py')})
    (out/'tactical-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,ensure_ascii=False),flush=True)


if __name__=='__main__':main()