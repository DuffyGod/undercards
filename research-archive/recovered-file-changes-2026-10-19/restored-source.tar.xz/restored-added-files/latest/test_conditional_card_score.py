"""Counterexamples for attribution, joint guarantees, timing and victory priority."""
import copy
import unittest

import conditional_card_score as score
import paid_board_tactics as paid
import score_cards
import build_damage_packet_comparison as packet


class ConditionalScoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def config(self,ids=(56,187,377),**changes):
        scene=packet.fixture()
        for k in ('hand_ids','objectives','purpose_constraints'):scene.pop(k)
        data=dict(scene=scene,candidate_ids=list(ids),include_delay=False)
        data.update(changes);return data

    def test_goal_hp_is_joint_lower_bound_not_victory_first_endpoint(self):
        d=dict(hand_ids=[],max_plays=0,gold_before_play=0,own_player_hp=3,enemy_player_hp=1,
            ally_bodies_before_play=[dict(card_id=2,attack=1,health=1,ready=False)],
            enemy_bodies=[dict(card_id=2,attack=2,health=2)],horizon='next_own_attack')
        task=dict(kind='joint',constraints=dict(min_own_player_hp=1))
        result=score.task_score(d,task,cards=self.cards)
        e=paid.PaidSearch(self.cards,dict(d,purpose_constraints=task['constraints']))
        old=e.solve(e.root(),'purpose')
        self.assertEqual(old['metrics']['own_player_hp'],3)
        self.assertTrue(result['feasible']);self.assertEqual(result['guaranteed_player_hp'],1)
        # Enemy face2 is legal, player3->1, ally1 survives and wins next.
        # Enemy instead kills ally, leaving player3 and an ongoing game.

    def test_packet_cohort_conditional_scores_and_removal_baseline(self):
        r=score.compare(self.config(),self.cards);by={x['card_id']:x for x in r['rows']}
        self.assertEqual(r['removal_baseline']['scores']['hp']['guaranteed_player_hp'],11)
        self.assertEqual([by[i]['scores']['hp']['guaranteed_player_hp'] for i in (56,187,377)],[11,11,12])
        self.assertEqual([by[i]['contribution_over_removed_copy']['hp']['hp_difference'] for i in (56,187,377)],[0,0,1])
        self.assertEqual(by[187]['scores']['body_2_2']['guaranteed_player_hp'],11)
        self.assertIsNone(by[56]['scores']['body_2_2']['guaranteed_player_hp'])
        self.assertTrue(by[56]['scores']['body_2_1']['feasible'])

    def test_background_cannot_impersonate_focal_copy(self):
        scene=dict(gold_before_play=0,own_player_hp=15,enemy_player_hp=30,
            ally_bodies_before_play=[dict(card_id=15,attack=2,health=3,max_health=5)],
            opponent_hand_ids=[],opponent_hand_known=True,max_plays=1,horizon='enemy_attack')
        tasks={name:dict(kind='joint',body_scope=scope,constraints=dict(min_own_body_attack=2,min_own_body_health=3))
            for name,scope in [('team','board'),('focal','focal')]}
        r=score.compare(dict(scene=scene,candidate_ids=[196],tasks=tasks,include_delay=False),self.cards)
        row=r['rows'][0]
        self.assertTrue(row['scores']['team']['feasible']);self.assertFalse(row['scores']['focal']['feasible'])
        self.assertEqual(row['contribution_over_removed_copy']['team']['hp_difference'],0)
        self.assertEqual(r['removal_baseline']['scores']['focal']['status'],'not_applicable')

    def test_delay_gates_only_one_physical_copy_and_not_future(self):
        d=dict(hand_ids=[187,187],hand_base_costs=[3,3],gold_before_play=3,max_plays=2,
            next_max_plays=1,next_own_gold_income=3,next_natural_draw_count=0,
            horizon='next_own_attack',opponent_hand_ids=[],opponent_hand_known=True)
        e=score.TaskSearch(self.cards,d,focal_index=1,delay_current=True)
        root=e.root();actions=list(e.deploys(root))
        self.assertEqual([a['hand_index'] for a,c in actions],[0])
        self.assertEqual(root.hand,(0,1));self.assertEqual(root.gold,3)
        future=e.boundary(e.boundary(actions[0][1]))
        a,c=next(e.deploys(future));self.assertEqual(a['hand_index'],1)
        self.assertEqual(c.next_paid_gold,3)

    def test_delay_keeps_copy_for_other_card_hand_magic(self):
        c=next(x for x in self.cards if x['name']=='Glyde')
        d=dict(hand_ids=[c['id'],187],hand_base_costs=[c['cost'],3],gold_before_play=c['cost'],max_plays=2,
            opponent_hand_ids=[],opponent_hand_known=True)
        e=score.TaskSearch(self.cards,d,focal_index=1,delay_current=True)
        a,s=next(e.deploys(e.root()))
        self.assertEqual(a['hand_index'],0);self.assertEqual(s.hand,(1,))
        self.assertEqual(s.own[0].attack,c['attack']+1);self.assertEqual(s.own[0].health,c['health']+1)

    def test_unknown_and_budget_failure_are_not_zero(self):
        r=score.compare(self.config(ids=[444],scene=dict(gold_before_play=11,opponent_hand_ids=[],opponent_hand_known=True,horizon='enemy_attack')),self.cards)
        self.assertFalse(r['rows'][0]['scores']['hp']['known'])
        self.assertIsNone(r['rows'][0]['scores']['hp']['guaranteed_player_hp'])
        self.assertFalse(r['selection']['optimum_within_supplied_candidates_certified'])
        cfg=self.config(ids=[187]);cfg['scene']['node_limit']=1
        r=score.compare(cfg,self.cards);self.assertFalse(r['rows'][0]['scores']['hp']['known'])
        self.assertEqual(r['selection']['best_supported_candidate_ids'],[])

    def test_victory_priority_over_equal_healing_score(self):
        r=score.compare(self.config(ids=[9,22]),self.cards)
        self.assertEqual([x['scores']['hp']['guaranteed_player_hp'] for x in r['rows']],[15,15])
        self.assertEqual(r['selection']['selected_task'],'win')
        self.assertEqual(r['selection']['best_supported_candidate_ids'],[9])
        self.assertEqual(r['diagnostic_task_leaders']['hp']['best_supported_candidate_ids'],[9,22])

    def test_single_health_point_unlocks_victory_and_body(self):
        config=self.config(ids=[56,187,377]);original=score.compare(config,self.cards)
        changed=copy.deepcopy(self.cards);next(c for c in changed if c['id']==377)['health']+=1
        variant=score.compare(config,changed)
        a=next(r for r in original['rows'] if r['card_id']==377);z=next(r for r in variant['rows'] if r['card_id']==377)
        self.assertFalse(a['scores']['win']['feasible']);self.assertTrue(z['scores']['win']['feasible'])
        self.assertFalse(a['scores']['body_2_1']['feasible']);self.assertEqual(z['scores']['body_2_1']['guaranteed_player_hp'],12)
        self.assertEqual(variant['selection']['best_supported_candidate_ids'],[377])
        self.assertNotEqual(original['actual_cards_canonical_sha256'],variant['actual_cards_canonical_sha256'])

    def test_cost_point_crosses_real_payment_without_phantom_spend(self):
        config=self.config(ids=[187]);a=score.compare(config,self.cards)
        config['candidate_current_costs']={'187':4};z=score.compare(config,self.cards)
        self.assertTrue(a['rows'][0]['scores']['body_2_2']['feasible'])
        self.assertFalse(z['rows'][0]['scores']['body_2_2']['feasible'])
        self.assertEqual(z['rows'][0]['scores']['hp']['search']['payment_accounting']['current_paid_gold'],0)

    def test_infeasible_cells_have_no_fabricated_hp_difference(self):
        r=score.compare(self.config(ids=[56,377]),self.cards)
        gap=r['rows'][1]['same_slot_reference_difference']['body_4_3']
        self.assertTrue(gap['jointly_infeasible']);self.assertIsNone(gap['hp_difference'])

    def test_higher_same_body_threshold_cannot_improve_joint_hp(self):
        cfg=self.config(ids=[187]);cfg['tasks']={str(h):dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=2,min_own_body_health=h)) for h in (1,2,3)}
        r=score.compare(cfg,self.cards);v=r['rows'][0]['scores']
        self.assertEqual([v[str(h)]['feasible'] for h in (1,2,3)],[True,True,False])
        self.assertGreaterEqual(v['1']['guaranteed_player_hp'],v['2']['guaranteed_player_hp'])

    def test_constrained_task_matches_exhaustive_full_vector(self):
        d=packet.fixture(53);task=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=2,min_own_body_health=2))
        a=score.task_score(d,task,cards=self.cards,focal_index=0)
        x=score.task_score(dict(d,search_algorithm='exhaustive'),task,cards=self.cards,focal_index=0)
        self.assertTrue(a['known']);self.assertTrue(x['known'])
        self.assertEqual(a['search']['objective_vector'],x['search']['objective_vector'])

    def test_schema_rejects_overridden_victory_and_phantom_hand(self):
        for update in [dict(tasks={'win':dict(kind='joint',constraints=dict(max_enemy_player_hp=5))}),
                dict(candidate_current_costs={'99999':1})]:
            with self.assertRaises(ValueError):score.compare(self.config(**update),self.cards)
        cfg=self.config();cfg['scene']['hand_ids']=[196]
        with self.assertRaises(ValueError):score.compare(cfg,self.cards)

    def test_clear_and_body_tasks_produce_different_real_choices(self):
        import build_paid_standing_comparison as standing
        scene=standing.config('next_enemy_attack')['scene'];scene['gold_before_play']=8
        tasks=dict(clear=dict(kind='joint',constraints=dict(max_enemy_living_count=0)),
            body=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=4,min_own_body_health=3)))
        r=score.compare(dict(scene=scene,candidate_ids=[21,8],tasks=tasks,include_delay=False),self.cards)
        self.assertEqual(r['diagnostic_task_leaders']['clear']['best_supported_candidate_ids'],[21])
        self.assertEqual(r['diagnostic_task_leaders']['body']['best_supported_candidate_ids'],[8])
        by={x['card_id']:x for x in r['rows']}
        self.assertEqual(by[21]['scores']['clear']['guaranteed_player_hp'],7)
        self.assertEqual(by[8]['scores']['body']['guaranteed_player_hp'],4)


if __name__=='__main__':unittest.main()