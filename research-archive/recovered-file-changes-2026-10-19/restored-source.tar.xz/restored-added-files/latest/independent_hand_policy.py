"""Source-literal five-event enumeration. Imports no game/search/payment module.

Checks one common policy, not the best whole-hand strategy: pay Dummy now,
hold candidate, naturally draw Tiny and gain6, pay candidate next own turn,
make no own attacks. Enemy hero30 never dies in this policy.
"""
from functools import lru_cache
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'experiments/damage-packet-v01'


@lru_cache(None)
def replies(player,dummy,candidate,tiny,attacks,gems):
    # Stop is legal at each prefix. Every Gem costs1; physical copies=2.
    leaves={(player,dummy,candidate,tiny,gems)}
    bodies=[i for i,h in enumerate((dummy,candidate,tiny),1) if h>0]
    # Taunt constrains monster attacks, not source-literal targetALL spells.
    monster_targets=[1] if dummy>0 else [0,*bodies]
    for kind,left,targets in [('attack',attacks,monster_targets),('gem',gems,[0,*bodies])]:
        if left==0:continue
        for target in targets:
            hp=[player,dummy,candidate,tiny];hp[target]=max(0,hp[target]-1)
            leaves.update(replies(*hp,attacks-int(kind=='attack'),gems-int(kind=='gem')))
    return frozenset(leaves)


def main():
    snapshot=ROOT.parents[1]/'skills/undercards/references/snapshot.json'
    native={c['id']:c for c in json.loads(snapshot.read_text())['cards']}
    expected={1:(1,0,4,'Taunt.'),187:(3,2,6,''),
        22:(3,2,4,'Magic: Heal 4 HP.'),
        53:(3,5,5,'Turn end: Lose 1 ATK. If this has 0 ATK, kill this.'),
        196:(0,1,1,''),598:(1,None,None,'Deal 1 DMG.')}
    for cid,values in expected.items():
        c=native[cid]
        assert (c['cost'],c['attack'],c['health'],c['effect_readable'])==values
    assert native[598]['target']=='ALL'
    timing=json.loads((OUT/'hand-structure.json').read_text())
    inputs={r['card_id']:r['input'] for r in timing['cases']}
    # Explicit source literals carried by source-bound hand-structure cases.
    # The arithmetic below never calls a core function.
    cards={r['card_id']:r['result'] for r in timing['cases']}
    source_hashes={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in
        ('research-runs/damage-packet-v01/independent_hand_policy.py',)}
    rows=[]
    for cid,health,heal,attack in ((187,6,0,2),(22,4,4,2),(53,5,0,4)):
        data=inputs[cid]
        assert data['hand_ids']==[cid,1] and data['gold_before_play']==3
        assert data['next_own_gold_income']==6 and data['enemy_player_hp']==30
        assert data['own_player_hp']==15 and data['own_deck_ids']==[196]
        assert data['opponent_deck_ids']==[196,196]
        assert data['opponent_hand_ids']==[598,598]
        assert data['opponent_gold_before_response']==10 and data['next_opponent_gold_income']==5
        assert data['hand_base_costs']==[3,1]
        assert 3-1+6>=3
        # First enemy only Aaron is ready. Its first Tiny is fresh.
        first=replies(15,4,0,0,1,2)
        final=set()
        for player,dummy,_,_,gems in first:
            # True next own start; own Tiny is fresh too. Candidate End
            # modifies Napstablook5->4 but never invents an attack.
            final.update(replies(min(30,player+heal),dummy,health,1,2,gems))
        guaranteed_player=min(s[0] for s in final)
        guaranteed_body=min(s[2] for s in final)
        threshold=4 if cid!=53 else 3
        joint=all(s[0]>=13 and s[2]>=threshold for s in final)
        assert guaranteed_player=={187:13,22:17,53:13}[cid]
        assert guaranteed_body=={187:4,22:2,53:3}[cid]
        assert joint==(cid!=22)
        # Native literals checked separately by the main source receipt;
        # equality here only compares distinct computed outcome evidence.
        actual=cards[cid]['objectives']
        assert actual[0]['metrics']['own_player_hp']==guaranteed_player
        assert actual[1]['purpose_guaranteed']==joint
        rows.append(dict(card_id=cid,policy='pay Dummy1 now; pay candidate3 next own turn; no own attacks',
            first_states=len(first),final_states=len(final),player_hp_lower=guaranteed_player,
            body_hp_lower=guaranteed_body,body_attack=attack,joint_player13_body_goal=joint,
            matches_main_hp_and_joint=True))
    report=dict(cases=rows,source_hashes=source_hashes,
        hand_structure_input_sha256=hashlib.sha256((OUT/'hand-structure.json').read_bytes()).hexdigest(),
        accounting=dict(current_paid=1,next_paid=3,available_next=8,remaining_next=5),
        snapshot_sha256=hashlib.sha256(snapshot.read_bytes()).hexdigest(),
        assumptions=['Snapshot-checked literals Dummy0/4 Taunt, Candy2/6, Shy2/4 heal4, Nap5/5 loses1ATK ownEnd, Tiny1/1, Gem1G/1DMG targetALL. Aaron1/5 is declared observation, not its printed6ATK.',
            'No callbacks/status/Armor/Soul/artifacts; all ordinary1damage events. New Tiny cannot attack on its fresh turn.',
            'Enemy can stop or interleave every ready monster attack and each paid Gem on every living own target. Taunt alone forces monster targets. Opponent self-target Gems only waste a damage resource or remove an unmodified attacker in this no-callback/no-slot-pressure subclass, and cannot lower our player/candidate bound.',
            'This certifies one fixed shared policy, not general server rules, whole-hand vector optimum or carrying probability.'])
    (OUT/'independent-hand-policy.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(rows))


if __name__=='__main__':main()