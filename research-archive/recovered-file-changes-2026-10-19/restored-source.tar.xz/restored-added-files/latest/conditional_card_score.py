"""Same-purpose conditional card scores from executable joint guarantees.

For a task G, maximize min_enemy (G, own player HP, old tie-breakers).
If G is guaranteed, its second coordinate is the highest jointly guaranteed
HP, rather than HP on the old victory-first purpose's selected endpoint.
No HP/ATK/Gold exchange rate or unobserved context frequency is invented.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
from pathlib import Path

import board_tactics as board
import paid_board_tactics as paid
import score_cards

VERSION='conditional-task-card-score-0.1.0'
HERE=Path(__file__).resolve().parent
DEFAULT_TASKS={
    'body_2_1':dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=2,min_own_body_health=1)),
    'body_2_2':dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=2,min_own_body_health=2)),
    'body_4_3':dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=4,min_own_body_health=3)),
    'clear':dict(kind='joint',constraints=dict(max_enemy_living_count=0)),
}
RESERVED={
    'hp':dict(kind='hp'),
    'win':dict(kind='joint',constraints=dict(max_enemy_player_hp=0)),
}


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


class TaskSearch(paid.PaidSearch):
    """Reuse rules, change explicit objective and one optional action restriction."""
    def __init__(self,cards,data,*,body_scope='board',focal_index=None,delay_current=False):
        self.body_scope=body_scope;self.focal_index=focal_index;self.delay_current=delay_current
        super().__init__(cards,data)

    def purpose_body_witnesses(self,state):
        witnesses=super().purpose_body_witnesses(state)
        if self.body_scope=='board':return witnesses
        if self.focal_index is None:return []
        key='hand:'+str(self.focal_index)
        return [w for w in witnesses if w['key']==key or
            (self.body_scope=='lineage' and w['key'].startswith(key+':'))]

    def objective(self,state,mode):
        if mode!='purpose':return super().objective(state,mode)
        feasible=super().objective(state,mode)[0]
        return (feasible,board.metrics(state)['own_player_hp'])+board.objective_vector(state,'survive')

    def deploys(self,state):
        # Keep the focal copy physically held: hand Magic, capacity, prices
        # and death discounts still observe it. Exclude only its own phase0
        # deployment. The inherited generator validates even discarded
        # transitions; an unclosed excluded effect therefore conservatively
        # stays unknown, never an invented zero or favourable omission.
        for action,child in super().deploys(state):
            if self.delay_current and state.phase==0 and action.get('side','own')=='own' \
                    and action.get('kind')=='deploy' and action.get('hand_index')==self.focal_index:
                continue
            yield action,child


def task_score(data,task,*,cards=None,focal_index=None,delay_current=False):
    cards=score_cards.load_cards() if cards is None else cards
    kind=task.get('kind','joint');scope=task.get('body_scope','board')
    if kind not in ('hp','joint') or scope not in ('board','focal','lineage'):
        raise ValueError('Task kind hp/joint; body_scope board/focal/lineage')
    if set(task)-{'kind','body_scope','constraints'}:raise ValueError('Unknown task field')
    constraints=copy.deepcopy(task.get('constraints',{}))
    if kind=='hp' and (constraints or scope!='board'):raise ValueError('HP task has no body constraints')
    if scope!='board' and not paid.SINGLE_BODY_PURPOSE_FIELDS.intersection(constraints):
        raise ValueError('Focal/lineage scope requires same-body constraints')
    if scope!='board' and focal_index is None:
        return dict(known=True,status='not_applicable',feasible=None,guaranteed_player_hp=None,
            reason='No focal copy in the removal baseline; this is not a background-body score.',search=None)
    scene=copy.deepcopy(data);scene.pop('objectives',None);scene.pop('purpose_constraints',None)
    mode='guaranteed_hp' if kind=='hp' else 'purpose'
    if kind=='joint':scene['purpose_constraints']={'min_own_player_hp':1,**constraints}
    e=TaskSearch(cards,scene,body_scope=scope,focal_index=focal_index,delay_current=delay_current)
    root=e.root()
    if e.unknown:
        result=dict(search_complete=False,unknown=sorted(set(e.unknown)),metrics=None,principal_variation=[])
    else:result=e.solve(root,mode)
    known=result['search_complete']
    feasible=(result['metrics']['own_player_hp']>0 if kind=='hp' else result['purpose_guaranteed']) if known else None
    hp=result['metrics']['own_player_hp'] if known and (kind=='hp' or feasible) else None
    return dict(known=known,status='known' if known else 'unknown',feasible=feasible,
        guaranteed_player_hp=hp,body_scope=scope,task=copy.deepcopy(task),
        numeric_semantics='maximal jointly guaranteed player HP' if kind=='joint' else 'maximal guaranteed player HP',
        unknown=result.get('unknown',[]),search=result,
        all_metrics_componentwise_guaranteed=False,
        endpoint_is_one_adversarial_path=True)


def difference(value,reference):
    if not value['known'] or not reference['known']:
        return dict(known=False,hp_difference=None,feasibility_change=None)
    if value['status']=='not_applicable' or reference['status']=='not_applicable':
        return dict(known=True,hp_difference=None,feasibility_change=None,not_applicable=True)
    vf,rf=value['feasible'],reference['feasible']
    delta=value['guaranteed_player_hp']-reference['guaranteed_player_hp'] \
        if value['guaranteed_player_hp'] is not None and reference['guaranteed_player_hp'] is not None else None
    return dict(known=True,hp_difference=delta,feasibility_change=int(vf)-int(rf),
        jointly_infeasible=not vf and not rf)


def ranking(rows,task,*,victory_first=True):
    def key(cell):
        return (int(cell['feasible']),cell['guaranteed_player_hp'] if cell['guaranteed_player_hp'] is not None else float('-inf'))
    wins=[r for r in rows if r['scores']['win']['known'] and r['scores']['win']['feasible']] if victory_first else []
    selected='win' if wins else task
    pool=wins if wins else [r for r in rows if r['scores'][task]['known'] and r['scores'][task]['feasible']]
    best=max((key(r['scores'][selected]) for r in pool),default=None)
    blocked=[r['card_id'] for r in rows if (victory_first and not r['scores']['win']['known']) or
        (not wins and not r['scores'][task]['known'])]
    return dict(requested_task=task,selected_task=selected,
        guaranteed_victory_takes_precedence=bool(wins),
        diagnostic_task_ranking_only=not victory_first,
        best_supported_candidate_ids=[r['card_id'] for r in pool if key(r['scores'][selected])==best],
        unresolved_candidate_ids=blocked,
        optimum_within_supplied_candidates_certified=not blocked,
        any_task_feasible_within_supplied_candidates=bool(pool) if pool or not blocked else None,
        scope='Only supplied candidates, this declared observation and task; not whole pool or construction ranking.')


def compare(config,cards=None):
    cards=score_cards.load_cards() if cards is None else cards;by={c['id']:c for c in cards}
    allowed={'scene','candidate_ids','background_hand','tasks','reference_card_id','include_delay','candidate_current_costs','candidate_base_costs','selection_task'}
    if not isinstance(config,dict) or set(config)-allowed or not {'scene','candidate_ids'}<=set(config):
        raise ValueError('Score config requires scene/candidate_ids with documented optional fields')
    scene=copy.deepcopy(config['scene'])
    forbidden={'hand_ids','hand_costs','hand_base_costs','hand_silenced','objectives','purpose_constraints','hp_certificate_prefix'}
    if forbidden.intersection(scene):raise ValueError('Scene omits own hand, goals and fixed prefix')
    if 'gold_before_play' not in scene:raise ValueError('Same explicit actual cash budget required')
    ids=config['candidate_ids']
    if not isinstance(ids,list) or not ids or len(ids)!=len(set(ids)) or any(type(cid) is not int or cid not in by \
            or by[cid]['card_type']!='monster' or by[cid]['pool_category']!='ordinary_non_token' for cid in ids):
        raise ValueError('Unique native ordinary monster candidate IDs required')
    background=config.get('background_hand',[])
    if not isinstance(background,list) or len(background)>6:raise ValueError('At most6 background copies')
    for item in background:
        if not isinstance(item,dict) or set(item)!={'card_id','current_cost','base_cost'} or item['card_id'] not in by:
            raise ValueError('Background copy requires known card_id/current_cost/base_cost')
        board.finite_number(item['current_cost'],'background cost');board.finite_number(item['base_cost'],'background base cost')
    extra=config.get('tasks',DEFAULT_TASKS)
    if not isinstance(extra,dict) or any(not isinstance(n,str) or not n or n in RESERVED for n in extra):
        raise ValueError('Named tasks object; hp/win reserved')
    tasks={**copy.deepcopy(RESERVED),**copy.deepcopy(extra)}
    selected=config.get('selection_task','hp')
    if selected not in tasks:raise ValueError('selection_task must name an available task')
    current=config.get('candidate_current_costs',{});bases=config.get('candidate_base_costs',{})
    if any(type(d) is not dict for d in (current,bases)):raise ValueError('Candidate costs are objects keyed by ID')
    if any(str(k) not in {str(cid) for cid in ids} for d in (current,bases) for k in d):raise ValueError('Candidate cost override has an unrequested ID')
    if any(len({str(k) for k in d})!=len(d) for d in (current,bases)):raise ValueError('Duplicate numeric/string cost keys')
    current={str(k):v for k,v in current.items()};bases={str(k):v for k,v in bases.items()}
    delay=config.get('include_delay',True)
    if type(delay) is not bool:raise ValueError('include_delay is boolean')
    index=len(background);rows=[];cache={}
    def data_for(cid):
        data=copy.deepcopy(scene);held=background+([] if cid is None else [dict(card_id=cid,
            current_cost=current.get(str(cid),current.get(cid,by[cid]['cost'])),base_cost=bases.get(str(cid),bases.get(cid,by[cid]['cost'])))])
        data.update(hand_ids=[h['card_id'] for h in held],hand_costs=[h['current_cost'] for h in held],hand_base_costs=[h['base_cost'] for h in held])
        return data
    def score(data,task,focal=None,restricted=False):
        key=canonical([data,task,focal,restricted])
        if key not in cache:cache[key]=task_score(data,task,cards=cards,focal_index=focal,delay_current=restricted)
        return copy.deepcopy(cache[key])
    absent_data=data_for(None)
    baseline={name:score(absent_data,t) for name,t in tasks.items()}
    for cid in ids:
        data=data_for(cid);scores={name:score(data,t,index) for name,t in tasks.items()}
        delayed={name:score(data,t,index,True) for name,t in tasks.items()} if delay else {}
        losses={name:difference(scores[name],delayed[name]) for name in delayed}
        for loss in losses.values():
            if loss['known'] and not loss.get('not_applicable'):
                assert loss['feasibility_change']>=0
                assert loss['hp_difference'] is None or loss['hp_difference']>=0
        rows.append(dict(card_id=cid,name=by[cid]['name'],printed_cost=by[cid]['cost'],input=data,
            source_text=by[cid]['effect_readable'],scores=scores,without_current_focal_deployment=delayed,
            current_deployment_right_value=losses,
            contribution_over_removed_copy={name:difference(s,baseline[name]) for name,s in scores.items()}))
    reference=config.get('reference_card_id',ids[0])
    if reference not in ids:raise ValueError('reference_card_id must be among candidates')
    ref=next(r for r in rows if r['card_id']==reference)
    for row in rows:row['same_slot_reference_difference']={n:difference(s,ref['scores'][n]) for n,s in row['scores'].items()}
    source_names=('conditional_card_score.py','paid_board_tactics.py','board_tactics.py','alpha_beta_search.py')
    return dict(version=VERSION,config=copy.deepcopy(config),tasks=tasks,reference_card_id=reference,
        removal_baseline=dict(input=absent_data,scores=baseline),rows=rows,
        selection=ranking(rows,selected),selections_by_task={name:ranking(rows,name) for name in tasks},
        diagnostic_task_leaders={name:ranking(rows,name,victory_first=False) for name in tasks},
        actual_search_queries=len(cache),
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in source_names},
        actual_cards_canonical_sha256=hashlib.sha256(canonical(sorted(cards,key=lambda c:c['id'])).encode()).hexdigest(),
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        limits=['Joint score is max_min(goal,playerHP), with goal first; unavailable goal has no numericHP, not0.',
            'Focal means the exact paid physical hand index; lineage additionally admits own Summon/Dust descendants. Board means any one own physical body.',
            'Removal baseline measures conditional possession contribution, not a replacement draw. Focal baseline is not applicable; compare same-slot alternatives for focal scores.',
            'Current deployment right value forbids only focal phase0 deployment, keeps it held, permits other copies/background and real later payment. It is not all hand-clog or construction opportunity cost.',
            'Filtered action generation still validates excluded effects; unresolved excluded mechanics conservatively block that timing query.',
            'Each task is its own adaptive strategy menu. Do not sum columns or combine their individually optimized endpoints.',
            'Selection puts proven victory ahead of the requested nonwinning task; winning-body diagnostics are not future resource value after the game ends.',
            'All observations, prices, incomes, libraries and deadlines are caller-declared. No context frequencies, Gold, probabilities or whole-pool strength are inferred.'])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',required=True,type=Path);parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args();result=compare(json.loads(args.input.read_text()))
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(version=VERSION,candidates=len(result['rows']),selection=result['selection']),ensure_ascii=False))


if __name__=='__main__':main()