"""Do not attribute whole-hand HP to a card: add a no-copy baseline.

The baseline is an observed-hand causal ablation, not an unobserved deck-slot
replacement or calibrated carrying value. Independent bounds use literal
damage/payment facts, then the tactical engine attempts to falsify them.
"""
import hashlib
import json
from pathlib import Path
import re

import build_damage_packet_comparison as comparison
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/damage-packet-v01'


def main():
    cards=score_cards.load_cards();by={c['id']:c for c in cards}
    damage=re.fullmatch(r'Deal (\d+) DMG\.',by[598]['effect_readable'])
    assert damage and by[598]['cost']==1 and by[598]['target']=='ALL'
    # No own body/action/draw/heal; enemy can retain or spend both physical
    # copies, attack once at each reached enemy turn, and choose only its
    # observed targets. The available face damage has this same lower/upper.
    independent_hp=15-2*1-2*int(damage[1]);assert independent_hp==11
    rows=[]
    for enemy_hp in (2,3,4):
        data=comparison.fixture(56,enemy_hp);data.update(hand_ids=[],objectives=['guaranteed_hp'])
        baseline=paid.evaluate(data,cards);assert baseline['complete_in_declared_scope']
        hp=baseline['objectives'][0]['metrics']['own_player_hp'];assert hp==independent_hp
        assert not any(a['kind']=='deploy' for a in baseline['objectives'][0]['principal_variation'])
        for cid in comparison.COHORT:
            d=comparison.fixture(cid,enemy_hp);d.update(objectives=['guaranteed_hp'])
            r=paid.evaluate(d,cards);assert r['complete_in_declared_scope']
            value=r['objectives'][0]['metrics']['own_player_hp']
            rows.append(dict(enemy_player_hp=enemy_hp,card_id=cid,name=by[cid]['name'],input=d,
                baseline_without_copy_input=data,baseline_without_copy=baseline,with_optional_copy=r,
                baseline_player_hp=hp,card_player_hp=value,incremental_player_hp=value-hp,
                independent_baseline_bounds=[independent_hp,independent_hp]))
    assert [r['incremental_player_hp'] for r in rows]==[1,1,1,0,0,1,0,0,0]
    out=dict(version='paid-packet-hand-ablation-0.1.0',rows=rows,
        independent_baseline_proof=dict(player_hp=15,enemy_observed_attack=1,reached_enemy_turns=2,
            physical_spells=[598,598],actual_enemy_cash=2,spell_price=1,spell_damage=int(damage[1]),
            lower_bound='Any legal enemy attack/cast subset has face damage at most4; no unknown incoming sources.',
            upper_witness='Use each of the two1G copies on our hero and attack our hero once at each enemy turn; no own bodies/attacks/heal can interfere.',
            scope='Caller-declared two response windows; no further draw/income or SOUL/artifacts. Literal arithmetic independent of engine primitives.'),
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('build_packet_incremental.py','build_damage_packet_comparison.py','paid_board_tactics.py','board_tactics.py')},
        source_snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        limits=['This removes an already-held physical copy without adding a replacement; it is not an equal deck-slot construction comparison.',
            'Baseline cash is unchanged. Merely holding the copy does not spend its printed3G.',
            'A zero playerHP increment does not mean zero body/control value.',
            'PlayerHP and separately optimized same-bodyHP are not combined into one strategy.',
            'No probabilities, winrates or Gold equivalence fitted.'])
    (OUT/'incremental-comparison.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    lines=['# 先扣观察基线，再解释玩家HP贡献','',
        '前表11/11/12不能直接作为三张卡的HP收益。保持现金和所有对手事实，只移除这张已抽到副本，两个敌回应的玩家HP精确为11：15−两次1ATK−两张各付1G的1伤。合法攻击和付款给出同一上下界；不引用伤害/搜索原语先做这个算术证明。','',
        '| 敌玩家HP | Mettaton增量 | Candy Dish增量 | Ranger增量 |','|---|---:|---:|---:|',
        '| 2 | +1 | +1 | +1 |','| 3 | 0 | 0 | +1 |','| 4 | 0 | 0 | 0 |','',
        '3HP敌面前Mettaton/Candy的保命增量为0，但可以分别保证身体HP1/2；Ranger保命+1却不能保证留体。此处零是这个HP目的的已求解增量，不是整卡0分。敌HP2时三者都有合法终结机会，HP4时窗口内都不终结。','',
        '移除已持牌是有限手牌的因果基线，并非把抽牌卡位换成一张真实替代。携带价值仍须与相同卡位、相同背景下的另一个可行动副本比较，并包含未来到手/持有策略。']
    (OUT/'incremental-comparison.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps([{k:r[k] for k in ('enemy_player_hp','card_id','baseline_player_hp','card_player_hp','incremental_player_hp')} for r in rows]))


if __name__=='__main__':main()