"""Independent search algorithm comparison for the real future cash threshold."""
import hashlib
import json
from pathlib import Path
import time

import paid_board_tactics as paid

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/damage-packet-v01'


def main():
    source_names=('verify_packet_timing_search.py','paid_board_tactics.py','board_tactics.py')
    hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in source_names}
    rows=[]
    records=json.loads((OUT/'timing-comparison.json').read_text())
    for row in records['cases']:
        if row['case'] not in ('candy-cash2-income0','candy-cash2-income1'):continue
        data=dict(row['input'],objectives=['purpose'],
            purpose_constraints=dict(min_own_player_hp=1,min_own_body_attack=2,min_own_body_health=2),
            search_algorithm='exhaustive')
        started=time.monotonic();result=paid.evaluate(data)
        assert result['complete_in_declared_scope'],result['unknown']
        expected=row['goals']['body2']['objectives'][0]['objective_vector']
        assert list(result['objectives'][0]['objective_vector'])==expected
        rows.append(dict(case=row['case'],seconds=time.monotonic()-started,
            full_vector_equal=True,result=result))
        print(json.dumps(dict(case=row['case'],full_vector_equal=True)),flush=True)
    assert len(rows)==2
    assert all(hashlib.sha256((HERE/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
    (OUT/'timing-exhaustive.json').write_text(json.dumps(dict(cases=rows,source_hashes=hashes,
        comparison_input_sha256=hashlib.sha256((OUT/'timing-comparison.json').read_bytes()).hexdigest(),
        limitation='Different search algorithms share rule primitives. This is search validation, not independent rule or real-match evidence.'),indent=2)+'\n')


if __name__=='__main__':main()