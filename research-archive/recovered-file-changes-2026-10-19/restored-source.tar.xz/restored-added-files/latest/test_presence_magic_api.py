"""Production API: paid Charge prerequisite and newly drawn conditional Magic."""
import copy
import unittest
import evaluate_situation as api
import paid_board_tactics as paid
import test_presence_magic_probe as presence_tests


class PresencePublicTests(unittest.TestCase):
    def public(self,scene):
        obs={k:copy.deepcopy(scene.get(k,[] if 'bodies' in k else 0)) for k in ('hand_ids','gold_before_play',
            'opponent_gold_before_response','own_player_hp','enemy_player_hp','ally_bodies_before_play','enemy_bodies')}
        params={k:copy.deepcopy(v) for k,v in scene.items() if k not in obs and k not in
            ('own_player_max_hp','enemy_player_max_hp','hand_costs','opponent_hand_known')}
        return dict(obs,role='midrange',own_turn=9,hand_costs=scene['hand_costs'],paid_board_scenario=params,
            callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30))

    def data(self,*args,**kwargs):
        helper=presence_tests.PresenceTests();helper.setUpClass();return helper.data(*args,**kwargs)

    def test_real_taunt_payment_opens_guaranteed_win_in_public_api(self):
        data=self.data(ids=(1,116),cash=5,own_player_hp=1,enemy_player_hp=4,
            objectives=['purpose'],purpose_constraints=dict(min_own_player_hp=1,max_enemy_player_hp=0))
        direct=paid.evaluate(data);public=api.evaluate(self.public(data))['paid_board_tactics']
        self.assertTrue(public['complete_in_declared_scope'],public['unknown']);self.assertEqual(public,direct)
        result=public['objectives'][0];self.assertTrue(result['purpose_guaranteed'])
        self.assertEqual(result['payment_accounting']['current_paid_gold'],5)

    def test_newly_drawn_conditional_hand_magic_is_real_future_payment(self):
        data=self.data(ids=(47,43),cash=12,own_deck_ids=[46],horizon='next_own_attack',
            next_own_gold_income=6,next_natural_draw_count=1,next_max_plays='all_physical',objectives=['guaranteed_hp'])
        direct=paid.evaluate(data);public=api.evaluate(self.public(data))['paid_board_tactics']
        self.assertTrue(public['complete_in_declared_scope'],public['unknown']);self.assertEqual(public,direct)
        result=public['objectives'][0];plays=[a for a in result['principal_variation'] if a['kind']=='deploy' and a['card_id']==46]
        self.assertEqual(len(plays),1);self.assertEqual(plays[0]['paid_gold'],6)
        self.assertGreaterEqual(result['payment_accounting']['next_paid_gold'],6)
        self.assertEqual(result['draw_accounting']['remaining_known_deck'],0)


if __name__=='__main__':unittest.main()