"""Reproduce a common-API scalar certificate without hiding vector failure."""
import copy
import hashlib
import json
from pathlib import Path
import build_second_reply_comparison as comparison
import evaluate_situation
import paid_board_tactics
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/second-reply-v01'


def main():
    record=json.loads((OUT/'comparison.json').read_text())
    saved=record['native_current_four_scalar_certificate']
    scene=comparison.native(4)
    cards=score_cards.load_cards();by={c['id']:c for c in cards}
    scene['hand_costs']=[by[cid]['cost'] for cid in scene['hand_ids']]
    # A computational budget, not a smaller action menu. The independent
    # continuation needs 3166 states and the full vector remains unproven.
    scene.update(node_limit=5000,hp_certificate_prefix=saved['request_prefix'])
    current={k:copy.deepcopy(scene[k]) for k in ('hand_ids','gold_before_play','own_player_hp',
        'enemy_player_hp','ally_bodies_before_play','enemy_bodies','opponent_gold_before_response','hand_costs')}
    root_keys=set(current)|{'condition_known_state','own_player_max_hp'}
    current.update(role='midrange',own_turn=4,condition_state=scene['condition_known_state'],
        callback_state={'own_player_max_hp':30},response_weights={'enemy_face':1},
        paid_board_scenario={k:copy.deepcopy(v) for k,v in scene.items() if k not in root_keys})
    direct=paid_board_tactics.evaluate(scene,cards)
    result=evaluate_situation.evaluate(current,cards=cards)
    if json.loads(json.dumps(result['paid_board_tactics']))!=json.loads(json.dumps(direct)):
        left=direct['hp_optimum_certificate']['input']
        right=result['paid_board_tactics']['hp_optimum_certificate']['input']
        differences={k:[left.get(k),right.get(k)] for k in left.keys()|right.keys() if left.get(k)!=right.get(k)}
        raise AssertionError(('Common API differs from standalone',differences))
    certificate=direct['hp_optimum_certificate']
    if direct['complete_in_declared_scope'] or direct['recommendations']:
        raise AssertionError('Budget failure was incorrectly converted into a full recommendation')
    if not certificate['hp_optimum_certified'] or certificate['guaranteed_hp_bounds']!=[12,12]:
        raise AssertionError(certificate['unknown'])
    for name,document in (('current.input.json',current),('current.result.json',result),
        ('hp-optimum-certificate.json',certificate)):
        (OUT/name).write_text(json.dumps(document,ensure_ascii=False,indent=2)+'\n')
    binding=dict(api_matches_standalone=True,full_vector_complete=False,scalar_hp_exact=12,
        source_hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in
            ('build_second_reply_api.py','evaluate_situation.py','paid_board_tactics.py','board_tactics.py',
             'certify_hand_hp.py','alpha_beta_search.py')},
        input_sha256=hashlib.sha256((OUT/'current.input.json').read_bytes()).hexdigest(),
        result_sha256=hashlib.sha256((OUT/'current.result.json').read_bytes()).hexdigest())
    (OUT/'api-verification.json').write_text(json.dumps(binding,indent=2)+'\n')
    print('Common API: scalar HP [12,12], full-vector budget failure retained, standalone equal')


if __name__=='__main__':main()