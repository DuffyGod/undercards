"""Rerun affected test modules; explicitly carry unchanged source-bound tests.

A module is reused only when every recursively imported local source matches a
passed baseline. New/changed dependencies select the entire test module. This
does not reuse a baseline merely because a version string or output agrees.
"""
import argparse
import ast
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import unittest

import verify_research_integration as integration

HERE=Path(__file__).resolve().parent


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def dependencies(module):
    pending=[module];found={}
    while pending:
        name=pending.pop().split('.')[0];path=HERE/(name+'.py')
        if not path.is_file() or path.name in found:continue
        raw=path.read_bytes();found[path.name]=hashlib.sha256(raw).hexdigest()
        for node in ast.walk(ast.parse(raw)):
            if isinstance(node,ast.Import):pending.extend(a.name for a in node.names)
            elif isinstance(node,ast.ImportFrom) and node.module:pending.append(node.module)
    return found


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',type=Path,default=HERE/'research-runs/periodic-spatial-v01/full-regression.json')
    parser.add_argument('--output',type=Path,default=HERE/'research-runs/literal-magic-v01/selective-regression.json')
    parser.add_argument('--extra-module',action='append',default=[])
    args=parser.parse_args();started=datetime.now(timezone.utc).isoformat()
    baseline=json.loads(args.baseline.read_text())
    if not baseline['passed'] or not baseline['source_unchanged_during_run']:
        raise ValueError('A passed source-stable baseline is required')
    modules=list(dict.fromkeys(integration.MODULES+args.extra_module));selected=[];carried=[];counts={};graphs={}
    registered=integration.regression_sources()
    frozen=dict(registered)
    for module in modules:
        graph=dependencies(module);graphs[module]=graph;frozen.update(graph)
        changed=[name for name,h in graph.items() if baseline['source_hashes'].get(name)!=h]
        count=unittest.defaultTestLoader.loadTestsFromName(module).countTestCases();counts[module]=count
        assert count>0
        row=dict(module=module,test_count=count,changed_dependencies=changed,source_hashes=graph)
        if changed:selected.append(row)
        else:carried.append(row)
    print(json.dumps(dict(selected_modules=len(selected),selected_tests=sum(r['test_count'] for r in selected),
        unchanged_modules=len(carried),unchanged_tests=sum(r['test_count'] for r in carried))),flush=True)
    command=[sys.executable,'-m','unittest',*[r['module'] for r in selected]]
    done=subprocess.run(command,cwd=HERE,capture_output=True,text=True) if selected else None
    log=(done.stdout+done.stderr) if done else 'No test modules affected; no tests executed.\n'
    logfile=args.output.with_suffix('.log');logfile.write_text(log)
    match=re.search(r'Ran (\d+) tests in ([\d.]+)s',log)
    actual=int(match[1]) if match else 0
    expected=sum(r['test_count'] for r in selected)
    stable=registered==integration.regression_sources() and all(graph==dependencies(name) for name,graph in graphs.items())
    result=dict(started_at_utc=started,finished_at_utc=datetime.now(timezone.utc).isoformat(),source_hashes=frozen,
        source_unchanged_during_run=stable,runner_sha256=digest(Path(__file__)),command=command,
        tests_executed=bool(selected),test_count=actual,runner_seconds=float(match[2]) if match else 0,
        exit_code=done.returncode if done else 0,passed=(done is None or done.returncode==0) and actual==expected and stable,
        current_source_test_coverage=sum(counts.values()),actual_retested=selected,reused_unchanged=carried,
        registered_modules=integration.MODULES,extra_modules=args.extra_module,
        baseline_receipt=str(args.baseline),baseline_sha256=digest(args.baseline),test_log=str(logfile),
        interpretation='test_count is actually executed now. current_source_test_coverage also includes individually source-identical baseline modules; it is not a fresh whole-suite run.')
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('passed','test_count','current_source_test_coverage','source_unchanged_during_run','runner_seconds')}),flush=True)
    if not result['passed']:sys.exit(1)


if __name__=='__main__':main()