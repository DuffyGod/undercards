import unittest

import evaluate_situation as situation
import score_cards as base


def probe(hand=None):
    return dict(hand_ids=[115,438] if hand is None else hand,role='midrange',own_turn=5,
        gold_before_play=12,opponent_gold_before_response=0,own_player_hp=8,enemy_player_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[dict(attack=6,health=6),dict(attack=3,health=3)],
        condition_state={'last_turn_gold_spent_on_spells':0},response_weights={'enemy_face':1})


class SituationEvaluatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards=base.load_cards()
        cls.reference,_=base.make_reference(cls.cards)

    def evaluate(self,data):
        return situation.evaluate(data,self.reference,self.cards)

    def test_tactical_api_uses_physical_copy_costs_and_observed_enemy_readiness(self):
        data=probe([15,1,1])
        data.update(gold_before_play=5,own_player_hp=2,hand_costs=[5,1,2],
            enemy_bodies=[dict(attack=6,health=5,ready=True),dict(attack=2,health=3,ready=True)],
            board_tactics_scenario=dict(horizon='enemy_attack',max_plays=2))
        r=self.evaluate(data)
        self.assertTrue(r['board_tactics']['complete_in_declared_scope'])
        for objective in r['board_tactics']['objectives']:
            self.assertFalse(objective['metrics']['own_player_dead'])
            self.assertEqual(objective['metrics']['own_remaining_gold'],2)
        self.assertTrue(r['declared_current_state']['legacy_board_metadata_omitted'])

    def test_tactical_parameters_cannot_override_root_observations(self):
        data=probe([15]);data['board_tactics_scenario']={'own_player_hp':100}
        with self.assertRaisesRegex(ValueError,'board_tactics_scenario'):self.evaluate(data)

    def test_hidden_hand_recommendation_requires_one_shared_current_policy(self):
        for enemy_cash,hp in ((3,0),(2,2)):
            data=probe([1,22])
            data.update(gold_before_play=3,own_player_hp=3,opponent_gold_before_response=enemy_cash,
                enemy_bodies=[dict(card_id=15,attack=6,health=5,max_health=5)],
                callback_state={'own_player_max_hp':30,'enemy_player_max_hp':30},
                hidden_reply_scenario={'opponent_hands':[{'ids':[96]},{'ids':[598]}],
                    'max_plays':1,'objective':'guaranteed_hp'})
            result=self.evaluate(data);hidden=result['hidden_reply_policy']
            self.assertTrue(hidden['complete_in_declared_scope'],hidden['unknown'])
            self.assertEqual(hidden['metrics']['own_player_hp'],hp)
            self.assertEqual(result['authoritative_tactical_recommendation']['source'],'hidden_reply_policy')
            self.assertEqual(result['authoritative_tactical_recommendation']['guaranteed_survival'],hp>0)
            self.assertTrue(result['hand_survival']['diagnostic_only'])
            if enemy_cash==2:self.assertEqual(hidden['common_own_prefix'][0]['card_id'],1)

    def test_hidden_parameters_cannot_override_public_hp_or_conflict_with_known_scope(self):
        data=probe([1,22]);data['hidden_reply_scenario']={'opponent_hands':[{'ids':[96]},{'ids':[598]}],
            'own_player_hp':999}
        with self.assertRaisesRegex(ValueError,'hidden_reply_scenario'):self.evaluate(data)
        data['hidden_reply_scenario'].pop('own_player_hp')
        data['paid_board_scenario']={'horizon':'enemy_attack'}
        with self.assertRaisesRegex(ValueError,'Choose a declared'):self.evaluate(data)

    def test_actual_first_draw_keeps_private_library_out_of_current_hand(self):
        for enemy_cash,hp in ((3,0),(2,2)):
            data=probe([1,22])
            data.update(gold_before_play=3,own_player_hp=3,opponent_gold_before_response=enemy_cash,
                enemy_bodies=[dict(card_id=15,attack=6,health=5,max_health=5)],
                callback_state={'own_player_max_hp':30,'enemy_player_max_hp':30},
                hidden_reply_scenario=dict(opponent_hands=[dict(ids=[],deck_ids=[96]),
                    dict(ids=[],deck_ids=[598])],first_opponent_natural_draw_count=1,
                    max_plays=1,objective='guaranteed_hp'))
            hidden=self.evaluate(data)['hidden_reply_policy']
            self.assertTrue(hidden['complete_in_declared_scope'],hidden['unknown'])
            self.assertEqual(hidden['metrics']['own_player_hp'],hp)
            for panel in hidden['input']['panels']:
                self.assertEqual(panel['opponent_hand_ids'],[])
                self.assertEqual(len(panel['opponent_deck_ids']),1)
        data.pop('hidden_reply_scenario')
        data['paid_board_scenario']=dict(opponent_hand_ids=[],opponent_deck_ids=[96],
            first_opponent_natural_draw_count=1,max_plays=1,objectives=['guaranteed_hp'])
        paid=self.evaluate(data)['paid_board_tactics']
        self.assertTrue(paid['complete_in_declared_scope'],paid['unknown'])
        self.assertEqual(paid['objectives'][0]['opponent_draw_accounting']['first_natural_draw_count'],1)

    def test_observed_transparency_is_forwarded_and_does_not_guard_face(self):
        for transparent,hp in ((True,2),(False,8)):
            data=probe([1])
            data.update(gold_before_play=0,own_player_hp=8,
                ally_bodies_before_play=[dict(card_id=397,attack=4,health=4,ready=False,transparency=transparent)],
                enemy_bodies=[dict(card_id=15,attack=6,health=5)],
                paid_board_scenario=dict(horizon='enemy_attack',max_plays=0,objectives=['guaranteed_hp']))
            result=self.evaluate(data);paid=result['paid_board_tactics']
            self.assertTrue(paid['complete_in_declared_scope'],paid['unknown'])
            self.assertEqual(paid['objectives'][0]['metrics']['own_player_hp'],hp)
            self.assertEqual(result['input']['ally_bodies_before_play'][0]['transparency'],transparent)
        data['ally_bodies_before_play'][0].pop('transparency')
        result=self.evaluate(data)
        self.assertFalse(result['paid_board_tactics']['complete_in_declared_scope'])
        self.assertFalse(result['authoritative_tactical_recommendation']['complete'])

    def test_body_maximum_observation_controls_healing_recommendation(self):
        data=probe([22])
        data.update(gold_before_play=3,own_player_hp=3,
            callback_state={'own_player_max_hp':30},
            ally_bodies_before_play=[dict(card_id=15,attack=6,health=1,ready=False)],
            enemy_bodies=[dict(card_id=196,attack=1,health=1,max_health=1)],
            paid_board_scenario=dict(horizon='enemy_attack',max_plays=1,objectives=['purpose'],
                purpose_constraints=dict(min_own_player_hp=1,min_own_board_attack=6,min_own_board_health=1)))
        missing=self.evaluate(data)
        self.assertFalse(missing['authoritative_tactical_recommendation']['complete'])
        self.assertEqual(missing['authoritative_tactical_recommendation']['policies'],[])
        self.assertFalse(missing['paid_board_tactics']['body_hp_caps']['own'][0]['max_health_known'])
        data['ally_bodies_before_play'][0]['max_health']=5
        explicit=self.evaluate(data)
        self.assertTrue(explicit['paid_board_tactics']['complete_in_declared_scope'])
        self.assertTrue(explicit['paid_board_tactics']['objectives'][0]['purpose_guaranteed'])
        self.assertEqual(explicit['authoritative_tactical_recommendation']['policies'][0]['first_action']['magic_target'],('own',0))

    def test_scalar_hp_certificate_survives_full_vector_budget_failure_without_recommendation(self):
        data=probe([1])
        data.update(gold_before_play=1,own_player_hp=3,
            enemy_bodies=[dict(card_id=15,attack=6,health=5)],
            paid_board_scenario=dict(horizon='enemy_attack',max_plays=1,
                objectives=['guaranteed_hp'],node_limit=4,
                hp_certificate_prefix=[dict(kind='deploy',hand_index=0),dict(kind='end_turn')]))
        result=self.evaluate(data);search=result['paid_board_tactics']
        self.assertFalse(search['complete_in_declared_scope'])
        self.assertEqual(search['recommendations'],[])
        self.assertTrue(search['scalar_guaranteed_hp_exact'])
        self.assertEqual(search['hp_optimum_certificate']['guaranteed_hp_bounds'],[3,3])
        self.assertFalse(search['hp_optimum_certificate']['full_future_vector_optimized'])
        self.assertFalse(result['authoritative_tactical_recommendation']['complete'])
        self.assertEqual(result['authoritative_tactical_recommendation']['policies'],[])

    def test_emergency_survival_and_gold_headline_are_separate(self):
        r=self.evaluate(probe())
        spider,battleflies=r['action_windows']
        self.assertTrue(spider['window_known'])
        self.assertTrue(battleflies['window_known'])
        self.assertEqual(spider['death_probability'],1)
        self.assertEqual(battleflies['death_probability'],0)
        self.assertIsNone(r['card_quotes'][1]['net_model_gold'])
        self.assertEqual(battleflies['recommended_action'],'attack-1')
        self.assertEqual(r['hand_survival']['hold_death_probability'],1)
        self.assertEqual(r['hand_survival']['known_death_reducing_hand_indexes'],[1])
        self.assertEqual(r['hand_survival']['lowest_death_probability_bounds'],[0,0])

    def test_paid_reply_withdraws_conflicting_legacy_survival_recommendation(self):
        data=probe([1,990,932,582,438])
        data.update(gold_before_play=4,own_player_hp=3,opponent_gold_before_response=3,
            enemy_bodies=[dict(card_id=15,attack=6,health=5),dict(card_id=2,attack=2,health=3)],
            condition_state={'last_turn_gold_spent_on_spells':1},
            timing_scenario={'next_income':0,'next_draw_count':0},max_current_plays=1,
            paid_board_scenario={'max_plays':1,'horizon':'enemy_attack','objectives':['survive'],
                'opponent_hand_ids':[96],'own_deck_ids':[],'own_fatigue_next':1})
        result=self.evaluate(data)
        legacy=result['hand_survival']
        self.assertEqual(legacy['legacy_best_known_death_reducing_hand_index'],0)
        self.assertIsNone(legacy['best_known_death_reducing_hand_index'])
        self.assertTrue(legacy['diagnostic_only'])
        policy=result['authoritative_tactical_recommendation']['policies'][0]
        self.assertEqual(policy['first_action']['card_id'],438)
        self.assertEqual(result['paid_board_tactics']['objectives'][0]['metrics']['own_player_hp'],1)

    def test_first_four_gold_turn_is_evaluable_without_invented_income(self):
        data=probe([438])
        data.update(own_turn=2,gold_before_play=4,own_player_hp=30,enemy_bodies=[dict(attack=2,health=2)])
        r=self.evaluate(data)
        self.assertTrue(r['card_quotes'][0]['pricing_supported'])
        self.assertTrue(r['action_windows'][0]['deployment_legal_now'])
        self.assertEqual(r['declared_current_state']['cumulative_base_gold_cap'],4)

    def test_observed_nonbase_gold_does_not_become_free_candidate_payment(self):
        data=probe([438])
        data.update(own_turn=2,gold_before_play=12,own_player_hp=30,enemy_bodies=[])
        r=self.evaluate(data)
        self.assertEqual(r['declared_current_state']['gold_before_play'],12)
        self.assertFalse(r['action_windows'][0]['actual_payment_made'])
        self.assertTrue(r['action_windows'][0]['deployment_legal_now'])

    def test_missing_future_dust_hand_is_unknown_not_zero(self):
        data=probe([43,138])
        data.update(own_player_hp=30,enemy_bodies=[])
        r=self.evaluate(data)
        self.assertFalse(r['card_quotes'][0]['pricing_supported'])
        self.assertTrue(any('hand_at_event' in x for x in r['card_quotes'][0]['unsupported']))
        self.assertTrue(r['card_quotes'][1]['pricing_supported'])
        self.assertTrue(r['action_windows'][1]['window_known'])
        data['dust_timing']=dict(horizon=7,origin_turn=5,discount_rate=0,
            branches=[dict(event='ordinary_death',probability=1,event_turn=5,
                hand_at_event=[dict(cost=3,use_turn=6)],initial_gold=0,
                payment_windows=[dict(turn=6,income=3,max_plays=1)])])
        known=self.evaluate(data)
        term=known['effect_realizations'][0]['dust_realization'][0]
        self.assertEqual(term['model_gold'],1)
        self.assertEqual(term['earliest_realization_turn'],6)
        self.assertEqual(term['trigger_probability'],1)
        self.assertEqual(term['realization_probability'],1)

    def test_response_weights_apply_to_quote_and_action_paths(self):
        data=probe([438])
        data.update(own_player_hp=30)
        r=self.evaluate(data)
        self.assertEqual(r['action_windows'][0]['response_weights'],{'enemy_face':1})
        data['response_weights']={'none':1}
        z=self.evaluate(data)
        self.assertNotAlmostEqual(r['card_quotes'][0]['net_model_gold'],z['card_quotes'][0]['net_model_gold'])

    def test_unpayable_diagnostics_do_not_manufacture_legal_recommendation(self):
        data=probe([438]);data['gold_before_play']=3
        r=self.evaluate(data)
        self.assertFalse(r['action_windows'][0]['deployment_legal_now'])
        self.assertIsNone(r['action_windows'][0]['recommended_action'])

    def test_ordinary_body_certain_win_is_not_hidden_by_resource_greed(self):
        data=probe([15])
        data.update(own_player_hp=30,enemy_player_hp=1,
                    enemy_bodies=[dict(attack=1,health=6)],response_weights={'none':1})
        r=self.evaluate(data)
        # Aaron could earn a larger body-resource diagnostic by trading, but
        # a legal face attack ends this closed game first.
        self.assertEqual(r['action_windows'][0]['defeat_probability'],1)
        self.assertFalse(r['card_quotes'][0]['pricing_supported'])
        self.assertIsNone(r['card_quotes'][0]['net_model_gold'])

    def test_paid_search_mixed_hand_restores_real_seven_gold_rescue(self):
        data=probe([96,438])
        data.update(gold_before_play=7,own_player_hp=5,
                    condition_state={'last_turn_gold_spent_on_spells':1},
                    paid_board_scenario={'horizon':'enemy_attack','objectives':['survive']})
        result=self.evaluate(data)
        tactical=result['paid_board_tactics']
        self.assertTrue(tactical['complete_in_declared_scope'],tactical['unknown'])
        self.assertFalse(tactical['objectives'][0]['metrics']['own_player_dead'])
        self.assertEqual(tactical['objectives'][0]['metrics']['own_remaining_gold'],0)

    def test_paid_search_keeps_original_paralyze_observation(self):
        data=probe([1])
        data.update(gold_before_play=1,own_player_hp=3,enemy_bodies=[dict(attack=6,health=5,paralyze_owner_starts_remaining=2)],
                    paid_board_scenario={'horizon':'enemy_attack','objectives':['survive']})
        result=self.evaluate(data)
        self.assertTrue(result['paid_board_tactics']['complete_in_declared_scope'])
        self.assertEqual(result['paid_board_tactics']['objectives'][0]['metrics']['own_player_hp'],3)
        self.assertEqual(result['input']['enemy_bodies'][0]['paralyze_owner_starts_remaining'],2)


if __name__=='__main__':
    unittest.main()