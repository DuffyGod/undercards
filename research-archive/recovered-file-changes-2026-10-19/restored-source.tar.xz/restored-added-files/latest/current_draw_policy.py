"""Two unknown library orders: commit until a retained draw reveals the order.

This is a conservative guaranteed policy against a world-informed opponent,
not a stochastic deck prior or calibrated game strength. Quantity is committed
before the Draw; a kept identity reveals one of two distinct-card permutations.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path

import paid_board_tactics as paid
import score_cards

VERSION='finite-current-draw-observation-policy-0.1.0'
SCOPE='two_distinct_card_orders_shared_policy_until_retained_draw'


def action_key(action):return json.dumps(action,sort_keys=True,separators=(',',':'))


def validate(data):
    panels=data.get('panels')
    if not isinstance(panels,list) or len(panels)!=2 or any(not isinstance(p,dict) for p in panels):
        raise ValueError('Exactly two complete paid panels required')
    if [{k:v for k,v in p.items() if k!='own_deck_ids'} for p in panels][0] != \
            {k:v for k,v in panels[1].items() if k!='own_deck_ids'}:
        raise ValueError('Every public root field except own_deck_ids must match exactly')
    libraries=[p.get('own_deck_ids') for p in panels]
    if any(not isinstance(d,list) or len(d)!=2 or any(type(cid) is not int for cid in d)
           or d[0]==d[1] for d in libraries) or libraries[1]!=libraries[0][::-1]:
        raise ValueError('Two reverse permutations of exactly two distinct known card IDs required')
    scene=panels[0];horizon=scene.get('horizon','next_own_attack')
    for key in ('queued_delays','pending_events','pending_queue','soul','own_soul','enemy_soul',
                'soul_effects','artifacts','artifact_ids','slot_enchantments'):
        if scene.get(key):raise ValueError('Active unmodeled root field outside current Draw scope: '+key)
    if horizon not in ('enemy_attack','next_own_attack','next_enemy_attack'):
        raise ValueError('Unsupported horizon')
    if horizon!='enemy_attack' and scene.get('next_natural_draw_count')!=1:
        raise ValueError('A future own decision requires one explicit next natural draw to reveal the order')
    if scene.get('first_opponent_natural_draw_count',0)!=0 or scene.get('next_opponent_natural_draw_count',0)!=0:
        raise ValueError('Enemy natural draws must be absent in this known-enemy-hand scope')
    if data.get('opponent_hand_known') is not True or not isinstance(scene.get('opponent_hand_ids'),list):
        raise ValueError('Explicit identical known physical opponent hand required')
    if scene.get('opponent_deck_ids',[])!=[]:
        raise ValueError('Nonempty enemy libraries and joint hidden enemy information are outside this scope')
    if len(scene.get('hand_ids',[]))>6:
        raise ValueError('At most six current held copies required for guaranteed draw revelation')
    mode=data.get('objective','guaranteed_hp')
    if mode not in (*paid.board.OBJECTIVES,'guaranteed_hp','purpose'):raise ValueError('Unsupported objective')
    limit=data.get('node_limit',100000)
    if type(limit) is not int or limit<1:raise ValueError('Positive integer node_limit required')
    names=data.get('panel_names',['order-a-b','order-b-a'])
    if not isinstance(names,list) or len(names)!=2 or any(not isinstance(n,str) for n in names) or len(set(names))!=2:
        raise ValueError('Two unique string panel names required')
    return panels,mode,limit,names


def source_binding(cards):
    here=Path(__file__).resolve().parent
    return dict(cards_canonical_sha256=hashlib.sha256(json.dumps(sorted(cards,key=lambda c:c['id']),
        sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest(),
        source_hashes={name:hashlib.sha256((here/name).read_bytes()).hexdigest() for name in
            ('current_draw_policy.py','paid_board_tactics.py','board_tactics.py','alpha_beta_search.py',
             'finite_conditions.py','queued_delay.py','draw_options.py','score_cards.py')})


def evaluate(data,cards=None):
    panels,mode,limit,names=validate(data)
    cards=score_cards.load_cards() if cards is None else cards
    engines=[paid.PaidSearch(cards,copy.deepcopy(p)) for p in panels]
    roots=tuple(e.root() for e in engines)
    base=dict(version=VERSION,scope=SCOPE,input=copy.deepcopy(data),objective=mode,
        complete_in_declared_scope=False,objective_vector=None,metrics=None,
        shared_prefix=[],observation_policy=None,per_prefix_payoffs=[],
        perfect_information_oracles=[],oracle_minimum_vector=None,unknown=[],
        source_binding=source_binding(cards),action_scope=engines[0].action_scope(),
        body_hp_caps=paid.board.body_hp_caps(roots[0]),
        player_hp_caps={side:dict(maximum=getattr(roots[0],side+'_max_hp'),
            explicitly_supplied=side+'_player_max_hp' in panels[0]) for side in ('own','enemy')},
        information_protocol=dict(known_composition=panels[0]['own_deck_ids'],
            possible_orders=[p['own_deck_ids'] for p in panels],order_known_before_draw=False,
            draw_quantity_committed_before_reveal=True,kept_draw_identity_reveals_two_card_order=True,
            enemy_can_use_world_specific_worst_reply=True),
        assumptions=['Current own actions and optional draw quantity are shared until an actual retained card distinguishes both orders.',
            'With two distinct identities and known complete composition, observing one retained draw identifies the order and remaining identity. Draw chronology is observed.',
            'Future own decisions are admitted only after an explicit kept natural draw reveals the world; burning without a retained reveal is refused.',
            'Opponent replies are separately minimized in each world, giving a conservative guarantee against an opponent allowed hidden-order knowledge. This is not exact play against an uninformed real opponent.',
            'The quantity of one optional Draw is chosen before its first card. Choosing whether to continue after seeing that card is outside this source-unverified protocol.',
            'No empirical frequencies, arbitrary probability priors, Gold score or whole-game win probability are inferred.',
            'Reported metrics belong to one worst objective-vector endpoint. Purpose endpoint HP is not an independent HP guarantee; use guaranteed_hp for that scalar.',
            'Unknown mechanics, unequal pre-reveal legal action sets or state-budget exhaustion withdraw all policies.'],
        model_gold=None,empirical_win_probability=None)
    nodes=0;memo={};continuations={};rows=[]
    def tick(n=1):
        nonlocal nodes
        nodes+=n
        if nodes>limit:raise paid.UnknownMechanic('Shared current-draw policy state budget exhausted')
    def solve(i,state):
        key=i,state
        if key not in continuations:
            engines[i].node_limit=max(1,limit-nodes)
            result=engines[i].solve(state,mode)
            tick(max(result.get('visited_states',0),result.get('minimax_visited_states',0)))
            if not result['search_complete']:raise paid.UnknownMechanic('; '.join(result.get('unknown',[])) or 'Incomplete continuation')
            continuations[key]=result
        return continuations[key]
    def revealed(states):
        observations=[]
        for e,s in zip(engines,states):
            observations.append([dict(physical_index=i,card_id=e.hand[i][0]['id'])
                for i in s.hand if i>=e.initial_hand_count])
        return bool(observations[0] and observations[1] and observations[0]!=observations[1]),observations
    def endpoint(states,prefix,reason,observations):
        results=[solve(i,s) for i,s in enumerate(states)]
        worst=min(range(2),key=lambda i:tuple(results[i]['objective_vector']))
        row=dict(shared_prefix=prefix,adaptation_boundary=reason,observations=observations,
            panel_payoffs=[dict(panel=names[i],result=r,phase=states[i].phase,
                own_order_observed=reason=='current_retained_draw') for i,r in enumerate(results)],
            worst_panel=names[worst],worst_objective_vector=results[worst]['objective_vector'])
        rows.append(row);return row
    def visit(states,prefix):
        if states in memo:return memo[states]
        tick();known,observations=revealed(states)
        if known:
            answer=endpoint(states,prefix,'current_retained_draw',observations)
        else:
            stops=[e.terminal(s) or s.phase!=0 for e,s in zip(engines,states)]
            if any(stops) and not all(stops):raise paid.UnknownMechanic('Unrevealed world termination mismatch')
            if all(stops):
                if any(s.phase not in (0,1) for s in states):raise paid.UnknownMechanic('Unrevealed prefix crossed the first enemy reply')
                if engines[0].horizon!='enemy_attack' and any(len(s.hand)>6 or not s.own_deck for s in states):
                    raise paid.UnknownMechanic('Future draw may burn or fail to reveal the unknown order')
                answer=endpoint(states,prefix,'current_window_ended',observations)
            else:
                menus=[]
                for e,s in zip(engines,states):
                    options=[(dict(kind='end_turn',phase=0),e.boundary(s)),*e.attacks(s),*e.deploys(s)]
                    menu={}
                    for action,child in options:
                        key=action_key(action)
                        if key in menu and menu[key][1]!=child:raise paid.UnknownMechanic('Ambiguous physical successor for one shared action')
                        menu[key]=action,child
                    menus.append(menu)
                if set(menus[0])!=set(menus[1]):raise paid.UnknownMechanic('Pre-reveal legal action sets differ; cannot intersect them')
                answer=None
                for key in sorted(menus[0]):
                    children=tuple(m[key][1] for m in menus)
                    changed=any(c.own_deck!=s.own_deck or c.own_cards_burned!=s.own_cards_burned
                        for s,c in zip(states,children))
                    if changed and not revealed(children)[0]:
                        raise paid.UnknownMechanic('Library changed without a distinguishing retained draw; observation scope insufficient')
                    candidate=visit(children,prefix+[menus[0][key][0]])
                    if answer is None or tuple(candidate['worst_objective_vector'])>tuple(answer['worst_objective_vector']):answer=candidate
        memo[states]=answer;return answer
    try:
        unknown=[u for e in engines for u in e.unknown]
        if unknown:raise paid.UnknownMechanic('; '.join(unknown))
        best=visit(roots,[])
        oracles=[solve(i,s) for i,s in enumerate(roots)]
        worst=next(p['result'] for p in best['panel_payoffs'] if p['panel']==best['worst_panel'])
        base.update(complete_in_declared_scope=True,objective_vector=best['worst_objective_vector'],
            metrics=worst['metrics'],shared_prefix=best['shared_prefix'],observation_policy=best,
            per_prefix_payoffs=rows,perfect_information_oracles=[dict(panel=names[i],result=r) for i,r in enumerate(oracles)],
            oracle_minimum_vector=min(tuple(r['objective_vector']) for r in oracles))
    except (paid.UnknownMechanic,paid.board.SearchLimit) as error:base['unknown']=[str(error) or 'Search budget exhausted']
    base.update(visited_states=nodes,shared_cached_states=len(memo),continuation_cached_states=len(continuations))
    return base


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();result=evaluate(json.loads(args.input.read_text()))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(complete=result['complete_in_declared_scope'],objective_vector=result['objective_vector'],unknown=result['unknown'])))


if __name__=='__main__':main()