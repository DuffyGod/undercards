"""Independent exhaustive comparisons for newly executable source mechanisms."""
import unittest
import alpha_beta_search as alpha
import paid_board_tactics as paid
import score_cards
from test_alpha_beta_search import exhaustive,replay


class NewMechanicSearchTests(unittest.TestCase):
    def test_control_dust_and_compound_search_match_exhaustive(self):
        cards=score_cards.load_cards()
        scenes=[
            dict(hand_ids=[101],gold_before_play=5,own_player_hp=3,enemy_player_hp=3,
                ally_bodies_before_play=[dict(card_id=9,attack=3,health=1,max_health=1)],
                enemy_bodies=[dict(card_id=108,attack=3,health=6,max_health=6)]),
            dict(hand_ids=[583],gold_before_play=4,own_player_hp=7,
                enemy_bodies=[dict(card_id=15,attack=6,health=5),dict(card_id=196,attack=1,health=1)],
                opponent_hand_ids=[96],opponent_gold_before_response=3),
            dict(hand_ids=[21],gold_before_play=7,own_player_hp=2,
                enemy_bodies=[dict(card_id=15,attack=6,health=1,max_health=5),
                    dict(card_id=2,attack=2,health=1,max_health=3)]),
            dict(hand_ids=[650],gold_before_play=5,own_player_hp=5,
                enemy_bodies=[dict(card_id=15,attack=6,health=3,max_health=5),
                    dict(card_id=196,attack=1,health=1)]),
            dict(hand_ids=[217],gold_before_play=4,own_player_hp=3,enemy_player_hp=3,
                ally_bodies_before_play=[dict(card_id=1,attack=0,health=4)],enemy_bodies=[]),
        ]
        for data in scenes:
            scene=dict(data,horizon='enemy_attack',max_plays=1,own_dustpile_monsters=[])
            for mode in ('guaranteed_hp','control','race'):
                with self.subTest(card=data['hand_ids'][0],mode=mode):
                    reference=paid.PaidSearch(cards,scene)
                    vector,_=exhaustive(reference,reference.root(),mode)
                    engine=paid.PaidSearch(cards,scene)
                    result=alpha.solve(engine,engine.root(),mode)
                    self.assertTrue(result['search_complete'],result.get('unknown'))
                    self.assertEqual(result['objective_vector'],vector)
                    replay(engine,engine.root(),result,mode)


if __name__=='__main__':unittest.main()