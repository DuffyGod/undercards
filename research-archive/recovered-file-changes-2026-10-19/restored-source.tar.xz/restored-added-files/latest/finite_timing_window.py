"""Observed actions through one absolute endpoint, rather than rolling quotes.

This is a bounded one-candidate combat subgame, not a match simulator. Cash and
damage are carried as physical state; only the final remaining bodies receive
F. A supplied opponent menu is a stress test, not a model of rational play.
"""
from __future__ import annotations

import copy
import json
import math
import re

import action_outcomes as actions
import combat_increment as combat
import context_value as ledger
import heuristic_contexts as contexts
import score_cards as prices
import timing_policy
import turn_end_effects as ending

VERSION = 'absolute-endpoint-action-window-0.1.0'
LIMITATIONS = [
    'One candidate and at most four primitive enemies; no other own plays or active allies.',
    'Own Haste attacks monsters only on deployment; later ordinary attacks may hit the hero.',
    'Opponent menus use strongest-first attacks; min is adversarial stress on OUR resource objective, not calibrated opponent strategy.',
    'Initial opposing bodies persist; no future enemy summons, artifacts, souls or hidden card identities.',
    'Remaining-body F, HP weights, cash retention and draw option priors are normative, not measured win value.',
    'Silence removes positive fresh modifiers under the existing assumption; injured HP reset is unknown.',
    'A terminal player outcome is an unknown Gold leaf; consult life outcomes instead.',
    'Fixed endpoint scores must only be compared at the same horizon, initial state and scale.',
    'Waiting cost is actual extra burned draws; background hand cards have no assumed free plays.',
]


def _number(x, name, low=0):
    if type(x) not in (int, float) or not math.isfinite(x) or x < low:
        raise ValueError(name + ' must be finite and >= ' + str(low))
    return x


def _integer(x, name, low=0, high=None):
    if type(x) is not int or x < low or (high is not None and x > high):
        raise ValueError(name + ' outside declared integer domain')
    return x


def _tick(turn, second):
    return 2 * turn - int(not second)


def _clean(s):
    s = copy.deepcopy(s)
    s['log'] = []
    if combat.terminal(s):
        s['terminal'] = True
    return s


def _key(s):
    return json.dumps(s, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _parts(s, reference, role, scale):
    raw = combat.utility_components(s, reference, role)
    raw.pop('opponent_cash_utility')
    return {**{k: v * scale for k, v in raw.items()},
            'retained_own_cash': s['own_gold'],
            'retained_draw_options': s['draw_options']}


class Window:
    def __init__(self, card, reference, scale, scenario):
        self.card, self.reference, self.scale = copy.deepcopy(card), reference, _number(scale, 'scale')
        self.scenario = copy.deepcopy(scenario)
        self.role = scenario.get('role', 'midrange')
        if self.role not in prices.ROLE_PARAMETERS:
            raise ValueError('Unknown role')
        self.second = scenario.get('second_player', False)
        if type(self.second) is not bool:
            raise ValueError('second_player must be boolean')
        self.start_turn = _integer(scenario['own_turn'], 'own_turn', 1)
        self.horizon = _integer(scenario['horizon_tick'], 'horizon_tick', _tick(self.start_turn, self.second))
        self.arrival = _integer(scenario.get('arrival_own_turn', self.start_turn), 'arrival_own_turn', self.start_turn)
        if self.arrival != self.start_turn:
            raise ValueError('Candidate is already drawn at the root; shift own_turn to compare later arrival')
        self.draws = _integer(scenario.get('natural_draw_count', 0), 'natural_draw_count')
        self.draw_value = _number(scenario.get('draw_option_value_model_gold', .6), 'draw option value')
        if scenario.get('random_no_target_policy', 'unknown') not in ('unknown', 'fizzle_assumed'):
            raise ValueError('Unknown no-target random-damage policy')
        self.response_mode = scenario.get('response_mode', 'chance')
        if self.response_mode not in ('chance', 'min'):
            raise ValueError('response_mode must be chance or min')
        self.responses = scenario.get('responses', {'enemy_face': 1.})
        if not isinstance(self.responses, dict) or not self.responses:
            raise ValueError('Declare nonempty opponent response menu')
        supported = {'none', 'enemy_face', 'enemy_contact', 'chip', 'silence'} | combat.COMPOUND_RESPONSES
        if set(self.responses) - supported:
            raise ValueError('Unclosed response event')
        if self.response_mode == 'chance':
            for p in self.responses.values():
                _number(p, 'probability')
            if abs(sum(self.responses.values()) - 1) > 1e-9:
                raise ValueError('Response probabilities must sum to one')
        self.responses_by_tick = scenario.get('responses_by_tick', {})
        for tick, menu in self.responses_by_tick.items():
            if not str(tick).isdigit() or not isinstance(menu, dict) or not menu or set(menu) - supported:
                raise ValueError('Invalid dated opponent menu')
            if self.response_mode == 'chance':
                for p in menu.values():
                    _number(p, 'probability')
                if abs(sum(menu.values()) - 1) > 1e-9:
                    raise ValueError('Dated response probabilities must sum to one')
        _number(card['cost'], 'cost')
        _number(card['attack'], 'attack')
        _number(card['health'], 'health', 1)
        growth = re.fullmatch(r'Turn start: Gain \+(\d+) (ATK|HP)\.', card['effect_readable'])
        self.growth = (growth[2], int(growth[1])) if growth else None
        self.binding_card = copy.deepcopy(card)
        if growth:
            self.binding_card['effect_readable'] = ''
        parsed_end = ending.compile(card)
        self.callback = parsed_end['callback'] if parsed_end['known'] else None
        if self.callback:
            # Binding current Haste is independent of a later callback. The
            # shared action source must not run or optimize that future here.
            words = {'haste': 'Haste', 'armor': 'Armor', 'taunt': 'Taunt'}
            self.binding_card['effect_readable'] = ' '.join(
                ('Dodge (' + str(v) + ')' if k == 'dodge' else words[k]) + '.'
                for k, v in parsed_end['statuses'].items())
        # Future discounts need actual matching hand identities and payments.
        # This subgame does not invent those actions.
        self.unsupported = ['Future hand discount payments are outside this subgame'] if 'Dust: Give' in card['effect_readable'] else []

    def root(self, absent=False):
        q = self.scenario
        enemies = q.get('enemy_bodies', [])
        if not isinstance(enemies, list) or len(enemies) > 4:
            raise ValueError('At most four primitive enemy bodies')
        for enemy in enemies:
            _number(enemy['attack'], 'enemy attack')
            _number(enemy['health'], 'enemy health', 1)
            if set(enemy) - {'attack', 'health', 'armor', 'dodge', 'taunt'}:
                raise ValueError('Only primitive enemy stats and statuses are supported')
        own_hp = _number(q.get('own_player_hp', 30), 'own HP', 1)
        enemy_hp = _number(q.get('enemy_player_hp', 30), 'enemy HP', 1)
        s = combat.state(0, 0, enemies, {}, _number(q.get('opponent_gold', 0), 'opponent Gold'), own_hp, enemy_hp)
        hand = _integer(q.get('initial_hand_size', 1), 'initial hand size', 1, 7)
        s.update(tick=_tick(self.start_turn, self.second), step=0, turn=self.start_turn, phase='own',
                 held=not absent, deployed=False, absent=absent, ready=False, attacked=False,
                 own_gold=_number(q.get('gold_before_play', 12), 'own Gold'),
                 own_hand_size=hand - int(absent),
                 own_deck_available=_integer(q.get('own_deck_available', 20), 'deck size'),
                 own_fatigue_next=q.get('own_fatigue_next'),
                 opponent_hand_size=_integer(q.get('opponent_hand_size', 4), 'opponent hand', 0, 7),
                 opponent_deck_available=_integer(q.get('opponent_deck_available', 20), 'opponent deck'),
                 opponent_fatigue_next=q.get('opponent_fatigue_next'),
                 own_player_max_hp=_number(q.get('own_player_max_hp', own_hp), 'max HP', own_hp),
                 draw_options=0., actual_paid=0., deployment_turn=None,
                 growth_count=0, callback_count=0, source_death_tick=None)
        return s

    def child(self, s, phase, tick=None, **changes):
        out = _clean(s)
        out.update(phase=phase, tick=s['tick'] if tick is None else tick, step=s['step'] + 1, **changes)
        if phase == 'unknown' or combat.terminal(out):
            out['terminal'] = True
        return out

    def leaf(self, s, reasons=None):
        if reasons:
            if not s.get('terminal'):
                return {'kind': 'chance', 'branches': [{'action_id': 'unclosed', 'probability': 1.,
                    'child_state': self.child(s, 'unknown', reason=reasons)}]}
            return {'kind': 'leaf', 'unknown': reasons}
        return {'kind': 'leaf', 'value': _parts(s, self.reference, self.role, self.scale)}

    def deploy_options(self, s):
        if self.unsupported:
            return [{'action_id': 'deploy_unknown', 'child_state': self.child(s, 'unknown', reason=self.unsupported)}]
        condition_state = copy.deepcopy(self.scenario.get('condition_state', {}))
        if s['turn'] > self.start_turn:
            # This subgame has no other own plays. Last turn's spell spend
            # cannot persist as an indefinitely favorable historical fact.
            condition_state['last_turn_gold_spent_on_spells'] = 0
        draw_state = copy.deepcopy(ledger.DEFAULT_DRAW_STATE)
        for key in ('own_deck_available', 'own_fatigue_next', 'opponent_hand_size',
                    'opponent_deck_available', 'opponent_fatigue_next'):
            draw_state[key] = s[key]
        ctx = dict(role=self.role, gold_before_play=s['own_gold'],
                   opponent_gold_before_response=s['enemy_gold'],
                   own_player_hp=s['own_player_hp'], enemy_player_hp=s['enemy_player_hp'],
                   own_player_max_hp=s['own_player_max_hp'],
                   enemy_bodies=[{k: v for k, v in e.items() if k != 'id'} for e in s['enemies'] if e['health'] > 0],
                   ally_bodies_before_play=[], reply_policy='candidate_only',
                   hand_size_after_play=s['own_hand_size'] - 1,
                   own_deck_available=s['own_deck_available'],
                   draw_state_assumptions=draw_state,
                   condition_state=condition_state)
        bound = actions.evaluate(self.binding_card, ctx, self.reference, {'none': 1.})
        unknown = bound['window_unknown']
        if unknown:
            return [{'action_id': 'deploy_unknown', 'child_state': self.child(s, 'unknown', reason=unknown)}]
        branches = []
        for action in bound['actions']:
            # Source binds current Magic and Haste only. Its later reply and
            # ordinary attack are discarded; our common timeline owns them.
            current = action['paths'][0]['after_current']['state']
            out = self.child(s, 'end', held=False, deployed=True, ready=False,
                             attacked=not action['action_id'].endswith('delay'),
                             deployment_turn=s['turn'], actual_paid=s['actual_paid'] + self.card['cost'])
            for field in ('actor', 'enemies', 'own_player_hp', 'enemy_player_hp', 'enemy_gold', 'own_gold'):
                out[field] = copy.deepcopy(current[field])
            out['hp_delta'] += current['hp_delta']
            out['enemy_hp_delta'] += current['enemy_hp_delta']
            out['own_attacks'] += current['own_attacks']
            out['own_hand_size'] = current.get('own_hand_size', s['own_hand_size'] - 1)
            out['own_deck_available'] = current.get('own_deck_available', s['own_deck_available'])
            for key in ('own_fatigue_next', 'opponent_hand_size', 'opponent_deck_available', 'opponent_fatigue_next'):
                out[key] = current.get(key, s[key])
            for event in current['log']:
                if event.get('event') == 'current_magic_draw':
                    for row in event['players']:
                        out['draw_options'] += (row['kept'] * self.draw_value if row['player'] == 'own'
                            else -row['retained_net_options_model_gold'])
            out['actor']['has_ordinary_ability'] = bool(self.growth or self.callback or out['actor'].get('dust_modules'))
            if out['actor']['health'] <= 0:
                out['source_death_tick'] = s['tick']
            branches.append({'action_id': 'deploy:' + action['action_id'], 'child_state': out})
        if not branches:
            raise ValueError('Legal deployment has no closed current actions')
        return branches

    def expand(self, s):
        if combat.terminal(s):
            return self.leaf(s, ['Player terminal state cannot be assigned resource Gold'])
        phase = s['phase']
        if phase == 'unknown':
            return self.leaf(s, s['reason'])
        if phase == 'leaf':
            return self.leaf(s)
        if phase == 'own':
            branches = [{'action_id': 'hold' if s['held'] else 'no_attack', 'child_state': self.child(s, 'end', attacked=False)}]
            if s['held'] and s['turn'] >= self.arrival and s['own_gold'] >= self.card['cost']:
                branches += self.deploy_options(s)
            if s['step'] == 0 and self.scenario.get('force_root_deployment') and not s['absent']:
                branches = [b for b in branches if b['action_id'].startswith('deploy')]
                if not branches:
                    raise ValueError('Forced deployment must be legal and payable at the root')
            if s['ready'] and s['actor']['health'] > 0 and s['actor']['attack'] > 0:
                for target in combat.legal_own_targets(s):
                    out = self.child(s, 'end', attacked=True, ready=False)
                    before = out['actor']['health']
                    combat.trade(out, target)
                    actions._dust_event(out, before, 'ordinary_own')
                    if out['actor']['health'] <= 0:
                        out['source_death_tick'] = s['tick']
                    branches.append({'action_id': 'attack:' + str(target), 'child_state': _clean(out)})
                if not any(e.get('taunt') and e['health'] > 0 for e in s['enemies']):
                    out = self.child(s, 'end', attacked=True, ready=False)
                    damage = min(out['enemy_player_hp'], out['actor']['attack'])
                    out['enemy_player_hp'] -= damage
                    out['enemy_hp_delta'] -= damage
                    out['own_attacks'] += 1
                    branches.append({'action_id': 'attack:face', 'child_state': out})
            return {'kind': 'max', 'branches': branches}
        if phase == 'end':
            next_phase = 'leaf' if s['tick'] == self.horizon else 'opponent'
            next_tick = s['tick'] if next_phase == 'leaf' else s['tick'] + 1
            if self.callback and s['deployed']:
                before_hand = s['own_hand_size']
                callback_state = _clean(s)
                if callback_state['own_fatigue_next'] is None:
                    # The primitive uses a missing field to mean unknown;
                    # present None is not a valid declared damage integer.
                    callback_state.pop('own_fatigue_next')
                if (self.callback['kind'] == 'random_enemy_damage' and s['actor']['health'] > 0
                    and not s['actor'].get('silenced') and not s['attacked']
                    and not any(e['health'] > 0 for e in s['enemies'])
                    and self.scenario.get('random_no_target_policy') == 'fizzle_assumed'):
                    return {'kind': 'chance', 'branches': [{'action_id': 'caller_assumed_no_target_fizzle',
                        'probability': 1., 'child_state': self.child(s, next_phase, next_tick)}]}
                if self.scenario.get('random_target_policy') == 'uniform_declared':
                    live = [e for e in s['enemies'] if e['health'] > 0]
                    if live:
                        callback_state['turn_end_random_target_weights'] = [
                            {'target_id': e['id'], 'weight': 1 / len(live)} for e in live]
                result = ending.apply(self.card, callback_state, s['attacked'], self.reference)
                if not result['known']:
                    return self.leaf(s, result['unknown'])
                states = [(1., result['state'])] if result['state'] is not None else [(b['weight'], b['state']) for b in result['branches']]
                branches = []
                for index, (p, out) in enumerate(states):
                    out.setdefault('own_fatigue_next', s['own_fatigue_next'])
                    out = self.child(out, next_phase, next_tick)
                    out['callback_count'] += int(bool(result['trace'] and result['trace'][0].get('event') == 'ordinary_owner_turn_end'))
                    out['draw_options'] += max(0, out['own_hand_size'] - before_hand) * self.draw_value
                    branches.append({'action_id': 'turn_end:' + str(index), 'probability': p, 'child_state': out})
                return {'kind': 'chance', 'branches': branches}
            return {'kind': 'chance', 'branches': [{'action_id': 'end', 'probability': 1., 'child_state': self.child(s, next_phase, next_tick)}]}
        if phase == 'opponent':
            branches = []
            for event, p in self.responses_by_tick.get(str(s['tick']), self.responses_by_tick.get(s['tick'], self.responses)).items():
                if self.response_mode == 'chance' and p == 0:
                    continue
                out = self.child(s, 'leaf' if s['tick'] == self.horizon else 'start')
                before = out['actor']['health']
                try:
                    actions._reply(out, event, {'reply_policy': 'candidate_only'})
                except ValueError as exc:
                    out.update(phase='unknown', reason=[str(exc)])
                if before > 0 and out['actor']['health'] <= 0:
                    out['source_death_tick'] = s['tick']
                branch = {'action_id': event, 'child_state': _clean(out)}
                if self.response_mode == 'chance':
                    branch['probability'] = p
                branches.append(branch)
            return {'kind': self.response_mode, 'branches': branches}
        if phase == 'start':
            out = self.child(s, 'own', s['tick'] + 1, turn=s['turn'] + 1, attacked=False)
            out['own_gold'] += contexts.base_income(out['turn'], self.second)
            from_deck = min(out['own_deck_available'], self.draws)
            empty = self.draws - from_deck
            if empty:
                if out['own_fatigue_next'] is None:
                    return self.leaf(s, ['Future natural draw reaches undeclared fatigue/depletion'])
                fatigue = _integer(out['own_fatigue_next'], 'fatigue next', 1)
                damage = min(out['own_player_hp'], sum(range(fatigue, fatigue + empty)))
                out['own_player_hp'] -= damage
                out['hp_delta'] -= damage
                out['own_fatigue_next'] += empty
            kept = min(from_deck, 7 - out['own_hand_size'])
            out['own_deck_available'] -= from_deck
            out['own_hand_size'] += kept
            out['draw_options'] += kept * self.draw_value
            if combat.terminal(out):
                out['ready'] = False
                return {'kind': 'chance', 'branches': [{'action_id': 'terminal_own_start',
                    'probability': 1., 'child_state': _clean(out)}]}
            actor = out['actor']
            out['ready'] = out['deployed'] and actor['health'] > 0
            if self.growth and out['ready'] and not actor.get('silenced'):
                stat, amount = self.growth
                key = 'attack' if stat == 'ATK' else 'health'
                actor[key] += amount
                actor['modifier'][key] += amount
                if stat == 'HP':
                    actor['max_hp'] += amount
                out['growth_count'] += 1
            return {'kind': 'chance', 'branches': [{'action_id': 'own_start', 'probability': 1., 'child_state': _clean(out)}]}
        raise ValueError('Unknown action phase ' + phase)

    def solve(self, absent=False):
        return timing_policy.evaluate(self.root(absent), horizon_tick=self.horizon, expand=self.expand, state_key=_key)


def evaluate(card, reference, scale, scenario, *, include_policy=False):
    window = Window(card, reference, scale, scenario)
    actual, absent = window.solve(), window.solve(True)
    a, b = actual['value_model_gold'], absent['value_model_gold']
    result = dict(version=VERSION, card_id=card['id'], name=card['name'],
                  horizon_tick=window.horizon, scenario=copy.deepcopy(scenario),
                  pricing_supported=a is not None and b is not None,
                  absolute_endpoint_option_model_gold=None if a is None or b is None else a - b,
                  actual_value_model_gold=a, absent_value_model_gold=b,
                  actual=actual, absent=absent, limitations=LIMITATIONS)
    result['reliability'] = dict(
        mechanics='Executable bounded transitions; caller observations and listed semantic assumptions apply',
        probability_source='Declared scenario; no sampled match frequency',
        numerical_calibration='Uncalibrated residual/HP/option priors; no win-rate confidence',
        opponent_min_meaning='Difference of two separately stressed endpoint utilities; not a guaranteed lower bound on paired incremental advantage')
    if not include_policy:
        for branch in ('actual', 'absent'):
            result[branch] = {k: v for k, v in result[branch].items() if k != 'policy'}
    return result