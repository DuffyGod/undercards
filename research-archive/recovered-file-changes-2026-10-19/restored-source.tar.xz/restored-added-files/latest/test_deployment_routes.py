import unittest
import deployment_routes as routes
import evaluate_situation as situation
import score_cards as base


def probe(hand,cash=8):
    return dict(hand_ids=hand,role='midrange',own_turn=5,gold_before_play=cash,
        opponent_gold_before_response=0,own_player_hp=8,enemy_player_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[dict(attack=6,health=6),dict(attack=3,health=3)],
        condition_state={'last_turn_gold_spent_on_spells':0},response_weights={'enemy_face':1})


class SharedRoutesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards=base.load_cards();cls.by_id={c['id']:c for c in cls.cards}
        cls.ref,_=base.make_reference(cls.cards)

    def run_routes(self,data):
        ctx,_=situation.make_state(data)
        return routes.evaluate([self.by_id[i] for i in data['hand_ids']],ctx,self.ref)

    def test_duplicate_copies_share_actual_payment_and_are_distinct_hand_objects(self):
        r=self.run_routes(probe([438,438]))
        pairs=[x for x in r['routes'] if len(x['steps'])==2]
        self.assertTrue(pairs)
        for x in pairs:
            self.assertEqual(x['actual_paid_gold'],8)
            self.assertEqual(x['gold_remaining'],0)
            self.assertEqual(len({s['hand_index'] for s in x['steps']}),2)
            self.assertIsNone(x['model_gold'])

    def test_insufficient_total_gold_never_creates_a_combo(self):
        r=self.run_routes(probe([438,438],7))
        self.assertFalse(any(len(x['steps'])==2 for x in r['routes']))

    def test_spell_income_can_legally_unlock_a_monster(self):
        r=self.run_routes(probe([81,438],3))
        unlocked=[x for x in r['routes'] if [s['card_id'] for s in x['steps']]==[81,438]]
        self.assertTrue(unlocked)
        self.assertTrue(all(x['gold_remaining']==0 for x in unlocked))
        self.assertFalse(any([s['card_id'] for s in x['steps']]==[438,81] for x in r['routes']))

    def test_future_need_does_not_change_after_casting_current_spell(self):
        r=self.run_routes(probe([81,582],4))
        self.assertTrue(any(len(x['steps'])==2 for x in r['routes']))
        self.assertTrue(all(x['death_probability']==1 for x in r['routes']))

    def test_full_board_keeps_spells_and_blocks_monster_routes(self):
        data=probe([76,15],8)
        data.update(own_player_hp=30,enemy_bodies=[],ally_bodies_before_play=[dict(attack=2,health=3) for _ in range(4)])
        r=self.run_routes(data)
        self.assertTrue(r['routes'])
        self.assertTrue(all(all(s['card_id']==76 for s in x['steps']) for x in r['routes']))

    def test_first_magic_draw_cannot_restore_library_before_second_play(self):
        data=probe([243,81],5)
        data.update(own_player_hp=1,enemy_bodies=[],response_weights={'none':1},
            draw_state={'own_deck_available':1,'own_fatigue_next':1})
        r=self.run_routes(data)
        pairs=[x for x in r['routes'] if [s['card_id'] for s in x['steps']]==[243,81]]
        self.assertTrue(pairs)
        # Bench uses the final card now. Fortune gives cash, but does not
        # prevent the compulsory next draw from dealing lethal fatigue.
        self.assertTrue(all(x['death_probability']==1 for x in pairs))
        self.assertTrue(all(x['actual_paid_gold']==5 for x in pairs))


if __name__=='__main__':unittest.main()