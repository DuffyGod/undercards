"""Conditional carrying value from real card quotes and an opportunity tree.

This is a single drawn deck-slot comparison, not a deck recommendation inferred
from synthetic frequency weights. Each replacement is fixed before the future
observations; both alternatives have the same observed-state opportunity tree.
"""
import copy
import math
from functools import lru_cache

import board_response
import carry_option
import combat_increment as combat
import joint_window_quote as joint
import spell_window
import score_cards as base

VERSION='conditional-construction-option-0.2.0'


def evaluate_cards(cards,reference,scale,scenario,state_builder,root_context=None):
    by=carry_option.validate(scenario)
    contexts={}
    for n in by.values():
        if 'observation' in n:
            ctx,_=state_builder(n['observation'])
        elif n['id']==scenario['root_id'] and root_context is not None:
            ctx=copy.deepcopy(root_context)
        else:raise ValueError('Every future node needs an independent complete observation')
        if ctx['own_turn']!=n['own_turn']:raise ValueError('Opportunity turn and observation turn disagree')
        # Carrying occupancy is tracked by the option tree. Including natural
        # draw slot release again in a local deployment quote would double it.
        ctx.update(resolve_next_own_start=False,next_draw_count=0,utility_scale=scale)
        contexts[n['id']]=ctx
    if len({c['role'] for c in contexts.values()})!=1:
        raise ValueError('One construction comparison requires one shared role')
    options=[];cache={}
    @lru_cache(None)
    def remaining_declared_draws(node_id):
        return max((e['cards_from_deck']+remaining_declared_draws(e['child_id'])
            for e in by[node_id].get('transitions',[]) if e['probability']>0),default=0)
    def quote(card,node,hand_size):
        key=(card['id'],card['cost'],card.get('attack'),card.get('health'),card['effect_readable'],node['id'],hand_size)
        if key in cache:return cache[key]
        ctx=copy.deepcopy(contexts[node['id']])
        ctx.update(hand_size_before_play=hand_size,hand_size_after_play=hand_size-1)
        legal=(card['cost']<=ctx['gold_before_play'] and
            (card['card_type']=='spell' or len(ctx['ally_bodies_before_play'])<4))
        q=(spell_window.evaluate(card,ctx,reference,ctx['growth_response_weights'],scale=scale)
            if card['card_type']=='spell' else joint.evaluate(card,ctx,reference,scale,ctx['growth_response_weights'],include_trace=True)) if legal else None
        net=q.get('model_gold') if card['card_type']=='spell' and q else q.get('net_margin_model_gold') if q else None
        result=dict(legal=legal,known=net is not None,net_model_gold=net,paid_gold=card['cost'] if legal else 0.,
            unknown=q.get('unknown',q.get('window_unknown',[])) if q else [],
            outcome_summary=q.get('outcome_summary') if q else None)
        if net is not None and card['card_type']=='monster':
            actual=q['worlds']['actual_card'];chosen=actual['best'];actions=[]
            def value(action):
                cash=math.fsum(o['probability']*math.fsum(o['components'].get(k,0.) for k in (
                    'own_callback_cash_model_gold','realized_dust_discount_model_gold',
                    'retained_draw_net_options_model_gold','retained_natural_draw_options_model_gold')) for o in action['outcomes'])
                return scale*(action['expected']-cash)+cash
            for action in actual['actions']:
                if not action['known'] or any(o['terminal'] for o in action['outcomes'] if o['probability']>0):continue
                hands={o['state'].get('own_hand_size',hand_size-1) for o in action['outcomes'] if o['probability']>0}
                if len(hands)!=1:
                    result.update(known=False,net_model_gold=None,
                        unknown=['Random post-deployment hand sizes require a joint future-opportunity law'])
                    break
                if any('own_deck_available' in o['state'] and
                        o['state']['own_deck_available']<remaining_declared_draws(node['id'])
                        for o in action['outcomes'] if o['probability']>0):
                    result.update(known=False,net_model_gold=None,
                        unknown=['Current Magic draw can deplete the future declared draw stream; depletion/fatigue and action-dependent future observations are not closed'])
                    break
                post=next(iter(hands))
                role_prior=base.role_parameters(ctx['role'])
                prior_change=scenario['draw_option_value_model_gold']-role_prior['draw_value']*role_prior['future_draw_use']
                # Closed own Draw is the only supported hand-size increase in
                # this quote family. The same card quality prior must value
                # current Magic retention and future displaced retention.
                retained=post-(hand_size-1)
                actions.append(dict(action_id=action['plan'],net_model_gold=net+value(action)-value(chosen)+prior_change*retained,
                    post_hand_size=post,paid_gold=card['cost']))
            result['actions']=actions
            if result['known'] and actions:result['net_model_gold']=max(a['net_model_gold'] for a in actions)
        elif net is not None:
            result['actions']=[dict(action_id='cast',net_model_gold=net,post_hand_size=hand_size-1,paid_gold=card['cost'])]
        cache[key]=result
        return result
    # A resource carrying option cannot price dying while waiting as zero.
    # Validate only positive-probability reachable observations.
    reachable=set()
    def visit(i):
        if i in reachable:return
        reachable.add(i)
        for e in by[i].get('transitions',[]):
            if e['probability']>0:visit(e['child_id'])
    visit(scenario['root_id'])
    unsafe=[]
    for i in sorted(reachable):
        ctx=contexts[i]
        for event,mass in ctx['growth_response_weights'].items():
            if mass<=0:continue
            raw=combat.state(0,0,ctx['enemy_bodies'],{},ctx['opponent_gold_before_response'],
                ctx['own_player_hp'],ctx['enemy_player_hp'],ctx.get('enemy_attack_limit',4))
            raw['external_allies']=copy.deepcopy(ctx['ally_bodies_before_play'])
            try:
                board_response.reply(raw,event)
                if combat.terminal(raw):unsafe.append(dict(node_id=i,event=event,reason='No-play response is terminal; use the separate survival axis'))
            except ValueError as exc:unsafe.append(dict(node_id=i,event=event,reason=str(exc)))
    for card in cards:
        if unsafe:
            option=dict(pricing_supported=False,option_value_model_gold=None,value_bounds_model_gold=[None,None],
                unknown=copy.deepcopy(unsafe),policy=[],policy_statistics_are_optimal=False)
        else:
            option=carry_option.evaluate(scenario,lambda node,h:quote(card,node,h))
        # An unsafe no-card comparator prevents finite Gold, but does not
        # erase a verified current rescue. Keep this local life policy outside
        # the multi-node carrying objective and do not price death in Gold.
        root_life=None
        if unsafe and card['card_type']=='monster':
            local=quote(card,by[scenario['root_id']],scenario['initial_hand_size'])
            summary=local.get('outcome_summary') or {}
            actual=summary.get('actual_card',{});absent=summary.get('absent',{})
            play_death=actual.get('death_probability');hold_death=absent.get('death_probability')
            reduces=(local['legal'] and play_death is not None and hold_death is not None and
                     play_death<hold_death)
            root_life=dict(deployment_legal_now=local['legal'],
                hold_death_probability=hold_death,deploy_death_probability=play_death,
                selected_current_plan=actual.get('selected_current_plan'),
                current_rescue=reduces,
                known_feasible_action='deploy_now_for_survival' if reduces else None,
                scope='One current deployment/response window only; this is not an optimal multi-turn life policy or a finite Gold value.')
        options.append(dict(option_key=card.get('construction_option_key',str(card['id'])),
            card_id=card['id'],name=card['name'],nominal_cost=card['cost'],**option))
        if root_life is not None:options[-1]['root_life_policy']=root_life
    return dict(version=VERSION,scale=scale,scenario=copy.deepcopy(scenario),cards=options,
        quote_scope='One local deployment window net of actual mana, with next natural draw excluded; holding capacity is priced once in the opportunity tree.',
        assumptions=[
            'These are conditional values for one already-drawn deck slot, not occurrence probabilities, full card lifetimes or calibrated deck win rates.',
            'Each node is observed before choosing deploy/wait. Future observations/Gold/conditions/background plays are explicit scenario inputs.',
            'After deploying the slot, its local closed quote is collected once. Subsequent action-dependent game states are not rolled out.',
            'An unused card pays no mana. Its construction disadvantage is the replacement opportunity and declared carrying cost.',
            'The no-card reference starts with one empty hand slot; accumulated capacity and common plays persist across waiting nodes.',
            'Local quotes do not resolve next natural draw: capacity loss from the same draw cannot also be added as deployment credit.',
            'The declared own draw-option quality prices both immediate Magic draws and the same future retained/displaced cards.',
            'If Magic draw can deplete the declared future draw stream, carrying pricing stays unknown rather than restoring spent library cards or suppressing future fatigue.',
            'Lethal no-play scenes are not resource-priced; use the current life/route axis. Unknown legal card mechanisms keep an unbounded upper interval.',
            'Future draw identities, companion tactics and per-card future cost changes are not inferred; this is a finite opportunity model.'])


def compare(result,candidate_ids,replacement_ids):
    by={c['option_key']:c for c in result['cards']}
    pairs=[]
    for cid in candidate_ids:
        for rid in replacement_ids:
            a,b=by[str(cid)],by[str(rid)];alo,ahi=a['value_bounds_model_gold'];blo,bhi=b['value_bounds_model_gold']
            lower=alo-bhi if alo is not None and bhi is not None else None
            upper=ahi-blo if ahi is not None and blo is not None else None
            verdict=(True if lower is not None and lower>1e-10 else
                False if upper is not None and upper<=1e-10 else None)
            known=a['pricing_supported'] and b['pricing_supported']
            pairs.append(dict(candidate_id=a['card_id'],replacement_id=b['card_id'],
                candidate_option_key=a['option_key'],replacement_option_key=b['option_key'],
                advantage_model_gold=a['option_value_model_gold']-b['option_value_model_gold'] if known else None,
                advantage_bounds_model_gold=[lower,upper],
                worth_carrying_under_declared_scenario=verdict,
                criterion='Compare ex ante slot options with the same future observations; do not choose a different replacement after seeing the board.'))
    return pairs


def mixture_frontier(base_scenario,candidate,replacement,quote_at,probability_child_id,tolerance=1e-8):
    """Vary one binary root probability; keep observed rewards and costs fixed.

    quote_at(card,node,hand_size) is a reusable fixed quote cache. The binary
    root gives each card a maximum of affine deploy/capacity and wait values.
    Inspect their breakpoints instead of assuming monotonic advantage.
    """
    by=carry_option.validate(base_scenario)
    root=by[base_scenario['root_id']]
    edges=root.get('transitions',[])
    if len(edges)!=2 or probability_child_id not in {e['child_id'] for e in edges}:
        raise ValueError('A binary observed-next-opportunity mixture is required')
    def options_at(p):
        tree=copy.deepcopy(base_scenario)
        for edge in next(n for n in tree['nodes'] if n['id']==tree['root_id'])['transitions']:
            edge['probability']=p if edge['child_id']==probability_child_id else 1-p
        a=carry_option.evaluate(tree,lambda n,h:quote_at(candidate,n,h))
        b=carry_option.evaluate(tree,lambda n,h:quote_at(replacement,n,h))
        return a,b
    def values(p):
        a,b=options_at(p)
        return (a['option_value_model_gold']-b['option_value_model_gold']) if a['pricing_supported'] and b['pricing_supported'] else None
    grid=[dict(probability=i/100,advantage_model_gold=values(i/100)) for i in range(101)]
    all_known=all(g['advantage_model_gold'] is not None for g in grid)
    crossings=[];intervals=[];envelopes=[];knots={0.,1.}
    if all_known:
        endpoints=[options_at(0),options_at(1)]
        for index,card in enumerate((candidate,replacement)):
            roots=[next(n for n in pair[index]['policy'] if n['node_id']==base_scenario['root_id']) for pair in endpoints]
            w0,w1=[r['known_wait_value_model_gold'] for r in roots]
            alternatives=[{a['action_id']:a['full_value_model_gold'] for a in r['deployment_alternatives']} for r in roots]
            if set(alternatives[0])!=set(alternatives[1]):raise ValueError('Root actions must be fixed before changing probability')
            lines=[dict(action_id='wait',at_zero=w0,at_one=w1)]+[
                dict(action_id=i,at_zero=alternatives[0][i],at_one=alternatives[1][i]) for i in alternatives[0]]
            envelopes.append(dict(card_id=card['id'],affine_root_actions=lines))
            for k,line in enumerate(lines):
                for other in lines[k+1:]:
                    a=line['at_zero']-other['at_zero'];b=line['at_one']-other['at_one']
                    if abs(b-a)>1e-12:
                        kink=-a/(b-a)
                        if 0<kink<1:knots.add(kink)
        original=sorted(knots)
        for lo,hi in zip(original,original[1:]):
            a,b=values(lo),values(hi)
            if (a>1e-10)!=(b>1e-10) and abs(b-a)>1e-12:
                zero=max(lo,min(hi,lo-a*(hi-lo)/(b-a)))
                knots.add(zero)
                crossings.append(dict(probability=zero,
                    probability_interval=[max(0.,zero-tolerance),min(1.,zero+tolerance)],
                    entering_candidate_preferred=b>a))
        split=sorted(knots)
        for lo,hi in zip(split,split[1:]):
            if values((lo+hi)/2)>1e-10:
                entry=dict(lower=lo,upper=hi,include_lower=values(lo)>1e-10,include_upper=values(hi)>1e-10)
                if intervals and math.isclose(intervals[-1]['upper'],lo,abs_tol=1e-10) and entry['include_lower']:
                    intervals[-1].update(upper=hi,include_upper=entry['include_upper'])
                else:intervals.append(entry)
    return dict(candidate_id=candidate['id'],replacement_id=replacement['id'],
        varied_child_id=probability_child_id,grid=grid,crossings=crossings,
        profitable_probability_intervals=intervals,root_envelopes=envelopes,
        all_grid_values_known=all_known,
        grid_advantage_nondecreasing=(all(b['advantage_model_gold']>=a['advantage_model_gold']-1e-10 for a,b in zip(grid,grid[1:]))
            if all_known else None),
        assumption='Conditional crossing on this declared tree and local Gold standard; probabilities have not been calibrated to decks or matches.')