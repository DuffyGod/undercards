"""Actual production scores for position-constrained Switch and Dodge decay."""
import copy
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import conditional_card_score as score
import paid_board_tactics as paid
import evaluate_situation as api
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/nine-cost-v01'
PILOT=HERE/'research-runs/choice-magic-v01'
TASKS=dict(clear=dict(kind='joint',constraints=dict(max_enemy_living_count=0)),
    body_2_2=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=2,min_own_body_health=2)),
    body_2_3=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=2,min_own_body_health=3)),
    body_2_4=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=2,min_own_body_health=4)))


def fixtures():
    index=json.loads((PILOT/'index.json').read_text())
    for item in index['rows']:
        if item['card_id']!=419:continue
        original=json.loads((PILOT/item['artifact']).read_text());data=copy.deepcopy(original['input'])
        for field in ('hand_ids','hand_base_costs','hand_costs'):data.pop(field,None)
        data.update(max_plays='all_physical',own_deck_ids=[])
        yield item['scene'],dict(scene=data,candidate_ids=[419,249] if '-free-' in item['scene'] else [419,249,8,21,556],
            tasks=TASKS,include_delay=False),item['kill_threshold'],97
    scene=dict(horizon='enemy_attack',own_player_hp=15,own_player_max_hp=30,
        enemy_player_hp=30,enemy_player_max_hp=30,gold_before_play=9,
        max_plays='all_physical',own_deck_ids=[],opponent_hand_ids=[598,598],opponent_gold_before_response=2,
        physical_slots=True,front_slot_map=[0,1,2,3],switch_left_slots=[0,1],
        enemy_bodies=[dict(card_id=270,attack=4,health=4,max_health=4,slot=1)])
    for label,decay in (('robot-punishment-native',97),('robot-punishment-decay96',96)):
        yield label,dict(scene=copy.deepcopy(scene),candidate_ids=[249,419],tasks=TASKS,include_delay=False),2,decay
    first=json.loads((PILOT/'four-hp2-419.json').read_text())['input']
    first={k:v for k,v in first.items() if k not in ('hand_ids','hand_base_costs','hand_costs')}
    first.update(max_plays='all_physical',own_deck_ids=[])
    ids=[c['id'] for c in score_cards.load_cards() if c['card_type']=='monster' and c['pool_category']=='ordinary_non_token' and c['cost']==9]
    yield 'all-native9-four-hp2',dict(scene=first,candidate_ids=ids,tasks=TASKS,include_delay=False),2,97


def public_input(data):
    obs={k:copy.deepcopy(data.get(k,[] if 'bodies' in k else 0)) for k in ('hand_ids','gold_before_play',
        'opponent_gold_before_response','own_player_hp','enemy_player_hp','ally_bodies_before_play','enemy_bodies')}
    params={k:copy.deepcopy(v) for k,v in data.items() if k not in obs and k not in ('own_player_max_hp','enemy_player_max_hp','hand_costs')}
    params.pop('opponent_hand_known',None)  # public explicit hand_ids provides this observation
    return dict(obs,role='midrange',own_turn=9,hand_costs=data['hand_costs'],paid_board_scenario=params,
        callback_state={k:data[k] for k in ('own_player_max_hp','enemy_player_max_hp') if k in data})


def main():
    OUT.mkdir(exist_ok=True);bindings=score.source_bindings(Path(__file__));native=score_cards.load_cards()
    cases=[];records={};variants={};cross=[];flat=[]
    for name,cfg,threshold,decay in fixtures():
        cards=copy.deepcopy(native)
        if threshold!=2:next(c for c in cards if c['id']==419)['effect_readable']=next(c for c in cards if c['id']==419)['effect_readable'].replace('2 HP','3 HP')
        if decay!=97:next(c for c in cards if c['id']==249)['effect_readable']='Dodge (98). Turn end: Lose '+str(decay)+' Dodge.'
        changed=threshold!=2 or decay!=97
        if changed:(OUT/(name+'.cards.json')).write_text(json.dumps(cards,ensure_ascii=False,indent=2)+'\n')
        result=score.compare(cfg,cards);records[name]=result;variants[name]=cards
        for suffix,obj in [('.input.json',cfg),('.json',result)]:
            (OUT/(name+suffix)).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
        cases.append(dict(case=name,artifact=name+'.json',candidate_count=len(result['rows']),
            known_hp=sum(r['scores']['hp']['known'] for r in result['rows']),
            selection=result['selection'],leaders=result['diagnostic_task_leaders'],alternative_source=changed))
        for row in result['rows']:
            for task,value in row['scores'].items():
                flat.append(dict(case=name,card_id=row['card_id'],name=row['name'],task=task,known=value['known'],
                    feasible=value['feasible'],joint_hp=value['guaranteed_player_hp'],unknown='; '.join(value.get('unknown',[]))))
        # The prototype paired44 vectors; verify the new production path on
        # the single-variable geometry, health and Dodge-boundary cases.
        if name in ('four-hp2','right-full-four-hp2','right-free-four-hp2','left-full-transparent',
                'left-free-transparent','robot-punishment-native','robot-punishment-decay96'):
            focal=249 if name.startswith('robot') else 419
            row=next(r for r in result['rows'] if r['card_id']==focal)
            for task in ('hp','clear','body_2_4'):
                alpha=row['scores'][task];ex=score.task_score(dict(row['input'],search_algorithm='exhaustive'),result['tasks'][task],cards=cards,focal_index=0)
                assert alpha['known'] and ex['known']
                assert tuple(alpha['search']['objective_vector'])==tuple(ex['search']['objective_vector'])
                cross.append(dict(case=name,card_id=focal,task=task,full_vector_equal=True))
        print(json.dumps(dict(case=name,known=cases[-1]['known_hp'],total=len(result['rows']),
            hp=[(r['card_id'],r['scores']['hp']['guaranteed_player_hp']) for r in result['rows'] if r['scores']['hp']['known']])),flush=True)
    checks=[]
    for name,cid in (('four-hp2',419),('robot-punishment-native',249)):
        row=next(r for r in records[name]['rows'] if r['card_id']==cid)
        data=dict(row['input'],objectives=['guaranteed_hp'])
        direct=paid.evaluate(data);public=api.evaluate(public_input(data))['paid_board_tactics'];assert direct==public
        path=OUT/(name+'.paid-input.json');target=OUT/(name+'.paid-cli.json')
        path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        subprocess.run([sys.executable,str(HERE/'paid_board_tactics.py'),'--input',str(path),'--output',str(target)],cwd=HERE,check=True,capture_output=True,text=True)
        assert json.loads(target.read_text())==json.loads(json.dumps(direct))
        checks.append(dict(case=name,card_id=cid,api_direct_complete_json_equal=True,actual_cli_complete_json_equal=True))
    assert bindings==score.source_bindings(Path(__file__))
    with (OUT/'scores.csv').open('w',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
    index=dict(version=score.VERSION,source_hashes=bindings,source_stable_during_run=True,cases=cases,
        candidate_context_rows=sum(c['candidate_count'] for c in cases),full_vector_checks=cross,actual_api_cli=checks,
        artifact_hashes={c['artifact']:hashlib.sha256((OUT/c['artifact']).read_bytes()).hexdigest() for c in cases},
        fixed_partition_is_server_verified=False,old_free_branch_prototype_adopted=False)
    (OUT/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(cases=len(cases),rows=index['candidate_context_rows'],vector_checks=len(cross),api_cli=len(checks))))


if __name__=='__main__':main()