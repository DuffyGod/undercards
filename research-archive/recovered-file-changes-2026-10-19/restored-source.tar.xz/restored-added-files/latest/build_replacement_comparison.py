"""Native card-slot substitutions with background healing and real future pay."""
import copy
import hashlib
import json
from pathlib import Path

import compare_replacement_slots as slots
import paid_board_tactics as paid
import score_cards
from build_standing_objective_comparison import contexts

HERE = Path(__file__).resolve().parent
OUT = HERE/'experiments/replacement-slot-v01'
CANDIDATES = [14, 48, 21, 8]
PURPOSES = dict(pressure=dict(min_own_player_hp=1, min_own_board_attack=4, min_own_board_health=3))


def probes():
    configs = {}
    for attack in (6, 12):
        for punish in (False, True):
            for background in (108, 43):
                scene = copy.deepcopy(contexts()['emergency_empty_board'])
                scene.update(gold_before_play=8, max_plays=2, next_max_plays=1,
                             next_own_gold_income=1, node_limit=30000)
                scene['enemy_bodies'][0]['attack'] = attack
                scene['opponent_hand_ids'] = [96] if punish else []
                name = f'attack-{attack}-punishment-{int(punish)}-background-{background}'
                configs[name] = dict(scene=scene, candidate_ids=CANDIDATES, purposes=PURPOSES,
                    background_hand=[dict(card_id=22,current_cost=3,base_cost=3),
                                     dict(card_id=background,current_cost=6,base_cost=6)])
    weak = copy.deepcopy(configs['attack-6-punishment-1-background-108'])
    weak['scene']['enemy_bodies'][0]['attack'] = 2
    configs['attack-2-punishment-1-background-108'] = weak
    low = copy.deepcopy(weak)
    low['scene']['enemy_bodies'] = low['scene']['enemy_bodies'][:1]
    low['scene']['enemy_bodies'][0]['attack'] = 1
    configs['single-attack-1-punishment-1-background-108'] = low
    extra_play = copy.deepcopy(low)
    extra_play['scene']['next_max_plays'] = 2
    configs['single-attack-1-punishment-1-background-108-future2'] = extra_play
    for attack in (1,6,12):
        cheap = copy.deepcopy(low)
        cheap['scene']['enemy_bodies'][0]['attack'] = attack
        cheap['scene']['max_plays'] = 'all_physical'
        cheap['background_hand'][1] = dict(card_id=990,current_cost=1,base_cost=1)
        for future_plays in (1,3):
            config = copy.deepcopy(cheap)
            config['scene']['next_max_plays'] = 1 if future_plays==1 else 'all_physical'
            configs[f'single-attack-{attack}-punishment-1-background-K-future{future_plays}'] = config
    for attack in (6,12):
        complete_plays = copy.deepcopy(configs[f'attack-{attack}-punishment-1-background-108'])
        complete_plays['scene'].update(max_plays='all_physical',next_max_plays='all_physical')
        configs[f'attack-{attack}-punishment-1-background-108-full-hand-plays'] = complete_plays
    for attack in (6,12):
        healthier = copy.deepcopy(configs[f'attack-{attack}-punishment-1-background-108'])
        healthier['scene'].update(own_player_hp=26, next_own_gold_income=4)
        configs[f'attack-{attack}-punishment-1-background-108-healthy-income4'] = healthier
    return configs


def main():
    cards = score_cards.load_cards()
    configs = probes()
    results = {name: slots.compare(config, cards) for name,config in configs.items()}
    checks = []
    for name in ('attack-6-punishment-1-background-108',
                 'single-attack-1-punishment-1-background-K-future1',
                 'single-attack-1-punishment-1-background-K-future3',
                 'attack-12-punishment-1-background-108-healthy-income4'):
        for row in results[name]['rows']:
            for goal, original in row['searches'].items():
                data = dict(row['input'], search_algorithm='exhaustive',
                            objectives=['guaranteed_hp' if goal=='guaranteed_hp' else 'purpose'])
                if goal != 'guaranteed_hp':
                    data['purpose_constraints'] = PURPOSES[goal]
                exhaustive = paid.evaluate(data, cards)
                if exhaustive['complete_in_declared_scope'] != original['complete_in_declared_scope']:
                    raise AssertionError(('Completeness mismatch',name,row['card_id'],goal))
                if original['complete_in_declared_scope'] and exhaustive['objectives'][0]['objective_vector'] != original['objectives'][0]['objective_vector']:
                    raise AssertionError(('Full vector mismatch',name,row['card_id'],goal))
                checks.append(dict(probe=name,card_id=row['card_id'],objective=goal,
                    complete=original['complete_in_declared_scope'],full_vector_equal=original['complete_in_declared_scope']))
    result = dict(version='physical-slot-replacement-probes-0.1.0',results=results,
        independent_checks=checks,source_hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest()
            for name in ('build_replacement_comparison.py','compare_replacement_slots.py',
                         'paid_board_tactics.py','board_tactics.py','alpha_beta_search.py')})
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    current = configs['attack-6-punishment-1-background-108']
    (OUT/'current.input.json').write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n')
    (OUT/'current.result.json').write_text(json.dumps(results['attack-6-punishment-1-background-108'],ensure_ascii=False,indent=2)+'\n')
    lines = ['# 同一卡位、同预算：候选与替代牌的有限比较','',
        '四个已抽到的原生候选 Jerry、Greater Dog、Tsunderplane、Toriel 分别占据相同物理手牌槽。背景是 Shyren 加 Rock 或 Lesser Dog，当前同为8G、最多2次出牌，下一己方收入1G、最多1次出牌；敌 Aaron 与 Tiny，包含第二敌回应。当前和未来部署均可放弃；没有强迫无效打出，也没有删除背景手牌当持有对照。',
        '', '比较干预：Aaron 已观察 ATK 6/12、敌物理回应有无 Punishment、等费背景 Rock/Lesser；另保留 ATK2 双敌探针、单敌ATK1探针及其未来出牌上限1→2反事实，以及26HP且下一收入4G的等待探针。更健康与更多收入在后者同时改变，不能把它作为单独生命或收入的因果效应。双方玩家/怪物最大HP、敌身体费用及历史显式提供；没有自然抽牌、SOUL或神器。',
        '', '| 条件 | Jerry HP / 压力 | Greater Dog HP / 压力 | Tsunderplane HP / 压力 | Toriel HP / 压力 |',
        '|---|---|---|---|---|']
    for name,result in results.items():
        cells = [str(r['values']['guaranteed_hp'])+' / '+str(r['values']['pressure']) for r in result['rows']]
        lines.append('| '+name+' | '+' | '.join(cells)+' |')
    low1=results['single-attack-1-punishment-1-background-K-future1']
    low3=results['single-attack-1-punishment-1-background-K-future3']
    before=next(r for r in low1['rows'] if r['card_id']==8)
    after=next(r for r in low3['rows'] if r['card_id']==8)
    if before['values']['pressure'] is not False or after['values']['pressure'] is not True:
        raise AssertionError('Timing/action-scope counterexample changed')
    lines += ['', '## 被结果推翻的行动范围假设','',
        '“未来至多出一张足以判断站场用途”被原生卡反例推翻。单敌1ATK、背景Shyren+Kawkaw时，Toriel留压力从false变true，HP最优保持10；6ATK时Jerry与Greater Dog也出现同方向用途变化。仅查HP敏感度会漏掉这些合法续着。',
        '', '低攻Toriel的新目的路线是当前全部持有：承受1脸伤后剩6HP；未来8G留存加收入1G得到9G，先付Kawkaw1G增强并麻痹Aaron，再付Toriel8G削攻并加自身HP。第二敌回应的Punishment仍进入完整搜索。这说明适合时机包括等待与同回合配合支付，而不是强迫现在空效果出场。当前输入没有重复麻痹，不使用refresh/preserve规则猜测。',
        '', '同Shyren+Rock背景、6ATK双敌/P的受限面板，Jerry的HP最优路径完全不打Jerry；9/7/4HP分别属于GreaterDog/Plane/Toriel整手策略，不能把每个值直接当槽卡的独立贡献。Toriel压力可行而生命较低，说明应同时公开目的与替代差异。Rock换等费Lesser使Jerry4→3，而GreaterDog仍9，不能把Dog的+3HP文字硬加为固定协同分。',
        '', '行动范围反事实当前使用all_physical，未来上限1→all_physical（本探针是全部三张物理手牌，表中简称future3），其余输入保持相同。另对Rock背景双敌面板放开当前/未来all_physical。原受限上限的purpose=false只是否定该受限策略集，不能推成真实合法行动下不可行。']
    lines += ['', '压力要求同一策略对所有回应同时保命、己方总ATK≥4与身体总HP≥3，单独搜索。HP与压力来自各自最优策略；不相加、不把最坏路径的一列身体当全回应保证。JSON保留每个真实输入、全部搜索、付款、最坏路径、候选在该路径的实际部署时点及成对差异。',
        '', '这些是当前已抽到卡位的替代比较，不是整个25牌卡组的携带价值。最优策略完全可以不打候选而使用背景牌；这时手牌结果仍属于整手牌，不能全部归功于槽内卡。路径中的不出牌不是概率，更不是每个回应下都不出牌的证明。未知候选保留null，不参与确定排序。',
        '', str(len(checks))+'项独立 alpha-beta/exhaustive 完整向量对照已运行；它们共享机制原语，不证明服务器规则或实战频率。没有给这些设计条件指定天梯权重、Gold或胜率。',
        '', '```sh','python analysis/monster-value-heuristic/build_replacement_comparison.py',
        'python analysis/monster-value-heuristic/compare_replacement_slots.py --input analysis/monster-value-heuristic/experiments/replacement-slot-v01/current.input.json --output /tmp/replacement-slot.json','```','']
    (OUT/'comparison.md').write_text('\n'.join(lines))
    for name,result in results.items():
        print(name,[(r['card_id'],r['values']) for r in result['rows']],flush=True)


if __name__ == '__main__':
    main()