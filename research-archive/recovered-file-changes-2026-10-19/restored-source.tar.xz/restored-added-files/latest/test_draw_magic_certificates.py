"""New draw families cannot escape old source-bound proof inventories."""
import copy
import unittest

import certify_hand_hp as hp
import evaluate_situation
import future_draw_policy
import paid_board_tactics as paid
import prove_idle_reply_bound as idle
import score_cards
import test_future_draw_policy


def optional_scene():
    return dict(hand_ids=[44],hand_costs=[8],own_deck_ids=[22],own_fatigue_next=1,
        gold_before_play=8,own_player_hp=3,own_player_max_hp=30,enemy_player_hp=30,
        enemy_player_max_hp=30,ally_bodies_before_play=[],enemy_bodies=[],
        opponent_hand_ids=[],opponent_deck_ids=[],opponent_gold_before_response=0,
        first_opponent_natural_draw_count=0,horizon='next_own_attack',
        max_plays='all_physical',next_max_plays='all_physical',next_own_gold_income=3,
        next_natural_draw_count=0,objectives=['guaranteed_hp'])


class DrawMagicCertificateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def test_optional_draw_inventory_counts_actual_library_healing_once(self):
        data=optional_scene()
        certificate=hp.certify(data,[],self.cards)
        self.assertTrue(certificate['hp_optimum_certified'],certificate['unknown'])
        self.assertEqual(certificate['guaranteed_hp_bounds'],[7,7])
        sources=certificate['upper_certificate']['physical_healing_sources']
        self.assertEqual([(s['card_id'],s['max_player_hp_gain']) for s in sources],[(44,0),(22,4)])

    def test_bilateral_draw_inventory_checks_enemy_library_callbacks_and_missing_facts(self):
        for changes,phrase in [({},'Unknown enemy draw'),
            ({'opponent_deck_ids':[936,196]},'Enemy draw callback')]:
            data=dict(optional_scene(),hand_ids=[199],hand_costs=[5],gold_before_play=5)
            data.pop('opponent_deck_ids');data.update(changes)
            engine=paid.PaidSearch(self.cards,data)
            with self.assertRaisesRegex(paid.UnknownMechanic,phrase):hp.healing_ceiling(engine,engine.root())

    def test_current_optional_draw_is_rejected_by_unrevealed_future_protocol(self):
        data=test_future_draw_policy.fixture()
        for panel in data['panels']:
            panel.update(hand_ids=[44],hand_costs=[8],hand_base_costs=[8],gold_before_play=8,
                own_player_hp=10,max_plays=1)
        result=future_draw_policy.evaluate(data,self.cards)
        self.assertFalse(result['complete_in_declared_scope'])
        self.assertIsNone(result['metrics']);self.assertFalse(result['common_own_prefix'])
        self.assertIn('observation-aware branching',' '.join(result['unknown']))

    def test_common_api_preserves_native_optional_draw_and_exact_scalar_proof(self):
        scene=optional_scene()
        root=('hand_ids','hand_costs','gold_before_play','own_player_hp','enemy_player_hp',
              'ally_bodies_before_play','enemy_bodies','opponent_gold_before_response')
        data={k:copy.deepcopy(scene[k]) for k in root}
        data.update(role='midrange',own_turn=8,response_weights={'enemy_face':1},
            condition_state={},
            callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30),
            paid_board_scenario={k:copy.deepcopy(v) for k,v in scene.items()
                if k not in root and k not in ('own_player_max_hp','enemy_player_max_hp','condition_known_state')})
        data['paid_board_scenario']['hp_certificate_prefix']=[]
        scene['hp_certificate_prefix']=[]
        scene['condition_known_state']={}
        result=evaluate_situation.evaluate(data,cards=self.cards)
        self.assertEqual(result['paid_board_tactics'],paid.evaluate(scene,self.cards))
        self.assertTrue(result['paid_board_tactics']['scalar_guaranteed_hp_exact'])
        self.assertEqual(result['paid_board_tactics']['hp_optimum_certificate']['guaranteed_hp_bounds'],[7,7])
        self.assertFalse(result['certified_immediate_victory_options'])


if __name__=='__main__':unittest.main()