"""Searchable all-monster inventory with separate review and evidence levels.

Whole-card ratings remain null without an identified role/reference. Exact
local measurements can be useful while full game value remains unverified.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path

import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'research-runs/card-profiles-v01'
VERSION='card-profile-catalog-0.2.0'


def read(name):return json.loads((OUT/name).read_text())


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build():
    cards=[c for c in score_cards.load_cards() if c['card_type']=='monster' and c['pool_category']=='ordinary_non_token']
    by={c['id']:c for c in cards};source_hash=digest(score_cards.DEFAULT_SNAPSHOT)
    rows={str(c['id']):dict(card=c,review_materials=[],mechanism_candidates=[],
        coverage={'source_bound':True,'conditional_profile_reviewed':False,'local_measurement_available':False,
                  'complete_paid_search_supported':None,'server_verified':False},
        global_rating=None,empirical_frequency=None) for c in cards}
    sources={}
    def attach(cid,filename,kind,value):
        if cid not in by:return
        path=OUT/filename;sources[filename]=digest(path)
        rows[str(cid)]['review_materials'].append(dict(artifact=filename,evidence_type=kind,content=value))
        rows[str(cid)]['coverage']['conditional_profile_reviewed']=True
    basic=read('simple-family-review.json')
    assert basic['source']['sha256']==source_hash
    for c in basic['pure_body_review']['accepted_cards']:
        cid=c.get('id',c.get('card_id'))
        attach(cid,'simple-family-review.json','whole_text_basic_family_review',c)
    for c in basic['simple_magic_review']['cards']:
        attach(c['id'],'simple-family-review.json','source_scope_review_not_full_simulation',c)
    rubric=read('rubric-challenge.json');assert rubric['source']['sha256']==source_hash
    for c in rubric['challenge_cards']:attach(c['card_id'],'rubric-challenge.json','conditional_hypothesis_review',c)
    high=read('high-cost-expansion.json');assert high['source_snapshot_sha256']==source_hash
    for c in high['profiles']:
        assert c['card']['effect_readable']==by[c['card_id']]['effect_readable']
        attach(c['card_id'],'high-cost-expansion.json','conditional_hypothesis_review',c)
    for filename in ('low-cost-expansion.json','mid-cost-expansion.json'):
        if not (OUT/filename).exists():continue
        extra=read(filename);assert extra['source_snapshot_sha256']==source_hash
        for c in extra['profiles']:
            assert c['card']['effect_readable']==by[c['card_id']]['effect_readable']
            attach(c['card_id'],filename,'conditional_hypothesis_review',c)
            if c.get('counterfactual',{}).get('verified') is True:
                rows[str(c['card_id'])]['coverage']['local_measurement_available']=True
    high=read('high-cost-review.json');assert high['sources']['snapshot_sha256']==source_hash
    for c in high['profiles']:attach(c['card']['id'],'high-cost-review.json','literal_arithmetic_review',c)
    jevil=read('jevil-review.json');assert jevil['source']['snapshot_sha256']==source_hash
    attach(444,'jevil-review.json','literal_arithmetic_review',jevil)
    for cid in (444,60,62):rows[str(cid)]['coverage']['local_measurement_available']=True
    dynamic=HERE/'experiments/dynamic-body-v01/comparison.json'
    if dynamic.exists():
        d=json.loads(dynamic.read_text());assert d['snapshot_sha256']==source_hash
        for cid in (534,632):
            rows[str(cid)]['review_materials'].append(dict(artifact='../experiments/dynamic-body-v01/comparison.json',
                evidence_type='dynamic_state_paid_family_counterfactuals',source_sha256=digest(dynamic),
                scope='Declared dynamic-state inputs only; window/modifier/stat interactions may remain unknown.'))
            rows[str(cid)]['coverage']['dynamic_mechanism_evidence']=dict(paid_version=d['paid_version'],
                global_strength_calibrated=False,full_card_arbitrary_context_supported=False)
    packet=HERE/'experiments/damage-packet-v01/comparison.json'
    if packet.exists():
        p=json.loads(packet.read_text());assert p['source_snapshot_sha256']==source_hash
        for cid in (56,187,377):
            rows[str(cid)]['review_materials'].append(dict(artifact='../experiments/damage-packet-v01/comparison.json',
                evidence_type='actual_paid_enemy_reply_and_independent_subgame',
                source_sha256=digest(packet),scope='Specific declared paid scenarios; not arbitrary full-card value.'))
        for cid in (56,840):
            rows[str(cid)]['coverage']['packet_mechanism_evidence']=dict(paid_version=p['paid_version'],
                compiled_literal_mechanism=True,scope='New native damage modifier; order/source/zero-event guards can still make a scenario unknown.')
    if (OUT/'basic-body-comparison.json').exists():
        b=read('basic-body-comparison.json')
        assert b['source']['sha256']==source_hash
        # The strict source-reviewed cohort only, never all printed bodies.
        for cid in basic['pure_body_review']['accepted_ids']:
            rows[str(cid)]['coverage']['local_measurement_available']=True
            rows[str(cid)]['review_materials'].append(dict(artifact='basic-body-comparison.json',evidence_type='local_body_arithmetic'))
        sources['basic-body-comparison.json']=digest(OUT/'basic-body-comparison.json')
        if (OUT/'basic-penalty-sequences.json').exists():
            seq=read('basic-penalty-sequences.json');assert seq['source']['sha256']==source_hash
            assert seq['previous_report_sha256']==sources['basic-body-comparison.json']
            sources['basic-penalty-sequences.json']=digest(OUT/'basic-penalty-sequences.json')
            for cid in basic['pure_body_review']['accepted_ids']:
                rows[str(cid)]['review_materials'].append(dict(artifact='basic-penalty-sequences.json',evidence_type='persistent_packet_sequence_arithmetic'))
    queue_files=[];token_count=0;cache_tokens=0;variants={};failure_tasks=[];question_count=0
    for name in ('deepseek-v05','deepseek-v05-repair','deepseek-v05-repair2'):
        p=OUT/name
        if not (p/'merged-candidates.json').exists():continue
        manifest=json.loads((p/'manifest.json').read_text());assert manifest['source_snapshot_sha256']==source_hash
        d=json.loads((p/'merged-candidates.json').read_text());token_count+=d['total_api_tokens']
        queue_files.append(dict(folder=name,manifest_sha256=digest(p/'manifest.json'),merged_sha256=digest(p/'merged-candidates.json')))
        for cid,item in d['profiles'].items():
            if cid not in rows:continue
            profile=item['profile'];assert profile['printed_effect']==by[int(cid)]['effect_readable']
            rows[cid]['mechanism_candidates'].append(dict(folder=name,source_task=item['source_task'],profile=profile,
                adoption='questions for triage only; role candidates and hypothetical premises not certified'))
        for cid,v in d['overlap_variants'].items():variants.setdefault(cid,[]).extend(dict(folder=name,**x) for x in v)
        failure_tasks.extend(dict(folder=name,**x) for x in d['failures'])
        for task in manifest['tasks']:
            file=p/(task['id']+'.json')
            if not file.exists():continue
            raw=json.loads(file.read_text())
            cache_tokens+=sum(a.get('usage',{}).get('prompt_tokens_details',{}).get('cached_tokens',0) for a in raw['attempts'])
    overlap=[]
    for cid,vs in variants.items():
        if len(vs)<2:continue
        signatures={json.dumps(v['profile']['role_candidates'],sort_keys=True) for v in vs}
        overlap.append(dict(card_id=int(cid),name=by[int(cid)]['name'],observations=len(vs),role_variants=[json.loads(x) for x in sorted(signatures)],
            source_text_consistent=len({v['profile']['printed_effect'] for v in vs})==1,
            interpretation='Candidate role disagreement is retained; no averaging or automatic adoption.'))
    coverage=dict(total_monsters=len(cards),source_bound=len(rows),
        llm_source_question_candidates=sum(bool(r['mechanism_candidates']) for r in rows.values()),
        conditional_profile_reviewed=sum(r['coverage']['conditional_profile_reviewed'] for r in rows.values()),
        local_measurement_available=sum(r['coverage']['local_measurement_available'] for r in rows.values()),
        complete_paid_search_supported='Separate existing paid reports; not inferred from profiles.',
        newly_added_packet_mechanisms=sum('packet_mechanism_evidence' in r['coverage'] for r in rows.values()),
        newly_added_dynamic_mechanisms=sum('dynamic_mechanism_evidence' in r['coverage'] for r in rows.values()),
        server_verified=0,global_gold_calibrated=0)
    out=dict(version=VERSION,source_snapshot_sha256=source_hash,catalog_source_sha256=digest(__file__),coverage=coverage,
        review_policy='Main adopted cited scope/conditional reasoning after source checks. Independent agent agreement is not empirical validation; conditional profiles are not whole-card scores.',
        profiles=rows,review_artifact_hashes=sources,question_queue_sources=queue_files,
        question_queue_tokens=token_count,reported_cached_input_tokens=cache_tokens,overlap_review=overlap,retained_failure_tasks=failure_tasks,
        unresolved='Event interpretation, real distributions and future opponent replies remain explicit; final Gold/null is not0.')
    (OUT/'catalog.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    with (OUT/'catalog.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['id','name','cost','attack','health','conditional_review','local_measurement','llm_questions','global_rating','effect','review_artifacts'])
        for c in sorted(cards,key=lambda x:(x['cost'],x['id'])):
            r=rows[str(c['id'])];writer.writerow([c['id'],c['name'],c['cost'],c['attack'],c['health'],
                r['coverage']['conditional_profile_reviewed'],r['coverage']['local_measurement_available'],bool(r['mechanism_candidates']),
                '',c['effect_readable'],';'.join(dict.fromkeys(x['artifact'] for x in r['review_materials']))])
    (OUT/'coverage.json').write_text(json.dumps({k:v for k,v in out.items() if k!='profiles'},ensure_ascii=False,indent=2)+'\n')
    return coverage


def query(name=None,cost=None,reviewed=None):
    d=read('catalog.json');found=[]
    for row in d['profiles'].values():
        c=row['card']
        if name and name.casefold() not in c['name'].casefold() and str(c['id'])!=name:continue
        if cost is not None and c['cost']!=cost:continue
        if reviewed is not None and row['coverage']['conditional_profile_reviewed']!=reviewed:continue
        found.append(row)
    return found


def break_even(gain,loss):
    """Two-regime slot utility delta; input units must be identical and explicit.

    Holding is already inside each feasible policy. This function cannot invent
    frequencies or convert unlike HP/ATK/coins to a common utility.
    """
    if gain<0 or loss<0 or gain+loss<=0:raise ValueError('nonnegative common-unit gain/loss, at least one positive')
    return loss/(gain+loss)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['build','query'])
    p.add_argument('--name');p.add_argument('--cost',type=int);p.add_argument('--reviewed',action='store_true')
    args=p.parse_args()
    print(json.dumps(build() if args.command=='build' else query(args.name,args.cost,True if args.reviewed else None),ensure_ascii=False,indent=2))


if __name__=='__main__':main()