"""Same-endpoint cross-card scores, counterfacts and parameter robustness."""
import copy
import csv
import gzip
import hashlib
import json
from pathlib import Path

import construction_value
import evaluate_situation
import finite_timing_window as timing
import joint_window_quote as joint
import score_cards as base

HERE = Path(__file__).resolve().parent
OUT = HERE / 'experiments/absolute-timing-v01'


def scenes():
    common = dict(own_turn=4, horizon_tick=11, gold_before_play=12, role='midrange',
        own_player_hp=30, own_player_max_hp=30, enemy_player_hp=60,
        enemy_bodies=[], responses={'none':1}, initial_hand_size=1,
        random_target_policy='uniform_declared', random_no_target_policy='fizzle_assumed',
        condition_state={'last_turn_gold_spent_on_spells':1})
    mods = {
        'empty_early': {},
        'empty_arrival5': {'own_turn':5},
        'empty_arrival6': {'own_turn':6},
        'empty_longer': {'horizon_tick':13},
        'empty_full_hand': {'initial_hand_size':7,'natural_draw_count':1},
        'empty_gold4': {'gold_before_play':4},
        'curve4_first': {'own_turn':2,'horizon_tick':9,'gold_before_play':4},
        'curve4_second': {'own_turn':2,'horizon_tick':9,'gold_before_play':4,'second_player':True},
        'late_curve4_first': {'own_turn':4,'horizon_tick':9,'gold_before_play':4},
        'late_curve4_second': {'own_turn':4,'horizon_tick':9,'gold_before_play':4,'second_player':True},
        'target2_face': {'enemy_bodies':[{'attack':2,'health':8}],'responses':{'enemy_face':1}},
        'target2_mixed': {'enemy_bodies':[{'attack':2,'health':8}],'responses':{'enemy_face':.5,'enemy_contact':.5}},
        'target2_avoidance': {'enemy_bodies':[{'attack':2,'health':8}],'response_mode':'min',
            'responses':{'none':0,'enemy_face':0,'enemy_contact':0}},
        'target8_face': {'enemy_bodies':[{'attack':8,'health':8}],'responses':{'enemy_face':1}},
        'target8_paid_silence': {'enemy_bodies':[{'attack':8,'health':8}],
            'responses':{'silence_then_enemy_face':1},'opponent_gold':3},
        'injured_midrange': {'own_player_hp':10},
        'injured_aggro': {'own_player_hp':10,'role':'aggro'},
        'injured_control': {'own_player_hp':10,'role':'control'},
    }
    return [(name, dict(copy.deepcopy(common), **change)) for name, change in mods.items()]


def stats(result):
    if not result['pricing_supported']:
        return {}
    policy = {p['state_key']: p for p in result['actual']['policy']}
    root = next(p for p in policy.values() if p['step']==0)
    def visit(key):
        if key not in policy:
            s=json.loads(key)
            return dict(deployed_probability=float(s['deployed']),unused_probability=float(s['held']),
                actual_paid_gold=s['actual_paid'],deployed_turn_sum=(s['deployment_turn'] or 0),
                expected_own_attacks=s['own_attacks'],expected_growth_triggers=s['growth_count'],
                expected_own_hp=s['own_player_hp'],expected_callback_count=s['callback_count'])
        p=policy[key]
        branches=p['branches'] if p['kind']=='chance' else [b for b in p['branches'] if b['action_id']==p['selected_action_id']]
        out={}
        for b in branches:
            weight=b['probability'] if p['kind']=='chance' else 1.
            for k,v in visit(b['child_state_key']).items():out[k]=out.get(k,0.)+weight*v
        return out
    r=visit(root['state_key'])
    r['mean_deployment_turn_when_used']=r.pop('deployed_turn_sum')/r['deployed_probability'] if r['deployed_probability'] else None
    return r


def csv_file(path, rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    cards=base.load_cards();by={c['id']:c for c in cards};ref,_=base.make_reference(cards)
    norm=joint.make_normalization(ref,reply_policy='allied_board',resolve_next_own_start=True)
    old=json.loads((HERE/'experiments/integrated-window-v02/monster-pool.json').read_text())
    ids=list(dict.fromkeys([r['card_id'] for r in old['scores'] if r['pricing_supported']]+[307,225,43,385,438,582,138,509]))
    rows=[];traces=[]
    for name,scene in scenes():
        (OUT/(name+'.scenario.json')).write_text(json.dumps(scene,ensure_ascii=False,indent=2)+'\n')
        for cid in ids:
            r=timing.evaluate(by[cid],ref,norm['scale'],scene,include_policy=True)
            r['case']=name;traces.append(r)
            parts=r['actual']['selected_policy_components'] or {};absent=r['absent']['selected_policy_components'] or {}
            rows.append(dict(case=name,card_id=cid,name=by[cid]['name'],
                pricing_supported=r['pricing_supported'],option_net=r['absolute_endpoint_option_model_gold'],
                root_action=r['actual']['root_action_id'],
                actual_state_count=r['actual']['state_count'],unknown_leaf_count=len(r['actual']['unknown']),
                realized_player_hp_component=parts.get('own_player_hp',0)-absent.get('own_player_hp',0),
                realized_face_damage_component=parts.get('enemy_player_hp',0)-absent.get('enemy_player_hp',0),
                final_body_component=parts.get('remaining_actor_body',0),
                cash_component=parts.get('retained_own_cash',0)-absent.get('retained_own_cash',0),
                draw_capacity_component=parts.get('retained_draw_options',0)-absent.get('retained_draw_options',0),
                **stats(r)))
    csv_file(OUT/'comparison.csv',rows)
    with gzip.open(OUT/'policy-traces.json.gz','wt') as f:json.dump(traces,f,ensure_ascii=False)
    # Reuse exactly the same normalization for all numeric interventions.
    counter=[]
    chosen={n:s for n,s in scenes() if n in ('empty_early','empty_arrival6','empty_full_hand','target2_mixed','target2_avoidance')}
    for cid in (15,115,307,404,509,138,243,438):
        for name,scene in chosen.items():
            before=next(r for r in rows if r['card_id']==cid and r['case']==name)
            for field,change in (('attack',1),('health',1),('cost',-1)):
                variant=dict(by[cid]);variant[field]+=change
                after=timing.evaluate(variant,ref,norm['scale'],scene)
                delta=after['absolute_endpoint_option_model_gold']-before['option_net'] if after['pricing_supported'] and before['pricing_supported'] else None
                counter.append(dict(card_id=cid,name=by[cid]['name'],case=name,change=field+str(change),
                    before=before['option_net'],after=after['absolute_endpoint_option_model_gold'],delta=delta,
                    numerical_monotonic=delta>=-1e-9 if delta is not None else None))
    csv_file(OUT/'numeric-counterfacts.csv',counter)
    # Parameter grid: each row is a changed assumption, not empirical data.
    sensitivity=[]
    for horizon in (9,11,13):
        for hand in (1,7):
            for draw_prior in (.3,.6,.9):
                for role in ('aggro','midrange','control'):
                    scene=dict(scenes()[0][1],horizon_tick=horizon,initial_hand_size=hand,
                        natural_draw_count=1,draw_option_value_model_gold=draw_prior,
                        own_player_hp=10,role=role)
                    for cid in (15,307,404,509,243,602):
                        r=timing.evaluate(by[cid],ref,norm['scale'],scene)
                        sensitivity.append(dict(horizon_tick=horizon,hand=hand,draw_prior=draw_prior,
                            role=role,card_id=cid,name=by[cid]['name'],option_net=r['absolute_endpoint_option_model_gold'],
                            root_action=r['actual']['root_action_id']))
    csv_file(OUT/'parameter-sensitivity.csv',sensitivity)
    obs=dict(hand_ids=[197],role='midrange',own_turn=5,gold_before_play=12,
        opponent_gold_before_response=0,own_player_hp=5,enemy_player_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[{'attack':7,'health':4}],response_weights={'enemy_face':1})
    tree=dict(root_id='now',initial_hand_size=1,last_deployment_own_turn=5,draw_option_value_model_gold=.6,
        nodes=[dict(id='now',own_turn=5,observation=obs)])
    rescue=construction_value.evaluate_cards([by[197]],ref,norm['scale'],tree,evaluate_situation.make_state)
    (OUT/'null-gold-rescue.json').write_text(json.dumps(rescue,ensure_ascii=False,indent=2)+'\n')
    example=copy.deepcopy(obs);example.update(hand_ids=[307,404,509,15],own_turn=4,gold_before_play=12,
        own_player_hp=20,enemy_player_hp=60,enemy_bodies=[],response_weights={'none':1},
        callback_state={'own_player_max_hp':30},absolute_timing_scenario={'horizon_tick':11})
    (OUT/'current.input.json').write_text(json.dumps(example,ensure_ascii=False,indent=2)+'\n')
    report=dict(version=timing.VERSION,scale=norm['scale'],card_count=len(ids),case_count=len(scenes()),
        score_rows=len(rows),complete_score_rows=sum(r['pricing_supported'] for r in rows),
        numeric_counterfacts=len(counter),numeric_known=sum(r['delta'] is not None for r in counter),
        numeric_decreases=[r for r in counter if r['numerical_monotonic'] is False],
        sensitivity_rows=len(sensitivity),limitations=timing.LIMITATIONS,
        source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in HERE.glob('*.py')})
    (OUT/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('source_sha256','limitations','numeric_decreases')}),flush=True)


if __name__=='__main__':main()