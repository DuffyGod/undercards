import copy
import unittest
import certify_two_fee_rescue as certificates
import compare_monster_purposes as comparison
import score_cards


class PurposeComparisonTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.cards=score_cards.load_cards()

    def test_whole_two_cost_source_optimum_and_joint_impossibility(self):
        result=certificates.certify('two_attacks',self.cards)
        self.assertEqual(result['optimal_guaranteed_hp_bounds'],[2,2])
        self.assertEqual(result['known_optimal_card_ids'],[932])
        self.assertFalse(result['any_candidate_can_guarantee_survival_and_clear'])
        paid=certificates.certify('two_attacks_paid_damage',self.cards)
        self.assertEqual(paid['optimal_guaranteed_hp_bounds'],[0,0])
        self.assertEqual(paid['certified_survival_card_ids'],[])

    def test_numeric_source_drift_invalidates_goal_certificate(self):
        changed=copy.deepcopy(self.cards)
        next(c for c in changed if c['id']==932)['attack']+=1
        with self.assertRaisesRegex(ValueError,'Reviewed card changed'):
            certificates.certify('two_attacks',changed)

    def test_enemy_reply_outside_candidate_bucket_cannot_reuse_proof(self):
        changed=copy.deepcopy(self.cards)
        next(c for c in changed if c['id']==96)['effect_readable']='Deal 1 DMG to an enemy monster.'
        with self.assertRaisesRegex(ValueError,'Reviewed source game changed: 96'):
            certificates.certify('two_attacks_paid_damage',changed)

    def test_full_candidate_traversal_never_promotes_subset_winner(self):
        scene=dict(own_player_hp=3,own_player_max_hp=30,enemy_player_hp=30,
            enemy_bodies=[dict(card_id=15,attack=6,health=5)],max_plays=1,
            horizon='enemy_attack',own_deck_ids=[],own_fatigue_next=1)
        result=comparison.compare(dict(scene=scene,printed_costs=[2],
            purposes={'protect':{'min_own_player_hp':3}}),self.cards)
        bucket=result['buckets'][0]
        all_ids={c['id'] for c in self.cards if c['card_type']=='monster'
            and c['pool_category']=='ordinary_non_token' and c['cost']==2}
        self.assertEqual(set(bucket['all_candidate_ids']),all_ids)
        self.assertFalse(bucket['survival_optimum_certified'])
        self.assertTrue(bucket['unresolved_survival_card_ids'])
        self.assertTrue(bucket['purposes']['protect']['any_candidate_can_guarantee'])
        self.assertFalse(bucket['purposes']['protect']['all_feasible_candidates_identified'])


if __name__=='__main__': unittest.main()