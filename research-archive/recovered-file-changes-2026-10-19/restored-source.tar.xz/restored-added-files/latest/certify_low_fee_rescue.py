"""Source-proof + executable-search certificates for complete 0G/1G buckets.

This is an emergency-defense decision, not a whole-card Gold ranking. Every
ordinary low-fee monster is retained, including unknown possible ties. Source
lemmas prove a particular survival objective without claiming to simulate all
irrelevant generated resources. The certificate fails closed on source drift.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

import paid_board_tactics as paid
import score_cards

HERE = Path(__file__).resolve().parent
PROOF = HERE/'experiments/board-standard-v01/low-fee-bucket-source-proof.json'
VERSION = 'complete-low-fee-defense-certificates-0.1.0'
PANELS = {
    'one_attack': (False, None),
    'one_attack_paid_damage': (False, 96),
    'two_attacks': (True, None),
    'two_attacks_paid_damage': (True, 96),
    'one_attack_paid_silence': (False, 79),
}


def validate_source_game(cards):
    # A synthetic mutation of an opponent or an offer/product outside the
    # candidate bucket must not silently reuse a proof for the frozen game.
    canonical={c['id']:c for c in score_cards.load_cards()}
    provided={c['id']:c for c in cards}
    if set(canonical)!=set(provided): raise ValueError('Reviewed source game inventory changed')
    fields=('name','card_type','pool_category','rarity','cost','attack','health','target','effect_readable')
    for cid,c in provided.items():
        if any(c.get(k)!=canonical[cid].get(k) for k in fields):
            raise ValueError('Reviewed source game changed: '+str(cid))


def validate_lemmas(cards, proof):
    digest = hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest()
    if proof['snapshot_sha256'] != digest:
        raise ValueError('Source snapshot changed: reviewed survival lemmas require revalidation')
    by = {c['id']: c for c in cards}
    candidates = {c['id'] for c in cards if c['card_type'] == 'monster'
                  and c['pool_category'] == 'ordinary_non_token' and c['cost'] in (0, 1)}
    if {c['card_id'] for c in proof['cards']} != candidates:
        raise ValueError('Full 0G/1G candidate inventory differs from reviewed proof')
    for lemma in proof['cards']:
        c = by[lemma['card_id']]
        fields = {'name':'name', 'printed_cost':'cost', 'printed_attack':'attack',
                  'printed_health':'health', 'effect_readable':'effect_readable', 'target':'target'}
        if any(lemma[a] != c[b] for a, b in fields.items()):
            raise ValueError('Reviewed source lemma no longer matches card '+str(c['id']))
        for reference in lemma['references']:
            target=by[reference['card_id']]
            if any(reference[k] != target[k] for k in ('name','effect_readable','attack','health','cost')):
                raise ValueError('Reviewed product/source reference changed: '+str(target['id']))
    validate_source_game(cards)
    return by


def certify(panel='one_attack', *, two_plus_spells_cast=1, cards=None):
    if panel not in PANELS: raise ValueError('Unknown defense panel')
    if type(two_plus_spells_cast) is not int or two_plus_spells_cast < 1:
        raise ValueError('This certificate needs known historical 2+G spell count >=1; h=0 Noelle Cast/placement remains unresolved')
    cards = score_cards.load_cards() if cards is None else cards
    proof = json.loads(PROOF.read_text())
    by = validate_lemmas(cards, proof)
    second, spell = PANELS[panel]
    data = dict(hand_ids=[], gold_before_play=1, own_player_hp=3, own_player_max_hp=30,
                enemy_player_hp=30, enemy_player_max_hp=30, ally_bodies_before_play=[],
                enemy_bodies=[dict(card_id=15, attack=6, health=5, ready=True)],
                max_plays=1, horizon='enemy_attack', objectives=['survive'],
                opponent_hand_ids=[] if spell is None else [spell],
                opponent_gold_before_response=0 if spell is None else by[spell]['cost'],
                own_deck_ids=[], own_fatigue_next=1, next_natural_draw_count=0)
    if second: data['enemy_bodies'].append(dict(card_id=2, attack=2, health=3, ready=True))
    rows = []
    for lemma in proof['cards']:
        cid = lemma['card_id']
        c = by[cid]
        actual_cost = c['cost'] + (two_plus_spells_cast if cid == 792 else 0)
        status = lemma['survival_certificate']
        reason = lemma['complete_source_reasoning']
        bounds = None
        runtime = None
        if status == 'guaranteed_failure':
            # All these complete source clauses leave the strong attacker able
            # to hit face. Adding an independent 2/3 does not add a friendly
            # Taunt or clear the 6/5. Enemy-hand transformations can still
            # happen in paid panels; the direct face failure witness remains.
            # The opponent need not play its original or transformed spell.
            bounds = [0, 0]
            if cid == 779 and spell is not None:
                reason = '右位Magic可以把已知敌手法术变为4G Gaster Blaster；并非敌手为空。敌仍可不施法，让6/5直接打脸致死，该转换不提供挡脸或控敌。'
            if second:
                reason += ' 另加敌2/3不提供友军保护；单张该牌的完整文字仍不能清掉6/5或挡脸，强敌可继续执行失败见证。'
        elif cid == 792:
            bounds = [0, 0]
            reason = '已知历史h>=1，使当前手费1+h>=2；余额1、空场、无额外牌/减费，不能先执行其Magic获得免费Cast。'
        elif cid == 226:
            if spell == 96:
                bounds = [0, 0]
                reason = '无论空Magic能否出牌：不可出则6脸死；可出则敌支付Punishment3G杀2HP Taunt，再6脸死。'
            elif spell == 79:
                bounds = [0, 0]
                reason = '若可出，敌支付Penetration1G移除Taunt，然后6打脸；若不能出则直接失败。无需猜空选裁定。'
            elif second:
                bounds = [0, 0]
                reason = '若可出，敌2/3先与3/2 Taunt同死，6/5再打脸；若不能出则直接失败。'
            else:
                bounds = [0, 3]
                reason = '空Magic是否允许Play未定；可出时Taunt保3，不可出时死。它没有玩家治疗，因此两种裁定均不可能超过3。'
        if cid in (1, 990, 196, 115, 563, 792):
            runtime = paid.evaluate(dict(data, hand_ids=[cid], hand_costs=[actual_cost]), cards)
            if runtime['complete_in_declared_scope']:
                value = runtime['objectives'][0]['metrics']['own_player_hp']
                if bounds is not None and not bounds[0] <= value <= bounds[1]:
                    raise AssertionError('Source proof/search discrepancy for card '+str(cid))
                bounds = [value, value]
            elif bounds is None:
                bounds = [0, 3]
                reason = '; '.join(runtime['unknown'])
        if bounds is None: raise AssertionError('Candidate has no explicit survival bound')
        rows.append(dict(card_id=cid, name=c['name'], printed_cost=c['cost'], actual_current_cost=actual_cost,
                         guaranteed_endpoint_hp_bounds=bounds, source_reason=reason,
                         full_state_simulated=runtime is not None and runtime['complete_in_declared_scope'],
                         runtime=runtime, preserved_unknowns=lemma['preserved_unknowns']))
    buckets = []
    for cost in (0, 1):
        candidates = [r for r in rows if r['printed_cost'] == cost]
        lower = max(r['guaranteed_endpoint_hp_bounds'][0] for r in candidates)
        upper = max(r['guaranteed_endpoint_hp_bounds'][1] for r in candidates)
        known = [r['card_id'] for r in candidates if r['guaranteed_endpoint_hp_bounds'] == [lower, lower]]
        possible = [r['card_id'] for r in candidates if r['guaranteed_endpoint_hp_bounds'][0] != r['guaranteed_endpoint_hp_bounds'][1]
                    and r['guaranteed_endpoint_hp_bounds'][1] >= lower]
        buckets.append(dict(printed_cost=cost, all_candidate_ids=[r['card_id'] for r in candidates],
                            optimal_guaranteed_hp_bounds=[lower, upper], optimum_certified=lower == upper,
                            known_optimal_card_ids=known if lower == upper else [],
                            unresolved_possible_ties_or_winners=possible))
    return dict(version=VERSION, panel=panel, snapshot_sha256=proof['snapshot_sha256'],
                reviewed_proof_sha256=hashlib.sha256(PROOF.read_bytes()).hexdigest(),
                objective='Maximize guaranteed own HP at end of declared enemy attack window; 0 means death.',
                common_input=data, explicit_history={'two_plus_gold_spells_cast_this_game':two_plus_spells_cast},
                buckets=buckets, cards=rows,
                certified_minimum_monster_payment_for_survival=1 if buckets[0]['optimal_guaranteed_hp_bounds']==[0,0]
                    and buckets[1]['optimal_guaranteed_hp_bounds'][0]>0 else None,
                limitations=[
                    'All ordinary low-fee monsters included. Source survival lemmas are not complete-state simulation or automatic theorem proving.',
                    'Microwave empty-selection legality and Silence removal of Paralyze remain unknown; possible ties are retained.',
                    'Empty library, one current Play, no new enemy monsters, SOUL/artifacts/enchantments absent; no future natural draw.',
                    'One/two attack panels and declared enemy spell hands are conditional decisions, not matchup frequencies or constructed-deck win rates.',
                    'Kawkaw buffs the enemy to7/8. This endpoint guarantee does not price the later opportunity cost of that body.',
                ])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--panel', choices=list(PANELS), default='one_attack')
    parser.add_argument('--two-plus-spells-cast', type=int, required=True)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = certify(args.panel, two_plus_spells_cast=args.two_plus_spells_cast)
    text = json.dumps(result, ensure_ascii=False, indent=2)+'\n'
    if args.output: args.output.write_text(text)
    else: print(text, end='')


if __name__ == '__main__': main()