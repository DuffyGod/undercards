"""Living preconditions, paid order and a real later hand-buff outlet."""
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import conditional_card_score as score
import presence_magic_probe as probe

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,value):(HERE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def main():
    cards=score.score_cards.load_cards();by={c['id']:c for c in cards};bindings=score.source_bindings(ROOT/'presence_magic_probe.py')
    def scene(ids,cash,**extra):
        d=dict(hand_ids=ids,hand_costs=[by[i]['cost'] for i in ids],hand_base_costs=[by[i]['cost'] for i in ids],
            gold_before_play=cash,own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
            own_deck_ids=[],opponent_deck_ids=[],opponent_hand_ids=[],opponent_hand_known=True,opponent_gold_before_response=0,
            max_plays='all_physical',horizon='enemy_attack',node_limit=20000,
            enemy_bodies=[dict(card_id=270,attack=4,health=4,max_health=4,current_card_cost=3,base_cost=3,ready=True,slot=1)],
            physical_slots=True,front_slot_map=[0,1,2,3],front_missing_policy='fizzle',
            targeted_hand_empty='fizzle',targeted_hand_choice='eligible_targets')
        d.update(extra);return d
    hp=dict(kind='hp');win=copy.deepcopy(score.RESERVED['win'])
    def body(a,h):return dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=a,min_own_body_health=h))
    dogtasks=dict(hp=hp,body8_8=body(8,8),body8_4=body(8,4));birdtasks=dict(hp=hp,win=win)
    cases=[('dogs12',scene([46,47],12),1,dogtasks),('dogs11',scene([46,47],11),1,dogtasks),
        ('doga-alone12',scene([47],12),0,dogtasks),
        ('dogs-gem',scene([46,47],12,opponent_hand_ids=[598],opponent_hand_costs=[1],opponent_hand_base_costs=[1],opponent_gold_before_response=1),1,dogtasks),
        ('bird-dummy5',scene([1,116],5,own_player_hp=1,enemy_player_hp=4),1,birdtasks),
        ('bird-dummy4',scene([1,116],4,own_player_hp=1,enemy_player_hp=4),1,birdtasks),
        ('bird-tiny4',scene([196,116],4,own_player_hp=1,enemy_player_hp=4),1,birdtasks),
        ('bird-alone4',scene([116],4,own_player_hp=1,enemy_player_hp=4),0,birdtasks)]
    for transparent in (False,True):
        cases.append(('bird-taunt-'+str(transparent).lower(),scene([116],4,own_player_hp=1,enemy_player_hp=4,
            enemy_bodies=[dict(card_id=14,attack=4,health=5,max_health=5,current_card_cost=5,base_cost=5,
                taunt=True,transparency=transparent,slot=1)]),0,birdtasks))
    cases.append(('later-dog-outlet',scene([47,46,43],12,horizon='next_enemy_attack',next_max_plays='all_physical',
        next_own_gold_income=6,next_natural_draw_count=0,next_opponent_gold_income=0,next_opponent_natural_draw_count=0),2,dict(hp=hp,body7_7=body(7,7))))
    rows=[];pairs=[];queries=0
    for label,data,index,tasks in cases:
        values={}
        for name,task in tasks.items():
            result=probe.evaluate(data,task,cards=cards,focal_index=index);queries+=1;values[name]=result
            rows.append(dict(label=label,task=name,known=result['known'],feasible=result['feasible'],hp=result['guaranteed_player_hp'],
                states=result['search'].get('visited_states'),artifact=label+'.json',unknown=result['unknown']))
            if (label,name) in [('dogs12','hp'),('dogs-gem','body8_4'),('bird-dummy5','win'),('bird-taunt-true','win')]:
                other=probe.evaluate(dict(data,search_algorithm='exhaustive'),task,cards=cards,focal_index=index);queries+=1
                if result['known'] and other['known']:
                    assert tuple(result['search']['objective_vector'])==tuple(other['search']['objective_vector'])
                pairs.append(dict(label=label,task=name,alpha=result,exhaustive=other,
                    full_vector_match=result['known'] and other['known'] and result['search']['objective_vector']==other['search']['objective_vector']))
        write(label+'.json',dict(input=data,focal_index=index,tasks=tasks,results=values))
        print(json.dumps([r for r in rows if r['label']==label]),flush=True)
    write('vector-checks.json',pairs);pool=[]
    parent=ROOT/'research-runs/pool-frontier-v03'
    for cid in (46,47,116):
        cost=by[cid]['cost'];reference=next(parent.glob(f'native{cost}-card*.json'));raw=json.loads(reference.read_text())
        data=raw['input'];data.update(hand_ids=[cid],hand_costs=[cost],hand_base_costs=[cost])
        original=score.task_score(data,hp,cards=cards,focal_index=0);queries+=1;assert not original['known']
        values={}
        for name,task in raw['tasks'].items():values[name]=probe.evaluate(data,task,cards=cards,focal_index=0);queries+=1
        write(f'pool-card{cid}.json',dict(input=data,results=values,tasks=raw['tasks'],original_core_hp=original))
        pool.append(dict(card_id=cid,name=by[cid]['name'],scores={n:dict(known=r['known'],feasible=r['feasible'],hp=r['guaranteed_player_hp']) for n,r in values.items()}))
    assert bindings==score.source_bindings(ROOT/'presence_magic_probe.py')
    src=HERE/'source';src.mkdir(exist_ok=True)
    for name,h in bindings.items():assert sha(ROOT/name)==h;(src/name).write_bytes((ROOT/name).read_bytes())
    (HERE/'native-snapshot.json').write_bytes(score.score_cards.DEFAULT_SNAPSHOT.read_bytes())
    write('index.json',dict(source_hashes=bindings,source_stable=True,builder_sha256=sha(Path(__file__)),rows=rows,pool=pool,
        actual_queries=queries,vector_matches=sum(p['full_vector_match'] for p in pairs),prototype_only=True,production_unchanged=True,
        assumptions=['Status existence includes any living Taunt on either side, including Transparency; no server execution proof.',
            'Condition is sampled only when actual Magic resolves; later ally changes do not re-trigger it.'],
        limits=['Prototype not yet adopted into general production scorer or its card coverage.',
            'Dogamy drawn from library remains under the core held/draw callback guard until complete conditional Magic is registered.',
            'No empirical scene frequency, Gold or match-strength calibration.']))

if __name__=='__main__':main()