import copy
import unittest
import paid_board_tactics as paid
import score_cards


class ControlTimingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def test_conditional_paralyze_damage_reads_prior_status_and_source_amount(self):
        data=dict(hand_ids=[26],gold_before_play=4,own_player_hp=30,max_plays=1,
            enemy_bodies=[dict(card_id=15,attack=6,health=3,max_health=5,
                paralyze_owner_starts_remaining=2)],horizon='enemy_attack',objectives=['guaranteed_hp'])
        for damage,alive in ((2,1),(3,0)):
            cards=copy.deepcopy(self.cards)
            next(c for c in cards if c['id']==26)['effect_readable']= (
                'Magic: Paralyze a monster. If it was already Paralyzed, deal %d DMG to it.'%damage)
            result=paid.evaluate(data,cards)
            self.assertTrue(result['complete_in_declared_scope'],result['unknown'])
            self.assertEqual(result['objectives'][0]['metrics']['enemy_living_count'],alive)
            data_no_clock=copy.deepcopy(data)
            data_no_clock['enemy_bodies'][0]['paralyze_owner_starts_remaining']=0
            result=paid.evaluate(data_no_clock,cards)
            self.assertTrue(result['complete_in_declared_scope'],result['unknown'])
            self.assertEqual(next(u for u in result['objectives'][0]['endpoint_boards']['enemy']
                if u['health']>0)['health'],3)

    def test_unverified_reapplication_changes_real_guaranteed_hp(self):
        data=dict(hand_ids=[990,990],gold_before_play=2,own_player_hp=30,max_plays=1,
            next_max_plays=1,next_own_gold_income=0,current_turn_gold_spent_on_spells=0,
            enemy_bodies=[dict(card_id=15,attack=6,health=5)],horizon='next_enemy_attack',
            next_opponent_gold_income=0,next_opponent_natural_draw_count=0,
            objectives=['guaranteed_hp'])
        unknown=paid.evaluate(data,self.cards)
        self.assertFalse(unknown['complete_in_declared_scope'])
        self.assertTrue(any('reapplication' in s for s in unknown['unknown']))
        for rule,hp in (('refresh',30),('preserve',24)):
            result=paid.evaluate(dict(data,paralyze_reapplication=rule),self.cards)
            self.assertTrue(result['complete_in_declared_scope'],result['unknown'])
            self.assertEqual(result['objectives'][0]['metrics']['own_player_hp'],hp)
            self.assertEqual(result['rule_hypotheses'],['paralyze_reapplication='+rule])


if __name__=='__main__':unittest.main()