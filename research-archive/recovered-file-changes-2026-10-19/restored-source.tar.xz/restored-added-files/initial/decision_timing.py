"""Now versus next-own deployment at ONE fixed next-own deadline.

Waiting receives a real opponent reply first. Its later choice may observe that
reply, but it never receives a second reply/attack window as a free extra life.
"""
import copy
import math
import action_outcomes
import board_response
import combat_increment as combat
import coupled_magic as coupled
import deployment_routes as routes
import heuristic_contexts as contexts

VERSION='fixed-deadline-deployment-decision-0.1.0'


def _phi(raw,origin,reference):
    state=copy.deepcopy(raw)
    state['hp_delta']=state['own_player_hp']-origin['own_player_hp']
    state['enemy_hp_delta']=state['enemy_player_hp']-origin['enemy_player_hp']
    if 'actor' not in state:
        state['actor']=dict(attack=0,health=0,dodge=0,armor=False,taunt=False)
    terms=coupled._components(state,reference,origin['role'])
    terms['opponent_cash_utility']=0.
    return sum(terms.values())


def _endpoint(raw,origin,reference,scale,cost):
    return dict(own_player_dead=raw['own_player_hp']<=0,enemy_player_defeated=raw['enemy_player_hp']<=0,
        own_player_hp=raw['own_player_hp'],enemy_player_hp=raw['enemy_player_hp'],
        terminal=combat.terminal(raw),utility=None if combat.terminal(raw) else scale*_phi(raw,origin,reference)-cost,
        state=copy.deepcopy(raw))


def evaluate(card,ctx,reference,scale,scenario=None):
    if card['card_type']!='monster':
        return dict(version=VERSION,card_id=card['id'],unknown=['Fixed-deadline monster deployment only'],now=None,wait=None)
    scenario={} if scenario is None else scenario
    if not isinstance(scenario,dict) or not set(scenario)<={'next_income','next_condition_state_by_response','next_draw_count'}:
        raise ValueError('Timing scenario fields: next_income, next_condition_state_by_response, next_draw_count')
    income=scenario.get('next_income',contexts.base_income(ctx['own_turn']+1,ctx.get('second_player',False)))
    draw=scenario.get('next_draw_count',1)
    if type(income) not in (int,float) or not math.isfinite(income) or income<0:
        raise ValueError('Next income must be finite and nonnegative')
    if type(draw) is not int or draw<0:
        raise ValueError('Next draw count must be a nonnegative integer')
    weights=ctx['growth_response_weights'];unknown=[];hold=[];wait=[]
    for event,p in weights.items():
        if not p:continue
        raw=combat.state(0,0,ctx['enemy_bodies'],{},ctx['opponent_gold_before_response'],
            ctx['own_player_hp'],ctx['enemy_player_hp'],ctx.get('enemy_attack_limit',4))
        raw['external_allies']=copy.deepcopy(ctx['ally_bodies_before_play'])
        try:
            board_response.reply(raw,event)
        except ValueError as exc:
            unknown.append(dict(mode='hold',event=event,reason=str(exc)));continue
        baseline=_endpoint(raw,ctx,reference,scale,0)
        hold.append(dict(event=event,probability=p,endpoint=baseline))
        if baseline['terminal']:
            wait.append(dict(event=event,probability=p,endpoint=baseline,action_id='terminal_before_deployment',paid_gold=0));continue
        future=routes._next_context(ctx,raw,min(7,ctx['hand_size_before_play']+draw),ctx['gold_before_play']+income)
        future['own_turn']=ctx['own_turn']+1
        future['condition_state']=copy.deepcopy(scenario.get('next_condition_state_by_response',{}).get(event,{}))
        # At the deadline only current Magic/Haste is evaluated. Its simulated
        # later reply has zero probability and is discarded, not reweighted.
        candidate=action_outcomes.evaluate(card,future,reference,{'none':1})
        if not candidate['deployment_legal_now']:
            wait.append(dict(event=event,probability=p,endpoint=baseline,action_id='hold_unpayable_or_no_slot',paid_gold=0));continue
        if not candidate['window_known']:
            unknown.append(dict(mode='wait',event=event,reasons=candidate['window_unknown']))
        options=[dict(endpoint=baseline,action_id='hold',paid_gold=0)]
        for a in candidate['actions']:
            # Only immediate state is relevant; later-stage unknowns must not
            # erase a known immediate branch. Parser/target unknowns remain.
            current=a['paths'][0]['after_current']['state']
            options.append(dict(endpoint=_endpoint(current,ctx,reference,scale,card['cost']),action_id=a['action_id'],paid_gold=card['cost']))
        best=max(options,key=lambda a:(not a['endpoint']['own_player_dead'],a['endpoint']['enemy_player_defeated'],
            a['endpoint']['utility'] if a['endpoint']['utility'] is not None else -math.inf,-a['paid_gold']))
        wait.append(dict(event=event,probability=p,**best))
    current=action_outcomes.evaluate(card,ctx,reference,weights)
    if current['deployment_legal_now'] and not current['window_known']:
        unknown.append(dict(mode='now',reasons=current['window_unknown']))
    now=[]
    if current['deployment_legal_now']:
        for action in current['actions']:
            if not action['outcome_known']:continue
            endpoints=[dict(event=p['event'],probability=p['probability'],endpoint=_endpoint(
                p['after_later_attack']['state'],ctx,reference,scale,card['cost'])) for p in action['paths']]
            now.append(dict(action_id=action['action_id'],paths=endpoints,**_aggregate(endpoints,hold)))
    now_best=max(now,key=lambda a:(-a['death_probability'],a['defeat_probability'],a['net_model_gold'] if a['net_model_gold'] is not None else -math.inf)) if now else None
    wait_result=dict(paths=wait,**_aggregate(wait,hold)) if len(wait)==len(hold)==sum(p>0 for p in weights.values()) else None
    if any(u['mode']=='wait' for u in unknown) and wait_result:
        wait_result['known_paths_diagnostic_model_gold']=wait_result['net_model_gold'];wait_result['net_model_gold']=None
    return dict(version=VERSION,card_id=card['id'],name=card['name'],deadline_own_turn=ctx['own_turn']+1,
        next_income=income,next_draw_count=draw,now=now_best,now_actions=now,wait=wait_result,
        unknown=unknown,comparison_complete=not unknown,scale=scale,
        scope=['Both modes end at the same next-own decision deadline; waiting has no second enemy reply or later attack.',
            'Current action commits before hidden reply; wait target/action may use the observed reply at next own turn.',
            'One real cost, carried current balance plus declared next income, remaining body residual and HP changes counted once.',
            'No enemy new cards/turn income or extra allied attacks; this is a controlled scene trajectory, not a full opponent turn.',
            'Last-turn Need history after waiting is unknown unless supplied; current history is never copied forward.',
            'Natural draw changes hand capacity only; unknown drawn identity supplies no free playable option.'])


def _aggregate(paths,hold):
    death=sum(p['probability']*p['endpoint']['own_player_dead'] for p in paths)
    defeat=sum(p['probability']*p['endpoint']['enemy_player_defeated'] for p in paths)
    terminal=any(p['endpoint']['terminal'] for p in paths+hold)
    value=None if terminal else sum(p['probability']*p['endpoint']['utility'] for p in paths)-sum(p['probability']*p['endpoint']['utility'] for p in hold)
    return dict(death_probability=death,defeat_probability=defeat,net_model_gold=value,terminal_in_paired_window=terminal)