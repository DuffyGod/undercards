// Execute actual view selectors with a DOM substitute; no layout claim.
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const out=path.resolve(__dirname,'../../experiments/pool-frontier-v01');
const html=fs.readFileSync(path.join(out,'score-explorer.html'),'utf8');
const encoded=html.match(/<script type="application\/json" id="data">([\s\S]*?)<\/script>/)[1];
const data=JSON.parse(encoded),script=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
const raw=JSON.parse(fs.readFileSync(path.join(__dirname,'frontiers.json'),'utf8'));
class Element{
 constructor(tag='div'){this.tag=tag;this.children=[];this.value='';this.textContent='';this.checked=true;this.events={};this.classList={add:()=>{}};}
 append(...nodes){this.children.push(...nodes);if(this.tag==='select'&&!this.value&&nodes.length)this.value=nodes[0].value;}
 replaceChildren(...nodes){this.children=[];if(this.tag==='select')this.value='';this.append(...nodes);}
 addEventListener(name,fn){this.events[name]=fn;}
}
const ids={};
for(const id of ['data','scene','task','known','facts','summary','rows','count','links','detail'])ids[id]=new Element(['scene','task'].includes(id)?'select':'div');
ids.data.textContent=encoded;
const document={getElementById:id=>ids[id],createElement:tag=>new Element(tag)};
vm.runInNewContext(script,{document},{timeout:2000});
let renders=0,cells=0;
for(const group of data.groups){
 const source=raw.groups.find(g=>g.budget===group.budget&&g.label===group.label);
 assert.deepStrictEqual(group.rows,source.rows);
 ids.scene.value=group.key;ids.scene.events.change();
 for(const task of Object.keys(data.tasks)){
  ids.task.value=task;
  for(const known of [true,false]){
   ids.known.checked=known;ids.task.events.change();
   const rows=group.rows.filter(r=>!known||r.scores[task].known);
   assert.equal(ids.rows.children.length,rows.length);
   for(const tr of ids.rows.children){
    const card=rows.find(r=>tr.children[0].textContent===r.name+' #'+r.card_id);assert(card);
    const score=card.scores[task],expected=!score.known?'未知':score.guaranteed_player_hp!==null?(task==='hp'?'玩家 ':'用途成立 · 玩家 ')+score.guaranteed_player_hp+'HP':'不能保证';
    assert.equal(tr.children[2].textContent,expected);
    tr.events.click();const detail=JSON.parse(ids.detail.textContent);
    assert.equal(detail.card_id,card.card_id);assert.deepStrictEqual(detail.score,score);cells++;
   }
   renders++;
  }
 }
}
assert.equal(data.groups.length,10);assert.equal(data.groups.reduce((s,g)=>s+g.rows.length,0),572);
console.log(JSON.stringify({groups:10,candidate_context_rows:572,selector_renders:renders,score_cells_checked:cells,data_values_match:true,scope:'JavaScript DOM substitute; browser layout untested'}));