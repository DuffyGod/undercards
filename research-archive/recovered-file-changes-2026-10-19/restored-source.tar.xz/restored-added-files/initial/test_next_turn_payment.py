"""Physical payment and timing counterfacts, not empirical card calibration."""
from dataclasses import replace
import unittest
import paid_board_tactics as paid
import prove_idle_reply_bound as bounds
import score_cards


class NextPaymentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards = score_cards.load_cards()

    def scene(self, **changes):
        return dict(dict(hand_ids=[582], gold_before_play=3, max_plays=1,
            next_max_plays=1, next_own_gold_income=2, horizon='next_own_attack',
            current_turn_gold_spent_on_spells=0,
            condition_known_state={'last_turn_gold_spent_on_spells':1}), **changes)

    def next_turn(self, engine, state=None):
        return engine.boundary(engine.boundary(state or engine.root()))

    def test_carry_plus_income_once_and_fresh_turn_limit(self):
        e = paid.PaidSearch(self.cards, self.scene(hand_ids=[1,582], max_plays=1))
        first = next(s for a,s in e.deploys(e.root()) if a.get('card_id') == 1)
        self.assertEqual(list(e.deploys(first)), [])
        nxt = self.next_turn(e, first)
        self.assertEqual((nxt.gold,nxt.plays,nxt.next_income_credited), (4,0,2))
        action, body = next(iter(e.deploys(nxt)))
        self.assertEqual((action['card_id'],body.gold,body.hand), (582,0,()))
        end = e.boundary(body)
        self.assertEqual((end.gold,end.next_income_credited,end.current_paid_gold,end.next_paid_gold), (0,2,1,4))

    def test_actual_spell_history_overrides_root_both_directions_and_free(self):
        for paid_cost, expected in ((2,(3,True)),(0,(2,False))):
            e = paid.PaidSearch(self.cards,self.scene(hand_ids=[578,582],hand_costs=[paid_cost,4],
                gold_before_play=paid_cost+4,next_own_gold_income=0,
                condition_known_state={'last_turn_gold_spent_on_spells':0}))
            cast = next(s for a,s in e.deploys(e.root()) if a['kind'] == 'cast_spell')
            body = next(s for a,s in e.deploys(self.next_turn(e,cast)))
            self.assertEqual((body.own[0].attack,body.own[0].taunt),expected)
        e = paid.PaidSearch(self.cards,self.scene())
        body = next(s for a,s in e.deploys(self.next_turn(e)))
        self.assertEqual((body.own[0].attack,body.own[0].taunt),(2,False))

    def test_missing_earlier_current_spend_unknown_but_positive_payment_proves_need(self):
        data=self.scene(gold_before_play=4,next_own_gold_income=0)
        del data['current_turn_gold_spent_on_spells']
        e=paid.PaidSearch(self.cards,data)
        with self.assertRaisesRegex(paid.UnknownMechanic,'Need unknown'):
            list(e.deploys(self.next_turn(e)))
        data.update(hand_ids=[578,582],gold_before_play=6)
        e=paid.PaidSearch(self.cards,data)
        cast=next(s for a,s in e.deploys(e.root()) if a['kind']=='cast_spell')
        body=next(s for a,s in e.deploys(self.next_turn(e,cast)))
        self.assertEqual((body.own[0].attack,body.own[0].taunt),(3,True))

    def test_future_delay_resolves_after_source_dies(self):
        e=paid.PaidSearch(self.cards,self.scene(hand_ids=[580],gold_before_play=0,
            next_own_gold_income=3,own_player_hp=3,own_player_max_hp=30,
            own_dustpile_monsters=[dict(card_id=108,current_cost=6,base_cost=6)]*3))
        played=next(s for a,s in e.deploys(self.next_turn(e)))
        dead=replace(played,own=(replace(played.own[0],health=0),))
        dead=e.deaths(played,dead)
        end=e.boundary(dead)
        self.assertEqual((end.own_hp,end.delay_healed_hp,end.queued_delays),(8,5,()))

    def test_future_silence_queue_remains_unknown(self):
        e=paid.PaidSearch(self.cards,self.scene(hand_ids=[580,79],gold_before_play=4,
            max_plays=0,next_max_plays=2,next_own_gold_income=0,
            own_dustpile_monsters=[dict(card_id=108,current_cost=6,base_cost=6)]*3))
        played=next(s for a,s in e.deploys(self.next_turn(e)) if a['kind']=='deploy')
        with self.assertRaisesRegex(paid.UnknownMechanic,'queued Delay'):
            list(e.deploys(played))

    def test_fresh_charge_silence_differs_from_old_normal_attack(self):
        e=paid.PaidSearch(self.cards,self.scene(hand_ids=[9],gold_before_play=3,next_own_gold_income=0))
        old=next(s for a,s in e.deploys(e.root()))
        nxt=self.next_turn(e,old)
        self.assertEqual(e.silence(nxt.own[0],phase=2).ready,2)
        fresh=next(s for a,s in e.deploys(self.next_turn(e)))
        self.assertEqual(e.silence(fresh.own[0],phase=2).ready,0)

    def test_future_haste_is_monster_only_and_normal_fresh_body_cannot_attack(self):
        e=paid.PaidSearch(self.cards,self.scene(hand_ids=[438],gold_before_play=0,next_own_gold_income=4,
            enemy_bodies=[dict(attack=0,health=5)],current_turn_gold_spent_on_spells=1))
        body=next(s for a,s in e.deploys(self.next_turn(e)))
        self.assertEqual(body.own[0].attack,5)
        actions=list(e.attacks(body))
        self.assertEqual(len(actions),1)
        self.assertNotEqual(actions[0][0]['target'],'face')
        e=paid.PaidSearch(self.cards,self.scene(hand_ids=[15],gold_before_play=0,next_own_gold_income=5))
        body=next(s for a,s in e.deploys(self.next_turn(e)))
        self.assertEqual(list(e.attacks(body)),[])

    def test_drawn_card_can_be_paid_but_burned_card_cannot(self):
        e=paid.PaidSearch(self.cards,self.scene(hand_ids=[],gold_before_play=0,next_own_gold_income=3,
            own_deck_ids=[9],next_natural_draw_count=1))
        nxt=self.next_turn(e)
        self.assertEqual([a['card_id'] for a,s in e.deploys(nxt)],[9])
        e=paid.PaidSearch(self.cards,self.scene(hand_ids=[1]*7,gold_before_play=0,next_own_gold_income=3,
            own_deck_ids=[9],next_natural_draw_count=1))
        nxt=self.next_turn(e)
        self.assertEqual(nxt.own_cards_burned,1)
        self.assertTrue(all(a.get('card_id')!=9 for a,s in e.deploys(nxt)))

    def test_deck_need_does_not_reuse_pre_draw_observation(self):
        e=paid.PaidSearch(self.cards,self.scene(hand_ids=[468],gold_before_play=0,next_own_gold_income=4,
            own_deck_ids=[578],next_natural_draw_count=1,
            condition_known_state={'remaining_deck':[dict(identity=578,generated=False,card_type='spell')]}))
        with self.assertRaisesRegex(paid.UnknownMechanic,'Need unknown'):
            list(e.deploys(self.next_turn(e)))

    def test_unknown_becomes_affordable_and_fatigue_death_cannot_be_healed(self):
        e=paid.PaidSearch(self.cards,self.scene(hand_ids=[17],gold_before_play=0,next_own_gold_income=100))
        with self.assertRaisesRegex(paid.UnknownMechanic,'Reachable next-turn card 17'):
            list(e.deploys(self.next_turn(e)))
        r=paid.evaluate(self.scene(hand_ids=[22],gold_before_play=0,next_own_gold_income=3,
            own_player_hp=1,own_player_max_hp=30,own_deck_ids=[],own_fatigue_next=1,
            next_natural_draw_count=1,objectives=['guaranteed_hp']),self.cards)
        self.assertTrue(r['complete_in_declared_scope'],r['unknown'])
        self.assertEqual(r['objectives'][0]['metrics']['own_player_hp'],0)
        self.assertFalse(any(a['kind']=='deploy' for a in r['objectives'][0]['principal_variation']))

    def test_old_negative_clear_certificate_refuses_future_play_scope(self):
        result=bounds.prove(self.scene())
        self.assertFalse(result['bound_complete'])
        self.assertIsNone(result['any_policy_can_guarantee_clear'])

    def test_future_income_must_be_explicit(self):
        data=self.scene();del data['next_own_gold_income']
        with self.assertRaisesRegex(ValueError,'explicit'):
            paid.PaidSearch(self.cards,data)


if __name__=='__main__':unittest.main()