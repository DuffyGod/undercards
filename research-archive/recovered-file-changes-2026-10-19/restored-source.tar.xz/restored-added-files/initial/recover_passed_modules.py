"""Carry only completed unaffected modules from a one-failure unittest run.

No test is run here. The entire failed module is excluded. The original failed
receipt/log stay immutable; a later runner must rerun every excluded module.
"""
import hashlib
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    path=HERE/'selective-regression.json';original=json.loads(path.read_text());log=Path(original['test_log']);text=log.read_text()
    assert not original['passed'] and original['source_unchanged_during_run'] and original['exit_code']==1
    counts=re.search(r'Ran (\d+) tests in [\d.]+s',text);assert counts and int(counts[1])==original['test_count']
    expected=sum(r['test_count'] for r in original['actual_retested']);assert expected==original['test_count']
    failures=re.findall(r'^(?:FAIL|ERROR): \S+ \((\w+)\.[^)]+\)$',text,re.M)
    summary=re.search(r'^FAILED \(([^)]+)\)$',text,re.M);assert summary
    items=dict((key,int(n)) for key,n in re.findall(r'(failures|errors)=(\d+)',summary[1]))
    assert sum(items.values())==len(failures)>0
    assert not re.search(r'skipped|expected failure|unexpected success|_FailedTest|KeyboardInterrupt|SystemExit',text,re.I)
    failed=set(failures);all_modules={r['module'] for r in original['actual_retested']}
    assert failed<=all_modules
    preserved=[r for r in original['actual_retested']+original['reused_unchanged'] if r['module'] not in failed]
    sources={}
    for row in preserved:
        for name,h in row['source_hashes'].items():
            assert name not in sources or sources[name]==h;sources[name]=h
    excluded=[r for r in original['actual_retested'] if r['module'] in failed]
    # This observed single test-expectation correction must have a private leaf
    # source. If a failed test module is imported by another module, its source
    # cannot be safely erased to trigger a selective rerun; fail instead.
    for row in excluded:assert row['module']+'.py' not in sources
    result=dict(passed=True,source_unchanged_during_run=True,source_hashes=sources,
        tests_executed=False,test_count=0,current_source_test_coverage=sum(r['test_count'] for r in preserved),
        successful_modules=preserved,excluded_modules=excluded,
        original_failed_receipt_sha256=sha(path),original_failed_log_sha256=sha(log),
        original_failed_receipt=str(path),no_new_tests_executed=True,
        interpretation='Only completed modules without a reported unittest failure/error are reusable. This derived subset is not a passed whole-suite receipt. Failed modules and their leaf test source are absent and must be rerun.')
    (HERE/'passed-subset.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(reusable_modules=len(preserved),reusable_tests=result['current_source_test_coverage'],excluded=sorted(failed))))

if __name__=='__main__':main()