"""Pin finished evidence and a complete current local Python source snapshot.

Historical before-* directories retain their own manifests. Their receipts
are referenced rather than relabelled with the current source snapshot.
"""
import argparse
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('roots',nargs='+',type=Path)
    args=parser.parse_args()
    for root in args.roots:
        root=root.resolve()
        if not root.is_relative_to(HERE/'research-runs'):raise ValueError('Research evidence directories only')
        receipt=root/'frozen-receipt.json'
        if receipt.exists():raise ValueError('Already frozen; verify or create a new version, do not overwrite')
        source=root/'source';source.mkdir(exist_ok=True)
        for p in HERE.glob('*.py'):(source/p.name).write_bytes(p.read_bytes())
        files={};historical={}
        for p in sorted(root.rglob('*')):
            rel=p.relative_to(root)
            if '__pycache__' in rel.parts:continue
            if any(part.startswith('before-') for part in rel.parts):
                if p.is_file() and p.name=='frozen-receipt.json':historical[str(rel)]=sha(p)
                continue
            if p.is_file() and p!=receipt:files[str(rel)]=sha(p)
        receipt.write_text(json.dumps(dict(source_model='paid0.27',artifact_sha256=files,
            current_source_sha256={p.name:sha(p) for p in sorted(source.glob('*.py'))},
            historical_receipt_sha256=historical,
            scope='Current sources and named exact files. Historical failed runs remain evidence of failures; source snapshot does not relabel them passed.'),indent=2)+'\n')
        print(json.dumps(dict(root=str(root.relative_to(HERE)),files=len(files),source_files=len(list(source.glob('*.py'))))))


if __name__=='__main__':main()