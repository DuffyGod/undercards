"""Compare one physical hand slot with identical background, cash and horizon.

This is a conditional replacement experiment, not a deck win-rate estimator.
Playing the candidate is optional; remaining cash and other physical copies
are searched normally. Unknown candidates remain in the comparison.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path

import paid_board_tactics as paid
import score_cards

VERSION = 'conditional-physical-slot-replacement-0.1.0'


def compare(config, cards=None):
    cards = score_cards.load_cards() if cards is None else cards
    by_id = {c['id']: c for c in cards}
    scene = copy.deepcopy(config['scene'])
    forbidden = {'hand_ids', 'hand_costs', 'hand_base_costs', 'hand_silenced',
                 'objectives', 'purpose_constraints'}
    if forbidden.intersection(scene):
        raise ValueError('scene must omit hand and objective fields')
    if 'gold_before_play' not in scene:
        raise ValueError('A common explicit cash budget is required')
    if scene.get('next_natural_draw_count') != 0 or scene.get('own_deck_ids', []) != []:
        raise ValueError('This replacement scope requires no own future draw and an empty own library')
    background = config['background_hand']
    if not isinstance(background, list) or len(background) > 6:
        raise ValueError('At most six background physical hand copies')
    for held in background:
        if not isinstance(held, dict) or set(held) != {'card_id', 'current_cost', 'base_cost'}:
            raise ValueError('Every background copy needs card_id, current_cost and base_cost')
        if held['card_id'] not in by_id:
            raise ValueError('Unknown background card')
    ids = config['candidate_ids']
    if not isinstance(ids, list) or not ids or len(set(ids)) != len(ids):
        raise ValueError('Nonempty unique candidate IDs required')
    if any(cid not in by_id or by_id[cid]['card_type'] != 'monster'
           or by_id[cid]['pool_category'] != 'ordinary_non_token' for cid in ids):
        raise ValueError('Candidates must be native ordinary monsters')
    purposes = config.get('purposes', {})
    if not isinstance(purposes, dict):
        raise ValueError('purposes must be an object')
    rows = []
    for cid in ids:
        card = by_id[cid]
        data = dict(copy.deepcopy(scene),
            hand_ids=[h['card_id'] for h in background]+[cid],
            hand_costs=[h['current_cost'] for h in background]+[card['cost']],
            hand_base_costs=[h['base_cost'] for h in background]+[card['cost']])
        searches = {'guaranteed_hp': paid.evaluate(dict(data, objectives=['guaranteed_hp']), cards)}
        searches.update({name: paid.evaluate(dict(data, objectives=['purpose'],
            purpose_constraints=constraints), cards) for name, constraints in purposes.items()})
        values = {name: (out['objectives'][0]['metrics']['own_player_hp'] if name == 'guaranteed_hp'
            else out['objectives'][0]['purpose_guaranteed']) if out['complete_in_declared_scope']
            else None for name, out in searches.items()}
        choices = {}
        for name, out in searches.items():
            pv = out['objectives'][0]['principal_variation'] if out['complete_in_declared_scope'] else []
            actions = [a for a in pv if a.get('kind') == 'deploy'
                       and a.get('hand_index') == len(background) and a.get('phase') in (0, 2)]
            choices[name] = dict(candidate_deployment_in_one_worst_path=actions,
                candidate_not_deployed_in_one_worst_path=not actions if out['complete_in_declared_scope'] else None,
                diagnostic_only=True)
        rows.append(dict(card_id=cid, name=card['name'], printed_cost=card['cost'],
            source_text=card['effect_readable'], input=data, values=values,
            searches=searches, path_diagnostics=choices))
    pairs = []
    for left in rows:
        for right in rows:
            if left['card_id'] == right['card_id']:
                continue
            common = {k for k in left['values'] if left['values'][k] is not None and right['values'][k] is not None}
            hp_gap = left['values']['guaranteed_hp']-right['values']['guaranteed_hp'] if 'guaranteed_hp' in common else None
            pairs.append(dict(candidate=left['card_id'], alternative=right['card_id'],
                guaranteed_hp_difference=hp_gap,
                uniquely_guaranteed_purposes=[k for k in purposes if k in common and left['values'][k] and not right['values'][k]],
                unresolved_objectives=[k for k in left['values'] if k not in common],
                no_worse_in_all_measured_objectives=all(left['values'][k] >= right['values'][k] for k in common)
                    if len(common) == len(left['values']) else None))
    root = Path(__file__).resolve().parent
    return dict(version=VERSION, config=copy.deepcopy(config), rows=rows, pairwise_comparisons=pairs,
        source_hashes={name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in
            ('compare_replacement_slots.py', 'paid_board_tactics.py', 'board_tactics.py', 'alpha_beta_search.py')},
        cards_canonical_sha256=hashlib.sha256(json.dumps(cards, sort_keys=True, ensure_ascii=False,
            separators=(',', ':')).encode()).hexdigest(),
        limitations=[
            'Each candidate occupies the same already-drawn physical hand slot; background copies, observed cash and all other root fields match.',
            'Candidates have their own native prices; their cash budgets are identical. Declining to play or waiting until future own play is legal.',
            'Enemy physical response menu is explicitly known; no hidden-hand or unobserved future own-deck order is averaged into these values.',
            'HP and each purpose are separately optimized; differences do not combine into one executable multi-objective policy.',
            'Printed deployment in one worst path is a diagnostic, not a deployment probability or a complete adaptive policy.',
            'Unresolved comparisons remain null; measured dominance is only within the supplied objectives and candidate set.',
            'This is conditional drawn-slot substitution, not full deck construction opportunity cost, empirical frequency, win rate or Gold.'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = compare(json.loads(args.input.read_text()))
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps([dict(card_id=r['card_id'], values=r['values']) for r in result['rows']]))


if __name__ == '__main__':
    main()