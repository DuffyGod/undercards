"""Conditional deployment measurements, not whole-game scores or enemy search.

Shared observed state and real cash for Jevil/Papyrus/Undyne. Independent
literal arithmetic was reviewed before the comparisons; no LLM prices enter.
"""
import hashlib
import importlib.util
import json
from pathlib import Path

import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'research-runs/card-profiles-v01'
BY={c['id']:c for c in score_cards.load_cards()}


def arithmetic():
    p=OUT/'high_cost_probe.py'
    spec=importlib.util.spec_from_file_location('independent_high_cost',p)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m


def body(attack,health):
    return {'attack':attack,'health':health}


def measured(cid,mode,paid,cash,kills,remaining,own,hero_damage=0,uncertainties=None):
    return dict(card_id=cid,name=BY[cid]['name'],mode=mode,paid=paid,cash_remaining=cash-paid,
        immediate_enemy_kills=kills,enemy_remaining=remaining,own_living_bodies=own,
        own_total_attack=sum(x['attack'] for x in own),own_total_health=sum(x['health'] for x in own),
        immediate_hero_damage=hero_damage,
        single_body_4atk_3hp=any(x['attack']>=4 and x['health']>=3 for x in own),
        uncertainties=uncertainties or [])


def jevil(enemies,cash):
    if cash<11:return []
    rows=[measured(444,'Tail',11,cash,0,enemies,[body(8,9)])]
    alive=[dict(e,health=e['health']-3) for e in enemies if e['health']>3]
    rows.append(measured(444,'Spade (empty own board before play)',11,cash,len(enemies)-len(alive),alive,[body(7,7)],3))
    # Each random outcome stays separate. No invented uniform probability.
    for i in range(len(enemies)):
        rows.append(measured(444,f'Devil random target {i}',11,cash,1,enemies[:i]+enemies[i+1:],[body(7,7)]))
    return rows


def papyrus(m,enemies,cash):
    if cash<11:return []
    p=m.papyrus_sequences(enemies,cash)
    rows=[]
    for s in p['sequences']:
        attacked=s.get('steps',[]);remaining=[dict(e) for e in enemies]
        killed=[]
        for step in attacked:
            i=step['target_index'];remaining[i]['health']-=6
            if remaining[i]['health']<=0:killed.append(i)
        remaining=[e for e in remaining if e['health']>0]
        rows.append(measured(60,'monster chain '+str(s['order']),p['paid'],cash,len(killed),remaining,
            [body(6,s['own_hp'])] if s['alive'] else []))
    rows.append(measured(60,'first Charge attacks hero',p['paid'],cash,0,enemies,[body(6,9)],6))
    return rows


def undyne(m,enemies,cash):
    if cash<12:return []
    rows=[]
    for i,r in enumerate(m.undyne_outcomes(enemies)):
        n=r['unspent_instances'];own=[body(7,8)]+([body(n,n)] if n>0 else [])
        rows.append(measured(62,'lowest-HP pings outcome '+str(i),12,cash,len(enemies)-len(r['enemy_remaining']),
            r['enemy_remaining'],own,uncertainties=[] if n else ['0/0 Spear entry/death not server-verified; recorded living body excludes0HP.']))
    return rows


def row_summary(cid,rows):
    mine=[r for r in rows if r['card_id']==cid]
    if not mine:return {'deployable':False,'card_id':cid}
    # Jevil's random Devil cannot select a particular outcome. In this no-armor
    # domain every Devil outcome kills exactly1, so max kill is attainable.
    maxkills=max(r['immediate_enemy_kills'] for r in mine)
    clear=[r for r in mine if r['immediate_enemy_kills']==maxkills]
    return dict(deployable=True,card_id=cid,name=BY[cid]['name'],max_immediate_kills=maxkills,
        max_kills_with_living_body=max((r['immediate_enemy_kills'] for r in mine if r['own_living_bodies']),default=0),
        max_kills_with_single_4_3=max((r['immediate_enemy_kills'] for r in mine if r['single_body_4atk_3hp']),default=0),
        max_face_damage=max(r['immediate_hero_damage'] for r in mine),
        maxkill_examples=clear[:3],
        note='Each maximum is a separate purpose; do not concatenate their modes into one policy.')


def build():
    m=arithmetic()
    def units(cid,n):return [m.unit(cid) for _ in range(n)]
    cases=[('empty_safe',[],13),('four_native_rock_3hp',units(602,4),13),
        ('four_rock_hp_plus1',[dict(e,health=4) for e in units(602,4)],13),
        ('four_native_tiny',units(196,4),13),('one_native_aaron',units(15,1),13),
        ('three_native_rock',units(602,3),13),('rock_cash11',units(602,4),11),
        ('rock_cash12',units(602,4),12),
        ('single_hp6',[dict(card_id=-1,attack=6,health=6)],13),
        ('single_hp7',[dict(card_id=-1,attack=6,health=7)],13)]
    results={}
    for name,enemies,cash in cases:
        rows=jevil(enemies,cash)+papyrus(m,enemies,cash)+undyne(m,enemies,cash)
        results[name]=dict(cash=cash,enemy=enemies,measurements=rows,
            purpose_summaries=[row_summary(cid,rows) for cid in (444,60,62)])
    def val(case,cid,key):
        return next(x[key] for x in results[case]['purpose_summaries'] if x['card_id']==cid)
    # Fixed expectations, independent of measured-selection code.
    assert val('four_native_rock_3hp',444,'max_kills_with_single_4_3')==4
    assert val('four_native_rock_3hp',60,'max_kills_with_living_body')==4
    assert val('four_native_rock_3hp',60,'max_kills_with_single_4_3')==3
    assert val('four_native_rock_3hp',62,'max_immediate_kills')==3
    assert val('four_rock_hp_plus1',444,'max_immediate_kills')==1
    assert val('four_rock_hp_plus1',60,'max_kills_with_living_body')==4
    assert val('four_rock_hp_plus1',62,'max_immediate_kills')==2
    assert val('rock_cash11',60,'max_kills_with_living_body')==2
    assert val('rock_cash12',60,'max_kills_with_living_body')==2
    assert val('single_hp6',60,'max_immediate_kills')==1
    assert val('single_hp7',60,'max_immediate_kills')==0
    assert val('empty_safe',60,'max_face_damage')==6
    assert val('empty_safe',444,'max_face_damage')==3
    assert val('empty_safe',62,'max_face_damage')==0
    out=dict(version='conditional-card-profile-comparison-0.1.0',
        source_snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        source_program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        independent_arithmetic_sha256=hashlib.sha256((OUT/'high_cost_probe.py').read_bytes()).hexdigest(),
        domain={'own_board_before':[], 'own_player_health':30,'board_capacity':4,'targets':'native plain or declared body interventions',
            'excluded':'Armor/Dodge/Taunt/Transparency/Dust/other callbacks on enemy; enemy next reply; SOUL/artifacts; unknown generation/draw',
            'Jevil':'one selected deterministic effect; Devil outcomes separate; no Club/Diamond/Heart utility priced',
            'cast_assumption':'selected weapon cast free as source wording interpretation, not server verified',
            'Papyrus':'Program auto payment when affordable; may stop chain; face attack cannot follow monster chain',
            'Undyne':'adaptive lowest currentHP; all tied outcomes; no defenses, skipped hits = actual missing damage'},
        cases=results,assertions_passed=14,whole_tactical_search=False,final_gold=None,
        conclusion='Changing purpose or oneHP/cash reverses useful recommendations; no global card ranking identified.')
    (OUT/'conditional-comparison.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    lines=['# 三张高费卡的同预算条件数值比较','',
        '同一可观察敌场、己方空场、现金13G；目标无减伤/嘲讽/死亡回调。所有计算是当次部署端点，不含敌方下一轮回应。Jevil选定武器免费施放、Papyrus Program可付自动支付是公开的源文解释。未知随机法术、抽牌收益没有定价。','',
        '| 敌场/条件 | Jevil | Papyrus | Undyne |','|---|---|---|---|']
    labels={'empty_safe':'安全空场','four_native_rock_3hp':'四只原生3/3 Rock','four_rock_hp_plus1':'仅RockHP3→4','four_native_tiny':'四只原生1/1 Tiny',
        'one_native_aaron':'一只原生6/5 Aaron','three_native_rock':'三只原生3/3 Rock','rock_cash11':'四Rock，现金11G',
        'rock_cash12':'四Rock，现金12G','single_hp6':'一只6/6无文字体','single_hp7':'仅敌HP6→7'}
    for name,r in results.items():
        cells=[]
        for s in r['purpose_summaries']:
            if not s['deployable']:cells.append('付不起');continue
            cells.append(f"即时杀{s['max_immediate_kills']}；保活体杀{s['max_kills_with_living_body']}；保同一≥4/3体杀{s['max_kills_with_single_4_3']}")
        lines.append('| '+labels[name]+' | '+' | '.join(cells)+' |')
    lines+=['','这些是分别优化的目的，不能把最大杀数、打脸与身体拼成同一次行动。四Rock3HP时Jevil Spade清4并留7/7；Papyrus清4只能留6/1，若要求同一体至少4/3则必须停在杀3、余3HP；Undyne十伤只能清3，第四只剩2HP。仅将各RockHP加1，Jevil最可靠的即时杀数降到1（Devil），Papyrus仍能清4，Undyne降到2。',
        '', '安全空场发展：Jevil Tail一体8/9；Undyne两体7/8与10/10，总17/18，占两格；Papyrus支付13G后6/9 Armor并可首次打脸6。发展、保护单体和即时终结不能以总身材统一排序。',
        '', '携带判断需要这些窗口相对卡位替代的发生频率。可持有牌，不强制无效果出场，不扣未花掉的印刷费用；尚不能把本表改写为环境平均Gold或胜率。14个固定反事实断言通过，详细合法行动记录见JSON。']
    (OUT/'conditional-comparison.md').write_text('\n'.join(lines)+'\n')
    return out


if __name__=='__main__':
    result=build();print(json.dumps(dict(cases=len(result['cases']),assertions_passed=result['assertions_passed'])))