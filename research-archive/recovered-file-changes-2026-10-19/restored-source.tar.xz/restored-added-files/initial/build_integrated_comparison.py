"""Real cards, shared hand constraints and numerical counterfactuals."""
import copy
import csv
import gzip
import hashlib
import json
from pathlib import Path

import evaluate_situation as situation
import joint_window_quote as joint
import score_cards as base

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/integrated-window-v02'


def scene(name,hand,cash=12,hp=30,enemies=None,allies=None,response='enemy_face',**extra):
    return dict(context_id=name,hand_ids=hand,role='midrange',own_turn=5,
        gold_before_play=cash,opponent_gold_before_response=0,own_player_hp=hp,enemy_player_hp=30,
        ally_bodies_before_play=[] if allies is None else allies,
        enemy_bodies=[] if enemies is None else enemies,
        condition_state={'last_turn_gold_spent_on_spells':0},response_weights={response:1},**extra)


def inputs():
    lethal=[dict(attack=6,health=6),dict(attack=3,health=3)]
    glass=[dict(attack=6,health=4),dict(attack=3,health=3)]
    return [
        scene('common_4_4',[15,166,650,932],enemies=[dict(attack=4,health=4)]),
        scene('damage_haste_cash7',[96,438],7,5,lethal),
        scene('damage_haste_cash6',[96,438],6,5,lethal),
        scene('gemstone_haste_cash5',[598,438],5,5,glass),
        scene('gemstone_haste_cash4',[598,438],4,5,glass),
        scene('full_board_taunt_strength',[76,15],8,1,[dict(attack=4,health=5),dict(attack=3,health=3)],
            [dict(attack=4,health=4,taunt=True)]+[dict(attack=0,health=1) for _ in range(3)]),
        scene('fortune_safe',[81],response='none'),
        dict(scene('fortune_unlocks_chip',[81],allies=[dict(attack=4,health=4)],response='chip'),opponent_gold_before_response=1),
        scene('empty_broken_car_partner',[649,15],11),
        scene('early_need_history_missing',[438,582],4,30,[dict(attack=3,health=3)],timing_scenario={}),
        scene('current_turn_end_rescue',[197,509],10,5,[dict(attack=7,health=5)],
            callback_state={'own_player_max_hp':30}),
        scene('late_tree_eye_products',[307,385],8,response='none',
            lifecycle_scenario=dict(deadline_tick=13,discount_rate_per_tick=0,
                branches=[dict(event='none',probability=1)],draw_counts={'6':1,'7':1},generated_use_caps={'6':1,'7':1})),
    ]


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    cards=base.load_cards();ref,_=base.make_reference(cards);by={c['id']:c for c in cards}
    results=[];rows=[]
    for data in inputs():
        (OUT/(data['context_id']+'.input.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        result=situation.evaluate(data,ref,cards)
        results.append(result)
        best=result['deployment_routes']['best_known_survival_route']
        for c,w,q in zip(data['hand_ids'],result['action_windows'],result['finite_window_quotes']):
            rows.append(dict(scene=data['context_id'],card_id=c,name=by[c]['name'],cash=data['gold_before_play'],
                deployment_legal=w['deployment_legal_now'],action_window_known=w['window_known'],
                single_death=w['death_probability'],hold_death=result['hand_survival']['hold_death_probability'],
                best_route_death=best['death_probability'] if best else None,
                best_route_payment=best['actual_paid_gold'] if best else None,
                best_route=best['action_id'] if best else None,
                finite_net=q.get('model_gold') if by[c]['card_type']=='spell' else q.get('net_margin_model_gold')))
    normalization=joint.make_normalization(ref,reply_policy='allied_board')
    parsed_pool=json.loads((OUT/'monster-pool.json').read_text())
    closed=[by[r['card_id']] for r in parsed_pool['scores'] if r['pricing_supported']]
    counterfactuals=[]
    for c in closed:
        before=joint.score(c,ref,normalization,True)
        for field,delta in [('attack',1),('health',1),('cost',-1)]:
            if field=='cost' and c['cost']==0:continue
            changed=copy.deepcopy(c);changed[field]+=delta
            after=joint.score(changed,ref,normalization,True)
            pairs=zip(before['context_rows'],after['context_rows'])
            known=[(a,b) for a,b in pairs if a['pricing_supported'] and b['pricing_supported']]
            negative=[dict(context_id=a['context_id'],delta=b['net_margin_model_gold']-a['net_margin_model_gold'])
                      for a,b in known if b['net_margin_model_gold']-a['net_margin_model_gold'] < -1e-10]
            counterfactuals.append(dict(card_id=c['id'],name=c['name'],change=field,delta=delta,
                both_fully_priced=before['pricing_supported'] and after['pricing_supported'],
                panel_net_delta=after['net_margin_model_gold']-before['net_margin_model_gold'] if before['pricing_supported'] and after['pricing_supported'] else None,
                paired_known_context_count=len(known),negative_contexts=negative))
    sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in HERE.glob('*.py')}
    sources['snapshot.json']=hashlib.sha256(base.DEFAULT_SNAPSHOT.read_bytes()).hexdigest()
    summary=dict(version=situation.VERSION,source_sha256=sources,scale=normalization['scale'],
        scenes=len(results),rows=rows,numeric_counterfactuals=counterfactuals)
    (OUT/'comparison.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    with gzip.open(OUT/'situation-traces.json.gz','wt',encoding='utf-8') as f:
        json.dump(results,f,ensure_ascii=False)
    with (OUT/'comparison.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(json.dumps(dict(scenes=len(results),card_rows=len(rows),counterfactuals=len(counterfactuals),
        negative_context_variants=sum(bool(r['negative_contexts']) for r in counterfactuals),scale=normalization['scale'])))


if __name__=='__main__':main()