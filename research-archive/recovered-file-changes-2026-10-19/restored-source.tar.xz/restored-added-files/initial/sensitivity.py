"""Directed threshold interventions; no invented meta frequencies."""
import copy
import gzip
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]; sys.path.insert(0, str(ROOT))
import survival_pressure as pressure
from benchmark import cards, by, scene, stripped, DECLARED
P = Path(__file__).parent; OUT = P/'sensitivity'; OUT.mkdir(exist_ok=True)
bindings = pressure.score.source_bindings(ROOT/'survival_pressure.py')
cases = [(163, 'enemy_attack', n) for n in (1,3,4,5)] + [(526, 'enemy_attack', n) for n in (1,3,5)] + [(17, 'enemy_health', n) for n in (1,5)]
rows = []; calls = 0
for cid, field, n in cases:
    base = scene(cid, 'small')
    if field == 'enemy_attack': base['enemy_bodies'][0]['attack'] = n
    else: base['enemy_bodies'][0].update(health=n, max_health=n)
    for variant in ('unresolved', 'declared', 'removed'):
        data = copy.deepcopy(base); source = cards
        if variant == 'declared': data['combat_event_rules'] = DECLARED
        if variant == 'removed':
            c = stripped(by[cid]); data['hand_ids'] = [c['id']]; source = cards+[c]
        result = pressure.evaluate(data, floors=[1,11,15], focal_index=0, cards=source)
        file = f'card{cid}-{field}{n}-{variant}.json.gz'
        with gzip.open(OUT/file, 'wt') as f: json.dump(dict(scenario=data, result=result), f)
        rows.append(dict(card_id=cid, name=by[cid]['name'], field=field, value=n, variant=variant,
                         frontier=result['frontier'], complete_sampled_floors=result['complete_sampled_floors'],
                         maximum_survival=result['maximum_survival']['guaranteed_player_hp'], artifact=file))
        calls += result['core_search_calls']
        print(cid, field, n, variant, result['frontier'], result['complete_sampled_floors'], flush=True)
assert bindings == pressure.score.source_bindings(ROOT/'survival_pressure.py')
(OUT/'index.json').write_text(json.dumps(dict(source_hashes=bindings, rows=rows,
    actual_core_calls=calls, hypotheses=DECLARED, scope='One public numeric parameter changed from the small scene; all other resources identical. Declared rules are not server verified.'), ensure_ascii=False, indent=2)+'\n')