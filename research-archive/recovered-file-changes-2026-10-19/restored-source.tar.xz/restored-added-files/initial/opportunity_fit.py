"""A separate opportunity/hand-coverage axis on shared observable situations.

Keep whole-card quotes intact. Coverage is the union of affordable useful
actions in the same situation, never a product of independent card events.
Unknown abilities yield bounds, not invented bad-state scores. A no-play action
has zero current resource surplus; its strategic tempo/HP cost is unpriced.
"""
from __future__ import annotations

import copy
import json
import math

import context_value as ledger
import heuristic_contexts as contexts

VERSION='opportunity-and-hand-coverage-0.1.0'


def _validate_states(states):
    if not states or len({s['context_id'] for s in states})!=len(states):
        raise ValueError('Supply unique shared situation IDs')
    weights=[s['weight'] for s in states]
    if any(type(w) not in (int,float) or not math.isfinite(w) or w<0 for w in weights) or abs(sum(weights)-1)>1e-9:
        raise ValueError('Shared situation weights must sum to one; never renormalize favorable states')


def quote_now(card, state, reference):
    """Conditional current deployment quote; legal cash status is independent."""
    modules,unknown=ledger.parse(card)
    choices=[]
    for branch in contexts.enumerate_choice_branches(modules):
        selected=[modules[i] for i in branch['selected_module_indexes']]
        try:
            result=ledger.evaluate_branch(card,state,selected,reference,quote_only=True)
            choices.append({'gross_model_gold':result['gross_model_gold'],
                            'net_model_gold':result['gross_model_gold']-card['cost'],
                            'activation_conditions':result.get('activation_conditions',[]),
                            'choice_selection':branch['choice_selection']})
        except ValueError as exc:
            unknown.append(str(exc))
    best=max(choices,key=lambda r:r['net_model_gold']) if choices else None
    return {'card_id':card['id'],'name':card['name'],'nominal_cost':card['cost'],
            'payable_now':card['cost']<=state['gold_before_play'],
            'pricing_supported':not unknown and best is not None,
            'gross_model_gold':best['gross_model_gold'] if best and not unknown else None,
            'net_model_gold':best['net_model_gold'] if best and not unknown else None,
            'known_terms_diagnostic_not_lower_bound':best['net_model_gold'] if best else None,
            'activation_conditions':best.get('activation_conditions',[]) if best else [],
            'unsupported':sorted(set(unknown))}


def card_surface(card, states, reference, useful_threshold=0., high_threshold=1.):
    _validate_states(states)
    rows=[{'context_id':state['context_id'],'weight':state['weight'],
           'board_state':state.get('board_state'),'role':state['role'],
           **quote_now(card,state,reference)} for state in states]
    known=[r for r in rows if r['pricing_supported']]
    known_mass=sum(r['weight'] for r in known)
    values=[r['net_model_gold'] for r in known if r['weight']>0]
    useful=sum(r['weight'] for r in known if r['net_model_gold']>useful_threshold)
    high=sum(r['weight'] for r in known if r['net_model_gold']>=high_threshold)
    low=sum(r['weight'] for r in known if r['net_model_gold']<=useful_threshold)
    return {'version':VERSION,'card_id':card['id'],'name':card['name'],
            'all_state_mean_net_quote':sum(r['weight']*r['net_model_gold'] for r in known) if known_mass>=1-1e-9 else None,
            'known_state_weight':known_mass,'unknown_state_weight':1-known_mass,
            'useful_opportunity_weight_bounds':[useful,useful+1-known_mass],
            'high_opportunity_weight_bounds':[high,high+1-known_mass],
            'low_payoff_weight_bounds':[low,low+1-known_mass],
            'payable_useful_weight':sum(r['weight'] for r in known if r['payable_now'] and r['net_model_gold']>useful_threshold),
            'best_known_net_quote':max(values) if values else None,
            'worst_known_net_quote':min(values) if values else None,
            'useful_threshold':useful_threshold,'high_threshold':high_threshold,
            'rows':rows,'scope':'Unchanged quotes plus opportunity exposure; favorable-only averages are not whole-card scores.'}


def hand_coverage(hand, states, reference, useful_threshold=0., bind_actual_hand_size=True):
    """One observed immediate play per situation; keep/shared cash constraints.

    The hand is already present, not sampled from a deck. One card is played,
    other cards are options; their scores are not summed as simultaneous plays.
    """
    _validate_states(states)
    if not 1<=len(hand)<=7:
        raise ValueError('A known hand must contain one to seven cards')
    if type(useful_threshold) not in (int,float) or not math.isfinite(useful_threshold) or useful_threshold<0:
        raise ValueError('Useful-action threshold must be finite nonnegative')
    rows=[]; covered=possible=expected=0.; unknown_mass=0.
    for original in states:
        state=copy.deepcopy(original)
        if bind_actual_hand_size:
            state['hand_size_before_play']=len(hand)
            state['hand_size_after_play']=len(hand)-1
        actions=[{'hand_index':i,**quote_now(card,state,reference)} for i,card in enumerate(hand)]
        known=[a for a in actions if a['payable_now'] and a['pricing_supported']]
        uncertain=[a for a in actions if a['payable_now'] and not a['pricing_supported']]
        ready=[a for a in known if a['net_model_gold']>useful_threshold]
        best=max(known,key=lambda a:(a['net_model_gold'],-a['hand_index'])) if known else None
        surplus=max(0,best['net_model_gold']) if best else 0.
        covered+=state['weight']*bool(ready)
        possible+=state['weight']*bool(ready or uncertain)
        expected+=state['weight']*surplus
        unknown_mass+=state['weight']*bool(uncertain)
        rows.append({'context_id':state['context_id'],'weight':state['weight'],
                     'observed_board_state':state.get('board_state'),'gold_available_now':state['gold_before_play'],
                     'actions':actions,'known_useful_hand_indexes':[a['hand_index'] for a in ready],
                     'unknown_affordable_hand_indexes':[a['hand_index'] for a in uncertain],
                     'selected_known_hand_index':best['hand_index'] if best and surplus>0 else None,
                     'best_known_immediate_surplus':surplus,
                     'no_effective_action_bounds':[not bool(ready or uncertain),not bool(ready)]})
    return {'version':VERSION,'hand_ids':[card['id'] for card in hand],'useful_threshold':useful_threshold,
            'effective_action_coverage_bounds':[covered,possible],
            'no_effective_action_weight_bounds':[1-possible,1-covered],
            'expected_best_known_immediate_surplus':expected,
            'expected_best_immediate_surplus':expected if not unknown_mass else None,
            'unknown_affordable_action_weight':unknown_mass,'rows':rows,
            'assumptions':[
                'Shared observed board/cash states; probabilities are common design weights, not real-match frequencies.',
                'At most one immediate card deployment; combo sequencing and future draws are separate problems.',
                'Hold/no-play has zero current resource surplus; no-action weight diagnoses missing options, not a priced loss.',
                'Known hand already drawn; intrinsic conditional hand-size effects are recalculated, not renamed bonuses.',
                'Useful thresholds are common scenario cutoffs; retain sensitivity instead of fitting them per card.',
                'Future hidden scenarios cannot use this observed-state max as an advance guaranteed payoff.']}


def committed_action_value(hand, states, reference, bind_actual_hand_size=True):
    """Before seeing a hidden future board, commit one action or hold.

    Distinct from current observed-state coverage. Reject unknown pricing rather
    than silently dropping a hidden scenario. Unaffordable commits are infeasible.
    """
    _validate_states(states)
    values=[]
    for card in hand:
        rows=[]
        for original in states:
            state=copy.deepcopy(original)
            if bind_actual_hand_size:
                state.update(hand_size_before_play=len(hand),hand_size_after_play=len(hand)-1)
            result=quote_now(card,state,reference)
            rows.append((state['weight'],result))
        if any(w>0 and (not r['pricing_supported'] or not r['payable_now']) for w,r in rows):
            values.append(None)
        else:
            values.append(sum(w*r['net_model_gold'] for w,r in rows))
    known=max([0.]+[v for v in values if v is not None])
    return {'committed_hand_action_values':values,'best_known_committed_surplus':known,
            'best_committed_surplus':known if all(v is not None for v in values) else None,
            'scope':'One action committed before hidden scenario; no hindsight max.'}


def joint_capacity_loss(hand_size, released_slots, natural_draws, option_value):
    """Compare occupied vs released slots once for the entire waiting hand."""
    if any(type(x) is not int for x in (hand_size,released_slots,natural_draws)) or not 0<=hand_size<=7 or not 0<=released_slots<=hand_size or natural_draws<0:
        raise ValueError('Invalid joint hand capacity inputs')
    if type(option_value) not in (int,float) or not math.isfinite(option_value) or option_value<0:
        raise ValueError('Option value must be finite nonnegative')
    held=max(0,hand_size+natural_draws-7)
    released=max(0,hand_size-released_slots+natural_draws-7)
    return {'additional_burns':held-released,'joint_capacity_loss_model_gold':(held-released)*option_value,
            'scope':'Joint slot-capacity counterfactual only; not additive independent per-card risks.'}