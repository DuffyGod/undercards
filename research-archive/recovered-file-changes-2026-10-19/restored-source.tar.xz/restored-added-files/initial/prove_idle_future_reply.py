"""Exact future-action counterstrategy, not a whole-match optimality claim.

Fix enemy's legal idle reply, enumerate ALL own actions in the declared two
turns. If none meet the conjunction, this one strategy refutes a guarantee.
Finding a winning own route only makes this particular counterstrategy fail.
"""
from functools import lru_cache
import hashlib
from pathlib import Path
import board_tactics as board
import paid_board_tactics as paid
import score_cards


def prove(data, cards=None):
    cards=score_cards.load_cards() if cards is None else cards
    engine=paid.PaidSearch(cards,data); root=engine.root()
    if engine.horizon != 'next_own_attack' or not engine.purpose:
        raise ValueError('Explicit next-turn conjunctive purpose required')
    unknown=list(engine.unknown);counts={0:0,1:0,2:0,3:0}; endpoints=0
    witness=[]

    @lru_cache(maxsize=None)
    def visit(s):
        nonlocal endpoints
        counts[s.phase]+=1
        if sum(counts.values())>engine.node_limit:
            raise paid.UnknownMechanic('Idle future counterstrategy state budget exhausted')
        if engine.terminal(s) or s.phase==3:
            endpoints+=1
            return bool(engine.objective(s,'purpose')[0])
        if s.phase==1:
            return visit(engine.boundary(s))  # Legal stop: no optional attack or cast.
        actions=[(dict(kind='end_turn',phase=s.phase),engine.boundary(s))]
        actions.extend(engine.attacks(s));actions.extend(engine.deploys(s))
        for action,child in actions:
            if visit(child):
                witness.append(action)
                return True
        return False

    possible=None
    if not unknown:
        try: possible=visit(root)
        except paid.UnknownMechanic as error: unknown.append(str(error))
    complete=not unknown and possible is not None
    here=Path(__file__).resolve().parent
    return dict(bound_complete=complete and not possible,unknown=unknown,
        any_policy_can_guarantee_purpose=False if complete and not possible else None,
        own_route_satisfies_purpose_against_idle=possible if complete else None,
        counterstrategy='Enemy ends its turn without optional attacks or casts, for every own route.',
        purpose_constraints=engine.purpose,visited_states=sum(counts.values()),
        phase_states=counts,checked_terminal_states=endpoints,
        witness_against_idle=list(reversed(witness)) if possible else [],input=data,
        source_hashes={f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in
            ('prove_idle_future_reply.py','paid_board_tactics.py','queued_delay.py','board_tactics.py')},
        limitations=['Exact declared own actions, payment, draw and callbacks against ONE legal enemy strategy.',
            'Negative result refutes the conjunction. A positive route against idle cannot establish a guarantee against other replies.',
            'Unknown or budget exhaustion withdraw the bound. No probabilities or scalar card values.'])