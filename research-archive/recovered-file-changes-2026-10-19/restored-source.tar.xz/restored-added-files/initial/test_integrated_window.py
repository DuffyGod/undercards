import copy
import unittest
import action_outcomes as actions
import evaluate_situation as situation
import joint_window_quote as joint
import score_cards as base


def probe(hand,cash=10,hp=30,enemies=None):
    return dict(hand_ids=hand,role='midrange',own_turn=5,gold_before_play=cash,
        opponent_gold_before_response=0,own_player_hp=hp,enemy_player_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[] if enemies is None else enemies,
        condition_state={'last_turn_gold_spent_on_spells':0},response_weights={'enemy_face':1})


class IntegratedWindowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards=base.load_cards();cls.by_id={c['id']:c for c in cls.cards};cls.ref,_=base.make_reference(cls.cards)

    def test_two_play_rescue_requires_shared_cash_and_both_actions(self):
        data=probe([96,438],7,5,[dict(attack=6,health=6),dict(attack=3,health=3)])
        r=situation.evaluate(data,self.ref,self.cards)
        self.assertTrue(all(w['death_probability']==1 for w in r['action_windows']))
        best=r['deployment_routes']['best_known_survival_route']
        self.assertEqual(best['death_probability'],0)
        self.assertEqual(best['actual_paid_gold'],7)
        self.assertEqual(len(best['steps']),2)
        data['gold_before_play']=6
        x=situation.evaluate(data,self.ref,self.cards)
        self.assertEqual(x['deployment_routes']['best_known_survival_route']['death_probability'],1)

    def test_spell_and_monster_share_scale_but_real_cash_is_unscaled(self):
        r=situation.evaluate(probe([81,15]),self.ref,self.cards)
        spell,monster=r['finite_window_quotes']
        self.assertEqual(spell['scale'],monster['scale'])
        self.assertEqual(spell['model_gold'],1)

    def test_turn_end_precedes_reply_and_attack_disables_no_attack_effect(self):
        data=probe([509],10,5,[dict(attack=7,health=4)])
        data['callback_state']={'own_player_max_hp':30}
        ctx,_=situation.make_state(data)
        r=actions.evaluate(self.by_id[509],ctx,self.ref)
        self.assertTrue(r['window_known'])
        self.assertEqual(r['recommended_action'],'delay')
        wait=next(a for a in r['actions'] if a['action_id']=='delay')
        self.assertEqual(wait['paths'][0]['after_turn_end']['own_player_hp'],8)
        self.assertEqual(wait['death_probability'],0)
        attack=next(a for a in r['actions'] if a['current_action']=='attack_monster')
        self.assertEqual(attack['death_probability'],1)

    def test_random_callback_is_chance_and_never_selected_best_target(self):
        data=probe([197],10,5,[dict(attack=7,health=4),dict(attack=0,health=4)])
        data['callback_state']={'turn_end_random_target_weights':[dict(target_id=0,weight=.25),dict(target_id=1,weight=.75)]}
        ctx,_=situation.make_state(data)
        r=actions.evaluate(self.by_id[197],ctx,self.ref)
        delay=next(a for a in r['actions'] if a['action_id']=='delay')
        self.assertTrue(delay['outcome_known'])
        self.assertEqual(len(delay['paths']),2)
        self.assertAlmostEqual(sum(p['probability'] for p in delay['paths']),1)
        self.assertEqual(delay['death_probability'],.75)
        ctx['callback_state']={}
        missing=actions.evaluate(self.by_id[197],ctx,self.ref)
        self.assertFalse(missing['window_known'])
        self.assertIsNone(missing['recommended_action'])

    def test_cash_callback_is_not_scaled_as_body(self):
        data=probe([404]);data['response_weights']={'none':1}
        ctx,_=situation.make_state(data)
        quote=joint.evaluate(self.by_id[404],ctx,self.ref,scale=.4)
        blank=dict(self.by_id[404],effect_readable='')
        control=joint.evaluate(blank,ctx,self.ref,scale=.4)
        self.assertTrue(quote['pricing_supported'])
        self.assertAlmostEqual(quote['gross_model_gold']-control['gross_model_gold'],1)
        self.assertAlmostEqual(quote['ordinary_body_model_gold']+quote['magic_keywords_increment_model_gold'],quote['gross_model_gold'])

    def test_modified_existing_ally_does_not_become_known_after_projection(self):
        data=probe([314]);data['response_weights']={'silence':1};data['opponent_gold_before_response']=3
        data['ally_bodies_before_play']=[dict(attack=2,health=3)]
        ctx,_=situation.make_state(data)
        result=actions.evaluate(self.by_id[314],ctx,self.ref)
        self.assertTrue(result['window_known'])
        # Candidate is selected by this declared silence policy, leaving ally
        # modifiers intact. Remove candidate after its current action, and the
        # same metadata cannot be reset as if the ally were an ordinary body.
        raw=copy.deepcopy(result['actions'][0]['paths'][0]['after_current']['state'])
        raw['actor']['health']=0
        with self.assertRaisesRegex(ValueError,'stat-modified'):
            actions._reply(raw,'silence',ctx)


if __name__=='__main__':unittest.main()