"""Dynamic ATK is sampled from live predicates, never permanent damage buffs."""
from dataclasses import replace
import unittest

import board_tactics as b
import paid_board_tactics as p
import score_cards


class DynamicAttackTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def engine(self,cid=534,enemy=None,own=None,**overrides):
        data=dict(hand_ids=[cid] if own is None else [],gold_before_play=5,
            own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
            opponent_hand_known=True,opponent_hand_ids=[],enemy_bodies=enemy or [],
            ally_bodies_before_play=own or [],objectives=['purpose'],
            purpose_constraints=dict(min_own_player_hp=1,min_own_body_attack=4,min_own_body_health=1))
        data.update(overrides)
        e=p.PaidSearch(self.cards,data)
        return e,e.root()

    def deploy(self,e,s):return next(e.deploys(s))[1]

    def hit(self,e,s,target):return next(c for a,c in e.attacks(s) if a['target']==target)

    def test_complete_generic_templates(self):
        for text,field,n in [('Armor. Haste. This has +7 ATK while damaged.','damaged_attack_bonus',7),
                ('This has +6 ATK on the enemy turn and takes no DMG while attacking.','opponent_turn_attack_bonus',6)]:
            spec=b.compile_card(dict(id=99999,effect_readable=text))
            self.assertEqual(spec[field],n);self.assertFalse(spec['unknown'])
            self.assertTrue(b.compile_card(dict(id=99999,effect_readable=text+' Dust: Draw a card.'))['unknown'])

    def test_fresh_samples_before_exchange_then_recomputes(self):
        e,s=self.engine(enemy=[dict(attack=3,health=3)]);s=self.deploy(e,s)
        after=self.hit(e,s,'enemy:0')
        self.assertEqual((after.own[0].health,after.enemy[0].health),(3,1))
        self.assertEqual((after.own[0].attack,b.effective_attack(after.own[0],after,'own')),(2,5))
        self.assertFalse(list(e.attacks(after)))

    def test_armor_zero_damage_does_not_activate(self):
        e,s=self.engine(enemy=[dict(attack=1,health=2)]);s=self.deploy(e,s)
        after=self.hit(e,s,'enemy:0');self.assertEqual(after.own[0].health,5)
        self.assertEqual(b.effective_attack(after.own[0],after,'own'),2)

    def test_observed_attack_inverted_only_with_known_max(self):
        e,s=self.engine(own=[dict(card_id=534,attack=5,health=4,max_health=5)])
        self.assertFalse(e.unknown);self.assertEqual(s.own[0].attack,2)
        r=p.evaluate(dict(e.data,ally_bodies_before_play=[dict(card_id=534,attack=5,health=4)]),self.cards)
        self.assertFalse(r['complete_in_declared_scope']);self.assertIsNone(r['initial_metrics'])
        self.assertFalse(r['objectives']);self.assertFalse(r['exact_root_recommendations'])

    def test_healing_removes_bonus_but_not_permanent_buff(self):
        e,s=self.engine(own=[dict(card_id=534,attack=7,health=4,max_health=5)])
        u=s.own[0];self.assertEqual(u.attack,4)
        v,amount=e.fully_heal_unit(u);self.assertEqual(amount,1)
        self.assertEqual(b.effective_attack(v,s,'own'),4)

    def test_health_gain_preserves_injury(self):
        e,s=self.engine(own=[dict(card_id=534,attack=5,health=4,max_health=5)])
        v=replace(s.own[0],health=6,max_health=7)
        self.assertEqual(b.effective_attack(v,s,'own'),5)

    def test_mirror_turn_bonus_and_direct_attack_immunity(self):
        e,s=self.engine(cid=632,own=[dict(attack=4,health=5)],enemy=[dict(card_id=632,attack=4,health=5,max_health=5)])
        self.assertEqual(s.enemy[0].attack,2)
        after=self.hit(e,s,'enemy:0');self.assertEqual((after.own[0].health,after.enemy[0].health),(1,1))
        response=e.boundary(after)
        self.assertEqual(response.turn_owner,'enemy')
        self.assertEqual(b.effective_attack(response.enemy[0],response,'enemy'),2)
        after=self.hit(e,response,'own:0')
        self.assertEqual((after.own[0].health,after.enemy[0].health),(0,1))

    def test_new_trashy_has_no_immediate_attack(self):
        e,s=self.engine(cid=632,enemy=[dict(attack=6,health=2)])
        self.assertFalse(list(e.attacks(self.deploy(e,s))))

    def test_attacking_vs_defending_and_spell_damage(self):
        e,s=self.engine(own=[dict(card_id=632,attack=2,health=5,max_health=5)],enemy=[dict(attack=3,health=5)])
        response=e.boundary(s);after=self.hit(e,response,'own:0')
        self.assertEqual((after.own[0].health,after.enemy[0].health),(2,1))
        self.assertEqual(e.hurt_unit(s.own[0],5,source=None,source_is_enemy=True).health,0)

    def test_real_owner_survives_horizon_phase_jump(self):
        e,s=self.engine(own=[dict(card_id=632,attack=2,health=5,max_health=5)],horizon='enemy_attack')
        end=e.boundary(e.boundary(s))
        self.assertEqual((end.phase,end.turn_owner),(e.end_phase,'enemy'))
        self.assertEqual(b.metrics(end)['own_board_attack'],4)
        self.assertTrue(e.purpose_body_witnesses(end))
        e,s=self.engine(own=[dict(card_id=632,attack=2,health=5,max_health=5)],horizon='next_own_attack')
        end=e.boundary(e.boundary(e.boundary(s)))
        self.assertEqual((end.phase,end.turn_owner),(e.end_phase,'own'))
        self.assertEqual(b.metrics(end)['own_board_attack'],2)

    def test_zero_base_with_bonus_is_valid_counterattack(self):
        e,s=self.engine(own=[dict(attack=1,health=5)],enemy=[dict(card_id=632,attack=2,health=5,max_health=5)])
        self.assertEqual(s.enemy[0].attack,0)
        after=self.hit(e,s,'enemy:0');self.assertEqual(after.own[0].health,3)
        response=e.boundary(after);self.assertFalse(list(e.attacks(response)))

    def test_silence_native_dynamic_without_repair_or_reset_guess(self):
        for cid,a,h in ((534,5,4),(632,2,4)):
            e,s=self.engine(own=[dict(card_id=cid,attack=a,health=h,max_health=5)])
            v=e.silence(s.own[0]);self.assertEqual((v.attack,v.health),(2,h))
            self.assertEqual((v.damaged_attack_bonus,v.opponent_turn_attack_bonus,v.immune_while_attacking),(0,0,False))
        e,s=self.engine(own=[dict(card_id=534,attack=7,health=4,max_health=5)])
        with self.assertRaisesRegex(p.UnknownMechanic,'modified body'):e.silence(s.own[0])

    def test_dodge_and_neo_dust_attack_windows_unknown(self):
        e,s=self.engine(own=[dict(card_id=632,attack=2,health=5,max_health=5,dodge=1)],enemy=[dict(attack=3,health=2)])
        with self.assertRaisesRegex(p.UnknownMechanic,'damage modifiers'):list(e.attacks(s))
        e,s=self.engine(own=[dict(card_id=632,attack=2,health=5,max_health=5)],enemy=[dict(card_id=110,attack=13,health=1,max_health=1)])
        with self.assertRaisesRegex(p.UnknownMechanic,'callback window'):list(e.attacks(s))
        r=p.evaluate(e.data,self.cards);self.assertFalse(r['complete_in_declared_scope'])
        self.assertFalse(r['exact_root_recommendations'])

    def test_loss_floor_guard_and_current_attack_threshold(self):
        e,s=self.engine(own=[dict(card_id=534,attack=5,health=4,max_health=5)])
        v=e.shift_attack(s.own[0],-2,s,'own')
        self.assertEqual((v.attack,b.effective_attack(v,s,'own')),(0,3))
        with self.assertRaisesRegex(p.UnknownMechanic,'loss floor'):e.shift_attack(s.own[0],-3,s,'own')
        with self.assertRaisesRegex(p.UnknownMechanic,'dynamic ATK'):e.require_static_attack(v,'ATK set')

    def test_endpoint_and_algorithms_use_effective_attack(self):
        e,s=self.engine(own=[dict(card_id=534,attack=5,health=4,max_health=5)],enemy=[])
        data=dict(e.data,purpose_constraints=dict(min_own_player_hp=1,min_own_body_attack=5,min_own_body_health=1))
        a=p.evaluate(data,self.cards);x=p.evaluate(dict(data,search_algorithm='exhaustive'),self.cards)
        self.assertTrue(a['complete_in_declared_scope']);self.assertTrue(x['complete_in_declared_scope'])
        self.assertEqual(a['objectives'][0]['objective_vector'],x['objectives'][0]['objective_vector'])
        body=a['objectives'][0]['endpoint_boards']['own'][0]
        self.assertEqual((body['attack'],body['attack_base']),(5,2))


if __name__=='__main__':unittest.main()