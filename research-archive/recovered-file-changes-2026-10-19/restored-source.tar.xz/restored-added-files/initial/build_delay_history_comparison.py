"""Compare one physical hand across history, life and actual attack windows."""
import copy
import hashlib
import json
from pathlib import Path
import evaluate_situation
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/delay-history-v01'
HAND=[580,22,187,1,990,582,8]


def scene(hp=3,dust=3,spell=False,ally=False,horizon='enemy_attack'):
    cards={c['id']:c for c in score_cards.load_cards()}
    return dict(hand_ids=HAND,hand_base_costs=[cards[i]['cost'] for i in HAND],
        gold_before_play=8,own_player_hp=hp,own_player_max_hp=30,enemy_player_hp=30,
        ally_bodies_before_play=[] if not ally else [dict(card_id=15,attack=5,health=5,ready=True,
            current_card_cost=5,base_cost=5)],
        enemy_bodies=[dict(card_id=15,attack=6,health=5),dict(card_id=2,attack=2,health=3)],
        own_dustpile_monsters=[dict(card_id=108,current_cost=6,base_cost=6) for _ in range(dust)],
        opponent_hand_ids=[96] if spell else [],opponent_gold_before_response=3 if spell else 0,
        condition_known_state={'last_turn_gold_spent_on_spells':1},max_plays=1,horizon=horizon,
        own_deck_ids=[196],own_fatigue_next=1,next_natural_draw_count=0,
        objectives=['guaranteed_hp','purpose'],
        purpose_constraints={'min_own_player_hp':hp,'max_enemy_living_count':0})


def forced(search,root,index):
    # The same complete hand and balance survive each intervention. Search
    # existing allied attacks before or after the single required Play.
    def visit(state):
        branches=[]
        for action,child in search.deploys(state):
            if action.get('hand_index')==index and action['kind']=='deploy':
                result=search.solve(child,'guaranteed_hp')
                if not result['search_complete']: return result
                branches.append((result['objective_vector'],dict(action=action,result=result)))
        for action,child in search.attacks(state):
            result=visit(child)
            if result is not None:
                if result.get('search_complete') is False: return result
                branches.append((result['result']['objective_vector'],dict(result=result['result'],
                    pre_deploy_actions=[action]+result.get('pre_deploy_actions',[]),action=result['action'])))
        return max(branches,key=lambda r:r[0])[1] if branches else None
    return visit(root)


def main():
    OUT.mkdir(exist_ok=True)
    cards=score_cards.load_cards()
    cases=[]
    scenarios=[('dust_two',3,2,False,False,'enemy_attack'),('dust_three',3,3,False,False,'enemy_attack'),
        ('paid_damage',3,3,True,False,'enemy_attack'),('healthy',10,3,False,False,'enemy_attack'),
        ('healthy_paid',10,3,True,False,'enemy_attack'),('near_cap',28,3,False,False,'enemy_attack'),
        ('near_cap_paid',28,3,True,False,'enemy_attack'),('existing_ally',3,3,False,True,'enemy_attack'),
        ('ally_next_attack',3,3,False,True,'next_own_attack'),('ally_next_attack_paid',3,3,True,True,'next_own_attack')]
    for name,hp,dust,spell,ally,horizon in scenarios:
        data=scene(hp,dust,spell,ally,horizon)
        result=paid.evaluate(data,cards)
        if not result['complete_in_declared_scope']: raise AssertionError(result['unknown'])
        engine=paid.PaidSearch(cards,data);root=engine.root()
        rows=[]
        for i,cid in enumerate(HAND):
            route=forced(engine,root,i)
            if route is None or route.get('search_complete') is False: raise AssertionError(route)
            rows.append(dict(card_id=cid,name=engine.by[cid]['name'],
                guaranteed_hp=route['result']['metrics']['own_player_hp'],route=route))
        cases.append(dict(case=name,input=data,candidates=rows,actual_hand_optimum=result))
        print(name,[(r['name'],r['guaranteed_hp']) for r in rows],
            'joint_clear',result['objectives'][1]['purpose_guaranteed'],flush=True)
    # Common API keeps current observations; old diagnostics do not become
    # another authoritative recommendation.
    direct=scene()
    current={k:copy.deepcopy(direct[k]) for k in ('hand_ids','gold_before_play','own_player_hp',
        'enemy_player_hp','ally_bodies_before_play','enemy_bodies','opponent_gold_before_response')}
    keys=('hand_base_costs','own_dustpile_monsters','opponent_hand_ids','max_plays','horizon','objectives',
        'purpose_constraints','own_deck_ids','own_fatigue_next','next_natural_draw_count')
    current.update(role='midrange',own_turn=5,condition_state=direct['condition_known_state'],
        callback_state={'own_player_max_hp':30},response_weights={'enemy_face':1},
        paid_board_scenario={k:direct[k] for k in keys})
    api=evaluate_situation.evaluate(current,cards=cards)
    if json.loads(json.dumps(api['paid_board_tactics']))!=json.loads(json.dumps(paid.evaluate(direct,cards))):
        raise AssertionError('Common API differs from standalone')
    (OUT/'current.input.json').write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n')
    (OUT/'current.result.json').write_text(json.dumps(api,ensure_ascii=False,indent=2)+'\n')
    record=dict(version='delay-history-hand-comparison-0.1.0',cases=cases,
        source_hashes={f:hashlib.sha256((HERE/f).read_bytes()).hexdigest() for f in
            ('queued_delay.py','paid_board_tactics.py','board_tactics.py','evaluate_situation.py','build_delay_history_comparison.py')},
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        api_matches_standalone=True,limitations=['One full known physical hand, not whole-cost-pool champions.',
            'No empirical frequencies; normal library and healthy HP are explicit alternatives to former empty-library emergency fixtures.',
            'Future own attack window includes no future own plays or automatic income. No SOUL/artifact/position subsystem.'])
    (OUT/'comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()