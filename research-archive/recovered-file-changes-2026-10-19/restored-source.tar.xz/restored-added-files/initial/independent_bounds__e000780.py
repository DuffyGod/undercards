"""Strategy bounds for paid presence conditions; no game/search imports."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    cards={c['id']:c for c in json.loads((HERE/'native-snapshot.json').read_text())['cards']}
    assert (cards[46]['cost'],cards[46]['attack'],cards[46]['health'])==(6,5,6)
    assert (cards[47]['cost'],cards[47]['attack'],cards[47]['health'])==(6,6,5)
    assert cards[46]['effect_readable']=='Magic: If you have an ally Dogaressa [#47], give all Dog in your hand ATK +2/HP +2.'
    assert cards[47]['effect_readable']=='Magic: If you have an ally Dogamy [#46], gain ATK +2/HP +3, Taunt, and +1 Dodge.'
    assert (cards[116]['cost'],cards[116]['attack'],cards[116]['health'])==(4,4,3)
    assert cards[116]['effect_readable']=='Magic: If there is a Taunt monster, gain Charge.'
    assert (cards[1]['cost'],cards[1]['attack'],cards[1]['health'],cards[1]['effect_readable'])==(1,0,4,'Taunt.')
    expected={
        'dogs12':dict(hp=15,body8_8=15,body8_4=15),
        'dogs11':dict(hp=11,body8_8=None,body8_4=None),
        'doga-alone12':dict(hp=11,body8_8=None,body8_4=None),
        'dogs-gem':dict(hp=14,body8_8=None,body8_4=14),
        'bird-dummy5':dict(hp=1,win=1),'bird-dummy4':dict(hp=1,win=None),
        'bird-tiny4':dict(hp=0,win=None),'bird-alone4':dict(hp=0,win=None),
        'bird-taunt-false':dict(hp=0,win=None),'bird-taunt-true':dict(hp=1,win=1),
        'later-dog-outlet':dict(hp=15,body7_7=11),
    }
    checks=[]
    for label,tasks in expected.items():
        path=HERE/(label+'.json');raw=json.loads(path.read_text())
        for task,value in tasks.items():
            result=raw['results'][task];assert result['known'] and result['guaranteed_player_hp']==value,(label,task)
            assert result['feasible']==(value is not None and (task!='hp' or value>0))
            checks.append(dict(label=label,task=task,independent_hp=value,feasible=result['feasible'],artifact_sha256=sha(path)))
    # Numeric bounds originate from legal policies and enemy counters, not
    # production endpoint states. A1 counter chooses face4 whenever no Taunt;
    # a surviving Taunt forces the only body attack away from the hero.
    facts=dict(paid_pair=6+6,insufficient_cash=11,boosted_doga_attack=6+2,boosted_doga_hp=5+3,
        no_taunt_hp=15-4,gem_face_upper=15-1,gem_strips_dodge_then_body_hp=(5+3)-4,
        real_bird_taunt_payment=1+4,bird_face_damage=4,
        later_total_paid=6+6+6,later_goal_hp_upper=15-4)
    assert facts['boosted_doga_hp']==facts['boosted_doga_attack']==8
    assert facts['gem_strips_dodge_then_body_hp']==4
    pool=[]
    for cid in (46,47,116):
        r=json.loads((HERE/f'pool-card{cid}.json').read_text())['results']
        assert r['hp']['guaranteed_player_hp']==r['clear']['guaranteed_player_hp']==9
        assert not r['win']['feasible'] and not r['focal_2_2']['feasible']
        pool.append(dict(card_id=cid,hp=9,clear_hp=9,win=False,focal_2_2=False))
    report=dict(imports_production_model=False,checks=checks,matching_context_cells=len(checks),facts=facts,pool=pool,
        source_snapshot_sha256=sha(HERE/'native-snapshot.json'),builder_sha256=sha(Path(__file__)),
        policy_bounds=[
            'Dogamy first6 then Dogaressa6 creates8/8 Taunt+Dodge1. No healing can exceed15; no spell lets the lone4 attack damage the hero. Cash11 cannot pay both6, so no card can create8ATK or Taunt; face4 forces11.',
            'With one Gem the enemy can face1, forcing14. The alternative Gem on Doga consumes Dodge before the4 attack, leaving4HP and denying8/8. All replies leave at least8/4 when the pair is played in the correct order; hence joint14 for8/4, not8/8.',
            'Dummy1 then Bird4 supplies its own living Taunt and4 fresh Charge damage to the enemy4HP hero. At cash4 only one can be paid: Dummy preserves our1HP but cannot win; Bird or Tiny+Bird has no Taunt and the enemy face4 kills our1HP.',
            'Visible enemy Taunt prevents face despite granting Charge; Jerry5HP cannot be killed by one Bird attack (its resistance further lowers Bird damage). Transparent Taunt still satisfies the explicit status-existence interpretation but does not restrict face selection, permitting immediate4 damage before its owner-start status expiry.',
            'Three Dogs: HP15 uses Dogamy before Dogaressa, producing Taunt+Dodge. Focal Lesser>=7/7 instead needs Dogaressa before Dogamy while Lesser remains held; the first condition is permanently false, so enemy face4 bounds HP11. Existing5/6 or6/5 allies can then clear the4/4, and real next income6 pays the buffed7/7 Lesser before the second enemy response. Matching lower11; current12 and later6 are actually spent.',
            'Single-card pool: no named mate/Taunt, no conditional gain. Each nativeATK>=4 trades Thrashing4/4 before its second attack, giving15-4-2=9 and clear. Enemy two Gem damage plus4 attack can deny focal2/2; none can kill the30HP hero.'
        ],
        assumptions=['Current physical identity, living statuses and declared source COST facts are complete.',
            'Taunt-existence interpretation includes Transparency and samples once at Magic; not server verified.',
            'Every comparison uses its saved finite horizon, real hand, cash, income and reply menu.'])
    (HERE/'independent-bounds.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(context_cells=len(checks),pool_cells=12)))

if __name__=='__main__':main()