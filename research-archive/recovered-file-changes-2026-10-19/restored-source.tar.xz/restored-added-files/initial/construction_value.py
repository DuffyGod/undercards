"""Conditional carrying value from real card quotes and an opportunity tree.

This is a single drawn deck-slot comparison, not a deck recommendation inferred
from synthetic frequency weights. Each replacement is fixed before the future
observations; both alternatives have the same observed-state opportunity tree.
"""
import copy
import math

import board_response
import carry_option
import combat_increment as combat
import joint_window_quote as joint
import spell_window

VERSION='conditional-construction-option-0.1.0'


def evaluate_cards(cards,reference,scale,scenario,state_builder,root_context=None):
    by=carry_option.validate(scenario)
    contexts={}
    for n in by.values():
        if 'observation' in n:
            ctx,_=state_builder(n['observation'])
        elif n['id']==scenario['root_id'] and root_context is not None:
            ctx=copy.deepcopy(root_context)
        else:raise ValueError('Every future node needs an independent complete observation')
        if ctx['own_turn']!=n['own_turn']:raise ValueError('Opportunity turn and observation turn disagree')
        # Carrying occupancy is tracked by the option tree. Including natural
        # draw slot release again in a local deployment quote would double it.
        ctx.update(resolve_next_own_start=False,next_draw_count=0,utility_scale=scale)
        contexts[n['id']]=ctx
    if len({c['role'] for c in contexts.values()})!=1:
        raise ValueError('One construction comparison requires one shared role')
    options=[];cache={}
    def quote(card,node,hand_size):
        key=(card['id'],card['cost'],card.get('attack'),card.get('health'),card['effect_readable'],node['id'],hand_size)
        if key in cache:return cache[key]
        ctx=copy.deepcopy(contexts[node['id']])
        ctx.update(hand_size_before_play=hand_size,hand_size_after_play=hand_size-1)
        legal=(card['cost']<=ctx['gold_before_play'] and
            (card['card_type']=='spell' or len(ctx['ally_bodies_before_play'])<4))
        q=(spell_window.evaluate(card,ctx,reference,ctx['growth_response_weights'],scale=scale)
            if card['card_type']=='spell' else joint.evaluate(card,ctx,reference,scale,ctx['growth_response_weights'])) if legal else None
        net=q.get('model_gold') if card['card_type']=='spell' and q else q.get('net_margin_model_gold') if q else None
        result=dict(legal=legal,known=net is not None,net_model_gold=net,paid_gold=card['cost'] if legal else 0.,
            unknown=q.get('unknown',q.get('window_unknown',[])) if q else [],
            outcome_summary=q.get('outcome_summary') if q else None)
        cache[key]=result
        return result
    # A resource carrying option cannot price dying while waiting as zero.
    # Validate only positive-probability reachable observations.
    reachable=set()
    def visit(i):
        if i in reachable:return
        reachable.add(i)
        for e in by[i].get('transitions',[]):
            if e['probability']>0:visit(e['child_id'])
    visit(scenario['root_id'])
    unsafe=[]
    for i in sorted(reachable):
        ctx=contexts[i]
        for event,mass in ctx['growth_response_weights'].items():
            if mass<=0:continue
            raw=combat.state(0,0,ctx['enemy_bodies'],{},ctx['opponent_gold_before_response'],
                ctx['own_player_hp'],ctx['enemy_player_hp'],ctx.get('enemy_attack_limit',4))
            raw['external_allies']=copy.deepcopy(ctx['ally_bodies_before_play'])
            try:
                board_response.reply(raw,event)
                if combat.terminal(raw):unsafe.append(dict(node_id=i,event=event,reason='No-play response is terminal; use the separate survival axis'))
            except ValueError as exc:unsafe.append(dict(node_id=i,event=event,reason=str(exc)))
    for card in cards:
        if unsafe:
            option=dict(pricing_supported=False,option_value_model_gold=None,value_bounds_model_gold=[None,None],
                unknown=copy.deepcopy(unsafe),policy=[],policy_statistics_are_optimal=False)
        else:
            option=carry_option.evaluate(scenario,lambda node,h:quote(card,node,h))
        options.append(dict(card_id=card['id'],name=card['name'],nominal_cost=card['cost'],**option))
    return dict(version=VERSION,scale=scale,scenario=copy.deepcopy(scenario),cards=options,
        quote_scope='One local deployment window net of actual mana, with next natural draw excluded; holding capacity is priced once in the opportunity tree.',
        assumptions=[
            'These are conditional values for one already-drawn deck slot, not occurrence probabilities, full card lifetimes or calibrated deck win rates.',
            'Each node is observed before choosing deploy/wait. Future observations/Gold/conditions/background plays are explicit scenario inputs.',
            'After deploying the slot, its local closed quote is collected once. Subsequent action-dependent game states are not rolled out.',
            'An unused card pays no mana. Its construction disadvantage is the replacement opportunity and declared carrying cost.',
            'The no-card reference starts with one empty hand slot; accumulated capacity and common plays persist across waiting nodes.',
            'Local quotes do not resolve next natural draw: capacity loss from the same draw cannot also be added as deployment credit.',
            'Lethal no-play scenes are not resource-priced; use the current life/route axis. Unknown legal card mechanisms keep an unbounded upper interval.',
            'Future draw identities, companion tactics and per-card future cost changes are not inferred; this is a finite opportunity model.'])


def compare(result,candidate_ids,replacement_ids):
    by={c['card_id']:c for c in result['cards']}
    pairs=[]
    for cid in candidate_ids:
        for rid in replacement_ids:
            a,b=by[cid],by[rid];alo,ahi=a['value_bounds_model_gold'];blo,bhi=b['value_bounds_model_gold']
            lower=alo-bhi if alo is not None and bhi is not None else None
            upper=ahi-blo if ahi is not None and blo is not None else None
            verdict=(True if lower is not None and lower>1e-10 else
                False if upper is not None and upper<=1e-10 else None)
            known=a['pricing_supported'] and b['pricing_supported']
            pairs.append(dict(candidate_id=cid,replacement_id=rid,
                advantage_model_gold=a['option_value_model_gold']-b['option_value_model_gold'] if known else None,
                advantage_bounds_model_gold=[lower,upper],
                worth_carrying_under_declared_scenario=verdict,
                criterion='Compare ex ante slot options with the same future observations; do not choose a different replacement after seeing the board.'))
    return pairs


def mixture_frontier(base_scenario,candidate,replacement,quote_at,probability_child_id,tolerance=1e-8):
    """Vary one binary root probability; keep observed rewards and costs fixed.

    quote_at(card,node,hand_size) is a reusable fixed quote cache. Report all
    profitable intervals, never assume the advantage is globally monotone.
    """
    by=carry_option.validate(base_scenario)
    root=by[base_scenario['root_id']]
    edges=root.get('transitions',[])
    if len(edges)!=2 or probability_child_id not in {e['child_id'] for e in edges}:
        raise ValueError('A binary observed-next-opportunity mixture is required')
    def values(p):
        tree=copy.deepcopy(base_scenario)
        for edge in next(n for n in tree['nodes'] if n['id']==tree['root_id'])['transitions']:
            edge['probability']=p if edge['child_id']==probability_child_id else 1-p
        a=carry_option.evaluate(tree,lambda n,h:quote_at(candidate,n,h))
        b=carry_option.evaluate(tree,lambda n,h:quote_at(replacement,n,h))
        return (a['option_value_model_gold']-b['option_value_model_gold']) if a['pricing_supported'] and b['pricing_supported'] else None
    # Max of affine deployment/wait alternatives is piecewise affine. A
    # grid documents shape; crossing refinement is a numerical conditional
    # threshold, not an empirical probability estimate.
    grid=[dict(probability=i/100,advantage_model_gold=values(i/100)) for i in range(101)]
    crossings=[]
    for left,right in zip(grid,grid[1:]):
        a,b=left['advantage_model_gold'],right['advantage_model_gold']
        if a is None or b is None or (a>0)==(b>0):continue
        lo,hi=left['probability'],right['probability'];positive=a>0
        for _ in range(40):
            if hi-lo<=tolerance:break
            mid=(lo+hi)/2;v=values(mid)
            if v is None:break
            if (v>0)==positive:lo=mid
            else:hi=mid
        crossings.append(dict(probability_interval=[lo,hi],entering_candidate_preferred=not positive))
    return dict(candidate_id=candidate['id'],replacement_id=replacement['id'],
        varied_child_id=probability_child_id,grid=grid,crossings=crossings,
        all_grid_values_known=all(g['advantage_model_gold'] is not None for g in grid),
        grid_advantage_nondecreasing=(all(b['advantage_model_gold']>=a['advantage_model_gold']-1e-10 for a,b in zip(grid,grid[1:]))
            if all(g['advantage_model_gold'] is not None for g in grid) else None),
        assumption='Conditional crossing on this declared tree and local Gold standard; probabilities have not been calibrated to decks or matches.')