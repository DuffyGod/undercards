// Execute the standalone score view's JavaScript with a small DOM substitute.
// This checks data rendering and selectors; it is not a browser layout test.
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const root = path.resolve(__dirname, '../../experiments/conditional-score-v01');
const html = fs.readFileSync(path.join(root, 'score-explorer.html'), 'utf8');
const encoded = html.match(/<script type="application\/json" id="data">([\s\S]*?)<\/script>/)[1];
const data = JSON.parse(encoded);
const script = html.match(/<script>\s*([\s\S]*?)<\/script>/)[1];

class Element {
  constructor(tag = 'div') {
    this.tag = tag; this.children = []; this.value = ''; this.textContent = '';
    this.checked = true; this.events = {}; this.classList = {add: () => {}};
  }
  append(...nodes) {
    this.children.push(...nodes);
    if (this.tag === 'select' && this.value === '' && nodes.length) this.value = nodes[0].value;
  }
  replaceChildren(...nodes) {
    this.children = []; if (this.tag === 'select') this.value = '';
    this.append(...nodes);
  }
  addEventListener(name, callback) { this.events[name] = callback; }
}
const ids = {};
for (const id of ['scene', 'task', 'known', 'facts', 'summary', 'rows', 'count', 'links', 'detail', 'data'])
  ids[id] = new Element(['scene', 'task'].includes(id) ? 'select' : 'div');
ids.data.textContent = encoded;
const document = {
  getElementById: id => ids[id], createElement: tag => new Element(tag),
  createTextNode: text => ({textContent: text})
};
vm.runInNewContext(script, {document}, {timeout: 2000});
let renders = 0;
for (const scene of data.cases) {
  ids.scene.value = scene.name; ids.scene.events.change();
  assert.equal(ids.task.children.length, Object.keys(scene.tasks).length);
  for (const task of Object.keys(scene.tasks)) {
    ids.task.value = task;
    for (const filter of [true, false]) {
      ids.known.checked = filter; ids.task.events.change();
      const rows = scene.rows.filter(row => !filter || row.scores[task].known);
      assert.equal(ids.rows.children.length, rows.length, scene.name + '/' + task);
      for (const tr of ids.rows.children) {
        const label = tr.children[0].textContent;
        const card = rows.find(r => label === r.name + ' #' + r.card_id);
        assert(card, label);
        const score = card.scores[task];
        const expected = !score.known ? '未知' : score.guaranteed_player_hp !== null
          ? (task === 'hp' ? '玩家 ' : '用途成立 · 玩家 ') + score.guaranteed_player_hp + 'HP'
          : '不能保证';
        assert.equal(tr.children[2].textContent, expected);
        tr.events.click();
        const detail = JSON.parse(ids.detail.textContent);
        assert.equal(detail.card, card.name);
        assert.equal(detail.score.guaranteed_player_hp, score.guaranteed_player_hp);
      }
      renders++;
    }
  }
}
assert.equal(data.cases.length, 14);
assert.equal(data.cases.reduce((sum, c) => sum + c.rows.length, 0), 149);
console.log(JSON.stringify({cases: data.cases.length, selector_renders: renders,
  data_values_match: true, scope: 'JavaScript and DOM substitute; browser layout untested'}));