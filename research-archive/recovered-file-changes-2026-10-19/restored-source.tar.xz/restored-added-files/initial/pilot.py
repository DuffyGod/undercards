"""Does avoiding unrequested tie-breaks close the fixed resource challenge?"""
import copy
import hashlib
import json
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import board_tactics as board
import conditional_card_score as score
import position_quotient_score as quotient
from physical_slot_score import PhysicalSlotSearch

class ScalarPhysical(PhysicalSlotSearch):
    def objective(self,state,mode):
        return (board.metrics(state)['own_player_hp'],)

class ScalarPlain(score.TaskSearch):
    def objective(self,state,mode):
        return (board.metrics(state)['own_player_hp'],)

def main():
    cards=score.score_cards.load_cards();bindings=score.source_bindings(Path(__file__))
    rows=[]
    for cid in (30,107,187):
        original=json.loads((ROOT/f'research-runs/pool-frontier-v02/resource-challenge-card{cid}.json').read_text())
        scene=original['input'];certificate=quotient.eligibility(scene,cards)
        for geometry,cls in [('physical',ScalarPhysical),('quotient',ScalarPlain)]:
            if geometry=='quotient' and not certificate['eligible']:continue
            data=quotient.erased_scene(scene) if geometry=='quotient' else copy.deepcopy(scene)
            e=cls(cards,data);root=e.root();start=time.monotonic()
            result=e.solve(root,'guaranteed_hp') if not e.unknown else dict(search_complete=False,unknown=e.unknown)
            seconds=time.monotonic()-start
            row=dict(card_id=cid,geometry=geometry,input=data,original_input=scene,geometry_certificate=certificate,
                scalar_semantics='HP only; no tie-break optimum or componentwise endpoint guarantee',
                source_hashes=bindings,result=result,seconds=seconds,original_physical_known=original['result']['known'])
            (HERE/f'card{cid}-{geometry}.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n')
            compact=dict(card_id=cid,geometry=geometry,known=result['search_complete'],
                hp=result.get('metrics',{}).get('own_player_hp') if result.get('metrics') else None,
                states=result.get('visited_states'),seconds=seconds,unknown=result.get('unknown',[]))
            rows.append(compact);print(json.dumps(compact),flush=True)
    assert bindings==score.source_bindings(Path(__file__))
    (HERE/'pilot-index.json').write_text(json.dumps(dict(rows=rows,source_hashes=bindings,source_stable=True,
        pilot_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')

if __name__=='__main__':main()