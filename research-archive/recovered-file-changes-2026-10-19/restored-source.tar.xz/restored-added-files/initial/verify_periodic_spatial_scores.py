"""Check independent values, full vectors, physical capacity and real CLIs."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import conditional_card_score as score
import build_conditional_scores as old
import score_cards
import verify_research_integration as integration

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/periodic-spatial-v01'
RUN=HERE/'research-runs/periodic-spatial-v01'


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    started=datetime.now(timezone.utc).isoformat();bindings=score.source_bindings(Path(__file__))
    index=json.loads((OUT/'index.json').read_text());artifacts={};cards=score_cards.load_cards()
    assert index['source_hashes']==score.source_bindings(HERE/'build_periodic_spatial_scores.py')
    assert index['observation_counterfactuals']['source_hashes']==score.source_bindings(HERE/'build_silence_observation_probes.py')
    for item in index['cases']:
        name=item['case'];r=json.loads((OUT/item['artifact']).read_text());artifacts[name]=r
        assert r['source_hashes']==score.source_bindings() and r['source_stable_during_run']
        assert r['snapshot_sha256']==digest(score_cards.DEFAULT_SNAPSHOT)
        assert r['actual_cards_match_default_snapshot']
        assert r['config']==json.loads((OUT/(name+'.input.json')).read_text())
    proof=json.loads((HERE/'research-runs/periodic-heal-v01/results.json').read_text())
    script=HERE/'research-runs/periodic-heal-v01/independent_probe.py'
    assert proof['source_sha256']==digest(script) and proof['snapshot_sha256']==digest(score_cards.DEFAULT_SNAPSHOT)
    independent=[];crosschecks=[]
    for row in proof['rows']+proof['interventions']:
        d=old.scene3(row['enemy_player_hp'])
        d.update(hand_ids=[row['card_id']],own_player_hp=row['initial_player_hp'],
            opponent_hand_ids=[598]*row['physical_gem_count'],opponent_gold_before_response=2,
            next_max_plays=1 if row['future_play'] else 0,next_own_gold_income=0,
            allies_include_player=row['allies_include_player'])
        if row['goal']=='hp':task=dict(kind='hp')
        elif row['goal']=='win':task=dict(kind='joint',constraints=dict(max_enemy_player_hp=0))
        else:
            a,h=row['body_threshold'];task=dict(kind='joint',body_scope='focal',
                constraints=dict(min_own_body_attack=a,min_own_body_health=h))
        r=score.task_score(d,task,cards=cards,focal_index=0,delay_current=row['delayed_only'])
        assert r['known'],r
        assert (r['feasible'],r['guaranteed_player_hp'])==(row['feasible'],row['guaranteed_player_hp']),(row,r)
        independent.append(dict(card_id=row['card_id'],gems=row['physical_gem_count'],enemy_hp=row['enemy_player_hp'],
            task=row['goal'],body_threshold=row['body_threshold'],future_play=row['future_play'],
            delayed_only=row['delayed_only'],initial_hp=row['initial_player_hp'],
            allies_include_player=row['allies_include_player'],feasible=r['feasible'],hp=r['guaranteed_player_hp']))
        # A predeclared subset covers all three cards, each physical threat
        # count and both tasks while avoiding repeated high-branch probes.
        if row in proof['rows'] and row['enemy_player_hp']==30 and row['goal'] in ('hp','win'):
            x=score.task_score(dict(d,search_algorithm='exhaustive'),task,cards=cards,focal_index=0,
                delay_current=row['delayed_only'])
            assert x['known'] and x['search']['objective_vector']==r['search']['objective_vector']
            crosschecks.append(dict(card_id=row['card_id'],gems=row['physical_gem_count'],task=row['goal'],
                objective_vector=r['search']['objective_vector'],full_vector_equal=True))
    print(json.dumps(dict(independent_healing_matches=len(independent),full_vector_checks=len(crosschecks))),flush=True)
    spatial=json.loads((HERE/'research-runs/spatial-magic-v01/production_agreement.json').read_text())
    assert spatial['source_bindings']==score.source_bindings()
    assert spatial['all_values_agree'] and spatial['all_alpha_exhaustive_vectors_agree']
    for name,h in spatial['verification_source_bindings'].items():
        assert h==digest(HERE/'research-runs/spatial-magic-v01'/name)
    subprocess.run([sys.executable,str(RUN/'hand_capacity_bounds.py')],cwd=HERE,check=True,capture_output=True,text=True)
    bounds=json.loads((RUN/'hand-capacity-bounds.json').read_text());assert not bounds['production_modules_imported']
    capacity=[]
    for n in (5,6):
        r=artifacts[f'hand-{n}-draw-clog']
        for cid in (None,8,196):
            actual=r['removal_baseline']['scores']['hp'] if cid is None else next(c for c in r['rows'] if c['card_id']==cid)['scores']['hp']
            expected=next(x for x in bounds['scenarios'] if x['background_copies']==n and x['focal_card_id']==cid and x['next_card_id']==22)
            assert actual['known'] and expected['lower_bound']==actual['guaranteed_player_hp']==expected['upper_bound']
            capacity.append(dict(background=n,focal=cid,hp=actual['guaranteed_player_hp']))
    cli=[]
    for name in ('spatial-background-1','hand-6-draw-clog','silence-native-taunt-window'):
        output=RUN/(name+'.cli.json');command=[sys.executable,str(HERE/'conditional_card_score.py'),
            '--input',str(OUT/(name+'.input.json')),'--output',str(output)]
        done=subprocess.run(command,cwd=HERE,capture_output=True,text=True,check=True)
        assert json.loads(output.read_text())==artifacts[name]
        cli.append(dict(case=name,command=command,exit_code=done.returncode,complete_json_equal=True,
            stdout=done.stdout.strip(),output_sha256=digest(output)))
    tests=json.loads((RUN/'full-regression.json').read_text())
    assert tests['passed'] and tests['source_unchanged_during_run']
    assert tests['source_hashes']==integration.regression_sources()
    assert bindings==score.source_bindings(Path(__file__))
    result=dict(version=score.VERSION,started_at_utc=started,finished_at_utc=datetime.now(timezone.utc).isoformat(),
        source_hashes=bindings,source_unchanged_during_run=True,cases=len(artifacts),
        candidate_context_rows=sum(len(r['rows']) for r in artifacts.values()),
        source_independent_healing_comparisons=independent,healing_full_vector_crosschecks=crosschecks,
        spatial_independent_comparisons=spatial['candidate_context_comparisons'],spatial_full_vector_queries=spatial['production_queries'],
        capacity_bounds_matches=capacity,cli_replays=cli,
        regression=dict(tests=tests['test_count'],passed=True,seconds=tests['runner_seconds'],receipt_sha256=digest(RUN/'full-regression.json')),
        artifact_hashes={item['artifact']:digest(OUT/item['artifact']) for item in index['cases']},
        limits=['All independent implementations share public rule interpretations; server execution and scene frequencies are not verified.',
            'No whole-pool champion or single Gold score is certified.'])
    (OUT/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(cases=len(artifacts),candidate_context_rows=result['candidate_context_rows'],
        independent_healing=len(independent),spatial_values=spatial['candidate_context_comparisons'],capacity=len(capacity),cli_replays=len(cli))),flush=True)


if __name__=='__main__':main()