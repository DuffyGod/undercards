"""Compare the same acceptable outcomes across every currently compiled native."""
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
import alternative_goal_score as alt
import conditional_card_score as score


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name, value): (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    cards = score.score_cards.load_cards(); by = {c['id']: c for c in cards}
    bindings = score.source_bindings(ROOT / 'alternative_goal_score.py')
    union = dict(kind='any', clauses=[dict(constraints=dict(max_enemy_living_count=0)),
        dict(body_scope='focal', constraints=dict(min_own_body_attack=4, min_own_body_health=1))])
    tasks = dict(hp=dict(kind='hp'), clear=dict(kind='joint', **union['clauses'][0]),
        focal4_1=dict(kind='joint', **union['clauses'][1]), clear_or_focal4_1=union)
    def scene(cid):
        return dict(hand_ids=[cid], hand_costs=[by[cid]['cost']], hand_base_costs=[by[cid]['cost']],
            gold_before_play=10, own_player_hp=15, own_player_max_hp=30, enemy_player_hp=30, enemy_player_max_hp=30,
            own_deck_ids=[], opponent_deck_ids=[], opponent_hand_ids=[], opponent_hand_known=True,
            opponent_gold_before_response=0, max_plays='all_physical', horizon='enemy_attack', node_limit=20000,
            physical_slots=True, front_slot_map=[0,1,2,3], front_missing_policy='fizzle', switch_left_slots=[0,1],
            targeted_hand_empty='fizzle', targeted_hand_choice='eligible_targets',
            enemy_bodies=[dict(card_id=270, attack=4, health=5, max_health=5,
                current_card_cost=3, base_cost=3, silenced=True, slot=1)])
    measured = json.loads((ROOT / 'research-runs/pool-frontier-v04/index.json').read_text())
    ids = sorted(r['card_id'] for r in measured['rows'])
    rows = []; queries = 0; vectors = []
    configurations = [('card' + str(cid), scene(cid), cid) for cid in ids]
    for label, changes in [('hp26', dict(health=26)), ('hp27', dict(health=27)),
            ('armor24', dict(health=24, armor=True)), ('armor25', dict(health=25, armor=True)),
            ('dodge13', dict(health=13, dodge=1)), ('dodge14', dict(health=14, dodge=1))]:
        data = scene(110); data['enemy_bodies'][0].update(changes)
        data['enemy_bodies'][0]['max_health'] = changes['health']
        configurations.append((label, data, 110))
    for cash in (5, 6):
        data = scene(110); data.update(opponent_hand_ids=[100], opponent_hand_costs=[6],
            opponent_hand_base_costs=[6], opponent_gold_before_response=cash)
        configurations.append(('headshot-cash'+str(cash), data, 110))
    for hp in (4, 5):
        configurations.append(('hero-hp'+str(hp), dict(scene(110), own_player_hp=hp), 110))
    configurations.append(('silenced-hp26', dict(scene(110), hand_silenced=[True],
        enemy_bodies=[dict(scene(110)['enemy_bodies'][0], health=26, max_health=26)]), 110))
    for label, data, cid in configurations:
        results = {}
        for name, task in tasks.items():
            value = (alt.evaluate(data, task, cards=cards, focal_index=0) if name=='clear_or_focal4_1'
                else score.task_score(data, task, cards=cards, focal_index=0))
            queries += 1; results[name] = value
        known = [v for v in results.values() if v['known']]
        # These are logical implications, not guessed monotonicity in scene facts.
        either = results['clear_or_focal4_1']; hp = results['hp']
        for name in ('clear', 'focal4_1'):
            one = results[name]
            if one['known'] and one['feasible'] and either['known']:
                assert either['feasible'] and either['guaranteed_player_hp'] >= one['guaranteed_player_hp']
        if either['known'] and either['feasible'] and hp['known']:
            assert hp['guaranteed_player_hp'] >= either['guaranteed_player_hp']
        write(label+'.json', dict(input=data, card=by[cid], tasks=tasks, results=results))
        row = dict(context=label, card_id=cid, name=by[cid]['name'], cost=by[cid]['cost'], artifact=label+'.json',
            scores={n:{k:v.get(k) for k in ('known','feasible','guaranteed_player_hp','unknown')} for n,v in results.items()})
        rows.append(row)
        print(json.dumps(row, ensure_ascii=False), flush=True)
        if label in ('card110', 'card443', 'headshot-cash6', 'armor24'):
            ex = alt.evaluate(dict(data, search_algorithm='exhaustive'), union, cards=cards, focal_index=0)
            queries += 1
            assert ex['known'] and either['known']
            assert tuple(ex['search']['objective_vector']) == tuple(either['search']['objective_vector'])
            vectors.append(dict(context=label, alpha=either, exhaustive=ex))
    write('vector-checks.json', vectors)
    assert bindings == score.source_bindings(ROOT / 'alternative_goal_score.py')
    write('index.json', dict(version=alt.VERSION, source_hashes=bindings, source_stable=True,
        builder_sha256=sha(Path(__file__)), pool_index_sha256=sha(ROOT/'research-runs/pool-frontier-v04/index.json'),
        same_cash_for_all_candidates=10, native_compiled_candidates=len(ids), counterfactual_contexts=len(configurations)-len(ids),
        actual_task_queries=queries, full_vector_matches=len(vectors), rows=rows,
        logical_implications_checked=True, assumptions=['Inherited explicitly saved physical and hand-target hypotheses.',
            'Only one enemy response; empty libraries and no exogenous draws/income.',
            'Alternative success applies at the endpoint under one policy, never independent arm-score arithmetic.'],
        full_pool_optimum_certified=False, global_gold=None, empirical_frequencies=None))
    write('native-snapshot.json', dict(cards=cards))
    print(json.dumps(dict(complete=True, contexts=len(rows), actual_queries=queries)), flush=True)


if __name__ == '__main__': main()