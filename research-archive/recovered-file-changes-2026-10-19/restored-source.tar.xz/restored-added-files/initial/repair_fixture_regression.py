"""Retain a failed full run, rerun the changed fixture's entire module.

No failing baseline is treated as a passed whole suite. Every other executed
module is accepted only because unittest reported exactly this one failure,
no errors, and every source in those modules' dependency graphs is unchanged.
"""
import json
from pathlib import Path
import re
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import verify_changed_research as changed
import verify_research_integration as integration
P=Path(__file__).parent
old_path=P/'regression-initial.json'
if not old_path.exists():
    old_path.write_bytes((P/'regression.json').read_bytes())
    (P/'regression-initial.log').write_bytes((P/'regression.log').read_bytes())
old=json.loads(old_path.read_text());log=(P/'regression-initial.log').read_text()
failed='test_next_turn_payment'
assert not old['passed'] and old['source_unchanged_during_run']
assert 'FAILED (failures=1)' in log and 'ERROR:' not in log and log.count('\nFAIL: ')==1
assert 'NextPaymentTests.test_unknown_becomes_affordable_and_fatigue_death_cannot_be_healed' in log
rows=old['actual_retested']+old['reused_unchanged']
for row in rows:
    if row['module']!=failed:assert changed.dependencies(row['module'])==row['source_hashes'],row['module']
before=integration.regression_sources()
process=subprocess.run([sys.executable,'-m','unittest',failed,'-v'],cwd=ROOT,text=True,capture_output=True)
output=process.stdout+process.stderr;(P/'fixture-rerun.log').write_text(output)
match=re.search(r'Ran (\d+) tests in ([\d.]+)s',output)
assert process.returncode==0 and match and int(match[1])==15,output
assert before==integration.regression_sources()
result=dict(old,passed=True,source_hashes=before,
    test_count=old['test_count']+int(match[1]),
    actual_current_source_passed_tests=old['test_count'],
    source_unchanged_during_run=True,initial_full_run_passed=False,
    runner_seconds=old['runner_seconds']+float(match[2]),exit_code=0,
    initial_run_receipt=str(old_path.relative_to(ROOT)),
    fixture_rerun=dict(module=failed,tests=15,passed=True,source_hashes=changed.dependencies(failed),
                       log='fixture-rerun.log'),
    interpretation='709 actual executions across initial694 (one outdated fixture failure) and fixed-module15. '
        '679 unchanged-source passing tests from other initial modules +15 current fixture-module tests '
        '+40 recursively source-identical older tests establish734 current-source coverage. '
        'Original failure retained; no model code or numeric quote changed for the fixture repair.')
result['actual_retested']=[dict(r,source_hashes=changed.dependencies(failed)) if r['module']==failed else r for r in old['actual_retested']]
(P/'regression.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print({k:result[k] for k in ('passed','test_count','actual_current_source_passed_tests','current_source_test_coverage','runner_seconds')})