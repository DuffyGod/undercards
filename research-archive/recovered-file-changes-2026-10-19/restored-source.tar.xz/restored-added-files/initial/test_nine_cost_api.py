"""Production hooks for positional Switch and persistent Dodge decay."""
import copy
import unittest

import paid_board_tactics as paid
import evaluate_situation as api


class NineCostPublicTests(unittest.TestCase):
    def scene(self,cid=419):
        return dict(hand_ids=[cid],gold_before_play=9,opponent_gold_before_response=0,
            own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
            ally_bodies_before_play=[],enemy_bodies=[dict(card_id=270,attack=4,health=2,max_health=4,slot=i) for i in range(4)],
            max_plays=1,horizon='enemy_attack',opponent_hand_ids=[],objectives=['guaranteed_hp'],
            physical_slots=True,front_slot_map=[0,1,2,3],switch_left_slots=[0,1])

    def entry(self,scene):
        observations={k:copy.deepcopy(scene[k]) for k in ('hand_ids','gold_before_play','opponent_gold_before_response',
            'own_player_hp','enemy_player_hp','ally_bodies_before_play','enemy_bodies')}
        params={k:copy.deepcopy(v) for k,v in scene.items() if k not in observations and k not in ('own_player_max_hp','enemy_player_max_hp')}
        return dict(observations,role='midrange',own_turn=9,paid_board_scenario=params,
            callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30))

    def test_positional_switch_public_matches_direct_complete_json(self):
        scene=self.scene();direct=paid.evaluate(scene);public=api.evaluate(self.entry(scene))['paid_board_tactics']
        self.assertTrue(direct['complete_in_declared_scope'],direct['unknown']);self.assertEqual(public,direct)
        self.assertEqual(public['objectives'][0]['metrics']['own_player_hp'],15)
        self.assertEqual(public['objectives'][0]['payment_accounting']['current_paid_gold'],9)
        self.assertTrue(any('switch_left_slots' in item for item in public['rule_hypotheses']))

    def test_missing_partition_unknown_clears_public_recommendation(self):
        scene=self.scene();scene.pop('switch_left_slots')
        public=api.evaluate(self.entry(scene))['paid_board_tactics']
        self.assertFalse(public['complete_in_declared_scope']);self.assertFalse(public['recommendations'])
        self.assertTrue(any('partition' in reason for reason in public['unknown']))

    def test_native_robot_reaches_public_api_and_loses_printed_stack(self):
        scene=self.scene(249);scene['enemy_bodies']=[];direct=paid.evaluate(scene)
        public=api.evaluate(self.entry(scene))['paid_board_tactics'];self.assertEqual(public,direct)
        self.assertTrue(public['complete_in_declared_scope'])
        own=public['objectives'][0]['endpoint_boards']['own'];self.assertEqual(own[0]['dodge'],1)


if __name__=='__main__':unittest.main()