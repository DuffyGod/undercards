"""All-pool physical stat sensitivity, preserving the fixed target cohort.

These are fractions in a source-defined reference set, not expectations over
actual encounters. No formula refitting after a candidate's stat intervention.
"""
import collections
import csv
import gzip
import hashlib
import json
from pathlib import Path
import board_pool_inventory as inventory
import board_tactics as tactics
import score_cards as source

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/board-standard-v01'


def main():
    cards=[c for c in source.load_cards() if c['card_type']=='monster' and c['pool_category']=='ordinary_non_token']
    targets=[c for c in cards if inventory.scope(c,inventory.families(c))[0] in ('standalone_board','mixed_board_resource_or_synergy')]
    def unit(c):
        f=tactics.compile_card(c)['statuses']
        return tactics.Unit(str(c['id']),c['id'],c['attack'],c['health'],c['health'],c['cost'],f['taunt'],f['armor'],f['dodge'])
    targets=[(c,unit(c)) for c in targets]
    rows=[]
    for c in cards:
        u=unit(c);counts=collections.defaultdict(collections.Counter)
        for other,v in targets:
            baseline_a,baseline_b=(tactics.hurt(u,v.attack),tactics.hurt(v,u.attack)) if u.attack>0 else (u,v)
            higher_atk=tactics.hurt(v,u.attack+1)
            higher_hp_survives=(u.health+1 > (0 if u.dodge and v.attack>0 else max(0,v.attack-int(u.armor)))) if u.attack>0 else True
            x=counts[other['cost']];x['n']+=1
            x['baseline_kills']+=int(u.attack>0 and baseline_b.health<=0)
            x['atk1_kills']+=int(higher_atk.health<=0)
            x['baseline_survives']+=int(baseline_a.health>0)
            x['hp1_survives']+=int(higher_hp_survives)
            x['baseline_effective_damage']+=v.health-baseline_b.health
            x['atk1_effective_damage']+=v.health-higher_atk.health
        for cost,x in sorted(counts.items()):
            n=x['n']
            rows.append(dict(card_id=c['id'],name=c['name'],attack=c['attack'],health=c['health'],cost=c['cost'],target_cost=cost,target_count=n,
                             baseline_kill_fraction=x['baseline_kills']/n,attack_plus_one_kill_fraction=x['atk1_kills']/n,
                             attack_plus_one_kill_fraction_delta=(x['atk1_kills']-x['baseline_kills'])/n,
                             baseline_survive_fraction=x['baseline_survives']/n,health_plus_one_survive_fraction=x['hp1_survives']/n,
                             health_plus_one_survive_fraction_delta=(x['hp1_survives']-x['baseline_survives'])/n,
                             baseline_effective_damage_mean=x['baseline_effective_damage']/n,
                             attack_plus_one_effective_damage_mean_delta=(x['atk1_effective_damage']-x['baseline_effective_damage'])/n,
                             scope='printed_body_single_forced_exchange',source_text_omitted=c['effect_readable']))
    with (OUT/'body-all-pool-sensitivity.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    # Cross-check every baseline against the previous independently generated
    # pair/stratum artifact; this checks freshness and arithmetic, not gameplay.
    baseline={(int(r['card_id']),float(r['target_cost'])):r for r in csv.DictReader((OUT/'body-exchange-profiles.csv').open())}
    for r in rows:
        b=baseline[r['card_id'],float(r['target_cost'])]
        assert abs(r['baseline_kill_fraction']-float(b['kill_fraction']))<1e-12
        assert abs(r['baseline_survive_fraction']-float(b['survive_fraction']))<1e-12
        assert r['attack_plus_one_kill_fraction_delta']>=0
        assert r['health_plus_one_survive_fraction_delta']>=0
    summary=dict(candidate_count=len(cards),fixed_target_count=len(targets),candidate_target_pairs=len(cards)*len(targets),
        stratum_rows=len(rows),attack_plus_one_cards_with_any_new_kill_threshold=len({r['card_id'] for r in rows if r['attack_plus_one_kill_fraction_delta']>0}),
        attack_plus_one_cards_with_any_effective_exchange_damage_gain=len({r['card_id'] for r in rows if r['attack_plus_one_effective_damage_mean_delta']>0}),
        health_plus_one_cards_with_any_new_survival_threshold=len({r['card_id'] for r in rows if r['health_plus_one_survive_fraction_delta']>0}),
        baseline_artifact_all_rows_matched=True,target_cohort_refit=False,
        caveats=['Printed-body and literal-prefix status only; all other candidate and target text omitted.',
                 'Cohort frequencies are deterministic coverage fractions, not metagame encounter probabilities.',
                 'Zero ATK cannot attack: forced-exchange profile changes legality when raised to one. Tactical choice can still decline the exchange.',
                 'HP/ATK effects on Magic, Dust, healing, conditions and card identities require the separate whole-mechanism evaluator.',
                 'Armor/Dodge combined ordering follows the shared source-unverified primitive assumption.'],
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (OUT/'body-all-pool-sensitivity.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,ensure_ascii=False))


if __name__=='__main__':main()