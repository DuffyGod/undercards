# 不知道规则时，可执行打法的保证

2026-10-15（北京时间）。入口：[rule_probe_score.py](../../rule_probe_score.py)，7个实际输入/结果和[scores.csv](scores.csv)。不修改原paid/API/scorer语义，仍保留它们对完整状态分歧的unknown。

## 原生卡反例：逐规则最优会高估

己10HP、2G；手持Migosp（原生2/2、2G），己方Charles在slot0（3/1、Armor），Ranger在slot3（3/1/max2、Dodge1）；两只当前不可攻击。对方有两只观察0攻4血、已沉默的Tem，和可付3G的Allergic Tem。位置是声明事实，不把这种配合免费计入构筑。

Migosp只能不出、出slot1、出slot2。出slot1给Charles+1HP，出slot2给Ranger+1HP。敌方两名其他Tem使Allergic的两种假说为聚合2伤或两次1伤。

| 当前共同准备 | 聚合2伤：保两体 | 两次1伤：保两体 |
|---|---|---|
| 不出 | 否 | 否 |
| Migosp出slot1 | 是，联合玩家10HP | 否 |
| Migosp出slot2 | 否 | 是，联合玩家10HP |

两种已知规则各自最优都能保两体、玩家10，但规则未知时没有一个共同准备能保证。程序返回`common_policy.feasible=false, guaranteed_player_hp=null`；逐规则最优的最差值10仅是先知上界。翻转左右位置仍出现缺口；敌其他Tem数2→1后两种伤害包解释相同，共同准备可保两体、玩家10。

[独立敌回应枚举](native_migosp_reply.py)只用标准库，246状态、6个准备×规则值与生产工具匹配。它包括敌0攻旧体的所有攻击目标/顺序/停止、真实付3G与部署格；旧Tem至多受一次3反击，不能死，因此配合数始终2。首次独立稿把Migosp原生HP误记1，被卡源断言拒绝；改回2后重算通过，原稿与首失败日志保留。不能用子智能体意见或相同结论代替这项核对。

## 能够闭合的用途与限制

Fox敌手例中，单个3攻2血Ranger面对未知重复端点规则，两种规则都保玩家10，故短窗共同保命10可精确计算；保3攻2血则无法跨规则保证。只将当前/最大HP同时2→3，该身体目的变成可保证10。玩家HP相同不能证明整卡所有用途都相同。

本程序刻意只允许`enemy_attack`：所有己方决策都在未知规则影响发生前完成，此后只有敌方决策。枚举全部当前完整前缀，对每个固定前缀在各具体规则下让知情敌方完整搜索，然后计算`max_prefix min_rule`。每个前缀的根状态、动作菜单与物理转移必须逐世界完全相同，规则参数不能流入己动作元数据；有未来己决策、受影响己方来源、预算耗尽或未支持机制时拒绝/unknown。

合并物理端点在此短协议中不丢信息：规则尚未影响可见状态，己方以后没有决策，过去的行动历史不能再用于适应。长窗口、可见伤害反馈后分支和一般隐藏规则信息集尚未实现。敌方被允许知道规则；给出的规则worlds只是明确假说包络，未证明穷尽服务器实现。

还区分`min_rule max_prefix`（共同策略的先知上界）与`max_rule max_prefix`（任何一种真实规则最优的上界）。前者不能解释成“每种真实规则都至多如此”，更不能当作可执行推荐。

```sh
python analysis/monster-value-heuristic/rule_probe_score.py --input analysis/monster-value-heuristic/research-runs/rule-ambiguity-v01/tem-migosp-hidden-packets.input.json --output /tmp/common-rule-score.json
python analysis/monster-value-heuristic/research-runs/rule-ambiguity-v01/native_migosp_reply.py
```

16项新测试实际通过8.383s（另有早先代理局部16项5.879s记录），覆盖原生先知反例、已知规则与完整搜索逐向量一致、alpha/穷举、预算unknown、不同物理前缀拒绝与真实CLI。该次按依赖复用485项源完全相同的已通过测试，详见[正式回归回执](selective-regression.json)。这些是实现与短协议证据，不是服务器裁定、真实胜率或全Goal完成。