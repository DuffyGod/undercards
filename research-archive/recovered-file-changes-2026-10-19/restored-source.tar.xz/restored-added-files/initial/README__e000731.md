# 原生9G：真实Switch位置与回合末Dodge

2026-10-15（北京时间）。paid0.24 / board0.6 / API0.26 / conditional score0.4。直接打开[交互表](score-explorer.html)、[CSV](scores.csv)、[验证](verification.json)。10个声明输入、65个候选与条件组合，其中35个保命评分闭合、30个保留未知。32张原生9G全保留，当前2闭合/30未知；未认证全桶最佳。

## Switch是位置约束，不是独立二选一

源关键词`kw-switch-desc`（快照来源行2257）规定：触发时怪物在左侧执行第一分支，否则第二分支。Spade King的群体沉默/当前HP≤2击杀由**实际部署槽**决定；程序不再单独枚举左右分支。`switch_left_slots=[0,1]`明确声明本实验四槽的左右分区，补集是右侧；这个数字分区尚无服务器执行验证。无位置/分区时unknown。

同一9G现金，己15HP、敌30HP，四只观察4攻、max4HP的Thrashing Machine，敌手为空；截止一次完整敌回应，己方可不出/停止，敌方可任意攻击或停止。候选实际付Spade9、Robot9、Toriel8、Plane7、Baron8，不虚构剩余现金收益。

| 仅改变敌体当前HP/击杀阈值 | Spade | Robot 98 | Toriel | Tsunderplane | Baron |
|---|---:|---:|---:|---:|---:|
| 四体2HP，原生阈值2 | 15 | 0 | 2 | 3 | 7 |
| 四体3HP，原生阈值2 | 11 | 0 | 2 | 3 | 7 |
| 上一行，仅Spade阈值2→3 | 15 | 0 | 2 | 3 | 7 |

0是已知的最坏玩家死亡HP，不是unknown。Spade首/第三行能保证清场并保15；第二行不能保证清场。Robot没有Taunt或当前攻击权，不能阻止四体直接打脸16。不能只看高费9/8与大量印刷Dodge就称其能救宽场。

真正的机会也受格子约束：右侧槽2、3被两只Tiny占据时，Spade只能左侧沉默，保11且不能清场；只把一只Tiny从slot3移到slot1，右侧击杀开放，保15且可清场。左侧满时，不能沉默透明Big Hat Charles来让准备攻击的Aaron清场；只移动Tiny开放左侧，清场变为可保证且保15。不是重写卡牌分数，是改变合法动作集合。

沉默复用DT免疫、modified-stat/maxHP与queued Delay守卫；自动全体效果包括Transparency。直接击杀保留Dust，不当伤害，不被Armor/Dodge减免。所有目标串行顺序与同时批次必须产生同一完整物理状态，否则unknown。

## Dodge98不能当作敌方回合的98层保护

Robot原生9/8，`Dodge (98). Turn end: Lose 97 Dodge.`。只在活着的拥有者回合末扣当前层数，最低0；下次拥有者开始不会重置为98。Decline/Dust可能与扣层竞争时比较触发次序，不擅取有利顺序。

同9G、己15HP、单4攻4血敌体、敌手两张可实际支付的1伤Gem、一次完整敌回应：

| 参数 | 到敌回应时Dodge | 最坏剩余体血 | 保命HP | 保自身≥2攻4血的联合HP |
|---|---:|---:|---:|---:|
| 原生每轮失97 | 1 | 3 | 9 | 不能保证 |
| 仅失97→96 | 2 | 4 | 9 | 9 |

敌可先用便宜Gem耗Dodge，再让4攻体命中；不能强制对手先打大伤害。独立程序枚举`[4,1,1]`的次序，最大体伤分别5、4，得到同值上下界。该例说明纯保命评分相同，身体用途仍对一个数值差敏感。反事实完整卡源另存`.cards.json`，不是原生结果。

## 验证、失败与运行

当前21个生产目标完整向量与穷举一致；独立策略上下界中21个9G值匹配，另20个8G/5G值在[观察探针](../frontier-observations-v01/README.md)。2个实际公共API/direct/CLI完整JSON一致；Spade阈值与Robot扣层两个修改卡源又经真实评分CLI完整重放。505项受影响测试实际通过265.9s；25项全部递归依赖与通过基线相同而复用，共530项当前覆盖，不称全数重跑。视图120次选择切换逐行核对，DOM替身不当浏览器布局验证。

早先“自由选Switch分支”的180查询已撤为宽松历史上界，完整保留`research-runs/choice-magic-v01/superseded-free-branch/`，从未接生产核。原型查源纠正后才整合。构建时一个私有敌手字段误入公共参数而被拒绝，修正公共包装后重跑；验证脚本一条多余筛选表达式语法错误亦留原日志。测试通过不取代源规则与独立推演。

```sh
python analysis/monster-value-heuristic/build_nine_cost_scores.py
python analysis/monster-value-heuristic/build_conditional_score_view.py --directory analysis/monster-value-heuristic/experiments/nine-cost-v01 --default-case robot-punishment-native
python analysis/monster-value-heuristic/verify_nine_cost_scores.py
python analysis/monster-value-heuristic/conditional_card_score.py --input analysis/monster-value-heuristic/experiments/nine-cost-v01/robot-punishment-decay96.input.json --cards-source analysis/monster-value-heuristic/experiments/nine-cost-v01/robot-punishment-decay96.cards.json --output /tmp/robot-decay96.json
```

paid0.23此前7个当前报告已连同源码固定于`research-runs/nine-cost-v01/before`，旧48则固定paid0.22；它们仍可复现，不冒充新核心重算。这里没有真实场景频率、全局Gold、完整对局可靠率或服务器位置裁定；全池大量机制仍未闭合，整个Goal继续。