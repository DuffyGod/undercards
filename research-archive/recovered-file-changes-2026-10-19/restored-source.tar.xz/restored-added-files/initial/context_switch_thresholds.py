"""Exact context-mixture switch thresholds from comparable conditional HP.

No frequency is estimated. The candidate is fixed across contexts, while its
play policy may adapt to the declared context only once that context is observed.
This is a conditional construction probe, not a predicted match win rate.
"""
from fractions import Fraction
import hashlib
import json
from pathlib import Path

import conditional_card_score as score

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/periodic-spatial-v01'


def fraction(value):return Fraction(str(value))


def switch_threshold(first_high,second_high,first_low,second_low):
    high=fraction(first_high)-fraction(second_high)
    low=fraction(first_low)-fraction(second_low)
    slope=high-low
    root=-low/slope if slope else None
    return dict(high_context_difference=str(high),low_context_difference=str(low),
        first_minus_second_expression=f'({high})*p + ({low})*(1-p)',
        switch_probability=str(root) if root is not None and 0<=root<=1 else None,
        first_better_above_switch=slope>0 if root is not None and 0<=root<=1 else None,
        probability_estimated=False)


def main():
    bindings=score.source_bindings(Path(__file__));runs={}
    common=json.loads((HERE/'experiments/conditional-score-v01/toriel-window-target-6-8.input.json').read_text())
    for hp in (3,30):
        cfg=dict(common,candidate_ids=[8,21,196],tasks={},reference_card_id=196,include_delay=True)
        cfg['scene']=dict(common['scene'],enemy_player_hp=hp)
        name=f'context-8g-enemyhp{hp}';r=score.compare(cfg);runs[name]=r
        for suffix,value in [('.input.json',cfg),('.json',r)]:
            (OUT/(name+suffix)).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    high=runs['context-8g-enemyhp30'];low=runs['context-8g-enemyhp3']
    clog=json.loads((OUT/'hand-6-draw-clog.json').read_text())
    def value(r,cid):
        cell=next(c for c in r['rows'] if c['card_id']==cid)['scores']['hp']
        if not cell['known']:raise ValueError('Unknown values cannot define a switch threshold')
        return cell['guaranteed_player_hp']
    comparisons=[]
    for label,a,b,first,second in [('deep-target-versus-lethal-window',8,21,high,low),
            ('paid-control-window-versus-full-hand-clog',8,196,high,clog)]:
        for r in (first,second):
            ca=next(c for c in r['rows'] if c['card_id']==a);cb=next(c for c in r['rows'] if c['card_id']==b)
            # A pure HP switch must not recommend sacrificing a guaranteed
            # win in one context. Differing win feasibility needs another goal.
            assert ca['scores']['win']['known'] and cb['scores']['win']['known']
            assert ca['scores']['win']['feasible']==cb['scores']['win']['feasible']
        hp=[value(first,a),value(first,b),value(second,a),value(second,b)]
        comparisons.append(dict(comparison=label,first_candidate=a,second_candidate=b,
            hp_values=dict(first_high=hp[0],second_high=hp[1],first_low=hp[2],second_low=hp[3]),
            **switch_threshold(*hp)))
    assert bindings==score.source_bindings(Path(__file__))
    result=dict(version='observable-context-switches-0.1.0',source_hashes=bindings,
        source_stable_during_run=True,comparisons=comparisons,
        artifact_hashes={name+'.json':hashlib.sha256((OUT/(name+'.json')).read_bytes()).hexdigest() for name in runs}|{
            'hand-6-draw-clog.json':hashlib.sha256((OUT/'hand-6-draw-clog.json').read_bytes()).hexdigest()},
        limits=['p is supplied hypothetical context frequency, never estimated or a DeepSeek prior.',
            'The context must be genuinely observable before the per-context policy adapts; hidden-state oracle averaging is invalid.',
            'All opponent menus and physical prices/hands are declared. No global Gold, win probability or complete deck inclusion grade.',
            'These comparisons require equal within-context guaranteed-win feasibility before comparing conditional HP mixtures.',
            'The construction probe holds the declared contexts exogenous; inserting a real deck card can change their frequencies and needs separate calibration.'])
    (OUT/'context-switches.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(comparisons,ensure_ascii=False),flush=True)


if __name__=='__main__':main()