"""Local interventions on one physical hand, not a weighted scene benchmark."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/fee-purpose-v02'


def main():
    path=OUT/'heuristic-feedback.py'
    spec=importlib.util.spec_from_file_location('feedback_probe',path)
    probe=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(probe)
    cards=score_cards.load_cards()
    cases=[]
    interventions=[('no_spell',False,0,5,2),('punishment_unaffordable',True,2,5,2),
        ('punishment_payable',True,3,5,2),('strong_hp_plus_one',True,3,6,2),
        ('weak_attack_plus_one',True,3,5,3),('weak_attack_minus_one',True,3,5,1)]
    for name,spell,gold,strong_hp,weak_a in interventions:
        data=probe.scene(spell)
        data['opponent_gold_before_response']=gold
        data['enemy_bodies'][0]['health']=strong_hp
        data['enemy_bodies'][1]['attack']=weak_a
        rows=[]
        for i,cid in enumerate(probe.HAND):
            result=probe.locked_first_deployment(data,i,cards)
            if not result['search_complete']: raise AssertionError(result)
            m=result['selected']['metrics']
            rows.append(dict(card_id=cid,hp=m['own_player_hp'],
                remaining_enemy_attack=m['enemy_board_attack'],search=result))
        current={k:copy.deepcopy(data[k]) for k in ('hand_ids','gold_before_play',
            'opponent_gold_before_response','own_player_hp','enemy_player_hp',
            'ally_bodies_before_play','enemy_bodies')}
        current.update(data['paid_board_scenario'],condition_known_state=data['condition_state'],own_player_max_hp=30)
        result=paid.evaluate(current,cards)
        if not result['complete_in_declared_scope']: raise AssertionError(result['unknown'])
        cases.append(dict(intervention=name,input=data,all_first_deployments=rows,optimum=result))
        print(name,[(r['card_id'],r['hp']) for r in rows],flush=True)
    output=dict(version='physical-hand-local-boundary-counterfacts-0.1.0',cases=cases,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ['paid_board_tactics.py','board_tactics.py','build_hand_decision_boundaries.py']},
        probe_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        limitations=['Same physical hand, budget and endpoint; only one intervention per paid baseline.',
            'Enemy30HP cannot be defeated by these one-Play lines; survive HP is meaningful here, not a general componentwise bound.',
            'No empirical scene weights or full-cost-pool claim; these are local conditional decisions.'])
    (OUT/'hand-decision-boundaries.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()