"""Exact requested HP/task coordinates without optimizing unused tie-breaks.

An independent entry point. It retains the same actions, physical rules,
information and deadlines as TaskSearch; no approximate leaf evaluation is
used. Optional geometry erasure needs the separate position certificate.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path

import board_tactics as board
import conditional_card_score as score
from physical_slot_score import PhysicalSlotSearch
import position_quotient_score as quotient

VERSION='scalar-task-score-0.1.0'
LOADED_SOURCES=score.source_bindings(Path(__file__))


class ScalarObjective:
    def objective(self,state,mode):
        if mode=='guaranteed_hp':return (board.metrics(state)['own_player_hp'],)
        if mode=='purpose':return super().objective(state,mode)[:2]
        raise ValueError('Scalar task solver accepts guaranteed_hp or purpose only')


class ScalarPhysicalSearch(ScalarObjective,PhysicalSlotSearch):pass
class ScalarPlainSearch(ScalarObjective,score.TaskSearch):pass


def evaluate(data,task,*,cards=None,focal_index=None,delay_current=False,
             geometry='physical',vector_diagnostic=False):
    bindings=score.source_bindings(Path(__file__))
    if bindings!=LOADED_SOURCES:raise RuntimeError('Loaded scalar sources changed; start a fresh process')
    cards=score.score_cards.load_cards() if cards is None else cards
    digest=quotient._cards_digest(cards)
    if geometry not in ('physical','certified_quotient'):raise ValueError('Unknown geometry policy')
    if type(vector_diagnostic) is not bool or type(delay_current) is not bool:
        raise ValueError('Diagnostic and delay flags are boolean')
    if not isinstance(task,dict) or set(task)-{'kind','body_scope','constraints'}:
        raise ValueError('Task fields: kind/body_scope/constraints')
    kind=task.get('kind','joint');scope=task.get('body_scope','board')
    if kind not in ('hp','joint') or scope not in ('board','focal','lineage'):
        raise ValueError('Task kind hp/joint and body scope board/focal/lineage required')
    constraints=copy.deepcopy(task.get('constraints',{}))
    if not isinstance(constraints,dict):raise ValueError('Task constraints must be an object')
    if kind=='hp' and (constraints or scope!='board'):raise ValueError('HP task has no body constraints')
    if scope!='board' and not score.paid.SINGLE_BODY_PURPOSE_FIELDS.intersection(constraints):
        raise ValueError('Focal/lineage task requires same-body constraints')
    scene=copy.deepcopy(data)
    if type(scene.get('physical_slots',False)) is not bool:raise ValueError('physical_slots is boolean')
    if not scene.get('physical_slots') and quotient.GEOMETRY_FIELDS.intersection(scene)-{'physical_slots'}:
        raise ValueError('Geometry observations require physical_slots=true')
    result=dict(version=VERSION,known=False,status='unknown',task=copy.deepcopy(task),body_scope=scope,
        geometry=geometry,geometry_certificate=None,feasible=None,guaranteed_player_hp=None,
        search=None,source_bindings=bindings,cards_sha256=digest,
        input_sha256=hashlib.sha256(score.canonical(data).encode()).hexdigest(),
        numeric_semantics='Exact first coordinate (HP) or first two coordinates (goal,HP) of the original joint minimax.',
        tie_break_optimum_claimed=False,all_metrics_componentwise_guaranteed=False,
        original_full_vector_result_replaced=False,vector_diagnostic=None)
    if scope!='board' and focal_index is None:
        result.update(known=True,status='not_applicable')
    else:
        if geometry=='certified_quotient':
            if set(constraints)-quotient.GOAL_FIELDS:raise ValueError('Position-sensitive or unaudited goal')
            result['geometry_certificate']=quotient.eligibility(scene,cards)
            if not result['geometry_certificate']['issued']:
                result['status']='geometry_certificate_rejected'
                result['unknown']=result['geometry_certificate']['reasons']
                return _finish(result,cards,digest,bindings)
            scene=quotient.erased_scene(scene)
        scene.pop('objectives',None);scene.pop('purpose_constraints',None)
        if kind=='joint':scene['purpose_constraints']={'min_own_player_hp':1,**constraints}
        mode='guaranteed_hp' if kind=='hp' else 'purpose'
        cls=ScalarPhysicalSearch if scene.get('physical_slots') else ScalarPlainSearch
        engine=cls(cards,scene,body_scope=scope,focal_index=focal_index,delay_current=delay_current)
        root=engine.root()
        search=(engine.solve(root,mode) if not engine.unknown else
            dict(search_complete=False,root_value_proven=False,unknown=sorted(set(engine.unknown)),
                 metrics=None,principal_variation=[]))
        result['search']=search;result['known']=search['search_complete']
        result['status']='known' if result['known'] else 'unknown'
        result['unknown']=search.get('unknown',[])
        if result['known']:
            result['feasible']=search['metrics']['own_player_hp']>0 if kind=='hp' else search['purpose_guaranteed']
            result['guaranteed_player_hp']=search['metrics']['own_player_hp'] if kind=='hp' or result['feasible'] else None
        if vector_diagnostic:
            # Diagnostic completion is distinct from the requested proof.
            diagnostic=score.task_score(scene,task,cards=cards,focal_index=focal_index,delay_current=delay_current)
            result['vector_diagnostic']=diagnostic
            if result['known'] and diagnostic['known']:
                n=1 if kind=='hp' else 2
                if tuple(search['objective_vector'])!=tuple(diagnostic['search']['objective_vector'][:n]):
                    raise AssertionError('Scalar optimum differs from full-vector leading coordinates')
    return _finish(result,cards,digest,bindings)


def _finish(result,cards,digest,bindings):
    if bindings!=score.source_bindings(Path(__file__)) or digest!=quotient._cards_digest(cards):
        raise RuntimeError('Scalar source or card records changed during evaluation')
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path);parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--cards-source',type=Path)
    args=parser.parse_args();payload=json.loads(args.input.read_text());cards=None
    if args.cards_source:
        raw=json.loads(args.cards_source.read_text());cards=raw.get('cards') if isinstance(raw,dict) else raw
    result=evaluate(payload['scene'],payload['task'],cards=cards,focal_index=payload.get('focal_index'),
        delay_current=payload.get('delay_current',False),geometry=payload.get('geometry','physical'),
        vector_diagnostic=payload.get('vector_diagnostic',False))
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':main()