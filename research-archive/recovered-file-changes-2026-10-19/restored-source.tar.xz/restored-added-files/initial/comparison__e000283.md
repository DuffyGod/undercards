# 可复算的费用、保命目的与惩罚抗性

2026-10-11。入口 `evaluate_situation.py` 0.8.0，实际执行器 `paid_board_tactics.py`。本页发布条件最优与实际付款门槛；全部卡池的通用构筑排名仍未完成。

## 完整 0G、1G 怪物桶的条件最优

共同条件：我方空场、3/30HP、余额1G，手牌只有一张被评价怪物；敌玩家30HP，敌场唯一6/5 Aaron，允许其任意合法目标或停止。每次最多一个当前 Play，免费效果仍发生，牌库为空，没有下一自然抽牌。SOUL、神器与槽附魔不参与。Noellecoaster 的历史2+G法术计数已知至少1、无额外减费，因此实际手费至少2G，不能在1G时出场。

包括全部普通0G怪物1张和1G怪物28张，未按用途标签或当前程序覆盖排除。目的只比较敌攻击窗结束时**能保证的玩家生命**。逐卡来源失败证明与可执行赢家搜索结合；源证明不冒充整卡完整状态模拟。

| 同一条件中的回应/场面 | 0G最优保证HP | 1G最优保证HP | 确定达到最优的怪物 | 保留未知 |
|---|---:|---:|---|---|
| 单敌、没有新解牌 | 0 | 3 | Dummy、Kawkaw | Microwave可能并列，空选Erase合法性未定 |
| 单敌、敌有3G及Punishment | 0 | 3 | Kawkaw | 无更优竞争者；源死亡不撤销敌人已受的麻痹 |
| 再加一个2/3敌人、没有新解牌 | 0 | 1 | Dummy、Kawkaw | Microwave被2/3先撞死后，6/5可打脸，不能并列 |
| 双敌、敌有3G及Punishment | 0 | 1 | Kawkaw | 其他候选不能超过该生命保证 |
| 单敌、敌有1G及Penetration | 0 | **[0,3]，未定** | 不发布保命冠军 | Kawkaw目标的属性/Paralyze如何被Silence移除尚缺完整裁定 |

前四项最少支付1G才能保证存活；0G的Tiny Froggit无法挡住本窗致命攻击。第一项的未知Microwave保留生命上界3，不能超过已执行的两个赢家，所以不妨碍证明最优值3。已知Noelle不可支付的条件不可删除：h=0时的免费Cast、随机offer和空front裁定未闭合，本证明程序拒绝该历史。

**实际打法差异**：Dummy用一次Taunt消耗敌人的攻击；Kawkaw选择敌6/5，使其变7/8并麻痹，本攻击窗无法出手。Punishment杀死Kawkaw也不追回已施加效果。这不表示Kawkaw长期优于Dummy：它留下更大敌体，下一次机会需要额外处理。卡牌的保护方式、惩罚抗性与尾部代价均须独立说明。

五个面板的完整清单、上下界、源证明和支持的原始轨迹在同目录对应JSON。源快照、被评价卡文字/身材/费用及参考生成物变化会令证明失效；不沿用旧数值证书。

## 已知完整手牌：不同目的的精确预算门槛

共同输入：我3/30HP，敌6/5 Aaron＋2/3 Froggit；敌手中一张Punishment，余额3G。己手牌为 **Dummy、Dummy、Kawkaw、Battleflies、Rock、Punishment、Gemstone**，最多三个当前Play；Battleflies的Need已知成立。敌施法、攻击、目标和停止可任意交错。以下只对这组物理手牌作最优声明，**不是对应费用的全卡池冠军**。

| 当前预算 | 保命优先策略可保证HP | 同一最坏路线中的残留敌攻击力 | 代表动作 |
|---:|---:|---:|---|
| 0G | 0 | 8 | 无救命路线 |
| 1G | 1 | 9 | Kawkaw麻痹6/5，2/3仍可打脸 |
| 2G | 1 | 8 | Dummy＋Kawkaw给Dummy加身材；敌可攻击后Punishment破盾 |
| 3G | **3** | 8 | 两个Dummy＋Kawkaw，强化一只Dummy，能覆盖攻击/解牌交错 |
| 4G | 3 | 7 | Punishment杀2/3，Kawkaw麻痹6/5 |
| 5G | 3 | 3 | Punishment＋Gemstone清6/5，Kawkaw麻痹2/3 |
| 6G | 3 | 2 | Dummy获Kawkaw强化，Battleflies清6/5；盾能承受弱敌及解牌 |
| 7G | **3** | **0** | Punishment杀2/3，Battleflies Haste5攻击杀6/5，双方死亡 |

因此，在该手牌内，“保住全部3HP”的最低初始资金为 **3G**；“保住3HP并清空敌场”的最低初始资金为 **7G**。逐一穷举更低预算的合法路线，没有被跳过的未实现候选。双Dummy和Kawkaw提供可计算的手牌互补，不能把每张卡的孤立风险简单相加。

程序的保命、清场、抢血是公开的词典序偏好。敌人分别最小化所选完整向量；某条清场目标轨迹的HP并不自动成为该策略的独立最坏HP。上表采用保命目标。到8G时保命向量可能把最后1G用于Gemstone打脸；这只是当前偏好，不是经过校准的“1点伤害比未来1G更值”。最低任务付款由达到目标的最低预算另行证明。

## 数值反事实与跨卡影响

保持共同手牌、敌解牌及终点；仅改表中条件。原始结果在 `need_true.json`、`need_false.json`、`enemy_health_plus_one.json`、`attack_plus_one_recovers_threshold.json`。

| 改动 | 保住3HP最低G | 保住3HP并清场最低G | 通用原因 |
|---|---:|---:|---|
| 原始Need真、敌大怪5HP | 3 | 7 | Battleflies的5攻击恰好击杀 |
| Need假，Battleflies保留Haste但仅3攻击 | 3 | **8** | 用Punishment＋Gemstone先杀大怪，再让Battleflies杀小怪 |
| 大怪HP从5增到6 | 3 | **8** | 原来的一次Haste攻击不再达到击杀阈值 |
| 在6HP场面，把Battleflies基础ATK加1 | 3 | **7** | 激活后6攻击重新达到击杀阈值 |

没有给某张卡追加惩罚分或定向修公式。变化来自同一伤害、付款、攻击权限及目标规则。较高的击杀门槛改变了Punishment/Gemstone的必要使用，影响剩余牌与金币；廉价保命组合的3G门槛保持不变，说明“清场效率”和“生命保险”是不同用途。

## 与旧基础相比，实际补回和纠正了什么

- 复用既有 `spell_window.parse`、三值 `finite_conditions` 和 `draw_options.draw_ledger`；敌方用真实卡及费用，施法可以穿插攻击。敌支出从敌余额扣，绝不变成我方收益。
- 当前己方咒术可在满场施放；已知Draw执行真实容量、消耗牌库和疲劳，未知身份/疲劳不补默认值。Bench＋Fortune在最后一张库和两张库的下一自然抽牌结局不同，恢复旧回归。自然Draw与开始治疗会改变结果而缺裁定时保留unknown。
- 新增实际死亡计数和手中身材修改。独立反例中，Froggit与Moldsmal同时死后，Instant Noodles从当前8G降到6G，强化Spider，再付1G Spider Haste清受伤Aaron，7G能保住3HP。不是把印刷减费当现金；必须提供已观察的当前动态费用。
- Rock抗性不再只检查“先解后打”：双敌可先杀Rock，再花3G Punishment杀Dust Pebble，最后打脸；单敌的攻击已经耗尽则可存活。
- DT的Silence免疫执行；已沉默Tree可以通过`silenced:true`保留历史，不恢复成长。新部署Dust对象同时死亡争槽在实际事件时检查；未定队列不再输出完整保证。

独立审查的五个历史假完整路径及修正输出冻结在 `independent-counterexamples-before-after.json`。Noodles、既往Silence和DT免疫得到实际改正；竞争Dust队列和开始Draw顺序仍未知，未将其假装实现。公共API与独立搜索逐字段相同，见 `manifest.json`。

## 使用

在仓库根目录：

```sh
python analysis/monster-value-heuristic/certify_low_fee_rescue.py --panel one_attack_paid_damage --two-plus-spells-cast 1 --output /tmp/low-fee-rescue.json
python analysis/monster-value-heuristic/evaluate_situation.py --input analysis/monster-value-heuristic/experiments/reliable-defense-v01/current.input.json --output /tmp/current-paid-decision.json
python analysis/monster-value-heuristic/build_reliable_defense_comparison.py
```

公共API的 `authoritative_tactical_recommendation` 指向 `paid_board_tactics`；旧Gold报价与固定响应仅保留各自历史诊断范围。直接使用 `paid_board_tactics.py --input PATH` 可输入当前已知手牌、敌方声明咒术手牌、实际费用与观察场面，输出所有合法施法/攻击选择的策略。

## 尚不能据此宣布的结果

其他费用桶仍有未闭合竞争者，不能用受支持子集的冠军替代。新核还有未来己方出牌、敌怪部署、SOUL/神器、位置、多数回调、Lesser Dog后续完整付款与全场时机的缺口；既有携带与绝对时机模块仍单独保留，未宣称已全面合并。未知敌手概率、到手机会、构筑胜率与长期Gold标准没有实战校准。这些限制影响通用构筑/完整真实对局评价，但不抹去上述固定窗口、全低费桶上下界与完整声明手牌的可复算门槛。