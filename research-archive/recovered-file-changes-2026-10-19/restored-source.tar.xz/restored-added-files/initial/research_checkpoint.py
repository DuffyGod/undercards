#!/usr/bin/env python3
"""Create, verify and restore a portable research checkpoint (stdlib only)."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
META = "CHECKPOINT-MANIFEST.json"
EXTRA_FILES = (
    "tools/research_checkpoint.py",
    "CURRENT_CHECKPOINT.md",
    "analysis/monster-value-heuristic/information_pressure.py",
    "analysis/monster-value-heuristic/test_information_pressure.py",
)
EXTRA_DIRS = (
    "analysis/monster-value-heuristic/finite_game",
    "analysis/monster-value-heuristic/research-runs/information-policy-v01",
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_path(name: str) -> PurePosixPath:
    p = PurePosixPath(name)
    if (not name or p.is_absolute() or ".." in p.parts or "\\" in name
            or str(p) != name or ":" in name):
        raise ValueError(f"Unsafe archive path: {name!r}")
    if any(part in {".git", "__pycache__", ".aws", ".codex"}
           or part == ".env" or part.startswith(".env.") for part in p.parts):
        raise ValueError(f"Excluded path: {name!r}")
    if p.suffix in {".pem", ".key", ".pyc", ".pyo"} or p.name == "tencent-api-key":
        raise ValueError(f"Excluded path: {name!r}")
    return p


def git(*args: str) -> bytes:
    return subprocess.run(["git", *args], cwd=ROOT, check=True,
                          stdout=subprocess.PIPE).stdout


def create(archive: Path) -> dict:
    paths = set(git("ls-files", "-z").decode().rstrip("\0").split("\0"))
    # Old ignored research evidence is explicitly enumerated, never glob the workspace.
    old = json.loads((ROOT / "research-archive/manifest.json").read_text())
    paths.update(e["path"] for e in old["entries"])
    paths.update(EXTRA_FILES)
    for directory in EXTRA_DIRS:
        for p in (ROOT / directory).rglob("*"):
            if p.is_file() and "__pycache__" not in p.parts and p.suffix not in {".pyc", ".pyo"}:
                paths.add(p.relative_to(ROOT).as_posix())
    # Exclude our generated outputs even after they become tracked in Git.
    paths = {p for p in paths if not p.startswith("research-archive/information-policy-v01")}
    payload = {}
    for name in sorted(paths):
        safe_path(name)
        path = ROOT / name
        if path.is_symlink() or path.resolve() != path.absolute():
            raise ValueError(f"Refusing symlink: {name}")
        payload[name] = path.read_bytes()
    manifest = {
        "schema": "undercards-research-checkpoint-1",
        "checkpoint": "information-policy-v01-2026-10-17",
        "base_commit": git("rev-parse", "HEAD").decode().strip(),
        "scope": "Full available source/evidence; does not recover missing paid0.32/API0.34 work.",
        "entries": [{"path": name, "bytes": len(data), "sha256": sha(data)}
                    for name, data in payload.items()],
    }
    archive.parent.mkdir(parents=True, exist_ok=True)
    temporary = archive.with_suffix(archive.suffix + ".tmp")
    with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in payload.items():
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 17, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data)
        z.writestr(META, json.dumps(manifest, ensure_ascii=False, indent=2).encode())
    temporary.replace(archive)
    external = dict(manifest, archive_sha256=sha(archive.read_bytes()), archive_bytes=archive.stat().st_size)
    archive.with_suffix(".manifest.json").write_text(
        json.dumps(external, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"files": len(payload), "archive_bytes": archive.stat().st_size,
            "archive_sha256": external["archive_sha256"]}


def read_verified(archive: Path) -> tuple[dict, dict[str, bytes]]:
    archive_bytes = archive.read_bytes()
    sidecar = archive.with_suffix(".manifest.json")
    external = json.loads(sidecar.read_text()) if sidecar.exists() else None
    if external and external["archive_sha256"] != sha(archive_bytes):
        raise ValueError("Archive SHA256 differs from sidecar; no files restored")
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate ZIP members")
        manifest = json.loads(z.read(META))
        if manifest.get("schema") != "undercards-research-checkpoint-1":
            raise ValueError("Unsupported checkpoint schema")
        entries = manifest["entries"]
        paths = [e["path"] for e in entries]
        if len(paths) != len(set(paths)) or set(names) != set(paths) | {META}:
            raise ValueError("ZIP members differ from manifest")
        if external and any(external.get(k) != v for k, v in manifest.items()):
            raise ValueError("Internal and external manifests differ")
        payload = {}
        for entry in entries:
            name = entry["path"]
            safe_path(name)
            data = z.read(name)
            if len(data) != entry["bytes"] or sha(data) != entry["sha256"]:
                raise ValueError(f"Content checksum mismatch: {name}")
            payload[name] = data
    return manifest, payload


def restore(archive: Path, destination: Path) -> dict:
    _, payload = read_verified(archive)
    destination = destination.resolve()
    pending = []
    identical = 0
    # Check every collision and path before writing anything. Never overwrite a different file.
    for name, data in payload.items():
        target = destination / name
        if not target.resolve().is_relative_to(destination):
            raise ValueError(f"Destination escapes through symlink: {name}")
        for ancestor in target.parents:
            if ancestor == destination.parent:
                break
            if ancestor.exists() and not ancestor.is_dir():
                raise ValueError(f"Destination parent is not a directory: {name}")
        if target.exists():
            if not target.is_file() or target.read_bytes() != data:
                raise ValueError(f"Different existing content; use an empty destination: {name}")
            identical += 1
        else:
            pending.append((target, data))
    for target, data in pending:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    return {"restored": len(pending), "already_identical": identical,
            "destination": str(destination)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("create", "verify", "restore"))
    parser.add_argument("--archive", type=Path,
                        default=ROOT / "research-archive/information-policy-v01.zip")
    parser.add_argument("--destination", type=Path)
    args = parser.parse_args()
    if args.action == "create":
        result = create(args.archive)
    elif args.action == "verify":
        manifest, payload = read_verified(args.archive)
        result = {"verified_files": len(payload), "base_commit": manifest["base_commit"],
                  "archive_sha256": sha(args.archive.read_bytes())}
    else:
        if args.destination is None:
            parser.error("restore requires --destination; choose an empty directory")
        result = restore(args.archive, args.destination)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()