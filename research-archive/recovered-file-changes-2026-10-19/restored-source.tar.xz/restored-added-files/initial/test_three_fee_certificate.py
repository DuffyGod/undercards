import copy
import unittest
import certify_three_fee_rescue as proof
import score_cards


class ThreeFeeCertificateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.cards=score_cards.load_cards()

    def test_full_bucket_optimum_is_source_bounded_and_winner_executed(self):
        for panel,hp in (('one_attack',8),('two_attacks',6)):
            r=proof.certify(panel,self.cards)
            all_ids={c['id'] for c in self.cards if c['card_type']=='monster'
                and c['pool_category']=='ordinary_non_token' and c['cost']==3}
            self.assertEqual(set(r['all_candidate_ids']),all_ids)
            self.assertEqual(r['optimal_guaranteed_hp_bounds'],[hp,hp])
            self.assertEqual(r['known_optimal_card_ids'],[580])
            self.assertTrue(next(c for c in r['cards'] if c['card_id']==580)['full_state_simulated'])
            self.assertFalse(all(c['full_state_simulated'] for c in r['cards']))

    def test_semantic_pool_and_hidden_product_drift_reject_certificate(self):
        for cid,field,value in ((363,'effect_readable','Dust: Heal 99 HP to you.'),
                                (1,'tribes',['LOST_SOUL'])):
            changed=copy.deepcopy(self.cards)
            next(c for c in changed if c['id']==cid)[field]=value
            with self.assertRaises(ValueError):proof.certify('two_attacks',changed)