import copy
import unittest
import paid_board_tactics as paid
import score_cards


class QueuedDelayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.cards=score_cards.load_cards()

    def scene(self,n=3,**changes):
        data=dict(hand_ids=[580],hand_base_costs=[3],gold_before_play=3,own_player_hp=3,
            own_player_max_hp=30,enemy_player_hp=30,max_plays=1,horizon='enemy_attack',
            objectives=['guaranteed_hp'],enemy_bodies=[dict(card_id=15,attack=6,health=5)],
            own_dustpile_monsters=[dict(card_id=108,current_cost=6,base_cost=6) for _ in range(n)])
        return dict(data,**changes)

    def result(self,data,cards=None):
        result=paid.evaluate(data,cards or self.cards)
        self.assertTrue(result['complete_in_declared_scope'],result['unknown'])
        return result['objectives'][0]

    def test_actual_dust_threshold_changes_protection_and_paid_reply(self):
        for n,hp in ((2,3),(3,8)):
            self.assertEqual(self.result(self.scene(n))['metrics']['own_player_hp'],hp)
        two=[dict(card_id=15,attack=6,health=5),dict(card_id=2,attack=2,health=3)]
        self.assertEqual(self.result(self.scene(enemy_bodies=two))['metrics']['own_player_hp'],6)
        self.assertEqual(self.result(self.scene(opponent_hand_ids=[96],opponent_gold_before_response=3))['metrics']['own_player_hp'],2)
        self.assertEqual(self.result(self.scene(enemy_bodies=two,opponent_hand_ids=[96],opponent_gold_before_response=3))['metrics']['own_player_hp'],0)

    def test_source_dies_before_end_but_play_queue_still_heals_once(self):
        engine=paid.PaidSearch(self.cards,self.scene(hand_ids=[580,598,598,598],
            hand_base_costs=[3,1,1,1],gold_before_play=6,max_plays=4))
        state=next(s for a,s in engine.deploys(engine.root()) if a.get('card_id')==580)
        for _ in range(3):
            state=next(s for a,s in engine.casts(state,'own') if a['targets']==[('own',0)])
        self.assertEqual(state.own[0].health,0)
        self.assertEqual(len(state.queued_delays),1)
        result=engine.solve(state,'guaranteed_hp')
        self.assertTrue(result['search_complete'],result.get('unknown'))
        self.assertEqual(result['metrics']['own_player_hp'],2)
        self.assertEqual(result['delay_accounting']['healed_hp'],5)
        self.assertEqual(result['delay_accounting']['pending_count'],0)

    def test_ordinary_summon_does_not_enqueue_delay(self):
        cards=copy.deepcopy(self.cards)
        next(c for c in cards if c['id']==3)['effect_readable']='Magic: Summon a Totemic Guard [#580].'
        r=self.result(self.scene(hand_ids=[3]),cards)
        self.assertEqual(r['metrics']['own_player_hp'],3)
        self.assertEqual(r['delay_accounting']['healed_hp'],0)

    def test_missing_dust_and_disagreeing_cost_filters_remain_unknown(self):
        missing=self.scene();missing.pop('own_dustpile_monsters')
        altered=self.scene(own_dustpile_monsters=[dict(card_id=108,current_cost=3,base_cost=6)]*3)
        for data in (missing,altered):
            r=paid.evaluate(data,self.cards)
            self.assertFalse(r['complete_in_declared_scope'])
            self.assertTrue(any('cost filter/history' in u for u in r['unknown']))

    def test_current_cost_equal_printed_does_not_prove_base_cost(self):
        data=self.scene(0,hand_ids=[580,550,550,550]);data.pop('hand_base_costs')
        engine=paid.PaidSearch(self.cards,data)
        state=next(s for a,s in engine.deploys(engine.root()) if a.get('card_id')==580)
        self.assertIsNone(engine.delay_gate(state,{'threshold':3,'cost':6}))

    def test_changed_condition_timing_and_silence_are_not_guessed(self):
        data=self.scene(0,hand_ids=[580,108,108,108],hand_base_costs=[3,6,6,6],gold_before_play=9,max_plays=2)
        engine=paid.PaidSearch(self.cards,data)
        state=next(s for a,s in engine.deploys(engine.root()) if a.get('card_id')==580)
        state=next(s for a,s in engine.deploys(state) if a.get('card_id')==108)
        r=engine.solve(state,'guaranteed_hp')
        self.assertFalse(r['search_complete'])
        self.assertIn('condition changed',r['unknown'][0])
        r=paid.evaluate(self.scene(hand_ids=[580,79],hand_base_costs=[3,1],gold_before_play=4,max_plays=2),self.cards)
        self.assertFalse(r['complete_in_declared_scope'])
        self.assertTrue(any('Silence of already queued' in u for u in r['unknown']))

    def test_turn_end_queue_order_is_not_silently_assumed(self):
        r=paid.evaluate(self.scene(ally_bodies_before_play=[dict(card_id=23,attack=3,health=3,ready=False)]),self.cards)
        self.assertFalse(r['complete_in_declared_scope'])
        self.assertTrue(any('Turn end callback order' in u for u in r['unknown']))


if __name__=='__main__':unittest.main()