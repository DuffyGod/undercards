"""Complete106-card3G inventory in one shared paid context, no cherry picks."""
import hashlib
import json
from pathlib import Path

import build_damage_packet_comparison as fixture
import compare_monster_purposes as comparison
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/damage-packet-v01'


def main():
    cards=score_cards.load_cards();by={c['id']:c for c in cards}
    scene=fixture.fixture()
    for k in ('hand_ids','objectives','purpose_constraints'):scene.pop(k)
    scene['hand_base_costs']=[3]
    config=dict(scene=scene,printed_costs=[3],purposes={
        'live_and_keep_body1':dict(min_own_player_hp=1,min_own_body_attack=2,min_own_body_health=1),
        'live_and_keep_body2':dict(min_own_player_hp=1,min_own_body_attack=2,min_own_body_health=2),
        'defeat_enemy':dict(min_own_player_hp=1,max_enemy_player_hp=0)})
    result=comparison.compare(config,cards);assert len(result['cards'])==106
    b=result['buckets'][0];closed=[r for r in result['cards'] if r['survival']['complete_in_declared_scope']]
    summary=dict(candidates=106,closed=len(closed),unknown=106-len(closed),
        supported_subset_hp_best=b['supported_subset_best_guaranteed_hp'],
        hp_leaders=[dict(card_id=cid,name=by[cid]['name']) for cid in b['supported_subset_best_card_ids']],
        whole_pool_champion_certified=b['survival_optimum_certified'],
        body1_feasible=b['purposes']['live_and_keep_body1']['known_feasible_card_ids'],
        body2_feasible=b['purposes']['live_and_keep_body2']['known_feasible_card_ids'],
        defeat_feasible=b['purposes']['defeat_enemy']['known_feasible_card_ids'])
    out=dict(summary=summary,result=result,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('build_packet_pool.py','build_damage_packet_comparison.py','compare_monster_purposes.py','paid_board_tactics.py','board_tactics.py')},
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        limits=['All106 ordinary3G sources, not just a selected board-purpose family.',
            'Same15HP/3G,enemy3HP/1ATK5HP Aaron,two physically held1G Gems/2G; two enemy responses, no next draw/income/play.',
            'Native unmodified current/base/printed cost3 is declared for each candidate; actor effects/Need still checked.',
            'Unknown candidates retained. A supported-subset best is not a whole-bucket maximum.',
            'Purposes optimized separately; never concatenate their maxima or manufacture probabilities.'])
    (OUT/'pool-comparison.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    lines=['# 全106张普通3G卡的共同付费目的比较','',
        '同一场景：己15/30HP、银行3G、敌3/30HP和观察Aaron1ATK5HP；敌实际手持两张Gemstone，银行2G。当前可出候选或保留，下一己只攻击，直到第二敌回应，没有新增抽牌/现金/出牌。','',
        f"完整来源106张，闭合{summary['closed']}、未知{summary['unknown']}。已支持子集HP最佳{summary['supported_subset_hp_best']}，候选{summary['hp_leaders']}。未闭合者保留，所以未认证全桶冠军。",'',
        '| 已闭合候选 | 玩家HP保证 | 留同一≥2ATK/1HP体 | 留同一≥2ATK/2HP体 | 敌英雄归零 |','|---|---:|---|---|---|']
    for r in sorted(closed,key=lambda r:(-r['survival']['objectives'][0]['metrics']['own_player_hp'],r['card_id'])):
        hp=r['survival']['objectives'][0]['metrics']['own_player_hp']
        values=[r['purposes'][k]['guaranteed'] for k in config['purposes']]
        lines.append(f"| {r['name']} #{r['card_id']} | {hp} | "+' | '.join(str(x) for x in values)+' |')
    lines+=['','每列独立优化；例如赢的路线与保更厚身体的路线不一定相同。来源未知可能是完整文本、参数缺失或规则歧义，不能填0。所有106原文、输入、完整搜索结果与缺口均在JSON。']
    (OUT/'pool-comparison.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(summary,ensure_ascii=False))


if __name__=='__main__':main()