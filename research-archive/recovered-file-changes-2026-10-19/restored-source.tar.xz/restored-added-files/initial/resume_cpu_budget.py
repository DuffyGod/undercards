"""Resume unmeasured cards with an explicit CPU rather than load-sensitive gate.

The first16 and original wall-clock stop stay untouched. Node20k never changes.
Each remaining candidate has5CPU seconds/30wall seconds for its four tasks.
"""
import hashlib
import json
from pathlib import Path
import time
import run_timing as run

HERE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    original=json.loads((HERE/'index.json').read_text());catalog=json.loads((HERE/'inventory.json').read_text())['rows']
    bindings=run.score.source_bindings();assert bindings==original['source_bindings']
    rows=list(original['rows']);done={r['card_id'] for r in rows};new=[];stop=None
    for item in catalog:
        if not item['physical_compile_supported'] or item['card_id'] in done:continue
        start_cpu=time.process_time();start_wall=time.monotonic();row=run.run_one(item['card_id'])
        row['cpu_seconds']=time.process_time()-start_cpu;row['wall_seconds']=time.monotonic()-start_wall
        rows.append(row);new.append(row)
        run.write('resume-progress.json',dict(rows=rows,new_rows=new,source_bindings=bindings))
        if row['input_or_adapter_failure'] or row['cpu_seconds']>5 or row['wall_seconds']>30:
            stop=dict(card_id=item['card_id'],input_failure=row['input_or_adapter_failure'],
                cpu_seconds=row['cpu_seconds'],wall_seconds=row['wall_seconds']);break
    assert bindings==run.score.source_bindings()
    result=dict(original,rows=rows,source_stable_during_run=True,original_index_sha256=sha(HERE/'index.json'),
        original_stop_sha256=sha(HERE/'expansion-stop.json'),resume_builder_sha256=sha(Path(__file__)),
        resumed_candidates=len(new),resume_queries=4*len(new),cpu_gate_per_four_tasks=5,wall_guard_per_four_tasks=30,
        original_wall_gate_seconds=5,node_limit_unchanged=20000,expansion_stop=stop,
        unmeasured_compile_supported=[r['card_id'] for r in catalog if r['physical_compile_supported'] and r['card_id'] not in {v['card_id'] for v in rows}],
        protocol_change_reason='Concurrent unrelated processes can inflate wall time without increasing states or work. CPU time is the declared per-candidate work gate; the original16 results and wall stop are retained. This is a changed scheduling protocol, not a claim the original five-wall-second gate passed.')
    run.write('index.resumed.json',result)
    print(json.dumps(dict(measured=len(rows),resumed=len(new),unmeasured=result['unmeasured_compile_supported'],stop=stop)))

if __name__=='__main__':main()