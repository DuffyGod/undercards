"""Actual optional choices, bilateral payment risks and order refusals."""
import copy
import unittest

import board_tactics as board
import build_physical_draw_magic_comparison as comparison
import paid_board_tactics as paid
import score_cards


class PhysicalDrawMagicTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards=score_cards.load_cards()
        cls.record=comparison.build()
        cls.rows={r['case']:r for r in cls.record['cases']}
        cls.prefixes={r['case']:r for r in cls.record['forced_prefixes']}

    def objective(self,name,index=0):return self.rows[name]['result']['objectives'][index]

    def test_exact_templates_are_generic_and_plain_board_adapter_refuses(self):
        by={c['id']:c for c in self.cards}
        for cid,kind in ((44,'draw_optional'),(199,'draw_both')):
            fake=dict(by[cid],id=999123,name='Generic raw mechanism probe')
            self.assertEqual(board.compile_card(fake)['magic'],(kind,2))
            result=board.evaluate(dict(hand_ids=[cid],gold_before_play=8),self.cards)
            self.assertFalse(result['complete_in_declared_scope'])
        self.assertEqual(paid.DRAW_MAGIC_KINDS,('draw','draw_optional','draw_both'))

    def test_native_optional_choice_and_later_real_payment(self):
        self.assertEqual([self.objective('optional_forced_amount_'+str(n))['metrics']['own_player_hp']
                          for n in range(3)],[5,9,8])
        best=self.objective('optional_native_best_one')
        self.assertEqual((best['metrics']['own_player_hp'],best['principal_variation'][0]['draw_count']),(9,1))
        later=[a for a in best['principal_variation'] if a.get('kind')=='deploy' and a.get('card_id')==22]
        self.assertEqual([(a['hand_index'],a['paid_gold']) for a in later],[(2,3)])
        self.assertEqual(self.objective('optional_remove_magic')['metrics']['own_player_hp'],5)
        self.assertEqual(self.objective('optional_no_future_cash')['principal_variation'][0]['draw_count'],0)

    def test_optional_zero_and_unknown_positive_branches_are_distinct(self):
        best=self.objective('optional_only_fatigue_choose_zero')
        self.assertEqual((best['metrics']['own_player_hp'],best['principal_variation'][0]['draw_count']),(2,0))
        data=comparison.scene(own_deck_ids=None,max_plays=1,next_max_plays=0,horizon='enemy_attack')
        engine=paid.PaidSearch(self.cards,data);root=engine.root()
        self.assertEqual(engine.draw(root,0),root)
        result=paid.evaluate(data,self.cards)
        self.assertFalse(result['complete_in_declared_scope'])
        self.assertFalse(result['recommendations'])

    def test_bilateral_cash_changes_purpose_with_constant_hp(self):
        cheap=self.objective('both_enemy_cash_2',1);paid_reply=self.objective('both_enemy_cash_3',1)
        restored=self.objective('both_enemy_library_no_punishment',1)
        self.assertEqual([o['metrics']['own_player_hp'] for o in (cheap,paid_reply,restored)],[6,6,6])
        self.assertEqual([o['purpose_guaranteed'] for o in (cheap,paid_reply,restored)],[True,False,True])
        self.assertEqual([o['principal_variation'][0]['card_id'] for o in (cheap,paid_reply,restored)],[199,14,199])
        spells=[a for a in cheap['principal_variation'] if a['kind']=='cast_spell' and a.get('side')!='enemy']
        self.assertEqual([(a['card_id'],a['paid_gold']) for a in spells],[(96,3)])

    def test_real_copy_ledger_and_hand_capacity_after_source_removal(self):
        one=self.prefixes['gyftrot_actual_draw_one']['after']
        self.assertEqual((one['hand'],one['own_deck'],one['gold']),((1,2),(),0))
        both=self.prefixes['manticore_actual_both_draw_two']['after']
        self.assertEqual((both['hand'],both['enemy_hand'],both['gold']),((1,2,3),(0,1),3))
        burned=self.prefixes['gyftrot_hand_cap_burn']['after']
        self.assertEqual((len(burned['hand']),burned['own_cards_burned'],burned['own_deck']),(7,1,(9,)))

    def test_full_vectors_and_unrelated_card_controls(self):
        self.assertTrue(all(r['full_vectors_equal'] for r in self.record['cases']+self.record['forced_prefixes']))
        for cid in (14,556,8):
            original=self.rows['unrelated_native_'+str(cid)]['result']['objectives']
            changed=self.rows['unrelated_changed_draw_catalogue_'+str(cid)]['result']['objectives']
            self.assertEqual([o['objective_vector'] for o in original],[o['objective_vector'] for o in changed])

    def test_unknown_order_fatigue_library_and_turbo_are_not_given_fallback_scores(self):
        self.assertEqual(len(self.record['unknown_cases']),6)
        for row in self.record['unknown_cases']:
            with self.subTest(row=row['case']):
                result=row['result']
                self.assertFalse(result['complete_in_declared_scope']);self.assertTrue(result['unknown'])
                self.assertFalse(result['recommendations'])
                self.assertTrue(all(o['metrics'] is None and not o['principal_variation'] for o in result['objectives']))

    def test_enemy_owner_chooses_draw_quantity_and_consumes_its_actual_library(self):
        data=comparison.scene(hand_ids=[],own_deck_ids=[],max_plays=0,horizon='enemy_attack',
            opponent_hand_ids=[44],opponent_deck_ids=[22],opponent_gold_before_response=8,
            enemy_player_hp=7)
        engine=paid.PaidSearch(self.cards,data);state=engine.boundary(engine.root())
        choices=[(a,s) for a,s in engine.deploys(state) if a.get('card_id')==44]
        self.assertEqual([a['draw_count'] for a,s in choices],[0,1,2])
        action,drawn=choices[1]
        self.assertEqual((action['side'],action['paid_gold']),('enemy',8))
        self.assertEqual((drawn.enemy_hand,drawn.enemy_deck,drawn.enemy_gold),((1,),(),0))


if __name__=='__main__':unittest.main()