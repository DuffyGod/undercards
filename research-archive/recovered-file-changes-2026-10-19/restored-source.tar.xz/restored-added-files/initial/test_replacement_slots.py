"""A drawn-slot substitution cannot claim background actions as card gains."""
import copy
import unittest

import compare_replacement_slots as slots
import score_cards
from build_replacement_comparison import probes


class ReplacementSlotsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards = score_cards.load_cards()
        cls.config = probes()['attack-6-punishment-1-background-108']
        cls.result = slots.compare(cls.config, cls.cards)

    def test_identical_budget_background_and_native_candidate_payment(self):
        by_id = {c['id']:c for c in self.cards}
        for row in self.result['rows']:
            scene = row['input']
            self.assertEqual(scene['gold_before_play'],8)
            self.assertEqual(scene['hand_ids'][:-1],[22,108])
            self.assertEqual(scene['hand_costs'][-1],by_id[row['card_id']]['cost'])
            self.assertEqual(scene['hand_base_costs'][-1],by_id[row['card_id']]['cost'])
        self.assertEqual(self.config,probes()['attack-6-punishment-1-background-108'])

    def test_background_only_route_is_not_credited_as_candidate_deployment(self):
        jerry = next(r for r in self.result['rows'] if r['card_id']==14)
        dog = next(r for r in self.result['rows'] if r['card_id']==48)
        self.assertEqual(jerry['values']['guaranteed_hp'],4)
        self.assertTrue(jerry['path_diagnostics']['guaranteed_hp']['candidate_not_deployed_in_one_worst_path'])
        actions = dog['path_diagnostics']['guaranteed_hp']['candidate_deployment_in_one_worst_path']
        self.assertEqual([(a['card_id'],a['observed_path_phase']) for a in actions],[(48,0)])

    def test_hp_and_pressure_give_different_replacement_choices(self):
        by_id = {r['card_id']:r for r in self.result['rows']}
        self.assertEqual(by_id[48]['values'],dict(guaranteed_hp=9,pressure=False))
        self.assertEqual(by_id[8]['values'],dict(guaranteed_hp=4,pressure=True))
        pair = next(p for p in self.result['pairwise_comparisons'] if p['candidate']==48 and p['alternative']==8)
        self.assertEqual(pair['guaranteed_hp_difference'],5)
        self.assertFalse(pair['no_worse_in_all_measured_objectives'])

    def test_unknown_candidate_stays_visible_and_pairwise_values_unknown(self):
        config = copy.deepcopy(self.config)
        config['candidate_ids']=[34,48]
        result = slots.compare(config,self.cards)
        unknown = result['rows'][0]
        self.assertEqual(unknown['values'],dict(guaranteed_hp=None,pressure=None))
        self.assertIsNone(result['pairwise_comparisons'][0]['guaranteed_hp_difference'])
        self.assertIsNone(result['pairwise_comparisons'][0]['no_worse_in_all_measured_objectives'])
        self.assertTrue(result['pairwise_comparisons'][0]['unresolved_objectives'])

    def test_reserved_goal_and_variable_cash_or_unknown_draw_are_rejected(self):
        variants=[]
        a=copy.deepcopy(self.config);a['purposes']['guaranteed_hp']=dict(min_own_player_hp=1);variants.append(a)
        a=copy.deepcopy(self.config);del a['scene']['gold_before_play'];variants.append(a)
        a=copy.deepcopy(self.config);a['scene']['next_natural_draw_count']=1;variants.append(a)
        a=copy.deepcopy(self.config);a['scene']['hand_costs']=[1];variants.append(a)
        for config in variants:
            with self.assertRaises(ValueError):slots.compare(config,self.cards)


if __name__=='__main__':unittest.main()