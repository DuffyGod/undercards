# 手牌定向增益已进入通用评分

当前paid0.25／API0.27／scorer0.5，board0.6保持。入口仍是[conditional_card_score.py](../../conditional_card_score.py)与[evaluate_situation.py](../../evaluate_situation.py)；不需要专用卡名公式。`targeted_hand_magic.py`现在只是同一生产引擎的任务CLI。新家族覆盖Endogeny、Bone Painting、Sugar Pot、Town Hall Guy。

同现金10G、自己15HP、敌单只6/5 Aaron；真实手持辅助＋6G Lesser Dog，截止一次敌回应。保体指同一张Dog同时≥6攻1血，另查保命。

| 辅助＋Lesser Dog | 保命HP | 保Dog≥6/1时HP | 相对同现金仅Dog的保命增量 |
| --- | ---: | ---: | ---: |
| Endogeny | 15 | 不可保证 | +6 |
| Bone Painting | 15 | 不可保证 | +6 |
| Sugar Pot | 9 | 9 | 0 |
| 无辅助 | 9 | 不可保证 | 基准 |

Endogeny给Dog Haste，真付4＋6后先换掉敌人；Bone Painting真付3＋6，Taunt逼敌交战。两者都可牺牲Dog保命。Sugar Pot使Dog变7/7，敌能打脸6所以只保9，却无法用6攻杀掉它，留下厚体用途。不是保命值越高就覆盖所有用途，也不是整手15HP都应归给辅助。

数值与时机反事实：

- Sugar同手牌现金10→9，无法同时付款4＋6，保体保证消失；现金10不变、敌攻6→7，同样撤销保体，保命9→8。
- Town Hall Guy＋Long Sink同敌4/4，现金8时真付3＋5，给手中Haste Long增1攻，保证同体5攻1血／15HP；现金7时该用途不能保证。两者纯保命都是15，后者可以只付Long5换掉敌人。
- 迟抽到的另一张同名目标不继承早先buff；增益始终绑定物理手牌index。Taunt/Haste随原副本真实支付出场后转移并从手牌账本消费。新辅助牌自身后来被自然抽到，也由完整Play/Magic分类正常执行，没有关闭Turbo或未知held回调守卫。

12个手牌条件×2用途、原双敌轮4张×4用途已实际重算，共40个目的结果；另4个完整向量穷举、4个直接核心复核、1次任务CLI，主批49次。12个HP与12个身体结论、16个跨费用单元有独立标准库策略界。两例真实统一API／direct／CLI完整JSON相同，当前资源Burger的纯标量＋位置证书又实际保4HP。源稳定回归回执和最终核验见[verification.json](verification.json)；未将测试数当实战正确率。

原双敌轮单牌输入没有配合目标：Endogeny保命/清场9，Bone Painting／Sugar Pot／Town Hall Guy保命5、不能保证清场；四者均不能保证获胜或原体2/2。因此，不能把有Dog的组合成绩套到单牌状态。完整输入、支付账本和最坏路径在[本轮原始目录](../../research-runs/targeted-hand-production-v01/index.json)，[评分CSV](scores.csv)可直接比较；paid0.24原型完整保留在[冻结目录](../../research-runs/targeted-hand-v01/README.md)。

公开假设仍保留：`targeted_hand_empty=fizzle`指定无合法目标时无效果结算；`targeted_hand_choice=eligible_targets`指定Endogeny只可选择有匹配目标的选项。默认unknown拒绝推断，没有服务器执行证据。Charge与Haste的持牌目标分类也仍未知。若未知机制、信息或预算未闭合，统一入口撤销确定推荐。

这些是已声明观察与有限窗口中的策略保证。没有真实场景频率、全局Gold、构筑胜率或完整对战验证；后续继续用跨卡结果和反事实暴露缺口。