// Execute the generated page script. DOM substitute; no layout assertion.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const here=__dirname,html=fs.readFileSync(path.join(here,'score-explorer.html'),'utf8');
const encoded=html.match(/<script type="application\/json" id="data">([\s\S]*?)<\/script>/)[1],data=JSON.parse(encoded);
class Element{
 constructor(){this.children=[];this.listeners={};this.value='';this.checked=false;this.textContent='';this.className='';this.classList={add:name=>{this.className+=' '+name;}};}
 append(...children){this.children.push(...children);}replaceChildren(...children){this.children=[...children];}
 addEventListener(name,fn){(this.listeners[name]??=[]).push(fn);}fire(name){for(const fn of this.listeners[name]??[])fn();}
}
const elements={};for(const id of ['data','scene','task','known','certificate','facts','summary','rows','count','links','detail','provenance'])elements[id]=new Element();
elements.data.textContent=encoded;elements.known.checked=elements.certificate.checked=true;
const document={getElementById:id=>{assert(elements[id],id);return elements[id];},createElement:()=>new Element()};
const script=html.split('</script><script>')[1].split('</script>')[0],context=vm.createContext({document});vm.runInContext(script,context);
let switches=0,rowsChecked=0,detailsChecked=0,linksChecked=0;
for(const certificate of [false,true])for(const known of [false,true])for(const group of data.groups)for(const task of Object.keys(data.tasks)){
 elements.certificate.checked=certificate;elements.known.checked=known;elements.scene.value=group.key;elements.task.value=task;elements.task.fire('change');switches++;
 const get=r=>certificate?r.scores:r.physical_scores,shown=group.rows.filter(r=>!known||get(r)[task].known);
 assert.equal(elements.rows.children.length,shown.length);
 const found=new Set();for(const tr of elements.rows.children){
  const id=Number(tr.children[0].textContent.match(/#(\d+)$/)[1]),r=shown.find(x=>x.card_id===id);assert(r);found.add(id);
  const scores=get(r),cell=scores[task],hp=scores.hp;
  assert.equal(tr.children[0].textContent,r.name+' #'+id);assert.equal(tr.children[1].textContent,String(r.printed_cost));
  assert.equal(tr.children[2].textContent,!cell.known?'未知':cell.guaranteed_player_hp===null?'不可保证':String(cell.guaranteed_player_hp));
  assert.equal(tr.children[3].textContent,!cell.known||!hp.known?'未知':cell.guaranteed_player_hp===null?'不可行':String(hp.guaranteed_player_hp-cell.guaranteed_player_hp));rowsChecked++;
  tr.fire('click');const detail=JSON.parse(elements.detail.textContent);assert.deepStrictEqual(detail.score,cell);assert.deepStrictEqual(detail.original_physical,r.physical_scores[task]);
  assert.equal(detail.current_deployment_right,'not_queried');detailsChecked++;
  for(const a of elements.links.children){assert(fs.existsSync(path.resolve(here,a.href)),a.href);linksChecked++;}
 }assert.equal(found.size,shown.length);
}
assert.equal(switches,128);
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const report={passed:true,selector_states:switches,rendered_rows_checked:rowsChecked,details_checked:detailsChecked,raw_links_checked:linksChecked,
 html_sha256:sha(path.join(here,'score-explorer.html')),checker_sha256:sha(__filename),dom_substitute:true,browser_layout_tested:false,model_search_calls:0};
fs.writeFileSync(path.join(here,'delivery-verification.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));