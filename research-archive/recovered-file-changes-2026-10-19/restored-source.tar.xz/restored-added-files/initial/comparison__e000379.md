# 真实后续付款与持有手牌：2026-10-12

入口 0.10.0、paid 核 0.4.0。搜索已接入下一己方回合的剩余手牌出牌、一次显式收入、自然抽到的物理副本和真实付款。回合开始保留上一余额，付款消耗对应副本；两回合分别限制 Play 数。Need 使用分支中上一己方回合实际支付的法术金币，免费施法不能代替付款。下一回合新出的 Haste 只能打怪，普通新怪不能攻击；Charge 与被沉默的旧普通攻击分开，Delay 在实际 Play 的当回合末执行。

## 同一手牌的可比较结果

输入：8G，空己场，敌 6/5 Aaron 与 2/3 Froggit，敌已知一张 Punishment 且有 3G；己方手牌 Totemic Guard、Shyren、Candy Dish、Dummy、Kawkaw、Tiny Bookshelf、Toriel。上一己方回合实际法术支出 1G，本回合根节点之前支出 0G；墓地三张无修改的 6G Rock；牌顶 Tiny Froggit，下一己方回合自然抽一张。手牌身材与能力未修改，费用与基础费用明确。通常比较只允许当前一次 Play。两名玩家可选择攻击目标、顺序、停止，敌人可交错支付已知法术。

共同终点为下一己方回合结束，包含该回合 Delay。下表为专门按 HP 优化的、对所有已实现敌回应成立的 HP 保证，不取胜负优先路线的一列冒充独立下界。

| 初始 HP | 下一收入 | 下一 Play 上限 | HP 保证 | 首次出牌 |
|---:|---:|---:|---:|---|
| 3 | 5G | 0 | 1 | Tiny Bookshelf |
| 3 | 5G | 1 | 6 | Tiny Bookshelf |
| 3 | 0G | 2 | 10 | Kawkaw |
| 3 | 1G | 2 | 10 | Kawkaw |
| 3 | 2G | 2 | 10 | Tiny Bookshelf |
| 3 | 5G | 2 | 10 | Tiny Bookshelf |
| 10 | 5G | 0 | 8 | Tiny Bookshelf |
| 10 | 5G | 2 | 17 | Tiny Bookshelf |
| 28 | 5G | 2 | 30 | Toriel（包含公开的次级比较） |

5G 可对应普通先手的第五个己方回合；0/1/2G 是付款边界干预，不是自然回合收入或实战频率样本。程序要求调用者显式提供收入，不按余额或牌名猜测。

在 3HP、下一收入 5G 的路线中，当前支付 4G 打出满足 Need 的 Tiny Bookshelf，敌最差回应把己方 HP 压到 1；下一开始余额为剩余 4G 加收入 5G，即 9G。再支付 Totemic 3G 与 Shyren 3G，治疗合计 9HP，终点保证 10HP、剩余 3G。两次治疗只能归于这条实际手牌路线，不能重复算进当前护盾本身的价值。

## 出手选择的现金门槛

保持整个七张手牌不变，只强制首次打出指定卡，并选择最好的合法 Magic 目标和后续策略：

| 首次出牌 | 下一收入 0G 的 HP 保证 | 下一收入 2G 的 HP 保证 |
|---|---:|---:|
| Totemic Guard | 0 | 0 |
| Shyren | 0 | 0 |
| Candy Dish | 0 | 0 |
| Dummy | 0 | 0 |
| Kawkaw | 10 | 10 |
| Tiny Bookshelf | 6 | 10 |
| Toriel | 0 | 0 |

0 表示此强制首次出牌无法保证在本子游戏中存活。等待结束当前回合也不能保命，并非自动享有未来治疗。每行完整保留 Magic 各目标的原始搜索；展示分数取己方可选目标中最大的保证。

Kawkaw 支付 1G 冻结大敌，保留 7G，足以在下回合支付两张 3G 治疗牌。Tiny Bookshelf 支付 4G 后只剩 4G，需要至少 2G 后续收入才付得起两张。这说明机会成本来自共享付款约束、手牌替代方案及必须先活到下一回合，不能用一张卡固定的“卡手扣分”代替。Kawkaw 还给敌人加身材；相同 HP 保证并不代表相同后续场面。

跨卡牌验证：手牌改为 Punishment 与 Battleflies，10HP、其他对手输入保持一致。下一回合不许出牌时可保证 8HP，不能保证清场；允许下一回合一次真实付费法术后，仍保证 8HP，并可保证“至少3HP且清空敌场”。未来动作既能改变治疗兑现，也能改变 Haste 与解牌的联合目的。原始两种窗口结果在 `comparison.json`。

## 清场证明与效率检查

原来的“无未来 Play”清场证书及 HP 等式扩展已拒绝新范围，不能直接复用。对七张原始手牌，放开当前四次 Play、下一两次 Play、下一收入 5G 后，完整最优向量搜索仍超过 200000 状态；固定敌人不出牌不攻击，再精确遍历全部未来己方动作也超过 200000 状态。失败保留在 `full-hand-hp3-current4-next2.json`、`idle-counterstrategy-current4.json`，不是近似成功或零分。

改用通用足够条件：对所有 795 个当前己方状态，令敌人合法结束而不攻击/施法；检验所有未来手牌和可抽到的牌都不能增加当回合总伤害上界。新普通身体不能立即攻击；治疗、降低敌 ATK、新身体自己的 ATK 增益不增加既有攻击者的 ATK 总和；Kawkaw 增益既有攻击者时同时 Paralyze，不能兑现新增伤害。既有可用 ATK 上界至多 7，而敌总 HP 下界至少 8，所以无法保证该窗口清场。这个证书覆盖声明的未来 Play 范围；它没有求出四次当前出牌路线的未来 HP 最优值。

该证明遇到未来 Haste/Charge、直接伤害、法术或额外活回调，返回 unknown。独立审查找到实际 Cursor #623 + Library Loox #503 反例：未来 Draw 可消除牌库重复，使原来 false 的 Need 改变，不能只检查未来起点删去 Magic 的版本。已加防护与原始卡牌回归：可未来 Draw 且存在牌库 Need 的闭包不批准这个简单证书。原始七牌无该机制，7<8 证明仍成立。

本轮效率结论：先确定问题是 HP 最优还是清场保证；对能由明确反策略和保守上界否定的目标，使用窄证明节约搜索。完整向量的预算失败仍公开保留，不能用证明某个目标失败来声称所有策略已优化。

## 可复算与边界

```sh
python analysis/monster-value-heuristic/build_future_payment_comparison.py
python analysis/monster-value-heuristic/evaluate_situation.py --input analysis/monster-value-heuristic/experiments/future-payment-v01/current.input.json --output /tmp/future-payment-result.json
cd analysis/monster-value-heuristic
python -m unittest test_next_turn_payment test_paid_board_tactics test_queued_delay test_board_tactics test_situation_evaluator test_idle_reply_bound -q
```

`comparison.json` 保存全部输入、原始策略、实际付款/抽牌/Delay账本、跨卡反事实及来源 hash；公共接口与独立入口逐项一致。`verification.json` 保存当前核与受影响回归验证。旧目录与早期探针保留当时版本，不作为本次源码的实时验证。

未验证或未实现：当前/下一 Play 上限是公开的搜索范围；终点尚未包括随后的敌回合回应，所以 HP 保证不等于再下一轮存活。仍无敌新怪部署、隐藏手牌分布、SOUL、神器和位置系统；修改手牌身材、不同 Silence 裁定、Delay 条件检查时点/过滤轴、竞争回末顺序继续按已有规则保留 unknown。牌库 Need 在实际 Draw 后没有 Generated/当前身份映射时不能继承根节点结论。没有实战场景频率或校准 Gold，不宣称通用天梯强度已经可靠。

下一优先为补入后续敌方回应，使保留手牌、抢场面及受惩罚后的持续收益在同一窗口比较；再扩有明确机制证据的卡牌覆盖。下一张牌的价值不能继续因窗口在其刚打出时结束而免除付费惩罚。