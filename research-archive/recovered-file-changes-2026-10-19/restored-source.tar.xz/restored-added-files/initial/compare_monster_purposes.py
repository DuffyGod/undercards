"""Traverse complete printed-cost buckets for a declared tactical decision.

This runs the actual paid search wherever its complete source mechanics are
implemented. Unsupported candidates stay visible and block a global optimum;
an implemented-subset leader is never promoted to a whole-pool champion.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
from pathlib import Path

import paid_board_tactics as paid
import score_cards

VERSION = 'complete-candidate-purpose-traversal-0.1.0'


def compare(config, cards=None):
    cards = score_cards.load_cards() if cards is None else cards
    scene = copy.deepcopy(config['scene'])
    if any(k in scene for k in ('hand_ids', 'hand_costs', 'objectives', 'purpose_constraints')):
        raise ValueError('scene must omit candidate hand and objective fields')
    if scene.get('max_plays') != 1:
        raise ValueError('Single candidate decision requires explicit max_plays=1')
    costs = config.get('printed_costs', sorted({c['cost'] for c in cards
        if c['card_type']=='monster' and c['pool_category']=='ordinary_non_token'}))
    if not isinstance(costs,list) or not costs or len(set(costs)) != len(costs):
        raise ValueError('Nonempty unique printed_costs list required')
    purposes = config['purposes']
    if not isinstance(purposes,dict) or not purposes:
        raise ValueError('Named nonempty purposes required')
    actual = config.get('candidate_actual_costs', {})
    rows=[]
    for c in cards:
        if c['card_type']!='monster' or c['pool_category']!='ordinary_non_token' or c['cost'] not in costs:
            continue
        data = dict(scene, hand_ids=[c['id']], objectives=['survive'])
        if str(c['id']) in actual: data['hand_costs'] = [actual[str(c['id'])]]
        if 'gold_before_play' not in data: data['gold_before_play'] = c['cost']
        survival = paid.evaluate(data,cards)
        result={}
        for name,constraints in purposes.items():
            current=dict(data,objectives=['purpose'],purpose_constraints=constraints)
            output=paid.evaluate(current,cards)
            closed=output['complete_in_declared_scope']
            goal=output['objectives'][0]['purpose_guaranteed'] if closed else None
            result[name]=dict(guaranteed=goal,full_search=output)
        rows.append(dict(card_id=c['id'], name=c['name'],printed_cost=c['cost'],
            source_text=c['effect_readable'],input=data,survival=survival,purposes=result))
    buckets=[]
    for cost in costs:
        candidates=[r for r in rows if r['printed_cost']==cost]
        if not candidates: raise ValueError('No ordinary monsters at printed cost '+str(cost))
        known=[r for r in candidates if r['survival']['complete_in_declared_scope']]
        best=max((r['survival']['objectives'][0]['metrics']['own_player_hp'] for r in known),default=None)
        blocked=[r['card_id'] for r in candidates if not r['survival']['complete_in_declared_scope']]
        goals={}
        for name in purposes:
            positive=[r['card_id'] for r in candidates if r['purposes'][name]['guaranteed'] is True]
            unresolved=[r['card_id'] for r in candidates if r['purposes'][name]['guaranteed'] is None]
            # A known witness establishes existence even when the alternatives
            # are unclosed. Conversely, subset failure cannot prove impossibility.
            goals[name]=dict(known_feasible_card_ids=positive,unresolved_card_ids=unresolved,
                any_candidate_can_guarantee=True if positive else None if unresolved else False,
                all_feasible_candidates_identified=not unresolved)
        buckets.append(dict(printed_cost=cost,all_candidate_ids=[r['card_id'] for r in candidates],
            supported_subset_best_guaranteed_hp=best,
            supported_subset_best_card_ids=[r['card_id'] for r in known
                if r['survival']['objectives'][0]['metrics']['own_player_hp']==best],
            survival_optimum_certified=not blocked,unresolved_survival_card_ids=blocked,
            purposes=goals))
    here=Path(__file__).resolve().parent
    return dict(version=VERSION,config=config,buckets=buckets,cards=rows,
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        source_hashes={name:hashlib.sha256((here/name).read_bytes()).hexdigest() for name in
            ('compare_monster_purposes.py','paid_board_tactics.py','board_tactics.py')},
        limitations=[
            'All candidates of requested ordinary printed-cost buckets retained; no board-purpose label filter.',
            'Printed cost is not observed dynamic hand cost. Supply candidate_actual_costs where known; unresolved mechanics remain unknown.',
            'One hypothetical physical candidate hand at a time. Printed-cost budget is used only if scene has no actual gold_before_play.',
            'Goal guarantee minimizes the entire conjunction; no mixing metrics from different opponent strategies.',
            'Supported-subset HP leaders are diagnostics, not whole-pool champions or universal Gold scores.',
            'Declared contexts carry no empirical frequency weights. Source hashes bind outcomes, not real-match validity.',
        ])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    output=compare(json.loads(args.input.read_text()))
    args.output.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(output=str(args.output),buckets=output['buckets']),ensure_ascii=False))


if __name__=='__main__':main()