# 条件出场、费用伤害与当前状态：生产比较

来源：paid0.27 / API0.29 / conditional scorer0.7 / position quotient0.4。以下都是保存输入下的联合用途HP保证Q，不能保证用途记“不可保证”，未知另列。没有全局Gold分、场景频率或真实胜率。

| 同一场景内的变化 | 保命Q | 用途与Q |
|---|---:|---|
| Dogamy+Dogaressa，现金12，敌4/4 | 15 | 焦点Dogaressa至少8/8：15 |
| 现金12→11，其余不变 | 11 | 8/8：不可保证 |
| 原12G场景，敌增加Gem和1G | 14 | 8/8不可保证；8/4：14 |
| Dogaressa+Dogamy+Lesser Dog，当前12G、下次收入6G、两次敌回应 | 15 | Lesser至少7/7：11，付出4HP保证 |
| 自己1HP、敌4HP，Dummy+Small Bird，现金5 | 1 | 保证获胜：1 |
| 同输入现金5→4 | 1 | 获胜：不可保证 |

三Dog的目的会改变顺序：纯保命先Dogamy，再Dogaressa得到Taunt+Dodge；要让Lesser收到手牌增益，必须让Dogaressa先出，牺牲这次条件Taunt。不能把15HP和7/7身体拼成同一个保证。Small Bird的Charge需要真实存在的Taunt；它可以自己花1G提供，敌方Taunt也会同时限制打脸。显式Transparency仍算Taunt状态的解释尚未经服务器验证。

以下所有候选共享10G现金、自己15HP、敌30HP、一次敌回应。仅持一张候选，剩余现金没有虚构可用牌；敌怪修改属性均是明确观察，不是假称原生身材。

| 敌场与候选 | 保命Q | 清场Q | 焦点至少4/8的Q |
|---|---:|---:|---:|
| 4攻5血、COST3：Spade Chain | 15 | 15 | 15 |
| 同体COST2：Spade Chain | 15 | 15 | 不可保证 |
| 前两种场面：Toriel | 14 | 不可保证 | 不可保证 |
| 前两种场面：NEO | 11 | 不可保证 | 不可保证 |
| 20攻8血、COST3：Spade Chain | 15 | 15 | 不可保证 |
| 同场：Toriel | 14 | 不可保证 | 14 |
| 同场：NEO | 0 | 不可保证 | 不可保证 |
| 四只4攻2血：Spade Chain | 7 | 不可保证 | 不可保证 |
| 同宽场：Spade King | 15 | 15 | 15 |
| 同宽场：Robot 98 / NEO | 0 | 不可保证 | 不可保证 |
| 同宽场：Toriel | 2 | 不可保证 | 不可保证 |

Chain伤害为`4+floor(目标COST/3)`：目标费用3→2使5伤变4伤，需要自己Haste补刀并承4伤。固定COST2，把Chain源HP11→12后，4/8用途由不可保证变15，纯保命仍15。当前／基础／印刷费必须完整、算出的伤害相同；缺失或跨伤害桶冲突为未知。没有其他目标时仍未知，不擅自解释为自选或空放。

观察解码修复保留已沉默怪物的已知印刷费，以及沉默后重新获得的明确Taunt/Armor/Dodge/Transparency；真实Silence事件仍移除状态。实际运行冻结paid0.26和当前0.27：同一个已沉默且重新获得Taunt的敌Jerry，旧版错误认证打脸获胜，新版拒绝。另30条状态／候选／用途查询已保存。

证据入口：[可比较CSV](scores.csv)、[完整条件分数](comparison.json)、[验证与限制](verification.json)、[原始条件探针](../../research-runs/presence-magic-production-v01/index.json)、[原始费用探针](../../research-runs/cost-magic-production-v01/index.json)、[实际旧新解码重放](../../research-runs/observed-status-fix-v01/verification.json)。95次生产探针、6组完整向量alpha/exhaustive对照、72条件单元与12单牌单元独立上下界、实际API/CLI JSON比较。测试覆盖601：首轮542项中529通过，修正旧Transparency预期后实际重跑13项，另59项递归源相同而复用；不是601项全新运行。

比较依据是同一窗口内可兑现的打法和真实资源阈值。各列最优策略可以不同；构筑是否值得携带还取决于这些局面的实际到达频率、替代牌、持牌容量和更长窗口，目前没有由此识别出真实胜率或全卡池最优解。