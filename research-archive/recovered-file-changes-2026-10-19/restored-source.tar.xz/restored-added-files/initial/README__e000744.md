# 真实手牌补偿对1HP与1ATK的敏感度

沿用[原生手牌比较](../hand-outlet-v01/README.md)的完整输入：己现金3、Jerry5G与Burgerpants3G都真实在手；敌4/4 Thrashing、两Gem、5G Long Sink，敌现金2。Burger真实付3、回合末双方赚5、下一己真实付Jerry5；零外生收入/自然抽，截止第二敌回应。生产paid0.24源码保持不变，节点预算仍20k。

| 唯一修改的卡源字段 | 联合保命HP | 原生基准 |
| --- | ---: | ---: |
| Jerry HP5→6 | 7 | 6 |
| Jerry HP5→7 | 9 | 6 |
| 敌Long Sink ATK4→3 | 7 | 6 |

每个修改保存完整`.cards.json`，程序逐字段确认只改一数值；这些是假想反事实，不修改原卡池。三例都闭合，状态11,065／6,082／11,071，未加预算。原生Q6引用冻结来源，没有重复跑基准。

通用原因是Taunt清除所需的有限直伤数。Jerry5血时，敌方保存一Gem，就能第二轮先点Jerry再让Long4攻清Taunt、Thrashing打脸4，HP仅6。Jerry6血需要两Gem，少一Gem能打脸，保证升到7；Jerry7血时两Gem也不足以配合一次4攻清除，两个大体都需用于挡体，保证升到9。敌Long降为3攻同样需要两Gem，保证7。Jerry对3G Thrashing的减伤仍生效，对5G Long不生效。不能用固定“每点HP值多少”或“持有高费牌抵扣风险”代替这些门槛。

[independent_bounds.py](independent_bounds.py)只用标准库，枚举最终清Taunt的攻击者与两Gem分配，给出固定己方策略下界和敌方合法回应上界，三例相符。没有导入主搜索。替代首轮回应的保守界一并记录，不把某条最坏路径当全部策略。`independent-bounds.json`绑定修改源和结果哈希。

一次真实生产CLI以`--cards-source jerry-health6.cards.json`执行，完整HP结果与直接调用JSON相同，canonical卡源digest也相同。CLI还执行其规定的win与移除基准，共4次额外查询；与3个主HP反事实分开计数。日志、命令、原始输出与17份生产源码保留，旧回归没有重跑。

本结果说明当前程序能识别手牌配合中的数值门槛；没有证明其有限场景以外的真实胜率或构筑频率。相同Jerry背景下的原生比较仍是Water9 > Burger6 > Candy5，假想Jerry7只是使Burger在这里追平Water，不是全局排名。

```sh
python research-runs/hand-outlet-sensitivity-v01/run_probe.py
python research-runs/hand-outlet-sensitivity-v01/independent_bounds.py
```