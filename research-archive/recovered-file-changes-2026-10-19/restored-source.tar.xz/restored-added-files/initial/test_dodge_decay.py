"""Persistent owner-end stacks, actual punishment and ordering uncertainty."""
import copy
from dataclasses import replace
import unittest

import board_tactics as board
import paid_board_tactics as paid
import conditional_card_score as score
import certify_hand_hp
import score_cards


class DodgeDecayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def scene(self,**changes):
        data=dict(hand_ids=[249],gold_before_play=9,own_player_hp=15,own_player_max_hp=30,
            enemy_player_hp=30,enemy_player_max_hp=30,opponent_hand_ids=[],
            own_deck_ids=[],opponent_deck_ids=[],max_plays='all_physical',next_max_plays=0,
            next_own_gold_income=0,next_natural_draw_count=0,horizon='next_enemy_attack',
            next_opponent_gold_income=0,next_opponent_natural_draw_count=0)
        data.update(changes);return data

    def test_full_literal_and_numeric_generalization(self):
        s=board.compile_card(dict(effect_readable='Dodge (7). Turn end: Lose 3 Dodge.'))
        self.assertFalse(s['unknown']);self.assertEqual(s['end'],('lose_dodge',3));self.assertEqual(s['statuses']['dodge'],7)
        self.assertTrue(board.compile_card(dict(effect_readable='Turn end: Lose 3 Dodge. Dust: Draw a card.'))['unknown'])

    def test_owner_end_only_persistent_zero_floor_and_real_payment(self):
        e=paid.PaidSearch(self.cards,self.scene());s=next(e.deploys(e.root()))[1]
        self.assertEqual((s.own[0].dodge,s.current_paid_gold),(98,9))
        s=e.boundary(s);self.assertEqual(s.own[0].dodge,1)
        s=e.boundary(s);self.assertEqual(s.own[0].dodge,1)
        s=e.boundary(s);self.assertEqual(s.own[0].dodge,0)
        s=e.boundary(s);self.assertEqual(s.own[0].dodge,0)

    def test_opponent_source_waits_for_its_own_end(self):
        e=paid.PaidSearch(self.cards,self.scene(hand_ids=[],enemy_bodies=[dict(card_id=249,attack=9,health=8,max_health=8,dodge=98)]))
        s=e.boundary(e.root());self.assertEqual(s.enemy[0].dodge,98)
        s=e.boundary(s);self.assertEqual(s.enemy[0].dodge,1)

    def test_dead_source_does_not_trigger_or_revive(self):
        e=paid.PaidSearch(self.cards,self.scene());s=next(e.deploys(e.root()))[1]
        s=replace(s,own=(replace(s.own[0],health=0),))
        child=e.boundary(s);self.assertEqual((child.own[0].health,child.own[0].dodge),(0,98))

    def test_silence_removes_decay_and_current_dodge_without_reset(self):
        e=paid.PaidSearch(self.cards,self.scene());s=next(e.deploys(e.root()))[1]
        u=e.silence(s.own[0],phase=0);self.assertIsNone(u.end);self.assertEqual(u.dodge,0)
        self.assertEqual(e.boundary(replace(s,own=(u,))).own[0].dodge,0)

    def test_decay_vs_decline_dust_order_is_not_free_protection(self):
        data=self.scene(ally_bodies_before_play=[dict(card_id=196,attack=1,health=1,max_health=1)])
        e=paid.PaidSearch(self.cards,data);s=next(e.deploys(e.root()))[1]
        dying=replace(s.own[0],end=('decline',1),dust=('damage_all_monsters',1))
        source=replace(s.own[1],dodge=1)
        with self.assertRaisesRegex(paid.UnknownMechanic,'callback order'):
            e.boundary(replace(s,own=(dying,source)))

    def test_one_point_decay_changes_joint_body_not_raw_player_hp(self):
        data=self.scene(horizon='enemy_attack',next_own_gold_income=None,
            opponent_hand_ids=[598,598],opponent_gold_before_response=2,
            enemy_bodies=[dict(card_id=270,attack=4,health=4,max_health=4)])
        data.pop('next_opponent_gold_income');data.pop('next_opponent_natural_draw_count')
        task=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=9,min_own_body_health=4))
        native=score.task_score(data,task,cards=self.cards,focal_index=0)
        changed=copy.deepcopy(self.cards)
        next(c for c in changed if c['id']==249)['effect_readable']='Dodge (98). Turn end: Lose 96 Dodge.'
        amended=score.task_score(data,task,cards=changed,focal_index=0)
        self.assertTrue(native['known']);self.assertFalse(native['feasible']);self.assertIsNone(native['guaranteed_player_hp'])
        self.assertTrue(amended['feasible']);self.assertEqual(amended['guaranteed_player_hp'],9)
        for cards in (self.cards,changed):self.assertEqual(score.task_score(data,dict(kind='hp'),cards=cards)['guaranteed_player_hp'],9)

    def test_loss_is_registered_as_nonhealing_for_hp_certificate(self):
        e=paid.PaidSearch(self.cards,self.scene());ceiling=certify_hand_hp.healing_ceiling(e,e.root())
        self.assertTrue(ceiling['ceiling_complete']);self.assertEqual(ceiling['guaranteed_hp_upper'],15)


if __name__=='__main__':unittest.main()