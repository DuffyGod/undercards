"""Verify every measured quote and publish an offline comparison artifact."""
import csv
import gzip
import hashlib
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]; sys.path.insert(0, str(ROOT))
import survival_pressure as pressure
import evaluate_situation as api
from benchmark import cards, by, stripped, NEW
P = Path(__file__).parent; OUT = ROOT/'experiments/combat-event-v01'


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def digest(value): return hashlib.sha256(pressure.score.canonical(value).encode()).hexdigest()
def read(path): return json.loads((P/path).read_text())


def main():
    OUT.mkdir(exist_ok=True)
    current = pressure.score.source_bindings(ROOT/'survival_pressure.py')
    m, s, reg = read('main/index.json'), read('sensitivity/index.json'), read('regression.json')
    assert m['source_hashes'] == s['source_hashes'] == current
    assert reg['passed'] and reg['source_unchanged_during_run']
    artifacts = {}; allrows = []; count = feasible = 0; fingerprints = set()
    for folder, items in (('main', m['rows']), ('sensitivity', s['rows'])):
        for index in items:
            path = P/folder/index['artifact']; artifacts[str(path.relative_to(ROOT))] = sha(path)
            raw = json.loads(gzip.open(path, 'rt').read()); r = raw['result']; data = raw['scenario']
            source = cards+[stripped(by[index['card_id']])] if index['variant'].startswith('removed') else cards
            assert r['source_hashes'] == current
            assert r['input_sha256'] == digest(data) and r['cards_sha256'] == digest(source)
            assert r['frontier'] == index['frontier']
            fingerprints.add((r['input_sha256'], r['cards_sha256'], pressure.score.canonical(r['task']), r['focal_index']))
            quotes = []
            for q in r['rows']:
                count += 1
                if q['known'] and q['feasible']:
                    d, refinement = q['discovery'], q['refinement']
                    assert d['search_complete'] and d['objective_vector'][0]
                    assert -d['objective_vector'][1] == q['guaranteed_enemy_hp_at_most']
                    assert refinement['known'] and refinement['feasible']
                    assert refinement['guaranteed_player_hp'] == q['guaranteed_own_hp'] >= q['requested_own_hp_floor']
                    assert refinement['task']['constraints']['max_enemy_player_hp'] <= q['guaranteed_enemy_hp_at_most']
                    feasible += 1
                else:
                    assert q['guaranteed_own_hp'] is None and q['guaranteed_enemy_hp_at_most'] is None
                quotes.append(dict(floor=q['requested_own_hp_floor'], known=q['known'], feasible=q['feasible'],
                    own_hp=q['guaranteed_own_hp'], enemy_hp_cap=q['guaranteed_enemy_hp_at_most'],
                    unknown=q['discovery'].get('unknown', [])+(q['refinement'] or {}).get('unknown', [])))
            allrows.append(dict(index, family=folder, cost=by[index['card_id']]['cost'],
                situation=index.get('situation', 'small'), quotes=quotes,
                raw='../../research-runs/combat-event-v01/'+folder+'/'+index['artifact']))
    independent = read('review/independent-four-phase-main.json')
    interfaces = read('interface-verification.json')
    assert interfaces['passed']
    # The independent verifier has its own schema; inspect its explicit
    # pass/failure fields, never infer validity from a nonempty count.
    assert independent['passed']
    (P/'native-cards.json').write_text(json.dumps(cards, ensure_ascii=False, indent=2)+'\n')
    summary = dict(paid_version=pressure.score.paid.VERSION, api_version=api.VERSION,
        combat_events_version=pressure.score.paid.combat_events.VERSION,
        static=read('static-delta.json'), measured_cost_groups=[4,5,6,9],
        measured_native_candidates=m['measured_native_candidates'], main_curves=len(m['rows']),
        main_closed=sum(r['complete_sampled_floors'] for r in m['rows']),
        sensitivity_curves=len(s['rows']), sensitivity_closed=sum(r['complete_sampled_floors'] for r in s['rows']),
        formal_core_search_calls=m['actual_core_calls']+s['actual_core_calls'],
        pilot_core_search_calls=read('pilot/index.json')['actual_core_calls'],
        curve_entries=len(allrows), distinct_scenario_card_task_curves=len(fingerprints),
        checked_floor_rows=count, jointly_certified_feasible_rows=feasible,
        actual_regression_tests=reg['test_count'], regression_source_coverage=reg['current_source_test_coverage'],
        source_hashes=current)
    comparison = dict(summary=summary, declared_rule_hypothesis=m['explicit_rule_hypothesis'], rows=allrows,
        inventory=read('inventory.json'), scope='Only finite declared known-information conditions. '
        'Unresolved, declared hypotheses and hypothetical no-callback bodies are kept separate. '
        'No meta frequency, calibrated victory probability or full-pool champion.')
    (OUT/'comparison.json').write_text(json.dumps(comparison, ensure_ascii=False, indent=2)+'\n')
    verification = dict(passed=True, source_hashes=current, regression=reg, independent=independent,
        interfaces=interfaces, direct_transactions=read('review/direct-transaction-comparison.json'),
        damage_paths=read('review/paid-damage-paths.json'), raw_artifact_sha256=artifacts,
        producer_sha256={f:sha(P/f) for f in ('benchmark.py','sensitivity.py','publish.py','native-cards.json')},
        scope='Source/input/card and joint-coordinate checks plus an independent finite-game verifier. '
              'Independent checks use one declared concrete rule world and do not certify unknown server semantics.')
    (OUT/'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2)+'\n')
    with (OUT/'quotes.csv').open('w') as f:
        w = csv.writer(f); w.writerow(['id','name','cost','scene','variant','task','floor','known','feasible','own_hp','enemy_hp_cap','raw'])
        for row in allrows:
            for q in row['quotes']:
                w.writerow([row['card_id'],row['name'],row['cost'],row['situation'],row['variant'],
                    'attack_body' if row['variant'].endswith('attack_body') else 'hp',q['floor'],q['known'],q['feasible'],q['own_hp'],q['enemy_hp_cap'],row['raw']])
    template = (P/'explorer-template.html').read_text()
    (OUT/'comparison-explorer.html').write_text(template.replace('__DATA__', json.dumps(comparison, ensure_ascii=False).replace('</','<\\/')))
    print(json.dumps({k:v for k,v in summary.items() if k != 'source_hashes'}, ensure_ascii=False))


if __name__ == '__main__': main()