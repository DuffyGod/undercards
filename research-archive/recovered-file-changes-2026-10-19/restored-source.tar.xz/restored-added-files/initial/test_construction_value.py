import copy
import unittest

import construction_value as construction
import evaluate_situation as situation
import joint_window_quote as joint
import score_cards as base
from test_carry_option import tree,quotes


def observation(attack=None,turn=5,hp=30,cash=12):
    return dict(hand_ids=[8],role='midrange',own_turn=turn,gold_before_play=cash,
        opponent_gold_before_response=0,own_player_hp=hp,enemy_player_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[] if attack is None else [dict(attack=attack,health=8)],
        response_weights={'enemy_face':1})


def actual_tree(p=.2):
    s=tree(p)
    for n in s['nodes']:
        n['own_turn']+=1
        if n['id']!='now':n['observation']=observation(8 if n['id']=='good' else 2,6)
    s['last_deployment_own_turn']=6
    return s


class ConstructionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards=base.load_cards();cls.by={c['id']:c for c in cls.cards};cls.ref,_=base.make_reference(cls.cards)
        cls.norm=joint.make_normalization(cls.ref,reply_policy='allied_board')

    def evaluate(self,scenario,ids=(8,243),root=None):
        ctx,_=situation.make_state(observation() if root is None else root)
        return construction.evaluate_cards([self.by[i] for i in ids],self.ref,self.norm['scale'],scenario,situation.make_state,ctx)

    def test_negative_forced_average_can_be_positive_carrying_value(self):
        r=self.evaluate(actual_tree())
        toriel,bench=r['cards']
        good=next(p for p in toriel['policy'] if p['node_id']=='good')['local_quote']['net_model_gold']
        bad=next(p for p in toriel['policy'] if p['node_id']=='bad')['local_quote']['net_model_gold']
        self.assertLess(.2*good+.8*bad,0)
        self.assertAlmostEqual(toriel['option_value_model_gold'],.2*good)
        self.assertGreater(toriel['option_value_model_gold'],bench['option_value_model_gold'])
        self.assertAlmostEqual(toriel['unused_probability'],.8)
        self.assertAlmostEqual(toriel['expected_actual_mana_paid'],1.6)
        self.assertTrue(construction.compare(r,[8],[243])[0]['worth_carrying_under_declared_scenario'])

    def test_crowding_reverses_carrying_preference_without_charging_unused_mana(self):
        s=actual_tree();s['initial_hand_size']=7
        for e in s['nodes'][0]['transitions']:e['cards_from_deck']=1
        r=self.evaluate(s);toriel,bench=r['cards']
        self.assertAlmostEqual(toriel['expected_discounted_holding_cost_model_gold'],.6)
        self.assertLess(toriel['option_value_model_gold'],bench['option_value_model_gold'])
        self.assertFalse(construction.compare(r,[8],[243])[0]['worth_carrying_under_declared_scenario'])
        s['nodes'][0]['transitions'][0]['probability']=0;s['nodes'][0]['transitions'][1]['probability']=1
        dead=self.evaluate(s)['cards'][0]
        self.assertEqual(dead['expected_actual_mana_paid'],0)
        self.assertAlmostEqual(dead['option_value_model_gold'],-.6)

    def test_opportunity_requires_actual_payment_capacity(self):
        s=actual_tree(1);s['nodes'][1]['observation']['gold_before_play']=7
        r=self.evaluate(s)['cards'][0]
        self.assertEqual(r['option_value_model_gold'],0)
        self.assertEqual(r['deployed_probability'],0)

    def test_terminal_hold_is_not_resource_priced_as_a_free_wait(self):
        s=actual_tree(1);s['nodes'][1]['observation']['own_player_hp']=5
        r=self.evaluate(s)['cards'][0]
        self.assertFalse(r['pricing_supported'])
        self.assertEqual(r['value_bounds_model_gold'],[None,None])

    def test_current_api_preserves_different_costs_of_duplicate_copies(self):
        data=observation();data['hand_ids']=[8,8];data['hand_costs']=[8,2]
        s=actual_tree(0);s.pop('initial_hand_size');s['replacement_ids']=[243]
        data['construction_scenario']=s
        r=situation.evaluate(data,self.ref,self.cards)['construction_options']
        options={c['option_key']:c for c in r['cards']}
        self.assertEqual(options['hand-0']['nominal_cost'],8)
        self.assertEqual(options['hand-1']['nominal_cost'],2)
        self.assertEqual(options['hand-0']['expected_actual_mana_paid'],0)
        self.assertEqual(options['hand-1']['expected_actual_mana_paid'],2)
        self.assertEqual(len(r['replacement_comparisons']),2)

    def test_frontier_checks_nonmonotone_advantage_and_two_crossings(self):
        s=tree(.5)
        for e in s['nodes'][0]['transitions']:e['foregone_value_model_gold']=5
        values={0:{'now':1,'good':15,'bad':-1},1:{'now':.5,'good':11,'bad':5}}
        def quote(card,node,hand):return quotes(values[card['id']])(node,hand)
        r=construction.mixture_frontier(s,{'id':0},{'id':1},quote,'good')
        self.assertFalse(r['grid_advantage_nondecreasing'])
        self.assertEqual(len(r['profitable_probability_intervals']),2)
        self.assertAlmostEqual(r['crossings'][0]['probability'],1/6)
        self.assertAlmostEqual(r['crossings'][1]['probability'],5/9)

    def test_unknown_card_does_not_become_a_zero_valued_replacement(self):
        r=self.evaluate(actual_tree(),(8,307))
        self.assertFalse(r['cards'][1]['pricing_supported'])
        self.assertIsNone(construction.compare(r,[8],[307])[0]['worth_carrying_under_declared_scenario'])


if __name__=='__main__':unittest.main()