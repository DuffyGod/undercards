"""Enumerate all compiled native spell replies, preserving the unsupported pool."""
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import alternative_goal_score as alt
import conditional_card_score as score
import paid_board_tactics as paid


def main():
    cards=score.score_cards.load_cards();by={c['id']:c for c in cards}
    bindings=score.source_bindings(ROOT/'alternative_goal_score.py');inventory=[];rows=[]
    for c in cards:
        if c['card_type']=='spell' and c['pool_category']=='ordinary_non_token':
            spec=paid.spell_spec(c);inventory.append(dict(card=c,spec=spec,compile_supported=not spec['unknown']))
    assert len(inventory)==84
    compiled=[r['card'] for r in inventory if r['compile_supported']]
    assert {c['id'] for c in compiled}=={76,79,81,96,100}
    for cid in (20,110,292,534,443,8):
        raw=json.loads((HERE/f'card{cid}.json').read_text())
        for spell in compiled:
            for cash in sorted({max(0,spell['cost']-1),spell['cost']}):
                data=copy.deepcopy(raw['input'])
                # An observed silenced native Jerry has exactly the desired
                # printed4/5. No hypothetical stat-reset convention is needed
                # just to classify Silence on the initially observed enemy.
                data['enemy_bodies'][0].update(card_id=14,current_card_cost=by[14]['cost'],base_cost=by[14]['cost'])
                data.update(opponent_hand_ids=[spell['id']],opponent_hand_costs=[spell['cost']],
                    opponent_hand_base_costs=[spell['cost']],opponent_gold_before_response=cash)
                values={}
                for name in ('hp','clear_or_focal4_1'):
                    task=raw['tasks'][name]
                    values[name]=(alt.evaluate(data,task,focal_index=0) if task['kind']=='any'
                        else score.task_score(data,task,focal_index=0))
                label=f'answer-card{cid}-spell{spell["id"]}-cash{cash}'
                path=HERE/(label+'.json');path.write_text(json.dumps(dict(input=data,spell=spell,
                    tasks=raw['tasks'],results=values),ensure_ascii=False,indent=2)+'\n')
                row=dict(card_id=cid,spell_id=spell['id'],spell_name=spell['name'],soul=spell['soul'],
                    printed_spell_cost=spell['cost'],actual_payment_price=spell['cost'],enemy_cash=cash,
                    affordable=cash>=spell['cost'],artifact=path.name,
                    scores={n:{k:v.get(k) for k in ('known','feasible','guaranteed_player_hp','unknown')} for n,v in values.items()})
                rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
    assert bindings==score.source_bindings(ROOT/'alternative_goal_score.py')
    report=dict(source_hashes=bindings,source_stable=True,inventory=inventory,rows=rows,
        builder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),actual_task_queries=2*len(rows),
        all_native_spells=84,compile_supported_native_spells=5,compiler_unknown_native_spells=79,
        limitations=['Each spell is a different single-copy declared hand, not a combined cross-SOUL starting deck.',
            'Known affordable failure disproves a guarantee against this exact menu, not against every possible deck.',
            'No demonstrated answer is not immunity; unsupported spells and unknown stat-reset branches block global minima.',
            'Enemy14 is already silenced printed4/5, current/base/printed4G. Chain still deals5; no other chosen source reads that identity.'])
    (HERE/'native-spell-answers.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()