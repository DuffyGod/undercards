"""Complete variable-target COST damage prototype, without guessing referents.

Current, base and printed COST may differ: the calculated damage must agree
across all three known observations. Source cost/payment is never substituted.
"""
import copy
from dataclasses import replace
import hashlib
from pathlib import Path
import re

import board_tactics as board
import conditional_card_score as score
import held_magic_extensions as held
import paid_board_tactics as paid
from physical_slot_score import PhysicalGeometryMixin

VERSION='target-cost-damage-prototype-0.1.0'


def parse(card):
    rest=card.get('effect_readable','')
    if not isinstance(rest,str):return None
    rest=rest.strip();prefix=[]
    while (m:=board.PREFIX.match(rest)):
        prefix.append(rest[:m.end()]);rest=rest[m.end():]
    if not (m:=re.fullmatch(r'Magic: Deal (\d+) DMG to a monster\. Deal (\d+) extra DMG for every (\d+) GOLD it costs\.',rest)):
        return None
    return ''.join(prefix).strip(),('target_cost_damage',*map(int,m.groups()))


def dose(unit,effect):
    _,base,extra,step=effect
    if step<=0:raise paid.UnknownMechanic('COST damage requires positive literal bucket width')
    facts=dict(current=getattr(unit,'current_card_cost',None),base=getattr(unit,'base_cost',None),printed=unit.printed_cost)
    if any(v is None for v in facts.values()):raise paid.UnknownMechanic('Target COST damage needs current/base/printed facts')
    values={name:base+extra*(v//step) for name,v in facts.items()}
    if len(set(values.values()))!=1:raise paid.UnknownMechanic('Target COST referents produce different damage')
    return next(iter(values.values())),dict(cost_facts=facts,damage_by_referent=values)


class CostMagicMixin:
    def spec(self,card,observed=False,collect_unknown=True,condition_known_state=None):
        extension=parse(card)
        if extension is None or card.get('_silenced_in_hand'):
            return super().spec(card,observed=observed,collect_unknown=collect_unknown,condition_known_state=condition_known_state)
        prefix,effect=extension;changed=copy.deepcopy(card);changed['effect_readable']=prefix
        result=super().spec(changed,observed=observed,collect_unknown=False,condition_known_state=condition_known_state)
        result['magic']=None if observed else effect;result['evidence']=card.get('effect_readable','')
        if observed:result['resolved_magic_from_observation']=True
        if collect_unknown:self.unknown.extend('Card '+str(card['id'])+': '+x for x in result['unknown'])
        return result

    def magic(self,state,index,unit,spec,caster='own'):
        effect=spec.get('magic')
        if not effect or effect[0]!='target_cost_damage':return super().magic(state,index,unit,spec,caster=caster)
        state,unit=held.apply_played_keywords(self,state,index,unit,caster)
        if index in getattr(state,'hand' if caster=='own' else 'enemy_hand') or sum(u==unit for u in getattr(state,caster))!=1:
            raise paid.UnknownMechanic('Target COST Magic requires actual paid placed source')
        action=dict(kind='deploy',hand_index=index,card_id=unit.card_id,magic=effect)
        if caster=='enemy':action['side']='enemy'
        outcomes=[]
        for side in ('own','enemy'):
            for j,target in enumerate(getattr(state,side)):
                if target.health<=0 or target.transparency or target.key==unit.key:continue
                amount,evidence=dose(target,effect)
                units=list(getattr(state,side));units[j]=self.hurt_unit(target,amount,source=unit,source_is_enemy=side!=caster)
                child=replace(state,**{side:tuple(units)});child=self.deaths(state,child)
                outcomes.append((dict(action,magic_target=(side,j),target_key=target.key,calculated_damage=amount,
                    cost_referent_evidence=evidence),child))
        # Keep the existing selected-Magic source-exclusion convention explicit;
        # missing targets are refused until a caller asks for that convention.
        if not outcomes:raise paid.UnknownMechanic('No other selectable monster; self-target/no-target interpretation unverified')
        return outcomes


class CostMagicSearch(CostMagicMixin,score.TaskSearch):pass
class PhysicalCostMagicSearch(PhysicalGeometryMixin,CostMagicMixin,score.TaskSearch):pass

LOADED=score.source_bindings(Path(__file__))


def evaluate(data,task,*,cards=None,focal_index=0):
    bindings=score.source_bindings(Path(__file__))
    if bindings!=LOADED:raise RuntimeError('Loaded COST prototype source changed')
    cards=score.score_cards.load_cards() if cards is None else cards
    digest=hashlib.sha256(score.canonical(cards).encode()).hexdigest()
    kind=task.get('kind','joint');scope=task.get('body_scope','board');constraints=copy.deepcopy(task.get('constraints',{}))
    if set(task)-{'kind','body_scope','constraints'} or kind not in ('hp','joint') or scope not in ('board','focal','lineage'):
        raise ValueError('Invalid COST task')
    if kind=='hp' and (scope!='board' or constraints):raise ValueError('HP without body constraints')
    if scope!='board' and (focal_index is None or not paid.SINGLE_BODY_PURPOSE_FIELDS.intersection(constraints)):
        raise ValueError('Actual focal index and same-body goal required')
    scene=copy.deepcopy(data);scene.pop('objectives',None);scene.pop('purpose_constraints',None)
    if kind=='joint':scene['purpose_constraints']={'min_own_player_hp':1,**constraints}
    cls=PhysicalCostMagicSearch if scene.get('physical_slots') else CostMagicSearch
    engine=cls(cards,scene,body_scope=scope,focal_index=focal_index);root=engine.root()
    value=engine.solve(root,'guaranteed_hp' if kind=='hp' else 'purpose') if not engine.unknown else dict(search_complete=False,unknown=engine.unknown,metrics=None,principal_variation=[])
    known=value['search_complete'];feasible=(value['metrics']['own_player_hp']>0 if kind=='hp' else value['purpose_guaranteed']) if known else None
    result=dict(version=VERSION,known=known,feasible=feasible,task=task,search=value,unknown=value.get('unknown',[]),
        guaranteed_player_hp=value['metrics']['own_player_hp'] if known and (kind=='hp' or feasible) else None,
        source_hashes=bindings,cards_sha256=digest,prototype_only=True,
        assumptions=['COST referent envelope=current/base/printed; numerical damage must agree, not necessarily the COST itself.',
            'Existing selected-Magic convention excludes its source and Transparency; no-target cases remain unknown.'])
    if bindings!=score.source_bindings(Path(__file__)) or digest!=hashlib.sha256(score.canonical(cards).encode()).hexdigest():raise RuntimeError('COST source changed')
    return result