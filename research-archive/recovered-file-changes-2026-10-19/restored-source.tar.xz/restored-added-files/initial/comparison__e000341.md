# 墓地条件、Delay与不同对战目的

2026-10-12。公共入口0.9.0，付费搜索核0.3.0。此次把此前只能来源推演的条件治疗接入实际行动搜索；下面的数值是声明窗口里的物理保证，不是实战频率或通用Gold价格。

## 已实现的通用机制

完整数值模板 `Delay: If you have N+ C-COST monsters in your hand or dustpile, heal H HP to you.` 及无条件Delay治疗。参数来自源文字，执行没有卡名/ID分支。Play产生独立队列事件；来源提前死亡不撤队列，普通Summon不产生Delay，真正执行后消费一次。玩家已死不继续执行治疗。

墓地输入 `own_dustpile_monsters` 是己方实际怪物对象，接受 `card_id/current_cost/base_cost`，缺少事实保持未知，空牌库不推断墓地为空。普通死亡更新成本记录，重复实体分别计数；召唤支付0不是卡牌COST0。已修改对象跨区保留费用缺裁定，新增记录保留未知。

未选定运行时费用过滤：手牌、墓地分别比较current/base/通常印刷费用，共九种组合；也比较Play入队与回末检查结果。只有相关解释一致才执行。手牌当前费恰等于印刷费不证明基础费没改：不提供`hand_base_costs`时仍未知。手/墓地字段的互相补偿、费用变化造成的检查时点分歧、队列源后来沉默，以及Delay与活跃Turn end竞争均阻止确定评分。这里消除的是列出的裁定分歧，不冒充服务器独立验证。

手牌可逐物理副本声明 `hand_silenced`；出场前已沉默的普通怪物不发动能力、不保留关键词。DT不能声明被沉默。手中已改过的ATK/HP仍不支持：本报告明确使用源身材和观察到的费用。

## 同一七张手牌的可比较结果

手牌固定：Totemic Guard、Shyren、Candy Dish、Dummy、Kawkaw、Tiny Bookshelf、Toriel。共同余额8G，至多一个当前Play，出场与已有友军攻击可交错；双方玩家最大生命30，敌玩家30HP。敌场6/5＋2/3，两个Need已知成立。己方牌库有已知Tiny Froggit；下一攻击回合面板会实际自然抽它。墓地费用均明确观察到为三无修改Rock的current/base/印刷6，第一行减少一个。没有SOUL/神器/附魔、敌怪新部署或未来己方Play。

各首出保留同一完整手牌和余额，枚举所有Magic目标、已有友军先攻击的顺序，以及最坏敌施法/攻击交错。表中是直接`guaranteed_hp`目标，不将胜负优先路线的HP列当独立下界。

| 改动 / 初始生命 | Totemic | Shyren | Candy Dish | Dummy | Kawkaw | Tiny Bookshelf | Toriel |
|---|---:|---:|---:|---:|---:|---:|---:|
| 墓地只有两个6费，3HP，无解牌 | 1 | 0 | 0 | 1 | 1 | 3 | 0 |
| 墓地三个6费，3HP，无解牌 | **6** | 0 | 0 | 1 | 1 | 3 | 0 |
| 同上，敌Punishment＋3G | 0 | 0 | 0 | 0 | 1 | **1** | 0 |
| 10HP，无解牌 | **13** | 6 | 2 | 8 | 8 | 10 | 7 |
| 10HP，付费Punishment | 7 | 6 | 2 | 2 | 8 | **8** | 7 |
| 28HP，无解牌 | 28 | 22 | 20 | 26 | 26 | **28** | 25 |
| 28HP，付费Punishment | 22 | 22 | 20 | 20 | 26 | **26** | 25 |

粗体是该手牌内公开字典序选出的首出；不能扩展为对应费用全池冠军。第一行到第二行仅改变墓地计数，主推荐从Tiny Bookshelf转成Totemic。第二行到第三行仅加实际可支付解牌，又转回来。28HP的治疗最多兑现2HP，双敌最坏顺序还会产生2脸伤，所以Totemic最终28，不能机械地加上5。

单敌版本：无解牌时Totemic条件假/真为3/8HP；条件真但有Punishment时为2HP。双敌有Punishment时治疗至8后被6＋2打脸致死，说明治疗保险没有自动变成惩罚抗性。

## 时窗和目的会改变同一手牌的选择

加入己方已就绪5/5 Aaron，它可先与敌6/5同死；同一3HP/墓地条件下：

- 只到敌攻击窗结束，Totemic可保证8HP，但敌2/3可以停止攻击，不能保证清场。
- 到下一己方攻击回合，未被解掉的Totemic可再攻击2/3；无解牌时能保证8HP并清场。队列不在第二次己方回末重复治疗。
- 有Punishment时，最大保证HP路线仍选Totemic并保证6HP，却不能保证清场；联合“至少3HP且敌存活数0”改选Tiny Bookshelf，保证3HP并清场。目标合取直接搜索，没有拼接两条路线。

另一个控制目的：我10HP、敌12/5＋2/3、敌Punishment＋3G。只最大化HP时Tiny Bookshelf保证8HP，但敌残留14攻击。目的改为“至少7HP且敌残留攻击≤3”，同一手牌改选Toriel：将12攻降至1，最坏7HP、敌残留3攻。多留1HP与减少后续敌场压力是不同目标；当前没有经过实战校准的权重把它们折成Gold。

## 通用数值反事实

只把Totemic源模板治疗H从5改到4/6，其他卡、输入及代码不变：

| 初始HP，双敌无解牌 | H=4 | H=5 | H=6 | 实际边际 |
|---|---:|---:|---:|---|
| 3 | 5 | 6 | 7 | 每增加1治疗，保证HP增加1 |
| 10 | 12 | 13 | 14 | 同一通用机制，不限低血量 |
| 28 | 28 | 28 | 28 | 都只实际治疗2，受30HP上限约束 |

反事实是明确标注的合成源数值修改，不能沿用旧源证书。来源提前死亡的真实路径为Totemic→Crystal Shard指自己→回末，队列仍治疗5；沉默路径、区域费用字段互相补偿与未知历史则保留unknown。[独立审查](rule-review.md)记录采用与阻断理由，旧探针hash冻结；其两轴“已改费Demon Flowey”路径在加入印刷第三轴后已改为unknown，旧结果不作为现行可靠输入。

## 效率检查及下一缺口

这一轮产生了三种可用变化：此前来源推演的Delay进入可执行搜索；墓地阈值、真实解牌、治疗上限改变了推荐；已有友军与下一攻击回合让保命/清场/控制目的产生明确分歧。没有为旧Gold报价加一个“条件奖励分”，也没把子智能体一致当验证。传统Need、真实付款、Draw/疲劳、死亡与攻击顺序的相关回归继续通过。

场景已加入健康生命、非空库、已有场面、下一自然Draw和攻击回合；仍缺真实场景频率、未知敌手、未来己方Play/收入、SOUL/神器、多数触发与被修改手牌身材。需要把这些真实时机接回已有共同绝对终点的等待/付款模块。位置、显式触发召唤物Magic、Chessboard及Lesser Dog完整兑现仍是实质缺口，不能以本页代替通用构筑评价。

## 复算

```sh
python analysis/monster-value-heuristic/build_delay_history_comparison.py
python analysis/monster-value-heuristic/evaluate_situation.py --input analysis/monster-value-heuristic/experiments/delay-history-v01/current.input.json --output /tmp/delay-current-result.json
```

`comparison.json`保存全部物理手牌、首出反事实及策略；`current.input/result.json`通过公共API和独立核逐字段对照。以前费用比较目录是此前源码版本的冻结证据，不要求其旧hash等于本轮新源码。本轮verification记录现行源hash与复算；测试通过只证明声明范围内的程序行为，不是服务器规则或实战价值校准。