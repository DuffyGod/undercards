"""Native kill, actual enemy coupon, and separately optimized board purpose."""
import unittest

import paid_board_tactics as paid
import score_cards
from build_death_discount_resistance_comparison import build,scene


class DeathDiscountResistanceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards=score_cards.load_cards()
        cls.rows={r['case']:r for r in build()['cases']}

    def test_shared_hand_hp_and_durable_pressure_choose_different_actual_cards(self):
        row=self.rows['enemy_cash_2']
        hp=row['searches']['guaranteed_hp']['objectives'][0]
        pressure=row['searches']['durable_pressure']['objectives'][0]
        self.assertEqual((hp['metrics']['own_player_hp'],pressure['metrics']['own_player_hp']),(7,7))
        self.assertEqual((hp['principal_variation'][0]['card_id'],pressure['principal_variation'][0]['card_id']),(103,14))
        single={r['card_id']:r for r in row['candidate_slot_comparisons']}
        self.assertFalse(single[103]['searches']['durable_pressure']['objectives'][0]['purpose_guaranteed'])
        self.assertTrue(single[14]['searches']['durable_pressure']['objectives'][0]['purpose_guaranteed'])

    def test_kill_discounts_held_spell_then_two_gold_really_pays_it_once(self):
        engine=paid.PaidSearch(self.cards,scene())
        root=engine.root()
        _,after=next((a,s) for a,s in engine.deploys(root) if a.get('card_id')==103)
        self.assertEqual(after.enemy[0].health,0)
        self.assertEqual((root.enemy_hand_costs,after.enemy_hand_costs),(((0,3),),((0,2),)))
        reply=engine.boundary(after)
        action,paid_reply=next(iter(engine.deploys(reply)))
        self.assertEqual((action['card_id'],action['paid_gold']), (96,2))
        self.assertEqual((paid_reply.enemy_gold,paid_reply.enemy_first_paid_gold,paid_reply.enemy_hand),(0,2,()))
        self.assertEqual(paid_reply.own[0].health,1)

    def test_taunt_counterattack_leaves_dog_alive_without_opening_discount(self):
        engine=paid.PaidSearch(self.cards,scene())
        _,deployed=next((a,s) for a,s in engine.deploys(engine.root()) if a.get('card_id')==14)
        reply=engine.boundary(deployed)
        _,attacked=next(iter(engine.attacks(reply)))
        self.assertEqual((attacked.own[0].health,attacked.enemy[0].health),(3,1))
        self.assertEqual(attacked.enemy_hand_costs,((0,3),))
        self.assertFalse(list(engine.deploys(attacked)))

    def test_cash_death_callback_and_attack_threshold_are_separate_interventions(self):
        candidate=lambda label,cid:self.rows[label]['candidate_slot_comparisons'][0 if cid==103 else 1]
        goal=lambda row:row['searches']['durable_pressure']['objectives'][0]
        self.assertFalse(goal(candidate('enemy_cash_2',103))['purpose_guaranteed'])
        for name in ('enemy_cash_1','remove_enemy_dust','enemy_attack_3'):
            self.assertTrue(goal(candidate(name,103))['purpose_guaranteed'])
        self.assertEqual(goal(candidate('enemy_attack_3',103))['metrics']['own_player_hp'],6)
        self.assertFalse(goal(candidate('enemy_attack_3',14))['purpose_guaranteed'])
        for row in self.rows.values():
            self.assertTrue(all(c['full_vector_equal'] for c in row['algorithm_checks']))


if __name__=='__main__':unittest.main()