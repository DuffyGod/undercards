"""Independent complete-text prototype: sample living-body predicates at Magic.

Does not change the production compiler. Ally identity uses a checked raw CARD
reference; Taunt existence reads current living statuses on both sides.
"""
import copy
from dataclasses import replace
import hashlib
from pathlib import Path
import re

import board_tactics as board
import conditional_card_score as score
import held_magic_extensions as held
import paid_board_tactics as paid
from physical_slot_score import PhysicalGeometryMixin

VERSION='presence-magic-prototype-0.1.0'


def parse(card):
    text=card.get('effect_readable','')
    if not isinstance(text,str):return None
    rest=text.strip();prefix=[]
    while (m:=board.PREFIX.match(rest)):
        prefix.append(rest[:m.end()]);rest=rest[m.end():]
    raw=card.get('effect_raw','');raw=raw if isinstance(raw,str) else ''
    if (m:=re.fullmatch(r'Magic: If you have an ally .+ \[#(\d+)\], give all \w+ in your hand ATK \+(\d+)/HP \+(\d+)\.',rest)):
        refs=re.findall(r'\{\{CARD:(\d+)\|1\}\}',raw);tribes=re.findall(r'\{\{TRIBE:([A-Z][A-Z0-9_]*)\|2\}\}',raw)
        reference=int(m[1]) if refs==[m[1]] else None
        tribe=tribes[0] if len(tribes)==1 and card.get('tribe_mentions')==tribes else None
        effect=('presence_magic',('ally_card',reference),('held_tribe_stats',tribe,int(m[2]),int(m[3])))
    elif (m:=re.fullmatch(r'Magic: If you have an ally .+ \[#(\d+)\], gain ATK \+(\d+)/HP \+(\d+), Taunt, and \+(\d+) Dodge\.',rest)):
        refs=re.findall(r'\{\{CARD:(\d+)\|1\}\}',raw)
        reference=int(m[1]) if refs==[m[1]] else None
        effect=('presence_magic',('ally_card',reference),('self_stats_taunt_dodge',int(m[2]),int(m[3]),int(m[4])))
    elif rest=='Magic: If there is a Taunt monster, gain Charge.':
        effect=('presence_magic',('any_living_taunt',),('self_charge',))
    else:return None
    return ''.join(prefix).strip(),effect


class PresenceMixin:
    def spec(self,card,observed=False,collect_unknown=True,condition_known_state=None):
        extension=parse(card)
        if extension is None or card.get('_silenced_in_hand'):
            return super().spec(card,observed=observed,collect_unknown=collect_unknown,condition_known_state=condition_known_state)
        prefix,effect=extension;changed=copy.deepcopy(card);changed['effect_readable']=prefix
        result=super().spec(changed,observed=observed,collect_unknown=False,condition_known_state=condition_known_state)
        result['magic']=None if observed else effect;result['evidence']=card.get('effect_readable','')
        if observed:result['resolved_magic_from_observation']=True
        if collect_unknown:self.unknown.extend('Card '+str(card['id'])+': '+x for x in result['unknown'])
        return result

    def magic(self,state,index,unit,spec,caster='own'):
        effect=spec.get('magic')
        if not effect or effect[0]!='presence_magic':return super().magic(state,index,unit,spec,caster=caster)
        state,unit=held.apply_played_keywords(self,state,index,unit,caster)
        physical=getattr(state,'hand' if caster=='own' else 'enemy_hand')
        if index in physical or sum(v==unit and v.key==unit.key for v in getattr(state,caster))!=1:
            raise paid.UnknownMechanic('Presence Magic needs its actually paid and placed physical source')
        predicate=effect[1]
        if predicate[0]=='ally_card':
            cid=predicate[1]
            if cid not in self.by or self.by[cid]['card_type']!='monster':
                raise paid.UnknownMechanic('Presence predicate needs one consistent known raw CARD identity')
            matching=[u.key for u in getattr(state,caster) if u.health>0 and u.card_id==cid]
        else:
            matching=[u.key for side in ('own','enemy') for u in getattr(state,side) if u.health>0 and u.taunt]
        condition=dict(predicate=predicate,matching_live_keys=matching,satisfied=bool(matching),
            sample='After real payment/removal and placement, before Magic effects; not a continuous aura.')
        action=dict(kind='deploy',hand_index=index,card_id=unit.card_id,magic=effect,magic_condition=condition)
        if caster=='enemy':action['side']='enemy'
        if not matching or self.terminal(state):return [(action,state)]
        operation=effect[2]
        if operation[0]=='held_tribe_stats':
            _,tribe,attack,health=operation
            if tribe is None:raise paid.UnknownMechanic('Conditional hand buff needs consistent raw TRIBE metadata')
            delegated=dict(spec,magic=('buff_hand_monsters',tribe,attack,health))
            return [(dict(a,original_conditional_magic=effect,magic_condition=condition),child)
                for a,child in super().magic(state,index,unit,delegated,caster=caster)]
        if operation[0]=='self_charge':unit=replace(unit,ready=2)
        else:
            _,attack,health,dodge=operation
            unit=replace(unit,attack=unit.attack+attack,health=unit.health+health,max_health=unit.max_health+health,
                taunt=True,dodge=unit.dodge+dodge)
        child=replace(state,**{caster:tuple(unit if u.key==unit.key else u for u in getattr(state,caster))})
        return [(action,child)]


class PresenceSearch(PresenceMixin,score.TaskSearch):pass
class PhysicalPresenceSearch(PhysicalGeometryMixin,PresenceMixin,score.TaskSearch):pass

LOADED=score.source_bindings(Path(__file__))


def evaluate(data,task,*,cards=None,focal_index=None):
    bindings=score.source_bindings(Path(__file__))
    if bindings!=LOADED:raise RuntimeError('Presence prototype loaded source changed')
    cards=score.score_cards.load_cards() if cards is None else cards
    if not isinstance(cards,list) or any(type(c.get('id')) is not int for c in cards) or len({c['id'] for c in cards})!=len(cards):
        raise ValueError('Unique nonbool integer card IDs required')
    digest=hashlib.sha256(score.canonical(cards).encode()).hexdigest()
    kind=task.get('kind','joint');scope=task.get('body_scope','board');constraints=copy.deepcopy(task.get('constraints',{}))
    if set(task)-{'kind','body_scope','constraints'} or kind not in ('hp','joint') or scope not in ('board','focal','lineage'):
        raise ValueError('Invalid task')
    if kind=='hp' and (constraints or scope!='board'):raise ValueError('HP without body constraints')
    if scope!='board' and (focal_index is None or not paid.SINGLE_BODY_PURPOSE_FIELDS.intersection(constraints)):
        raise ValueError('Physical focal index and body constraints required')
    scene=copy.deepcopy(data);scene.pop('objectives',None);scene.pop('purpose_constraints',None)
    if kind=='joint':scene['purpose_constraints']={'min_own_player_hp':1,**constraints}
    cls=PhysicalPresenceSearch if scene.get('physical_slots') else PresenceSearch
    engine=cls(cards,scene,body_scope=scope,focal_index=focal_index);root=engine.root()
    search=engine.solve(root,'guaranteed_hp' if kind=='hp' else 'purpose') if not engine.unknown else dict(search_complete=False,unknown=engine.unknown,metrics=None,principal_variation=[])
    known=search['search_complete'];feasible=(search['metrics']['own_player_hp']>0 if kind=='hp' else search['purpose_guaranteed']) if known else None
    value=dict(version=VERSION,known=known,feasible=feasible,
        guaranteed_player_hp=search['metrics']['own_player_hp'] if known and (kind=='hp' or feasible) else None,
        task=task,search=search,unknown=search.get('unknown',[]),source_hashes=bindings,cards_sha256=digest,
        prototype_only=True,production_core_changed=False,
        assumptions=['Taunt existence reads living actual statuses on both sides, including Transparency; no target is selected.',
            'Ally CARD checks actual living current identity after real source deployment; no hand/deck presence substitution.'])
    if bindings!=score.source_bindings(Path(__file__)) or digest!=hashlib.sha256(score.canonical(cards).encode()).hexdigest():
        raise RuntimeError('Presence input/source changed during run')
    return value