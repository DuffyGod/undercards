# 按用途比较3–10费怪物：paid0.27

[打开交互表](score-explorer.html)；[完整CSV](../../research-runs/pool-frontier-v04/scores.csv)；[全部原始结果](../../research-runs/pool-frontier-v04/frontiers.json)。

565张原生候选完整保留，78张编译支持并实际执行312次物理目标查询。73张四用途闭合；另外3张Dust牌在位置无关证书下闭合，共76张。487张编译未知，Fox Head与Mace运行未知，共489张未知。每个费用桶都存在未知，因此没有任何全桶冠军认证。旧paid0.25的72张表仍单独保留。

每行允许现在部署、继续持有、在下一己方回合真实支付；所有候选现金为自身原生费用，只持这一张牌。己15/30HP、敌30/30HP；敌4/4 Thrashing Machine、两张Gem和2G，敌可以留Gem至第二次回应。外生收入和自然抽牌为0，双方显式空库、疲劳从1开始；卡牌自身的抽牌、赚金、减费仍照常发生。窗口截至第二次敌方攻击，不能当作真实对局频率。

Q是完成用途且活着时，**同一策略能够共同保证的最高玩家HP**。不同用途列可以采用不同打法。不可保证、死亡HP0、规则或预算未知、未查询分别保留，不能混作零分。身体用途要求候选的原始物理副本同时满足2攻2血。

| 原生费用 | 四用途闭合 / 候选 | 保命及清场的已支持领先项Q | 保原体2/2的已支持领先项Q |
|---|---:|---|---|
| 3G | 22/106 | Burgerpants 13 | 无可保证候选 |
| 4G | 18/131 | Parsnik / Diamond Receptionist / Cracked Geode 13 | Parsnik 9 |
| 5G | 12/95 | Long Sink 15 | Carbed 5 |
| 6G | 13/97 | Innkeeper 14 | Big Hat Charles 9 |
| 7G | 4/54 | Tsunderplane / Coffee Man 13 | 无可保证候选 |
| 8G | 3/27 | Gyftrot / Baron 13 | Gyftrot 13 |
| 9G | 2/32 | Spade King 13 | Spade King 13 |
| 10G | 2/23 | Spade Chain 13 | Spade Chain 13 |

这张表的纯保命与清场领先恰好相同，不代表这两个用途可普遍合并。新增条件三卡在单卡场景没有免费伙伴；Spade Chain在十费真实替代中改变已支持领先项。该结论只对当前观察成立，其他高费例子见[单体、宽场和费用阈值比较](../presence-magic-production-v01/README.md)。

位置证书只用于Blockler B、Rock、Dad Slime，额外12次请求、24次内部核心调用；完整手、库及生成闭包须通过位置无关白名单。原物理搜索未知不覆盖，页面可切换。front映射、空前方fizzle、Switch左区[0,1]、allies含玩家、手牌无目标fizzle与双选只选有目标分支，均是公开条件，尚无服务器轨迹验证。

本次从开始声明每张四用途5 CPU秒、30墙钟秒的扩展门槛，节点20k未提升；78张实际完成63.914秒，无扩展中止。[128种选择器组合验证](delivery-verification.json)实际检查5116行／细节和1256个原始链接，使用Node的DOM替身，不声称浏览器布局检查。页面只读冻结结果，不运行估值。当前部署权在本版本未查，绝不当作0；其历史按用途比较另见[paid0.24](../pool-frontier-v02/README.md)。

仍缺多数整卡机制、隐藏信息、长窗口与构筑到达频率，无法据此认证真实胜率或推荐全卡池最强牌。