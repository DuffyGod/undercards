"""Source-bound public-entry replay and frozen full-vector comparisons."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import conditional_card_score as score
import scalar_task_score as scalar

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,obj):(HERE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

def main():
    bindings=score.source_bindings(ROOT/'scalar_task_score.py');cards=score.score_cards.load_cards();rows=[]
    parent=ROOT/'research-runs/pool-frontier-v02'
    for fee,cid in ((3,107),(3,187),(5,509),(5,534),(8,8),(8,44),(9,249),(9,419)):
        path=parent/f'native{fee}-card{cid}.json';raw=json.loads(path.read_text())
        for task_name in ('hp','focal_2_2'):
            task=raw['tasks'][task_name];expected=raw['results'][task_name]
            value=scalar.evaluate(raw['input'],task,cards=cards,focal_index=raw['focal_index'])
            assert value['known'] and expected['known'],(cid,task_name,value.get('unknown'))
            n=1 if task['kind']=='hp' else 2
            assert tuple(value['search']['objective_vector'])==tuple(expected['search']['objective_vector'][:n])
            name=f'compare-card{cid}-{task_name}.json';write(name,dict(result=value,reference=str(path.relative_to(ROOT)),reference_sha256=sha(path)))
            rows.append(dict(card_id=cid,task=task_name,artifact=name,matched_primary=True,scalar_hp=value['guaranteed_player_hp']))
    rich=[]
    for cid in (30,107,187):
        path=parent/f'resource-challenge-card{cid}.json';raw=json.loads(path.read_text())
        payload=dict(scene=raw['input'],task=raw['task'],focal_index=0,geometry='certified_quotient')
        write(f'public-card{cid}.input.json',payload);start=time.monotonic()
        value=scalar.evaluate(**dict(data=payload['scene'],task=payload['task'],cards=cards,focal_index=0,geometry=payload['geometry']))
        write(f'public-card{cid}.json',value)
        rich.append(dict(card_id=cid,known=value['known'],hp=value['guaranteed_player_hp'],
            geometry_certificate=value['geometry_certificate']['issued'],states=value['search']['visited_states'],
            seconds=time.monotonic()-start,artifact=f'public-card{cid}.json',original_full_vector_known=raw['result']['known']))
        print(json.dumps(rich[-1]),flush=True)
    cmd=[sys.executable,str(ROOT/'scalar_task_score.py'),str(HERE/'public-card30.input.json'),'--output',str(HERE/'cli.output.json')]
    completed=subprocess.run(cmd,capture_output=True,text=True,cwd=ROOT)
    (HERE/'cli.stdout.log').write_text(completed.stdout);(HERE/'cli.stderr.log').write_text(completed.stderr)
    assert completed.returncode==0
    assert json.loads((HERE/'cli.output.json').read_text())==json.loads((HERE/'public-card30.json').read_text())
    assert bindings==score.source_bindings(ROOT/'scalar_task_score.py')
    source=HERE/'source';source.mkdir(exist_ok=True)
    for name,h in bindings.items():
        assert sha(ROOT/name)==h;(source/name).write_bytes((ROOT/name).read_bytes())
    (HERE/'native-snapshot.json').write_bytes(score.score_cards.DEFAULT_SNAPSHOT.read_bytes())
    write('validation.json',dict(source_hashes=bindings,source_stable=True,builder_sha256=sha(Path(__file__)),
        original_full_vector_primary_matches=rows,matches=len(rows),resource_challenges=rich,
        actual_queries=20,public_cli_full_json_equal=True,cli_command=cmd,
        all_node_limits_unchanged=20000,production_core_changed=False))
    print(json.dumps(dict(matches=len(rows),resource=rich,cli_equal=True)),flush=True)

if __name__=='__main__':main()