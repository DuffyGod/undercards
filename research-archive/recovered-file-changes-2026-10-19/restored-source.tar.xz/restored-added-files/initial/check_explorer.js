// Execute the actual inline application across every declared control state.
const fs=require('fs'),vm=require('vm'),path=require('path'),crypto=require('crypto');
const here=__dirname, htmlpath=path.resolve(here,'../../experiments/combat-event-v01/comparison-explorer.html');
const html=fs.readFileSync(htmlpath,'utf8');
const code=html.match(/<script>([\s\S]*)<\/script>/)[1];
const dom={};for(const id of ['family','cost','scene','variant','task','floor','rows','count','summary'])dom[id]={value:'',innerHTML:'',textContent:'',addEventListener(){}};
Object.assign(dom.family,{value:'main'});Object.assign(dom.cost,{value:'all'});Object.assign(dom.scene,{value:'small'});Object.assign(dom.variant,{value:'unresolved'});Object.assign(dom.task,{value:'hp'});Object.assign(dom.floor,{value:'1'});
const context=vm.createContext({document:{getElementById:id=>dom[id]}});vm.runInContext(code,context);
let states=0, links=0;
for(const family of ['main','sensitivity'])for(const cost of ['all','4','5','6','9'])for(const scene of ['small','open','wide','tall'])for(const variant of ['unresolved','declared','removed'])for(const task of ['hp','attack_body'])for(const floor of ['1','11','15']){
 for(const [id,value] of Object.entries({family,cost,scene,variant,task,floor}))dom[id].value=value;
 vm.runInContext('render()',context);states++;
 const expected=vm.runInContext(`DATA.rows.filter(r=>r.family===el('family').value&&(el('cost').value==='all'||r.cost===Number(el('cost').value))&&r.situation===el('scene').value&&r.variant===el('variant').value+(el('task').value==='attack_body'?'_attack_body':'')).length`,context);
 const actual=(dom.rows.innerHTML.match(/<tr>/g)||[]).length;if(actual!==expected)throw Error('Row count mismatch');
 const urls=[...dom.rows.innerHTML.matchAll(/href="([^"]+)"/g)].map(m=>m[1]);
 for(const url of urls){if(!fs.existsSync(path.resolve(path.dirname(htmlpath),url)))throw Error('Missing raw '+url);links++;}
 if(/undefined|NaN/.test(dom.rows.innerHTML))throw Error('Invalid visible quote');
}
const report={passed:true,control_states:states,raw_links_checked:links,actual_inline_script_executed:true,
 html_sha256:crypto.createHash('sha256').update(html).digest('hex'),
 scope:'Node DOM stub checks actual filtering/rendering and raw links; no browser layout check.'};
fs.writeFileSync(path.join(here,'explorer-verification.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));