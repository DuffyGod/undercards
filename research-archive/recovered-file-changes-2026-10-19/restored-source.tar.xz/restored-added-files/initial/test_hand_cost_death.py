import copy
from dataclasses import replace
import unittest
import paid_board_tactics as paid
import score_cards


def scenario(income=2,cash=3):
    return dict(hand_ids=[43,22],gold_before_play=6,own_player_hp=10,
        max_plays=1,next_max_plays=1,next_own_gold_income=income,
        current_turn_gold_spent_on_spells=0,
        enemy_bodies=[dict(card_id=15,attack=6,health=5),dict(card_id=196,attack=1,health=1)],
        opponent_hand_ids=[96],opponent_gold_before_response=cash,
        horizon='next_enemy_attack',next_opponent_gold_income=0,
        next_opponent_natural_draw_count=0,objectives=['guaranteed_hp'])


class HandCostDeathTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def test_real_payment_threshold_changes_survival_and_exhaustive_agrees(self):
        for income,native,removed in ((1,0,0),(2,2,0),(3,2,2)):
            for dust,hp in ((True,native),(False,removed)):
                cards=copy.deepcopy(self.cards)
                if not dust:next(c for c in cards if c['id']==43)['effect_readable']=''
                data=scenario(income)
                result=paid.evaluate(data,cards)
                self.assertTrue(result['complete_in_declared_scope'],result['unknown'])
                self.assertEqual(result['objectives'][0]['metrics']['own_player_hp'],hp)
                other=paid.evaluate(dict(data,search_algorithm='exhaustive'),cards)
                self.assertEqual(result['objectives'][0]['objective_vector'],other['objectives'][0]['objective_vector'])

    def test_physical_same_id_copies_and_late_draw_do_not_share_coupon(self):
        engine=paid.PaidSearch(self.cards,dict(hand_ids=[598,598],hand_costs=[0,1],
            gold_before_play=0,max_plays=2,own_deck_ids=[598],
            ally_bodies_before_play=[dict(card_id=43,attack=5,health=1,max_health=5)]))
        root=engine.root()
        after=next(s for a,s in engine.casts(root,'own') if a['hand_index']==0 and a['targets']==[('own',0)])
        self.assertEqual(after.own_hand_costs,((1,0),))
        self.assertEqual(root.own_hand_costs,((0,0),(1,1)))
        late=engine.draw(after,1)
        self.assertEqual(late.own_hand_costs,((1,0),(2,1)))
        self.assertEqual(late.own_hand_cost_reduction_events,1)
        again=engine.deaths(late,late)
        self.assertEqual(again.own_hand_costs,late.own_hand_costs)
        self.assertEqual(again.own_hand_cost_reduction_events,1)
        self.assertEqual(engine.hand[1][0]['cost'],1)

    def test_floor_zero_is_explicit_and_free_spell_does_not_unlock_need(self):
        data=dict(hand_ids=[598,598,582],hand_costs=[0,1,4],gold_before_play=0,max_plays=3,
            ally_bodies_before_play=[dict(card_id=43,attack=5,health=1,max_health=5)],
            current_turn_gold_spent_on_spells=0,
            condition_known_state={'last_turn_gold_spent_on_spells':1},
            horizon='next_own_attack',next_max_plays=1,next_own_gold_income=3)
        engine=paid.PaidSearch(self.cards,data)
        root=engine.root()
        after=next(s for a,s in engine.casts(root,'own') if a['hand_index']==0 and a['targets']==[('own',0)])
        after=next(s for a,s in engine.casts(after,'own') if a['hand_index']==1 and a['targets']==[('enemy_player',None)])
        future=engine.boundary(engine.boundary(after))
        action,state=next((a,s) for a,s in engine.deploys(future) if a['card_id']==582)
        self.assertEqual((action['paid_gold'],state.own[-1].attack,state.own[-1].taunt),(3,2,False))
        self.assertEqual(future.previous_own_spell_spend,0)
        r=paid.evaluate(data,self.cards)
        self.assertIn('hand_cost_floor=0 (source-unverified)',r['rule_hypotheses'])

    def test_enemy_discount_uses_only_its_held_copies_and_actual_payment(self):
        e=paid.PaidSearch(self.cards,dict(hand_ids=[598],gold_before_play=1,
            enemy_bodies=[dict(card_id=43,attack=5,health=1,max_health=5)],
            opponent_hand_ids=[2],opponent_gold_before_response=1))
        root=e.root()
        killed=next(s for a,s in e.casts(root,'own') if a['targets']==[('enemy',0)])
        self.assertEqual(killed.enemy_hand_costs,((0,1),))
        a,s=next(e.deploys(e.boundary(killed)))
        self.assertEqual((a['paid_gold'],s.enemy[-1].cost,s.enemy[-1].printed_cost),(1,1,2))
        self.assertEqual(s.enemy[-1].current_card_cost,1)
        self.assertEqual(s.enemy_hand_costs,())

    def test_discount_exposes_affordable_unknown_instead_of_skipping_it(self):
        e=paid.PaidSearch(self.cards,dict(hand_ids=[598,14],hand_costs=[0,1],gold_before_play=0,
            ally_bodies_before_play=[dict(card_id=43,attack=5,health=1,max_health=5)]))
        after=next(s for a,s in e.casts(e.root(),'own') if a['hand_index']==0 and a['targets']==[('own',0)])
        with self.assertRaisesRegex(paid.UnknownMechanic,'Reachable current card 14'):
            list(e.deploys(after))

    def test_multiple_dust_and_silenced_sources_remain_distinct(self):
        e=paid.PaidSearch(self.cards,dict(hand_ids=[22],gold_before_play=3,
            ally_bodies_before_play=[dict(card_id=43,attack=5,health=1,max_health=5),
                dict(card_id=138,attack=3,health=1,max_health=5)]))
        root=e.root()
        with self.assertRaisesRegex(paid.UnknownMechanic,'competes'):
            e.deaths(root,replace(root,own=tuple(replace(u,health=0) for u in root.own)))
        e=paid.PaidSearch(self.cards,dict(hand_ids=[22],gold_before_play=3,
            ally_bodies_before_play=[dict(card_id=43,attack=5,health=1,max_health=5,silenced=True)]))
        root=e.root();after=e.deaths(root,replace(root,own=(replace(root.own[0],health=0),)))
        self.assertEqual(after.own_hand_costs,((0,3),))
        self.assertEqual(after.own_hand_cost_reduction_events,0)


if __name__=='__main__':unittest.main()