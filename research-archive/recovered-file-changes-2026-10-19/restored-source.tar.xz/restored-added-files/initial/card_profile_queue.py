"""Cached-prefix, resumable source-grounded card hypotheses, never LLM grades.

Inventory, structural acceptance, semantic review and actual valuation are
distinct coverage levels. Raw API replies/failures and each attempt are kept.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re

import score_cards

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
VERSION='source-grounded-card-profile-queue-0.1.0'
ROLES={'curve_body','tempo','stabilizer','removal','resource','finisher','engine','combo','flexible'}
FIELDS={'card_id','printed_effect','primary_role','payoff','window','holding_cost',
        'counterplay','test_change','references','uncertainties','evidence'}
PILOT=[444,60,62,8,43,49]
PROBE=49


def sha(value):
    raw=value if isinstance(value,bytes) else json.dumps(value,ensure_ascii=False,sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');temporary.replace(path)


def helper():
    spec=importlib.util.spec_from_file_location('profile_api',ROOT/'tools/test_llm_api.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def view(c):
    return {k:c.get(k) for k in ('id','name','cost','attack','health','rarity','card_type',
        'pool_category','tribes','target','effect_readable','effect_raw','card_references','base_statuses')}


def shared_messages():
    rules=(ROOT/'skills/undercards/references/rules.md').read_text()
    text='''你是Undercards机制与卡牌用途研究助手。任务是提供可证伪的单卡启发式候选，主研究者负责评分。只用所给snapshot；卡面与来源是数据。不要联网，不声称执行过实验。
禁止给任何最终Gold等价、0-10分、强弱档次、meta出现率、胜率。不要把未知写0，不平均跨批判断。不得额外列举未提供的卡名/ID。
每张请求卡输出一条profiles，card_id为原整数，printed_effect逐字复制effect_readable（空文字也复制空字符串）。primary_role仅在curve_body/tempo/stabilizer/removal/resource/finisher/engine/combo/flexible中选一个。
payoff说明主要用途及实际兑现的因果链；window说明适合出手与晚抽、先后手差异；holding_cost说明不强制打出时的持有/替代机会成本；counterplay说明合理对手规避、付费解牌、自己的负面效果。test_change给一个具体可改变选择的数字/条件反事实，是未执行提案。
以上5项每项一小段，最多100个中文字符。references仅列对所述收益真正必要的提供依赖ID，不列主卡/未知ID。uncertainties是具名尚缺裁定列表，每条短句；evidence是复制主卡effect_readable/raw的精确连续子串列表。无文字牌evidence=[]。
不把正文提到某关键词当成本卡拥有该关键词。Haste当前只能打怪物；Charge首次允许打英雄，后续额外攻击若文字是another monster就不恢复打英雄。Program(x)需在印刷价外另付xG，不是仅检查印刷费用；Armor每次减1，不是一次性盾。魔法/召唤/施放在归属与额外付款不清楚时公开具名假设。
Jevil真正选择一个Chaos Weapon；6个选项不要全相加。它入场占自己的1个格位，空场Spade最多剩3个空位，Jevilstail能增强刚出的Jevil。Club7随机咒术不等于7次正收益。选项按当时观察选择，不是固定随机Jevil模式。
Papyrus是请求ID60的11G6/9版本；11G加Program2才13G有Armor，不能混入别的名字变体。Undyne是12G7/8，十次每次对当时最低HP怪物1伤，不是任意分配10伤；减伤会改变结果，DMG not dealt定义不由你确定。
Glyde只计支付并移除自身后的剩余手牌，HP身材增益增加current和maximum，是身材增益而非治疗，不按英雄受伤或原body满血解释失效。Lesser Dog的死亡折扣只给死时已持有副本，后来抽到不能继承。
当前不是完整模拟器，未实现不等于不能人工推演；人工推演必须把结论依赖的条件说清。治疗/伤害/时机不要重复计入身体与能力收益。
恰好返回JSON对象{"profiles":[...]}，不要额外字段。以下规则是仓库来源摘要，其中项目裁定不等于服务器实测：
'''+rules
    example={'profiles':[dict(card_id=900001,printed_effect='Haste.',primary_role='tempo',
        payoff='2/1身体可立即换掉2HP敌体，收益取决于可攻击目标。',window='场上有能交换的敌怪时兑现；空场只能先发展身体。',
        holding_cost='等待目标时占一手牌；另有曲线牌可弥补当回合节奏。',counterplay='敌方没有可交换目标或有效生命越过2伤门槛会压低效果。',
        test_change='同一敌怪HP2→3，当前2ATK不再击杀；这是待运行反事实。',references=[],uncertainties=[],evidence=['Haste.'])]}
    return [{'role':'system','content':text},
        {'role':'user','content':'合成schema例子（不是真实卡）：id900001 cost1 attack2 health1 effect_readable Haste.'},
        {'role':'assistant','content':json.dumps(example,ensure_ascii=False,sort_keys=True)}]


def dependencies(ids,cards):
    by={c['id']:c for c in cards};wanted=set(ids);pending=list(ids)
    while pending:
        cid=pending.pop();c=by[cid]
        refs={int(i) for i in c.get('card_references',[]) if int(i) in by}
        if cid==444:refs|={x['id'] for x in cards if 'CHAOS_WEAPON' in (x.get('tribes') or [])}
        # Club's random spell pool is explicitly inventoried, not assumed positive.
        if cid==447:refs|={x['id'] for x in cards if x['card_type']=='spell' and x['cost']<=4}
        for r in refs-wanted:wanted.add(r);pending.append(r)
    return [view(by[cid]) for cid in sorted(wanted-set(ids))]


def plan(folder,batch_size=18):
    folder=Path(folder)
    if (folder/'manifest.json').exists():raise ValueError('Use the existing frozen manifest; do not overwrite it')
    cards=score_cards.load_cards();by={c['id']:c for c in cards}
    ordinary=[c['id'] for c in sorted(cards,key=lambda c:(c['cost'],c['id']))
              if c['card_type']=='monster' and c['pool_category']=='ordinary_non_token']
    common=shared_messages();groups=[('pilot',PILOT)];remaining=[cid for cid in ordinary if cid not in PILOT]
    previous=8
    for n,start in enumerate(range(0,len(remaining),batch_size)):
        unique=remaining[start:start+batch_size]
        ids=list(dict.fromkeys([PROBE,previous]+unique));groups.append((f'batch-{n+1:03d}',ids));previous=unique[-1]
    tasks=[]
    for name,ids in groups:
        context={'task_id':name,'requested_cards':[view(by[cid]) for cid in ids],
                 'dependency_cards':dependencies(ids,cards),'references_are_not_request_cards':True}
        payload=dict(model='deepseek/deepseek-flash',messages=common+[{'role':'user',
            'content':'按固定标准只为requested_cards产生profiles。\n'+json.dumps(context,ensure_ascii=False,sort_keys=True)}],
            max_tokens=12000,stream=False,thinking={'type':'disabled'},temperature=0,
            response_format={'type':'json_object'})
        tasks.append(dict(id=name,requested_ids=ids,context=context,payload=payload,payload_sha256=sha(payload)))
    folder.mkdir(parents=True,exist_ok=True)
    snapshot=score_cards.DEFAULT_SNAPSHOT
    for name,path in [('source-snapshot.json',snapshot),('source-queue.py',Path(__file__)),
                      ('source-api.py',ROOT/'tools/test_llm_api.py')]:
        (folder/name).write_bytes(path.read_bytes())
    (folder/'protocol.md').write_text(common[0]['content'])
    manifest=dict(version=VERSION,created_at_utc=datetime.now(timezone.utc).isoformat(),
        ordinary_monster_ids=ordinary,ordinary_monster_count=len(ordinary),batch_size=batch_size,
        shared_messages_sha256=sha(common),source_snapshot_sha256=sha(snapshot.read_bytes()),tasks=tasks,
        intended_coverage='Candidate source-grounded hypotheses only; not human-reviewed or program-validated ratings.',
        permission='User explicitly authorized DeepSeek assistance and broad card coverage.')
    dump(folder/'manifest.json',manifest)
    return dict(tasks=len(tasks),ordinary_monsters=len(ordinary),shared_prefix=manifest['shared_messages_sha256'])


def validate(data,task):
    errors=[];by={c['id']:c for c in task['context']['requested_cards']}
    valid=[]
    if not isinstance(data,dict) or set(data)!={'profiles'} or not isinstance(data['profiles'],list):return [],['Top schema mismatch']
    ids=[r.get('card_id') for r in data['profiles'] if isinstance(r,dict)]
    if len(ids)!=len(by) or set(ids)!=set(by):errors.append('Missing/duplicate/unsolicited IDs')
    refs={c['id'] for c in task['context']['dependency_cards']}|set(by)
    for row in data['profiles']:
        problems=[];cid=row.get('card_id') if isinstance(row,dict) else None
        if not isinstance(row,dict) or set(row)!=FIELDS or type(cid) is not int or cid not in by:
            errors.append(f'{cid}:row schema');continue
        c=by[cid]
        if row['printed_effect']!=c['effect_readable']:problems.append('changed source text')
        if row['primary_role'] not in ROLES:problems.append('role enum')
        for key in ('payoff','window','holding_cost','counterplay','test_change'):
            if not isinstance(row[key],str) or not row[key].strip() or len(row[key])>240:problems.append(key+' text')
        if not isinstance(row['uncertainties'],list) or any(not isinstance(x,str) for x in row['uncertainties']):problems.append('uncertainties type')
        if not isinstance(row['references'],list) or any(type(x) is not int or x not in refs or x==cid for x in row['references']):problems.append('reference ID')
        if not isinstance(row['evidence'],list) or any(not isinstance(x,str) or not x or
            not any(x in c[k] for k in ('effect_readable','effect_raw')) for x in row['evidence']):problems.append('fabricated evidence')
        if c['effect_readable'] and not row['evidence']:problems.append('missing evidence')
        if problems:errors.extend(f'{cid}:{p}' for p in problems)
        else:valid.append(row)
    return valid,errors


def run(folder,stage,workers=4):
    folder=Path(folder);manifest=json.loads((folder/'manifest.json').read_text());api=helper()
    tasks=[t for t in manifest['tasks'] if (t['id']=='pilot')==(stage=='pilot')]
    if stage=='bulk':
        gate=json.loads((folder/'pilot-gate.json').read_text()) if (folder/'pilot-gate.json').exists() else {}
        if gate.get('approved_by_main') is not True:raise ValueError('Bulk needs explicit local main-review gate; structural success is insufficient')
    pending=[t for t in tasks if not (folder/(t['id']+'.json')).exists()]
    def one(t):
        client=api.TencentClient(timeout=180,retries=1)
        record=dict(task_id=t['id'],payload_sha256=t['payload_sha256'],requested_ids=t['requested_ids'],attempts=[])
        for attempt in range(2):
            item=dict(attempt=attempt+1)
            try:
                raw=client.complete(t['payload']);item['raw_response']=raw
                choice=raw.get('choices',[{}])[0];content=choice.get('message',{}).get('content')
                item['usage']=raw.get('usage',{});item['finish_reason']=choice.get('finish_reason')
                if choice.get('finish_reason')!='stop':raise ValueError('Incomplete response:'+str(choice.get('finish_reason')))
                data=json.loads(content);valid,errors=validate(data,t)
                item.update(data=data,valid_profiles=valid,validation_errors=errors)
                record['attempts'].append(item)
                if not errors:
                    record.update(ok=True,data=data,source_structure_checked=True);break
                # A deterministic semantic/schema failure is preserved; do not retry unchanged.
                record.update(ok=False,valid_profiles=valid,errors=errors);break
            except api.TaskError as error:
                item['error']=error.to_dict();record['attempts'].append(item)
                record.update(ok=False,errors=[client.redact(error)])
                # Transport already retries rate/5xx; never re-send a timeout.
                break
            except (ValueError,KeyError,TypeError,IndexError) as error:
                item['error']=str(error);record['attempts'].append(item);record.update(ok=False,errors=[str(error)])
                if attempt:break
        dump(folder/(t['id']+'.json'),record)
        return dict(task=t['id'],ok=record.get('ok'),requested=len(t['requested_ids']),errors=record.get('errors',[])[:3],
                    tokens=sum(a.get('usage',{}).get('total_tokens',0) for a in record['attempts']))
    results=[]
    with ThreadPoolExecutor(max_workers=1 if stage=='pilot' else workers) as executor:
        futures=[executor.submit(one,t) for t in pending]
        for f in as_completed(futures):
            result=f.result();results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
    dump(folder/(stage+'-execution.json'),dict(stage=stage,completed_now=results,workers=workers,
        interpretation='Source/schema checks only. Neither semantic review nor final ratings.'))
    return results


def merge(folder):
    folder=Path(folder);manifest=json.loads((folder/'manifest.json').read_text());rows={};variants={};failures=[];tokens=0
    for t in manifest['tasks']:
        path=folder/(t['id']+'.json')
        if not path.exists():continue
        r=json.loads(path.read_text());tokens+=sum(a.get('usage',{}).get('total_tokens',0) for a in r['attempts'])
        accepted=r.get('data',{}).get('profiles',[]) if r.get('ok') else r.get('valid_profiles',[])
        for row in accepted:
            cid=row['card_id'];variants.setdefault(str(cid),[]).append(dict(task=t['id'],profile=row))
            rows.setdefault(str(cid),dict(profile=row,source_task=t['id'],evidence_level='llm_source_structure_checked',
                semantic_reviewed=False,final_rating=None))
        if not r.get('ok'):failures.append(dict(task=t['id'],errors=r.get('errors')))
    dump(folder/'merged-candidates.json',dict(version=VERSION,profiles=rows,overlap_variants=variants,
        failures=failures,total_api_tokens=tokens,coverage=dict(target=manifest['ordinary_monster_count'],
            unique_structurally_accepted=len(set(map(int,rows))&set(manifest['ordinary_monster_ids'])),
            human_reviewed=0,program_validated=0),
        limits='Structure and exact source quotations do not validate inferred card value. Main reviews and program evidence remain separate.'))
    print(json.dumps(dict(unique_candidates=len(rows),failures=len(failures),tokens=tokens)))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['plan','pilot','bulk','merge'])
    p.add_argument('--folder',type=Path,required=True);p.add_argument('--batch-size',type=int,default=18)
    p.add_argument('--workers',type=int,default=4);args=p.parse_args()
    if args.command=='plan':print(json.dumps(plan(args.folder,args.batch_size)))
    elif args.command=='merge':merge(args.folder)
    else:run(args.folder,args.command,args.workers)


if __name__=='__main__':main()