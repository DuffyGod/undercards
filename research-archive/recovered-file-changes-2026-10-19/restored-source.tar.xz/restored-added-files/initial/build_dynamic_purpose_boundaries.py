"""Purpose threshold and paid healing counterfactual, no new score weights."""
import hashlib
import json
from pathlib import Path

import board_tactics as b
import build_dynamic_body_comparison as family
import paid_board_tactics as p
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/dynamic-body-v01'


def main():
    cards=score_cards.load_cards();rows=[]
    for cid in (534,15,14,509):
        for attack in (2,3):
            d=family.scene(cid,attack,3);d.update(objectives=['purpose'],
                purpose_constraints=dict(min_own_player_hp=1,min_own_body_attack=4,min_own_body_health=3))
            a=p.evaluate(d,cards);x=p.evaluate(dict(d,search_algorithm='exhaustive'),cards)
            assert a['complete_in_declared_scope'] and x['complete_in_declared_scope']
            assert a['objectives'][0]['objective_vector']==x['objectives'][0]['objective_vector']
            rows.append(dict(card_id=cid,enemy_attack=attack,input=d,result=a,
                joint_body43=a['objectives'][0]['purpose_guaranteed'],full_vectors_equal=True))
    assert [r['joint_body43'] for r in rows]==[True,False,True,False,True,False,True,True]
    heal=[]
    for attack in (5,7):
        d=dict(hand_ids=[868],hand_base_costs=[5],gold_before_play=5,
            own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
            ally_bodies_before_play=[dict(card_id=534,attack=attack,health=4,max_health=5)],
            enemy_bodies=[],opponent_hand_ids=[],opponent_hand_known=True,objectives=['guaranteed_hp'])
        e=p.PaidSearch(cards,d);root=e.root()
        action,child=next((a,c) for a,c in e.deploys(root) if a['magic_target']==('own',0))
        assert child.current_paid_gold==5 and child.own_hp==16
        assert child.own[0].health==5 and b.effective_attack(child.own[0],child,'own')==attack-3
        heal.append(dict(input=d,action=action,paid_gold=child.current_paid_gold,
            player_before=root.own_hp,player_after=child.own_hp,
            before=b.unit_description(root.own[0],root,'own'),
            after=b.unit_description(child.own[0],child,'own'),
            fixed_prefix_only=True))
    out=dict(cases=rows,paid_heal_prefixes=heal,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('build_dynamic_purpose_boundaries.py','build_dynamic_body_comparison.py','board_tactics.py','paid_board_tactics.py')},
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        interpretation='Closed joint4ATK/3HP queries have exact full-vector search; heal examples are actually paid fixed prefixes, not optimal policy recommendations.')
    (OUT/'purpose-boundaries.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    lines=['# 更高攻击目的与治疗反例','',
        '同5G背景和真实等待付款，目标同一身体≥4ATK/3HP、玩家存活。敌目标仍3HP，只将敌攻击2→3。','',
        '| 候选 | 敌2攻/3血 | 敌3攻/3血 |','|---|---|---|',
        '| Carbed | 可行 | 不可行 |','| Aaron | 可行 | 不可行 |',
        '| Jerry | 可行 | 不可行 |','| Long Sink | 可行 | 可行 |','',
        'Carbed能在较弱反击下激活5攻并保3血；目标多1攻使惩罚跨过耐久门槛。Long Sink原生4攻可立即杀3血体、6血承受3仍余3；不能靠统一身材公式说明这个差异。八个根完整向量与穷举相同。','',
        '真实付Pancakes5治疗受损Carbed4/5，玩家15→16、本体4→5血，但有效攻5→2。若此前已有永久+2攻，有效7→4，永久增益保留。是同一身体/同一付费前缀的反事实：治疗增加HP，也会撤销受损加成，不是所有目的上的无条件支配。JSON保留价格、付款、完整前后身体与动作，不称该固定前缀为整手最优。']
    (OUT/'purpose-boundaries.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps([dict(card_id=r['card_id'],enemy_attack=r['enemy_attack'],body43=r['joint_body43']) for r in rows]))


if __name__=='__main__':main()