"""Real rebuilding of all active old reports after dynamic-ATK changes."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
import sys
import time

import recompute_prior_packet_reports as old
import verify_research_integration as verification

HERE=Path(__file__).resolve().parent
OUT=HERE/'research-runs/dynamic-body-v01'
GROUPS=[old.GROUPS[0]+['build_damage_packet_comparison.py','build_packet_pool.py','build_packet_incremental.py'],
    old.GROUPS[1]+['build_damage_packet_api.py','build_packet_pool_challenge.py','build_packet_timing.py'],
    ['build_packet_hand_structure.py','build_packet_timing_api.py','verify_packet_timing_search.py'],
    ['research-runs/damage-packet-v01/independent_hand_policy.py']]


def main():
    sources=verification.regression_sources();started=datetime.now(timezone.utc).isoformat();rows=[]
    def one(name):
        t=time.monotonic();p=subprocess.run([sys.executable,name],cwd=HERE,capture_output=True,text=True)
        return dict(command=name,exit_code=p.returncode,seconds=round(time.monotonic()-t,3),output=(p.stdout+p.stderr)[-7000:])
    for group in GROUPS:
        with ThreadPoolExecutor(max_workers=3) as e:
            futures=[e.submit(one,n) for n in group]
            for f in as_completed(futures):
                row=f.result();rows.append(row)
                print(json.dumps({k:row[k] for k in ('command','exit_code','seconds')}),flush=True)
                (OUT/'prior-artifact-refresh.json').write_text(json.dumps(dict(started=started,commands=rows,stage='running'),indent=2)+'\n')
        if any(r['exit_code'] for r in rows):break
    audit=verification.audit()
    result=dict(started=started,finished=datetime.now(timezone.utc).isoformat(),commands=rows,
        source_hashes=sources,source_unchanged=sources==verification.regression_sources(),audit=audit,
        passed=not any(r['exit_code'] for r in rows) and sources==verification.regression_sources() and not audit['errors'],
        interpretation='Actual recalculation; old43 reports frozen before edits. Not a hash-only refresh or new server verification.')
    (OUT/'prior-artifact-refresh.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(passed=result['passed'],errors=audit['errors'])),flush=True)
    if not result['passed']:sys.exit(1)


if __name__=='__main__':main()