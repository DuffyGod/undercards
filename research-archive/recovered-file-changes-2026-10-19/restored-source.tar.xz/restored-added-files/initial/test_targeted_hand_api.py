"""New held-state mechanics through the authoritative public paid entry."""
import copy
import unittest
import evaluate_situation as api
import paid_board_tactics as paid


class HeldPublicTests(unittest.TestCase):
    def scene(self):
        return dict(hand_ids=[33,43],gold_before_play=10,opponent_gold_before_response=0,
            own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
            ally_bodies_before_play=[],enemy_bodies=[dict(card_id=15,attack=6,health=5,max_health=5,slot=1)],
            own_deck_ids=[],opponent_deck_ids=[],opponent_hand_ids=[],max_plays='all_physical',
            horizon='enemy_attack',objectives=['guaranteed_hp'],physical_slots=True,front_slot_map=[0,1,2,3],
            targeted_hand_empty='fizzle',targeted_hand_choice='eligible_targets')

    def public(self,scene):
        obs={k:copy.deepcopy(scene[k]) for k in ('hand_ids','gold_before_play','opponent_gold_before_response',
            'own_player_hp','enemy_player_hp','ally_bodies_before_play','enemy_bodies')}
        params={k:copy.deepcopy(v) for k,v in scene.items() if k not in obs and k not in ('own_player_max_hp','enemy_player_max_hp')}
        params.pop('opponent_hand_known',None)
        return dict(obs,role='midrange',own_turn=9,paid_board_scenario=params,
            callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30))

    def test_native_held_haste_real_payment_and_complete_public_json(self):
        scene=self.scene();direct=paid.evaluate(scene);public=api.evaluate(self.public(scene))['paid_board_tactics']
        self.assertTrue(direct['complete_in_declared_scope'],direct['unknown']);self.assertEqual(public,direct)
        result=public['objectives'][0];self.assertEqual(result['metrics']['own_player_hp'],15)
        self.assertEqual(result['payment_accounting']['current_paid_gold'],10)
        self.assertTrue(any('targeted_hand_choice' in row for row in public['rule_hypotheses']))

    def test_missing_choice_hypothesis_preserves_unknown_and_clears_recommendations(self):
        scene=self.scene();scene.pop('targeted_hand_choice');value=api.evaluate(self.public(scene))['paid_board_tactics']
        self.assertFalse(value['complete_in_declared_scope']);self.assertFalse(value['recommendations'])
        self.assertTrue(any('choice interpretation' in message for message in value['unknown']))

    def test_naturally_drawn_new_helper_has_real_future_payment(self):
        scene=self.scene();scene.update(hand_ids=[196],gold_before_play=0,own_deck_ids=[406],enemy_bodies=[],
            horizon='next_own_attack',next_own_gold_income=4,next_natural_draw_count=1,next_max_plays='all_physical')
        direct=paid.evaluate(scene);public=api.evaluate(self.public(scene))['paid_board_tactics']
        self.assertTrue(public['complete_in_declared_scope'],public['unknown']);self.assertEqual(public,direct)
        # The legacy secondary ordering elects the newly drawn3/3 body. The
        # paid ledger proves the future4G is required, not a free generated unit.
        self.assertEqual(public['objectives'][0]['payment_accounting']['next_paid_gold'],4)


if __name__=='__main__':unittest.main()