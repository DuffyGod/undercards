"""Verify independent victory evidence through the common API and real CLI."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import build_immediate_lethal_comparison as comparison
import certify_immediate_lethal as certificate
import evaluate_situation
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/immediate-lethal-v01'


def fixture(hp=10):
    scene=comparison.base()
    scene['own_player_hp']=hp
    scene.update(ally_bodies_before_play=[],hand_costs=[5,4],condition_known_state={})
    root=('hand_ids','hand_costs','gold_before_play','own_player_hp','enemy_player_hp',
          'ally_bodies_before_play','enemy_bodies','opponent_gold_before_response')
    data={k:copy.deepcopy(scene[k]) for k in root}
    data.update(role='midrange',own_turn=5,condition_state={},response_weights={'enemy_face':1},
        callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30),
        paid_board_scenario={k:copy.deepcopy(v) for k,v in scene.items()
            if k not in root and k not in ('own_player_max_hp','enemy_player_max_hp','condition_known_state')})
    return data,scene


def main():
    cards=score_cards.load_cards();rows=[]
    OUT.mkdir(parents=True,exist_ok=True)
    for hp in (10,11):
        data,scene=fixture(hp)
        result=evaluate_situation.evaluate(data,cards=cards)
        direct=paid.evaluate(scene,cards)
        attempts=certificate.certify_available(scene,cards)
        assert result['paid_board_tactics']==direct
        assert result['immediate_victory_certificate_attempts']==attempts
        options=result['certified_immediate_victory_options']
        assert len(options)==(1 if hp==10 else 0)
        if hp==10:
            assert not direct['complete_in_declared_scope'] and not direct['recommendations']
            assert not result['authoritative_tactical_recommendation']['complete']
            assert options[0]['policy_own_player_hp']==10
        input_path=OUT/f'current-hp-{hp}.input.json'
        result_path=OUT/f'current-hp-{hp}.result.json'
        input_path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        process=subprocess.run([sys.executable,str(HERE/'evaluate_situation.py'),
            '--input',str(input_path),'--output',str(result_path)],cwd=HERE,capture_output=True,text=True)
        assert process.returncode==0,(process.stdout,process.stderr)
        assert json.loads(result_path.read_text())==json.loads(json.dumps(result))
        summary=json.loads(process.stdout)
        assert len(summary['certified_immediate_victory_options'])==len(options)
        rows.append(dict(own_hp=hp,api_matches_standalone=True,cli_matches_api=True,
            certified_options=len(options),full_search_complete=direct['complete_in_declared_scope'],
            cli_summary=summary,input_sha256=hashlib.sha256(input_path.read_bytes()).hexdigest(),
            result_sha256=hashlib.sha256(result_path.read_bytes()).hexdigest()))
    document=dict(api_version=evaluate_situation.VERSION,cases=rows,
        source_hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in
            ('build_immediate_lethal_api.py','build_immediate_lethal_comparison.py',
             'evaluate_situation.py','certify_immediate_lethal.py','paid_board_tactics.py','board_tactics.py')},
        interpretation='Independent currently playable victory evidence; full paid search and recommendation remain unchanged.')
    (OUT/'api-verification.json').write_text(json.dumps(document,ensure_ascii=False,indent=2)+'\n')
    print('API and CLI equal standalone; HP10 independent victory, HP11 refused; full-state failure retained')


if __name__=='__main__':main()