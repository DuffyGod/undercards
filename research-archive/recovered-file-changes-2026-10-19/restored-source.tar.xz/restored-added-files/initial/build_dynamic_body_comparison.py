"""Dynamic-state family comparisons, fixed prefixes and honest refusals."""
from dataclasses import replace
import hashlib
import json
from pathlib import Path

import board_tactics as b
import paid_board_tactics as p
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/dynamic-body-v01'


def scene(cid,attack,health,*,ready_body=False,spells=False):
    cards={c['id']:c for c in score_cards.load_cards()}
    c=cards[cid]
    enemy=dict(card_id=15,attack=attack,health=health,max_health=max(5,health),
        current_card_cost=5,base_cost=5)
    data=dict(hand_ids=[cid],hand_base_costs=[c['cost']],gold_before_play=c['cost'],
        own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
        enemy_bodies=[enemy],opponent_hand_known=True,opponent_hand_ids=[598,598] if spells else [],
        opponent_gold_before_response=2 if spells else 0,
        horizon='next_enemy_attack',next_opponent_gold_income=0,next_opponent_natural_draw_count=0,
        next_max_plays=1,next_own_gold_income=0,next_natural_draw_count=0,
        own_deck_ids=[],opponent_deck_ids=[],objectives=['guaranteed_hp','purpose'],
        purpose_constraints=dict(min_own_player_hp=1,min_own_body_attack=2,min_own_body_health=3))
    if ready_body:
        data.update(hand_ids=[],hand_base_costs=[],gold_before_play=0,
            ally_bodies_before_play=[dict(card_id=cid,attack=c['attack'],health=c['health'],
                max_health=c['health'],ready=True,current_card_cost=c['cost'],base_cost=c['cost'])],
            next_max_plays=0)
    return data


def compare(name,data,cards):
    a=p.evaluate(data,cards);x=p.evaluate(dict(data,search_algorithm='exhaustive'),cards)
    assert a['complete_in_declared_scope']==x['complete_in_declared_scope'],name
    complete=a['complete_in_declared_scope']
    if complete:
        assert [r['objective_vector'] for r in a['objectives']]==[r['objective_vector'] for r in x['objectives']],name
    return dict(case=name,input=data,result=a,full_vectors_equal=complete,
        player_hp=a['objectives'][0]['metrics']['own_player_hp'] if complete else None,
        body23_guaranteed=a['objectives'][1]['purpose_guaranteed'] if complete else None)


def main():
    cards=score_cards.load_cards();by={c['id']:c for c in cards};rows=[];fixed=[]
    for family,cids in [('5G',[534,15,14,509]),('4G',[632,13,18,307])]:
        for attack,health in ((1,2),(2,3),(3,3),(6,2)):
            for cid in cids:
                rows.append(compare(f'{family}-{cid}-enemy{attack}-{health}',scene(cid,attack,health),cards))
    for cid in (632,13,18,307):
        d=scene(cid,6,2,ready_body=True)
        e=p.PaidSearch(cards,d);s=e.root()
        action,child=next((a,c) for a,c in e.attacks(s) if a['target']=='enemy:0')
        fixed.append(dict(case=f'actual-ready-exchange-{cid}',input=d,action=action,
            own_hp=child.own[0].health,enemy_hp=child.enemy[0].health,
            enemy_player_hp=child.enemy_hp,attack_sampling='both before simultaneous direct exchange'))
        rows.append(compare(f'ready-{cid}-enemy6-2',d,cards))
    for cid in (534,632):
        rows.append(compare(f'paid-two-gems-{cid}',scene(cid,3,3,spells=True),cards))
    # Distinguish early health activation from late attack capacity.
    for attack in (1,2,3):
        d=scene(534,attack,3);e=p.PaidSearch(cards,d);s=next(e.deploys(e.root()))[1]
        action,child=next((a,c) for a,c in e.attacks(s) if a['target']=='enemy:0')
        fixed.append(dict(case=f'healthy-carbed-counter{attack}',input=d,action=action,
            own_hp=child.own[0].health,enemy_hp=child.enemy[0].health,
            persistent_attack=child.own[0].attack,effective_attack=b.effective_attack(child.own[0],child,'own')))
    # Unknown tests have concrete physical source/facts, not synthetic omissions.
    unknown=[]
    d=scene(632,13,1,ready_body=True);d['enemy_bodies']=[dict(card_id=110,attack=13,health=1,max_health=1)]
    unknown.append(compare('trashy-attacks-neo-dust-window',d,cards))
    d=scene(534,3,3,ready_body=True);d['ally_bodies_before_play'][0].update(attack=5,health=4)
    d['ally_bodies_before_play'][0].pop('max_health')
    unknown.append(compare('damaged-atk-missing-maximum',d,cards))
    assert all(not r['result']['complete_in_declared_scope'] for r in unknown)
    assert [(r['own_hp'],r['enemy_hp']) for r in fixed[:4]]==[(5,0),(0,0),(0,0),(0,0)]
    assert [(r['own_hp'],r['enemy_hp'],r['effective_attack']) for r in fixed[4:]]==[(5,1,2),(4,1,5),(3,1,5)]
    OUT.mkdir(parents=True,exist_ok=True)
    record=dict(version='dynamic-body-family-0.1.0',paid_version=p.VERSION,board_version=b.VERSION,
        cases=rows,fixed_prefixes=fixed,unknown_cases=unknown,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('build_dynamic_body_comparison.py','board_tactics.py','paid_board_tactics.py','alpha_beta_search.py')},
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        limits=['All whole-hand roots permit waiting and actual next own payment; known empty libraries and draw0, no invented income.',
            'Different purposes optimize separately. No concatenated maxima, calibrated Gold, carrying frequency or server validation.',
            'Ready exchanges are post-deployment conditional states. Woshua Magic is already resolved; this does not erase it from paid fresh deployment.',
            'Known observed Aaron stats vary by case. Current/base/printed source cost5 agree for Jerry predicates.',
            'Dynamic attack sampling uses before-exchange convention. ATKset/swap, floor crossing, Dust/immunity or Dodge/immunity remain unknown.'])
    (OUT/'comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    lines=['# 动态身体：不能把局部优势直接写成携带评级','',
        '当前paid0.21/board0.4。两个原生literal模板全文识别，永久ATK与受损/真实敌回合临时ATK分离。当前身体可等待，下一己真实付费；双方15/30与30/30HP，两敌回应，无新增收入或抽牌。场景闭合只限声明规则和信息。','',
        '| 场景 | 玩家HP最大保证 | 同体≥2攻/3血且玩家存活 |','|---|---:|---|']
    for r in rows:lines.append(f"| {r['case']} | {r['player_hp']} | {r['body23_guaranteed']} |")
    lines+=['','所有闭合根两个目的的完整向量与穷举一致。玩家HP列与身体列独立优化，不能拼接。实际来源、序列/付款/端点记录均在JSON。','',
        '已站场并有攻击权的Trashy主动打6/2保5HP；Woshua/Pyrope/Bloody Tree相同交换都死，Pyrope另打脸3。新出Trashy没有攻击权；对手先伤它、直接打脸或真实法术可规避有利交换。因此此局部优势须与完整部署表一起读，不能认作4G冠军。','',
        '健康Carbed首击只打2：敌3HP均剩1；反击1被Armor减至0，Carbed仍满5HP/2攻；反击2/3使它余4/3HP、有效攻5，永久攻始终2。不能在同一击追溯成5伤。恢复满血撤销临时+3，永久增攻不撤销；下一回合和目的按当时状态重新计算。','',
        '原生Trashy攻击NEO的Dust时窗、Carbed观察缺maxHP均保持unknown和空推荐。继承的同时交换、攻击前读取两攻击是模型解释，没有声称服务器记录。']
    (OUT/'comparison.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(cases=len(rows),closed=sum(r['result']['complete_in_declared_scope'] for r in rows),
        unknown=len(unknown),fixed=len(fixed)),ensure_ascii=False))


if __name__=='__main__':main()