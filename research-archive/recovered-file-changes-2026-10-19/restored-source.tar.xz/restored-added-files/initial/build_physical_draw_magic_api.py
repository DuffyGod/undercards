"""Reproduce physical draw decisions through the common API and CLI."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import build_physical_draw_magic_comparison as comparison
import evaluate_situation
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/physical-draw-magic-v01'


def current_input(scene,cards):
    by={c['id']:c for c in cards}
    scene=copy.deepcopy(scene)
    scene.update(ally_bodies_before_play=[],condition_known_state={},
        hand_costs=[by[cid]['cost'] for cid in scene['hand_ids']])
    root=('hand_ids','hand_costs','gold_before_play','own_player_hp','enemy_player_hp',
          'ally_bodies_before_play','enemy_bodies','opponent_gold_before_response')
    data={k:copy.deepcopy(scene[k]) for k in root}
    data.update(role='midrange',own_turn=8,condition_state={},response_weights={'enemy_face':1},
        callback_state=dict(own_player_max_hp=scene['own_player_max_hp'],enemy_player_max_hp=scene['enemy_player_max_hp']),
        paid_board_scenario={k:copy.deepcopy(v) for k,v in scene.items()
            if k not in root and k not in ('own_player_max_hp','enemy_player_max_hp','condition_known_state')})
    return data,scene


def main():
    cards=score_cards.load_cards();rows=[];OUT.mkdir(parents=True,exist_ok=True)
    for name,scene in [('optional',comparison.scene()),('both-cash-2',comparison.both_scene()),
                       ('both-cash-3',comparison.both_scene(opponent_gold_before_response=3))]:
        data,scene=current_input(scene,cards)
        result=evaluate_situation.evaluate(data,cards=cards)
        assert result['paid_board_tactics']==paid.evaluate(scene,cards)
        assert result['paid_board_tactics']['complete_in_declared_scope']
        input_path=OUT/(name+'.input.json');result_path=OUT/(name+'.result.json')
        input_path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        process=subprocess.run([sys.executable,str(HERE/'evaluate_situation.py'),
            '--input',str(input_path),'--output',str(result_path)],capture_output=True,text=True,cwd=HERE)
        assert process.returncode==0,(process.stdout,process.stderr)
        assert json.loads(result_path.read_text())==json.loads(json.dumps(result))
        summary=json.loads(process.stdout)
        rows.append(dict(case=name,api_matches_standalone=True,cli_matches_api=True,cli_summary=summary,
            input_sha256=hashlib.sha256(input_path.read_bytes()).hexdigest(),
            result_sha256=hashlib.sha256(result_path.read_bytes()).hexdigest()))
    document=dict(api_version=evaluate_situation.VERSION,paid_version=paid.VERSION,cases=rows,
        source_hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in
            ('build_physical_draw_magic_api.py','build_physical_draw_magic_comparison.py',
             'evaluate_situation.py','paid_board_tactics.py','board_tactics.py','certify_hand_hp.py')})
    (OUT/'api-verification.json').write_text(json.dumps(document,ensure_ascii=False,indent=2)+'\n')
    print('3 physical draw cases: API=standalone=CLI, distinct purpose choices retained')


if __name__=='__main__':main()