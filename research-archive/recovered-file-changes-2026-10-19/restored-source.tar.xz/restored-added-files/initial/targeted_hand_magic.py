"""Standalone exact targeted held-monster Magic with persistent physical buffs.

Complete-text templates only. No changes to the production compiler or scores.
Keyword buffs live in immutable search state, then move onto their exact paid
copy. Empty-target and two-option selection conventions must be explicit.
"""
import argparse
import copy
from dataclasses import dataclass,replace
import hashlib
import json
from pathlib import Path
import re

import board_tactics as board
import paid_board_tactics as paid
import conditional_card_score as score
from physical_slot_score import PhysicalGeometryMixin

VERSION='targeted-held-magic-0.1.0'


def _tribes(card,count):
    raw=card.get('effect_raw','')
    keys=re.findall(r'\{\{TRIBE:([A-Z][A-Z0-9_]*)\|1\}\}',raw) if isinstance(raw,str) else []
    mentions=card.get('tribe_mentions')
    return tuple(keys) if len(keys)==count and isinstance(mentions,list) and sorted(set(keys))==sorted(mentions) else (None,)*count


def parse(card):
    text=card.get('effect_readable','')
    if not isinstance(text,str):return None
    rest=text.strip();prefix=[]
    while (match:=board.PREFIX.match(rest)):
        prefix.append(rest[:match.end()]);rest=rest[match.end():]
    if (m:=re.fullmatch(r'Magic: Give a monster in your hand ATK \+(\d+)/HP \+(\d+)\.',rest)):
        options=(('monster',None,int(m[1]),int(m[2]),False,False),)
    elif (m:=re.fullmatch(r'Magic: Give a Haste monster in your hand \+(\d+) ATK\.',rest)):
        options=(('haste',None,int(m[1]),0,False,False),)
    elif (m:=re.fullmatch(r'Magic: Give a \w+ in your hand ATK \+(\d+)/HP \+(\d+) and Taunt\.',rest)):
        tribe,=_tribes(card,1);options=(('tribe',tribe,int(m[1]),int(m[2]),True,False),)
    elif (m:=re.fullmatch(r'Magic: Give a \w+ in your hand \+(\d+) ATK and Haste or an? \w+ in your hand \+(\d+) HP and Taunt\.',rest)):
        dog,amalgamate=_tribes(card,2)
        options=(('tribe',dog,int(m[1]),0,False,True),('tribe',amalgamate,0,int(m[2]),True,False))
    else:return None
    return ''.join(prefix).strip(),('targeted_hand',options)


@dataclass(frozen=True)
class HandKeywordState(paid.PaidState):
    own_hand_keywords:tuple=()
    enemy_hand_keywords:tuple=()


class TargetedHandMixin:
    def __init__(self,cards,data,**kwargs):
        self.hand_empty_policy=data.get('targeted_hand_empty','unknown')
        self.hand_choice_policy=data.get('targeted_hand_choice','unknown')
        if self.hand_empty_policy not in ('unknown','fizzle') or self.hand_choice_policy not in ('unknown','eligible_targets'):
            raise ValueError('Explicit targeted_hand_empty=unknown/fizzle; targeted_hand_choice=unknown/eligible_targets')
        super().__init__(cards,data,**kwargs)

    def root(self):
        original=super().root()
        return HandKeywordState(**original.__dict__)

    def spec(self,card,observed=False,collect_unknown=True,condition_known_state=None):
        template=parse(card)
        if template is None or card.get('_silenced_in_hand'):
            return super().spec(card,observed=observed,collect_unknown=collect_unknown,
                condition_known_state=condition_known_state)
        prefix,effect=template;changed=copy.deepcopy(card);changed['effect_readable']=prefix
        result=super().spec(changed,observed=observed,collect_unknown=False,
            condition_known_state=condition_known_state)
        result['magic']=None if observed else effect;result['evidence']=card.get('effect_readable','')
        if observed:result['resolved_magic_from_observation']=True
        if collect_unknown:self.unknown.extend('Card '+str(card['id'])+': '+x for x in result['unknown'])
        return result

    def _matches(self,state,index,option,caster):
        predicate,tribe,*_=option;menu=self.hand if caster=='own' else self.enemy_hand
        card,cached=menu[index]
        if card['card_type']!='monster':return False
        if predicate=='monster':return True
        if predicate=='tribe':
            if tribe is None:raise paid.UnknownMechanic('Targeted held tribe needs unambiguous raw TRIBE keys')
            tribes=card.get('tribes')
            if not isinstance(tribes,list) or any(not isinstance(t,str) for t in tribes):
                raise paid.UnknownMechanic('Targeted held tribe lacks canonical metadata')
            return tribe in tribes
        spec=self.hand_spec(card,cached,state) if caster=='own' else self.enemy_hand_spec(card,cached,state)
        if spec['unknown']:raise paid.UnknownMechanic('Haste target has unclosed full behavior')
        if spec['statuses']['speed']==2:
            raise paid.UnknownMechanic('Charge versus Haste target classification is outside this prototype')
        grants={j:(taunt,haste) for j,taunt,haste in getattr(state,caster+'_hand_keywords')}
        return spec['statuses']['speed']==1 or grants.get(index,(False,False))[1]

    def magic(self,state,index,unit,spec,caster='own'):
        field=caster+'_hand_keywords';held_field='hand' if caster=='own' else 'enemy_hand'
        grants={j:(taunt,haste) for j,taunt,haste in getattr(state,field)}
        taunt,haste=grants.pop(index,(False,False))
        if taunt or haste:
            unit=replace(unit,taunt=unit.taunt or taunt,ready=max(unit.ready,1) if haste else unit.ready)
            state=replace(state,**{caster:tuple(unit if v.key==unit.key else v for v in getattr(state,caster))})
        state=replace(state,**{field:tuple((j,t,h) for j,(t,h) in sorted(grants.items()))})
        effect=spec.get('magic')
        if not effect or effect[0]!='targeted_hand':
            return super().magic(state,index,unit,spec,caster=caster)
        if index in getattr(state,held_field):raise paid.UnknownMechanic('Caster must actually pay and leave hand before targeted Magic')
        if sum(v.key==unit.key and v==unit for v in getattr(state,caster))!=1:
            raise paid.UnknownMechanic('Targeted Magic requires the actual matching deployed body')
        action=dict(kind='deploy',hand_index=index,card_id=unit.card_id,magic=effect)
        if caster=='enemy':action['side']='enemy'
        if self.terminal(state):return [(dict(action,magic_skipped_terminal=True),state)]
        options=effect[1]
        if len(options)>1 and self.hand_choice_policy!='eligible_targets':
            raise paid.UnknownMechanic('Two-option held Magic requires explicit eligible-target choice interpretation')
        outcomes=[]
        for number,option in enumerate(options):
            predicate,tribe,attack,health,add_taunt,add_haste=option
            if predicate=='tribe' and tribe is None:
                raise paid.UnknownMechanic('Targeted held tribe needs unambiguous raw TRIBE keys')
            for target in getattr(state,held_field):
                if not self._matches(state,target,option,caster):continue
                buffs={j:(a,h) for j,a,h in getattr(state,caster+'_hand_buffs')}
                a,h=buffs.get(target,(0,0));buffs[target]=(a+attack,h+health)
                keywords={j:(t,h) for j,t,h in getattr(state,field)}
                t,h=keywords.get(target,(False,False))
                if t or h or add_taunt or add_haste:keywords[target]=(t or add_taunt,h or add_haste)
                child=replace(state,**{caster+'_hand_buffs':tuple((j,a,h) for j,(a,h) in sorted(buffs.items())),
                    field:tuple((j,t,h) for j,(t,h) in sorted(keywords.items()))})
                outcomes.append((dict(action,hand_target_index=target,hand_option=number,
                    remaining_physical_indexes=getattr(state,held_field)),child))
        if outcomes:return outcomes
        if self.hand_empty_policy!='fizzle':raise paid.UnknownMechanic('No eligible held target; empty-target ruling unknown')
        return [(dict(action,magic_fizzled=True,empty_target_policy='explicit_fizzle'),state)]


class TargetedHandSearch(TargetedHandMixin,score.TaskSearch):pass
class TargetedPhysicalHandSearch(PhysicalGeometryMixin,TargetedHandMixin,score.TaskSearch):pass


LOADED_SOURCES=score.source_bindings(Path(__file__))


def evaluate(data,task,*,cards=None,focal_index=None,delay_current=False):
    bindings=score.source_bindings(Path(__file__))
    if bindings!=LOADED_SOURCES:raise RuntimeError('Loaded targeted-hand source changed; restart process')
    cards=score.score_cards.load_cards() if cards is None else cards
    if not isinstance(cards,list) or any(not isinstance(c,dict) or type(c.get('id')) is not int for c in cards) or len({c['id'] for c in cards})!=len(cards):
        raise ValueError('Unique integer card-source IDs required')
    digest=hashlib.sha256(score.canonical(sorted(cards,key=lambda c:c['id'])).encode()).hexdigest()
    if set(task)-{'kind','body_scope','constraints'}:raise ValueError('Unknown task field')
    kind=task.get('kind','joint');scope=task.get('body_scope','board');constraints=copy.deepcopy(task.get('constraints',{}))
    if kind not in ('hp','joint') or scope not in ('board','focal','lineage'):raise ValueError('Invalid task kind or scope')
    if kind=='hp' and (scope!='board' or constraints):raise ValueError('HP has no body constraints')
    if scope!='board' and (focal_index is None or not paid.SINGLE_BODY_PURPOSE_FIELDS.intersection(constraints)):
        raise ValueError('Targeted-hand focal task requires physical index and same-body constraints')
    scene=copy.deepcopy(data);scene.pop('objectives',None);scene.pop('purpose_constraints',None)
    if type(scene.get('physical_slots',False)) is not bool:raise ValueError('physical_slots is boolean')
    if not scene.get('physical_slots') and {'front_slot_map','front_missing_policy','switch_left_slots'}.intersection(scene):
        raise ValueError('Geometry observations require physical_slots=true')
    if kind=='joint':scene['purpose_constraints']={'min_own_player_hp':1,**constraints}
    cls=TargetedPhysicalHandSearch if scene.get('physical_slots') else TargetedHandSearch
    engine=cls(cards,scene,body_scope=scope,focal_index=focal_index,delay_current=delay_current);root=engine.root()
    value=(engine.solve(root,'guaranteed_hp' if kind=='hp' else 'purpose') if not engine.unknown else
        dict(search_complete=False,unknown=engine.unknown,metrics=None,principal_variation=[]))
    known=value['search_complete'];feasible=(value['metrics']['own_player_hp']>0 if kind=='hp' else value['purpose_guaranteed']) if known else None
    result=dict(version=VERSION,known=known,feasible=feasible,
        guaranteed_player_hp=value['metrics']['own_player_hp'] if known and (kind=='hp' or feasible) else None,
        task=copy.deepcopy(task),body_scope=scope,search=value,unknown=value.get('unknown',[]),
        source_hashes=bindings,cards_canonical_sha256=digest,input=copy.deepcopy(data),
        assumptions=dict(empty_target=engine.hand_empty_policy,choice=engine.hand_choice_policy),
        production_core_changed=False,endpoint_metrics_are_not_componentwise_guarantees=True)
    if bindings!=score.source_bindings(Path(__file__)) or digest!=hashlib.sha256(score.canonical(sorted(cards,key=lambda c:c['id'])).encode()).hexdigest():
        raise RuntimeError('Source or cards changed during targeted-hand evaluation')
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('input',type=Path)
    parser.add_argument('--output',required=True,type=Path);parser.add_argument('--cards-source',type=Path)
    args=parser.parse_args();payload=json.loads(args.input.read_text());cards=None
    if args.cards_source:
        raw=json.loads(args.cards_source.read_text());cards=raw.get('cards') if isinstance(raw,dict) else raw
    result=evaluate(payload['scene'],payload['task'],cards=cards,focal_index=payload.get('focal_index'),delay_current=payload.get('delay_current',False))
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':main()