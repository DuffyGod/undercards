import copy
import unittest

import context_value as ledger
import heuristic_contexts as contexts
import score_cards as base
import unified_value as unified


class DrawQuoteIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards={c['id']:c for c in base.load_cards()}
        cls.reference,_=base.make_reference(list(cls.cards.values()))

    def test_optional_taunt_and_bilateral_cards_get_common_panel_quotes(self):
        for cid in (44,199):
            result=unified.score(self.cards[cid],self.reference,include_rows=False)
            self.assertEqual(result['support_status'],'supported_local_heuristic')
            self.assertEqual(result['context_count'],72)
            self.assertAlmostEqual(result['weight_sum'],1)
        # Follow-on exchanges and typed draws are not silently accepted.
        for cid in (154,809):
            self.assertTrue(ledger.parse(self.cards[cid])[1])

    def test_opponent_capacity_changes_only_its_bilateral_retained_options(self):
        ctx=contexts.bind_candidate(contexts.make_contexts()[1],self.cards[199]['cost'])
        ctx['hand_size_after_play']=6
        modules,unknown=ledger.parse(self.cards[199])
        self.assertFalse(unknown)
        results=[]
        for hand in (0,6,7):
            state=copy.deepcopy(ctx)
            state['draw_state_assumptions']=dict(ledger.DEFAULT_DRAW_STATE,opponent_hand_size=hand)
            quoted=ledger.evaluate_branch(self.cards[199],state,modules,self.reference)
            row=next(r for r in quoted['ledger'] if r['term']=='bilateral_draw_net_options')
            players=row['details']['branches'][0]['players']
            self.assertEqual(players[0]['kept'],1)
            self.assertEqual(players[1]['kept'],min(2,7-hand))
            results.append(row['model_gold'])
        prior=ledger.DEFAULT_DRAW_STATE['opponent_net_option_value']
        self.assertAlmostEqual(results[1]-results[0],prior)
        self.assertAlmostEqual(results[2]-results[1],prior)

    def test_missing_library_input_and_invalid_profile_do_not_become_full_scores(self):
        assumptions=dict(ledger.DEFAULT_DRAW_STATE,own_deck_available=None)
        result=unified.score(self.cards[44],self.reference,{'draw_state_assumptions':assumptions},include_rows=False)
        self.assertEqual(result['support_status'],'partial')
        self.assertIsNone(result['value_margin_model_gold'])
        for changes in ({'opponent_hand_size':8},{'own_fatigue_next':0},{'opponent_net_option_value':float('nan')}):
            with self.assertRaises(ValueError):
                unified.normalize_profile({'draw_state_assumptions':dict(ledger.DEFAULT_DRAW_STATE,**changes)})


if __name__=='__main__': unittest.main()