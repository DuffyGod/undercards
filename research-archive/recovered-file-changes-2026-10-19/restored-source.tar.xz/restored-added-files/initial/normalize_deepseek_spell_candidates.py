"""Normalize one lossless scalar/list shell difference; raw replies stay intact."""
import copy
import hashlib
import json
from pathlib import Path

import deepseek_spell_mechanisms_v03 as runner


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def normalize(folder):
    raw_path=folder/'raw-response.json';raw=json.loads(raw_path.read_text());doc=json.loads(raw['choices'][0]['message']['content'])
    changes=[]
    for row in doc['annotations']:
        if isinstance(row.get('zone_copy_accounting'),str):
            row['zone_copy_accounting']=[row['zone_copy_accounting']]
            changes.append(dict(card_id=row['card_id'],field='zone_copy_accounting',from_type='string',to_type='one-element string list'))
    converted=copy.deepcopy(raw);converted['choices'][0]['message']['content']=json.dumps(doc,ensure_ascii=False)
    intent=json.loads((folder/'intent.json').read_text());ids=intent['task']['ids']
    by={c['id']:c for c in json.loads((runner.OUT/'cards.json').read_text())['cards']}
    result=runner.validate(converted,ids,by)
    result.update(raw_response_sha256=sha(raw_path),lossless_shell_changes=changes,
        raw_reply_modified=False,normalizer_sha256=sha(Path(__file__)),mechanics_accepted=False,numeric_scores_accepted=False)
    (folder/'normalized-candidates.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    return dict(task_id=folder.name,structural_passed=result['structural_passed'],changes=len(changes),errors=result['errors'])


def main():
    summaries=[]
    for folder in sorted(runner.OUT.iterdir()):
        if folder.is_dir() and (folder/'raw-response.json').exists():summaries.append(normalize(folder))
    (runner.OUT/'normalization-index.json').write_text(json.dumps(dict(attempts=summaries,
        semantic_adoption=False,normalization_is_not_new_llm_output=True),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summaries,ensure_ascii=False))


if __name__=='__main__':main()