"""Requested-coordinate proofs retain guarantees and fail-closed boundaries."""
import copy
import unittest
from unittest.mock import patch

import conditional_card_score as old
import scalar_task_score as scalar
import score_cards


class ScalarTaskTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def scene(self,**changes):
        data=dict(hand_ids=[187],hand_costs=[3],hand_base_costs=[3],gold_before_play=3,
            own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
            opponent_hand_ids=[],opponent_hand_known=True,own_deck_ids=[],opponent_deck_ids=[],
            max_plays='all_physical',horizon='enemy_attack',
            enemy_bodies=[dict(card_id=270,attack=4,health=4,max_health=4,ready=True)])
        data.update(changes);return data

    def test_hp_and_joint_leading_values_equal_both_original_algorithms(self):
        for task in (dict(kind='hp'),old.RESERVED['win'],old.DEFAULT_TASKS['clear'],old.DEFAULT_TASKS['body_2_2']):
            with self.subTest(task=task):
                values=[]
                for algorithm in ('alpha_beta','exhaustive'):
                    data=self.scene(search_algorithm=algorithm)
                    result=scalar.evaluate(data,task,cards=self.cards,focal_index=0,vector_diagnostic=True)
                    self.assertTrue(result['known']);diagnostic=result['vector_diagnostic']
                    self.assertTrue(diagnostic['known'])
                    self.assertEqual(result['guaranteed_player_hp'],diagnostic['guaranteed_player_hp'])
                    values.append(result['search']['objective_vector'])
                self.assertEqual(tuple(values[0]),tuple(values[1]))

    def test_win_first_path_hp_does_not_replace_joint_hp(self):
        data=dict(hand_ids=[],max_plays=0,gold_before_play=0,own_player_hp=3,enemy_player_hp=1,
            ally_bodies_before_play=[dict(card_id=2,attack=1,health=1,ready=False)],
            enemy_bodies=[dict(card_id=2,attack=2,health=2)],horizon='next_own_attack')
        result=scalar.evaluate(data,dict(kind='joint',constraints=dict(min_own_player_hp=1)),cards=self.cards)
        self.assertTrue(result['known']);self.assertEqual(result['guaranteed_player_hp'],1)

    def test_background_cannot_satisfy_focal_and_no_fake_zero_for_infeasible(self):
        result=scalar.evaluate(self.scene(gold_before_play=0,
            ally_bodies_before_play=[dict(card_id=15,attack=6,health=5,max_health=5)]),
            old.DEFAULT_TASKS['body_2_2'],cards=self.cards,focal_index=0)
        self.assertTrue(result['known']);self.assertFalse(result['feasible'])
        self.assertIsNone(result['guaranteed_player_hp'])

    def test_death_is_a_known_physical_zero(self):
        result=scalar.evaluate(self.scene(hand_ids=[],hand_costs=[],hand_base_costs=[],own_player_hp=1),dict(kind='hp'),cards=self.cards)
        self.assertTrue(result['known']);self.assertFalse(result['feasible']);self.assertEqual(result['guaranteed_player_hp'],0)

    def test_budget_exhaustion_keeps_empty_score_and_path(self):
        result=scalar.evaluate(self.scene(node_limit=1),dict(kind='hp'),cards=self.cards)
        self.assertFalse(result['known']);self.assertIsNone(result['guaranteed_player_hp'])
        self.assertEqual(result['search']['principal_variation'],[])

    def test_spatial_held_effect_refuses_geometry_certificate(self):
        data=self.scene(hand_ids=[419],hand_costs=[9],hand_base_costs=[9],gold_before_play=9,
            physical_slots=True,front_slot_map=[0,1,2,3],front_missing_policy='fizzle',switch_left_slots=[0,1],
            enemy_bodies=[dict(card_id=270,attack=4,health=4,max_health=4,slot=1)])
        result=scalar.evaluate(data,dict(kind='hp'),cards=self.cards,geometry='certified_quotient')
        self.assertFalse(result['known']);self.assertEqual(result['status'],'geometry_certificate_rejected')

    def test_loaded_code_cannot_bind_to_changed_disk(self):
        with patch.object(scalar,'LOADED_SOURCES',{}):
            with self.assertRaises(RuntimeError):scalar.evaluate(self.scene(),dict(kind='hp'),cards=self.cards)

    def test_duplicate_and_boolean_ids_rejected(self):
        for cards in ([self.cards[0],self.cards[0]],[dict(self.cards[0],id=True)]):
            with self.assertRaises(ValueError):scalar.evaluate(self.scene(),dict(kind='hp'),cards=cards)

    def test_delaying_a_copy_keeps_actual_payment_and_focal_identity(self):
        data=self.scene(hand_ids=[187,187],hand_costs=[3,3],hand_base_costs=[3,3],horizon='next_own_attack',
            next_max_plays=1,next_own_gold_income=3,next_natural_draw_count=0)
        task=old.DEFAULT_TASKS['body_2_2']
        result=scalar.evaluate(data,task,cards=self.cards,focal_index=1,delay_current=True,vector_diagnostic=True)
        self.assertTrue(result['known']);self.assertEqual(result['feasible'],result['vector_diagnostic']['feasible'])
        for action in result['search']['principal_variation']:
            if action['kind']=='deploy' and action.get('hand_index')==1:
                self.assertEqual(action['paid_gold'],3)
                self.assertNotEqual(action['before_metrics']['phase'],0) if 'phase' in action['before_metrics'] else None

    def test_not_applicable_is_distinct_from_infeasible(self):
        result=scalar.evaluate(self.scene(),old.DEFAULT_TASKS['body_2_2'],cards=self.cards)
        self.assertTrue(result['known']);self.assertEqual(result['status'],'not_applicable')
        self.assertIsNone(result['feasible']);self.assertIsNone(result['guaranteed_player_hp'])

    def test_source_counterfactual_is_bound_separately(self):
        changed=copy.deepcopy(self.cards);next(c for c in changed if c['id']==187)['health']+=1
        a=scalar.evaluate(self.scene(),dict(kind='hp'),cards=self.cards)
        b=scalar.evaluate(self.scene(),dict(kind='hp'),cards=changed)
        self.assertNotEqual(a['cards_sha256'],b['cards_sha256'])
        self.assertFalse(b['tie_break_optimum_claimed']);self.assertFalse(b['original_full_vector_result_replaced'])


if __name__=='__main__':unittest.main()