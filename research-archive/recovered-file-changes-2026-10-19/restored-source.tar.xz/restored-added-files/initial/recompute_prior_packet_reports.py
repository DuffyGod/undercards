"""Actually rebuild prior active evidence after packet model changes.

Frozen pre-change sources/outputs remain under research-runs/damage-packet-v01.
No editing hashes to bless stale calculations. Independent folders may run
concurrently; derived/API outputs follow their dependencies.
"""
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
import sys
import time

import verify_research_integration as integration

HERE=Path(__file__).resolve().parent
OUT=HERE/'research-runs/damage-packet-v01'
GROUPS=[[
 'build_paid_standing_comparison.py','build_standing_objective_comparison.py',
 'build_body_hp_observation_comparison.py','build_hand_magic_comparison.py',
 'build_transparency_comparison.py','build_cost_damage_comparison.py',
 'build_hand_cost_death_comparison.py','build_first_enemy_draw_comparison.py',
 'build_control_dust_comparison.py','build_compound_magic_comparison.py',
 'build_hidden_reply_comparison.py','build_future_draw_comparison.py',
 'build_replacement_comparison.py','build_physical_play_scope_comparison.py',
 'build_hand_buff_comparison.py','build_full_heal_comparison.py',
 'build_conditional_magic_comparison.py','experiments/conditional-challenge-v01/independent_challenge.py',
 'build_death_discount_resistance_comparison.py','build_immediate_lethal_comparison.py',
 'build_physical_draw_magic_comparison.py','build_current_draw_comparison.py',
 'build_single_body_purpose_comparison.py','experiments/current-draw-challenge-v01/independent_probe.py',
 'prove_current_draw_hand_bounds.py'],[
 'build_hidden_choice_boundaries.py','build_single_body_pool_comparison.py',
 'build_hidden_reply_api.py','build_second_reply_api.py','build_future_draw_api.py',
 'build_immediate_lethal_api.py','build_physical_draw_magic_api.py','build_current_draw_api.py']]


def main():
    rows=[];started=datetime.now(timezone.utc).isoformat();source_start=integration.regression_sources()
    def one(name):
        t=time.monotonic();p=subprocess.run([sys.executable,name],cwd=HERE,capture_output=True,text=True)
        return dict(command=name,exit_code=p.returncode,seconds=round(time.monotonic()-t,3),output=(p.stdout+p.stderr)[-6000:])
    for group in GROUPS:
        with ThreadPoolExecutor(max_workers=3) as executor:
            pending=[executor.submit(one,n) for n in group]
            for f in as_completed(pending):
                row=f.result();rows.append(row)
                print(json.dumps({k:row[k] for k in ('command','exit_code','seconds')}),flush=True)
                (OUT/'prior-artifact-refresh.json').write_text(json.dumps(dict(started=started,commands=rows,
                    stage='in_progress',source_start=source_start),ensure_ascii=False,indent=2)+'\n')
        if any(r['exit_code'] for r in rows):break
    audit=integration.audit();source_now=integration.regression_sources()
    receipt=dict(started=started,finished=datetime.now(timezone.utc).isoformat(),commands=rows,
        source_start=source_start,source_unchanged=source_now==source_start,audit=audit,
        passed=not any(r['exit_code'] for r in rows) and audit['all_bound_sources_current'] and source_now==source_start,
        note='Actual recalculation; frozen old artifacts retained. No hash-only refresh. Source coverage audit distinct from regression.')
    (OUT/'prior-artifact-refresh.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(passed=receipt['passed'],errors=audit['errors']),ensure_ascii=False),flush=True)
    if not receipt['passed']:sys.exit(1)


if __name__=='__main__':main()