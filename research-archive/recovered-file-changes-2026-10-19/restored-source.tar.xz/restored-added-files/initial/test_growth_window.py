import copy
import unittest

import combat_increment as combat
import context_value as ledger
import growth_window as growth
import heuristic_contexts as contexts
import score_cards as base
import unified_value as unified


class GrowthCounterfactualTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards={c['id']:c for c in base.load_cards()}
        cls.reference,_=base.make_reference(list(cls.cards.values()))

    def quote(self, attack=2, health=2, da=1, dh=1, enemies=None, statuses=None,
              gold=3, weights=None, role='control'):
        return growth.evaluate(attack,health,da,dh,enemies or [],statuses or {},gold,
                               self.reference,role,weights or {'none':1})

    def test_same_final_body_equivalence_across_roles_stats_and_no_silence_events(self):
        for role in combat.RESPONSE_WEIGHTS:
            for attack,health,da,dh in ((2,2,5,5),(9,7,1,0),(0,5,2,1),(4,2,0,3)):
                for event in ('none','enemy_contact','enemy_face','chip'):
                    result=self.quote(attack,health,da,dh,[{'attack':3,'health':4}],gold=3,
                                      weights={event:1},role=role)
                    expected=ledger.body(attack+da,health+dh,self.reference,role)
                    self.assertTrue(result['pricing_supported'])
                    self.assertAlmostEqual(result['gross_model_gold'],expected)
                    self.assertAlmostEqual(result['modifier_window_adjust_model_gold'],0)

    def test_full_silence_returns_printed_quote_not_negative_growth(self):
        for role in combat.RESPONSE_WEIGHTS:
            for da,dh in ((1,0),(0,3),(5,5)):
                result=self.quote(da=da,dh=dh,weights={'silence':1},role=role)
                self.assertAlmostEqual(result['gross_model_gold'],ledger.body(2,2,self.reference,role))
                state=result['routes']['actual_growth']['best_known']['outcomes']['silence']['state']
                self.assertEqual(state['actor']['modifier'],{'attack':0,'health':0})

    def test_unpayable_silence_does_not_remove_growth_or_receive_cash(self):
        result=self.quote(da=3,dh=2,gold=2,weights={'silence':1})
        self.assertAlmostEqual(result['gross_model_gold'],ledger.body(5,4,self.reference,'control'))
        state=result['routes']['actual_growth']['best_known']['outcomes']['silence']['state']
        self.assertEqual(state['enemy_gold'],2)
        self.assertEqual(state['actor']['modifier'],{'attack':3,'health':2})

    def test_weighted_modifier_risk_is_between_printed_and_grown(self):
        result=self.quote(da=5,dh=5,weights={'none':.6,'silence':.4})
        expected=.6*ledger.body(7,7,self.reference,'control')+.4*ledger.body(2,2,self.reference,'control')
        self.assertAlmostEqual(result['gross_model_gold'],expected)

    def test_haste_injured_hp_ambiguity_marks_all_policy_price_partial(self):
        result=self.quote(dh=2,da=0,enemies=[{'attack':3,'health':2}],
                          statuses={'haste':True},weights={'silence':1})
        self.assertFalse(result['pricing_supported'])
        self.assertIsNone(result['gross_model_gold'])
        self.assertTrue(result['unknown_routes'])
        self.assertEqual(result['routes']['growth_keywords']['best_known']['plan'],'delay')

    def test_ambiguity_is_reachability_based_not_a_blanket_haste_rejection(self):
        for da,dh,gold,weights,enemies in (
            (1,0,3,{'silence':1},[{'attack':1,'health':2}]),
            (0,2,2,{'silence':1},[{'attack':1,'health':2}]),
            (0,2,3,{'none':1,'silence':0},[{'attack':1,'health':2}]),
            (0,2,3,{'silence':1},[{'attack':0,'health':2}]),
            (0,2,3,{'silence':1},[{'attack':5,'health':2}])):
            result=self.quote(da=da,dh=dh,gold=gold,weights=weights,enemies=enemies,
                              statuses={'haste':True})
            self.assertTrue(result['pricing_supported'])
            if enemies[0]['attack']==5:
                # No resurrection after dying in the current exchange.
                self.assertNotEqual(result['routes']['growth_keywords']['best_known']['plan'],0)

    def test_zero_growth_keyword_price_matches_existing_common_window(self):
        for role in combat.RESPONSE_WEIGHTS:
            statuses={'haste':True,'taunt':True,'dodge':1}
            enemies=[{'attack':3,'health':3}]
            result=self.quote(4,5,0,0,enemies,statuses,3,role=role,
                              weights=combat.RESPONSE_WEIGHTS[role])
            old=combat.premium(4,5,enemies,statuses,3,self.reference,role)
            self.assertAlmostEqual(result['keyword_window_adjust_model_gold'],old['premium_model_gold'])

    def test_binding_and_cache_do_not_depend_on_names_cost_or_later_hand(self):
        card=self.cards[49]
        ctx=contexts.bind_candidate(contexts.make_contexts()[1],6)
        modules,unknown=ledger.parse(card)
        self.assertFalse(unknown)
        first=ledger.evaluate_branch(card,ctx,modules,self.reference)
        renamed=dict(card,id=-1,name='synthetic',cost=3)
        second=ledger.evaluate_branch(renamed,ctx,modules,self.reference)
        self.assertAlmostEqual(first['gross_model_gold'],second['gross_model_gold'])
        details=next(r['details'] for r in first['ledger'] if r['term']=='paired_growth_keyword_increment')
        self.assertEqual(details['bound_modifier'],{'attack':5,'health':5})
        details['bound_modifier']['attack']=100
        again=ledger.evaluate_branch(card,ctx,modules,self.reference)
        self.assertAlmostEqual(first['gross_model_gold'],again['gross_model_gold'])

    def test_new_growth_keyword_card_has_72_common_states_and_null_on_unverified_ruling(self):
        result=unified.score(self.cards[174],self.reference,include_rows=False)
        self.assertEqual(result['context_count'],72)
        self.assertAlmostEqual(result['weight_sum'],1)
        self.assertEqual(result['support_status'],'supported_local_heuristic')
        for cid in (386,624,773,910):
            self.assertTrue(ledger.parse(self.cards[cid])[1])

    def test_terminal_and_invalid_inputs_do_not_get_resource_gold_prices(self):
        result=growth.evaluate(2,2,1,1,[{'attack':8,'health':8}],{},3,
                               self.reference,'aggro',{'enemy_face':1},own_player_hp=1)
        self.assertFalse(result['pricing_supported'])
        self.assertIsNone(result['gross_model_gold'])
        for da,dh in ((-1,0),(0,float('nan')),(True,0)):
            with self.assertRaises(ValueError): self.quote(da=da,dh=dh)


if __name__=='__main__': unittest.main()