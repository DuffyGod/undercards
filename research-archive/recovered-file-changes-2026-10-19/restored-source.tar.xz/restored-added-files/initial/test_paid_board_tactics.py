import copy
import unittest

import paid_board_tactics as paid
import score_cards


class PaidBoardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards = score_cards.load_cards()
        cls.by = {c['id']: c for c in cls.cards}

    def body(self, cid, **changes):
        c = self.by[cid]
        return dict(card_id=cid, attack=c['attack'], health=c['health'], **changes)

    def solve(self, scene, objective='survive', cards=None):
        result = paid.evaluate(dict(scene, objectives=[objective]), cards or self.cards)
        self.assertTrue(result['complete_in_declared_scope'], result['unknown'])
        return result['objectives'][0]

    def test_paid_damage_releases_taunt_then_face_budget_threshold(self):
        scene = dict(hand_ids=[1], gold_before_play=1, own_player_hp=3,
                     enemy_bodies=[self.body(15)], opponent_hand_ids=[96], horizon='enemy_attack')
        safe = self.solve(dict(scene, opponent_gold_before_response=2))
        dead = self.solve(dict(scene, opponent_gold_before_response=3))
        self.assertEqual(safe['metrics']['own_player_hp'], 3)
        self.assertTrue(dead['metrics']['own_player_dead'])
        cast = next(a for a in dead['principal_variation'] if a['kind'] == 'cast_spell')
        self.assertEqual(cast['paid_gold'], 3)
        self.assertEqual(cast['after_metrics']['enemy_remaining_gold'], 0)
        self.assertEqual(cast['after_metrics']['own_remaining_gold'], 0)

    def test_rock_dust_survives_damage_but_not_silence(self):
        scene = dict(hand_ids=[108], gold_before_play=self.by[108]['cost'], own_player_hp=2,
                     enemy_bodies=[self.body(15), self.body(2)], horizon='enemy_attack')
        damage = self.solve(dict(scene, opponent_hand_ids=[96], opponent_gold_before_response=3))
        silence = self.solve(dict(scene, opponent_hand_ids=[79], opponent_gold_before_response=1))
        self.assertEqual(damage['metrics']['own_player_hp'], 2)
        self.assertTrue(silence['metrics']['own_player_dead'])

    def test_enemy_spell_may_target_its_own_monster(self):
        scene = dict(own_player_hp=2, enemy_bodies=[self.body(1)],
                     ally_bodies_before_play=[self.body(15)], opponent_hand_ids=[79],
                     opponent_gold_before_response=1, max_plays=0, horizon='next_own_attack')
        result = self.solve(scene, 'race')
        self.assertEqual(result['metrics']['enemy_player_hp'], 24)
        engine = paid.PaidSearch(self.cards, scene)
        enemy = engine.boundary(engine.root())
        targets = {a['targets'][0][0] for a, _ in engine.casts(enemy, 'enemy')}
        self.assertEqual(targets, {'own', 'enemy'})

    def test_spell_and_attacks_can_interleave(self):
        scene = dict(own_player_hp=2, ally_bodies_before_play=[dict(attack=0, health=6, taunt=True, dodge=1, ready=False)],
                     enemy_bodies=[self.body(2), self.body(15)], opponent_hand_ids=[598],
                     opponent_gold_before_response=1, max_plays=0, horizon='enemy_attack')
        r = self.solve(scene)
        self.assertTrue(r['metrics']['own_player_dead'])
        self.assertTrue(any(a['kind'] == 'cast_spell' for a in r['principal_variation']))

    def test_headshot_silences_dust_before_killing(self):
        scene = dict(hand_ids=[108], gold_before_play=6, own_player_hp=2,
                     enemy_bodies=[self.body(15), self.body(2)], horizon='enemy_attack',
                     opponent_hand_ids=[100], opponent_gold_before_response=6)
        r = self.solve(scene)
        self.assertTrue(r['metrics']['own_player_dead'])
        self.assertEqual(r['metrics']['own_living_count'], 0)

    def test_two_physical_spell_copies_require_two_payments(self):
        scene = dict(own_player_hp=1, opponent_hand_ids=[598, 598], opponent_gold_before_response=1,
                     max_plays=0, horizon='enemy_attack')
        r = self.solve(scene)
        casts = [a for a in r['principal_variation'] if a['kind'] == 'cast_spell']
        self.assertEqual(len(casts), 1)
        self.assertEqual(r['metrics']['enemy_remaining_gold'], 0)

    def test_restore_punishment_battleflies_seven_vs_six_real_gold(self):
        scene = dict(hand_ids=[96, 438], own_player_hp=5, enemy_bodies=[dict(attack=6, health=6), dict(attack=3, health=3)],
                     condition_known_state={'last_turn_gold_spent_on_spells': 1}, horizon='enemy_attack')
        high = self.solve(dict(scene, gold_before_play=7))
        low = self.solve(dict(scene, gold_before_play=6))
        self.assertFalse(high['metrics']['own_player_dead'])
        self.assertTrue(low['metrics']['own_player_dead'])
        self.assertEqual(high['metrics']['own_remaining_gold'], 0)

    def test_restore_gemstone_battleflies_five_vs_four(self):
        scene = dict(hand_ids=[598, 438], own_player_hp=5, enemy_bodies=[dict(attack=6, health=6), dict(attack=3, health=3)],
                     condition_known_state={'last_turn_gold_spent_on_spells': 1}, horizon='enemy_attack')
        self.assertFalse(self.solve(dict(scene, gold_before_play=5))['metrics']['own_player_dead'])
        self.assertTrue(self.solve(dict(scene, gold_before_play=4))['metrics']['own_player_dead'])

    def test_need_false_body_play_and_unknown_history_retained(self):
        scene = dict(hand_ids=[438], gold_before_play=4, enemy_bodies=[dict(attack=1, health=4, ready=False)], horizon='enemy_attack')
        false = self.solve(dict(scene, condition_known_state={'last_turn_gold_spent_on_spells': 0}), 'control')
        self.assertEqual(false['metrics']['enemy_board_health'], 1)
        missing = paid.evaluate(scene, self.cards)
        self.assertFalse(missing['complete_in_declared_scope'])
        self.assertTrue(any('Need unknown' in x for x in missing['unknown']))

    def test_full_board_spell_legal_monster_blocked(self):
        scene = dict(hand_ids=[76, 15], gold_before_play=8, max_plays=1,
                     ally_bodies_before_play=[self.body(2) for _ in range(4)], horizon='enemy_attack')
        r = self.solve(scene, 'control')
        self.assertFalse(any(a['kind'] == 'deploy' for a in r['principal_variation']))
        self.assertTrue(any(a['kind'] == 'cast_spell' for a in r['principal_variation']))

    def test_modified_stat_silence_unknown_not_dropped(self):
        scene = dict(hand_ids=[8], gold_before_play=8, own_player_hp=6, enemy_bodies=[self.body(15)],
                     opponent_hand_ids=[79], opponent_gold_before_response=1, horizon='enemy_attack')
        r = paid.evaluate(scene, self.cards)
        self.assertFalse(r['complete_in_declared_scope'])
        self.assertTrue(any('Silence stat reset' in x for x in r['unknown']))

    def test_unaffordable_unknown_enemy_not_assumed_free(self):
        scene = dict(hand_ids=[1], gold_before_play=1, own_player_hp=3, enemy_bodies=[self.body(15)],
                     opponent_hand_ids=[15], opponent_gold_before_response=4, horizon='enemy_attack')
        self.assertEqual(self.solve(scene)['metrics']['own_player_hp'], 3)
        r = paid.evaluate(dict(scene, opponent_gold_before_response=5), self.cards)
        self.assertFalse(r['complete_in_declared_scope'])


if __name__ == '__main__': unittest.main()