"""New complete programs reach the authoritative public paid component."""
import copy
import unittest
import evaluate_situation as api
import paid_board_tactics as paid
import score_cards


class ControlPublicTests(unittest.TestCase):
    def scene(self):
        by={c['id']:c for c in score_cards.load_cards()}
        return dict(hand_ids=[15,77],hand_costs=[by[15]['cost'],0],gold_before_play=by[15]['cost'],max_plays=2,
            own_player_hp=1,enemy_player_hp=30,own_player_max_hp=30,enemy_player_max_hp=30,
            ally_bodies_before_play=[],enemy_bodies=[dict(card_id=2,attack=2,health=3,max_health=3)],
            opponent_hand_ids=[],opponent_hand_known=True,opponent_gold_before_response=0,
            horizon='enemy_attack',objectives=['guaranteed_hp'])

    def public(self,data):
        names=('hand_ids','hand_costs','gold_before_play','own_player_hp','enemy_player_hp',
            'ally_bodies_before_play','enemy_bodies','opponent_gold_before_response','opponent_hand_known')
        obs={k:copy.deepcopy(data[k]) for k in names}
        params={k:copy.deepcopy(v) for k,v in data.items() if k not in names and k not in ('own_player_max_hp','enemy_player_max_hp')}
        return dict(obs,role='midrange',own_turn=10,paid_board_scenario=params,
            callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30))

    def test_real_pay_and_zero_fee_spell_full_public_json_match(self):
        data=self.scene();direct=paid.evaluate(data);actual=api.evaluate(self.public(data))['paid_board_tactics']
        self.assertEqual(actual,direct);self.assertTrue(actual['complete_in_declared_scope'])
        self.assertEqual(actual['objectives'][0]['metrics']['own_player_hp'],1)
        casts=[a for a in actual['objectives'][0]['principal_variation'] if a['kind']=='cast_spell']
        self.assertEqual(len(casts),1);self.assertEqual(casts[0]['card_id'],77);self.assertEqual(casts[0]['paid_gold'],0)

    def test_prison_status_goal_is_not_a_legacy_body_recommendation(self):
        data=self.scene();data.update(hand_ids=[],hand_costs=[],gold_before_play=0,max_plays=0,
            own_player_hp=30,ally_bodies_before_play=[dict(card_id=15,attack=6,health=5,max_health=5,ready=False,attacked=False)],
            opponent_hand_ids=[182],opponent_hand_costs=[3],opponent_gold_before_response=3,
            horizon='next_own_attack',objectives=['purpose'],purpose_constraints=dict(min_own_player_hp=1,
                min_own_body_attack=6,min_own_body_health=3,max_own_body_paralyze_starts_remaining=0))
        direct=paid.evaluate(data);actual=api.evaluate(self.public(data))['paid_board_tactics']
        self.assertEqual(actual,direct);self.assertTrue(actual['complete_in_declared_scope'])
        self.assertFalse(actual['objectives'][0]['purpose_guaranteed'])


if __name__=='__main__':unittest.main()