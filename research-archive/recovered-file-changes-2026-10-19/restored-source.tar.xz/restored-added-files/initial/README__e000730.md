# 从观察缺口到真正联合的清场与站场用途

2026-10-15（北京时间）。paid0.24 / board0.6 / API0.26 / scorer0.4。[交互表](score-explorer.html)、[CSV](scores.csv)、[验证](verification.json)。3个输入、10个候选与条件组合。明确声明双方空库、下一次疲劳为1，不用缺失观察的默认值补出分数。

共同输入：己15/max30、敌30、单只观察4血敌体，敌持可付的两Gem/2G；候选初始一手、当前/印刷同价，现金5或8G。无自然抽牌、未来收入/部署；截止下一己方攻击结束。当前允许全部物理副本，只有这张候选实际可持有/支付。

## 两个用途分别可行，不等于能共同保证

| 5G候选 | 保命HP | 清场并留自身≥2攻2血 |
|---|---:|---|
| Manticore | 9 | 不能保证 |
| Bench | 9 | 不能保证 |
| Long Sink | 15 | 不能保证 |
| Carbed | 9 | 不能保证 |

这里Manticore/Bench的9HP来自**持有不出**。空库Magic抽牌只增加疲劳，不能帮助阻止本轮打脸；没有强迫坏出场，也没给抽牌卡固定负分。以前缺疲劳事实时它们unknown，明确观察后才闭合。

Long Sink可用Haste清掉4/4并保15，但只剩2血，敌两Gem可杀掉它；若现在不换，敌4伤加两Gem也能杀它，因此不能保证联合身体。Carbed的纯保命、清场、保自身2/2各列有分数，**清场与2/2同策略合取却不能保证**：先手2攻换一次后剩2HP，次轮能杀敌的攻击也让自己死；当前不换时，敌打脸保留4血，下一己的2攻又无法清场。新目标直接同时要求清场和物理焦点身体，没有拼接两列。

## 只改变敌攻击，Toriel的携带用途出现差异

| 8G候选 | 敌4攻：保命HP | 敌4攻：清场并保自身2/2的联合HP | 敌8攻：保命HP | 敌8攻：同一联合用途 |
|---|---:|---:|---:|---:|
| Gyftrot | 13 | 13 | 13 | 不能保证 |
| Toriel | 12 | 12 | 12 | 12 |
| Baron | 13 | 不能保证 | 13 | 不能保证 |

所有敌体仍4当前/maxHP、敌手和费用不变。Gyftrot可合法选抽0；8HP的Taunt在4伤+两Gem下至少保2HP，并能按敌是否进攻决定下一己是否换掉它；8攻则能杀掉整个身体。Toriel将敌攻降至1、身体血量成为原攻击+3，因此两条件都可清4血敌并保体。Baron5HP可被4+1杀掉，13保命不能代替身体用途。

这里的意义是携带用途的条件边界：当目标是应对高攻击且要留下可用身体时，Toriel打开Gyftrot没有的保证；普通4攻场景同一用途Gyftrot高1HP。没有因此猜测真实对手高攻出现率、卡组携带率或全局Gold。

10个实际联合目标向量与穷举一致；20个独立策略上下界匹配。来源/真实卡牌摘要与当前530项覆盖见[verification.json](verification.json)，具体为505实际重跑、25源相同复用。视图30次切换检查通过。源规则解释、完整隐藏信息、窗口外影响与真实频率仍未验证。

```sh
python analysis/monster-value-heuristic/build_frontier_observation_probes.py
python analysis/monster-value-heuristic/build_conditional_score_view.py --directory analysis/monster-value-heuristic/experiments/frontier-observations-v01 --default-case fatigue1-8g-enemy8
```