"""Reproduce usable current-hand evaluations with explicit observed inputs."""
import copy
import csv
import hashlib
import json
from pathlib import Path

import evaluate_situation as situation
import score_cards as base

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/current-situation-v01'


def build():
    cards=base.load_cards();reference,_=base.make_reference(cards)
    template=dict(hand_ids=[115,438,582],role='midrange',own_turn=5,gold_before_play=12,
        opponent_gold_before_response=0,own_player_hp=30,enemy_player_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[],condition_state={'last_turn_gold_spent_on_spells':0},
        response_weights={'enemy_face':1})
    two=[dict(attack=6,health=6),dict(attack=3,health=3)]
    known_dust=dict(horizon=7,origin_turn=5,discount_rate=.1,
        branches=[dict(event='ordinary_death',probability=.5,event_turn=5,
                       hand_at_event=[dict(cost=3,use_turn=6),dict(cost=5,use_turn=7)],
                       payment_windows=[dict(turn=6,income=6,max_plays=1),dict(turn=7,income=7,max_plays=1)],initial_gold=0),
                  dict(event='none',probability=.5)])
    scenarios={
        'empty_board':{},
        'first_4G':dict(own_turn=2,gold_before_play=4,enemy_bodies=[dict(attack=2,health=2)]),
        'first_4G_second_player':dict(own_turn=2,gold_before_play=5,enemy_bodies=[dict(attack=2,health=2)],profile={'second_player':True}),
        'two_ready_high_hp':dict(enemy_bodies=two),
        'two_ready_emergency':dict(enemy_bodies=two,own_player_hp=8),
        'two_ready_emergency_need_true':dict(enemy_bodies=two,own_player_hp=8,condition_state={'last_turn_gold_spent_on_spells':1}),
        'emergency_cash_short':dict(enemy_bodies=two,own_player_hp=8,gold_before_play=3),
        'certain_win':dict(hand_ids=[15,115],enemy_player_hp=1,enemy_bodies=[dict(attack=1,health=6)],response_weights={'none':1}),
        'unclosed_haste_lifecycle':dict(hand_ids=[126,805,971],enemy_bodies=two),
        'dust_future_missing':dict(hand_ids=[43,138]),
        'dust_future_supplied':dict(hand_ids=[43,138],dust_timing=known_dust),
    }
    results={};summary=[]
    OUT.mkdir(parents=True,exist_ok=True)
    for name,changes in scenarios.items():
        data=copy.deepcopy(template);data.update(copy.deepcopy(changes));data['context_id']=name
        result=situation.evaluate(data,reference,cards);results[name]=result
        (OUT/(name+'.input.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        for quote,window in zip(result['card_quotes'],result['action_windows']):
            summary.append(dict(scenario=name,card_id=quote['card_id'],name=quote['name'],
                current_net_quote=quote['net_model_gold'],payable_now=quote['payable_now'],
                action_window_known=window['window_known'],recommended_action=window['recommended_action'],
                own_player_death=window['death_probability'],enemy_player_defeat=window['defeat_probability'],
                candidate_death=window['candidate_death_probability'],
                unknown='; '.join(quote['unsupported']+window['window_unknown'])))
    with (OUT/'comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
    output=dict(version=situation.VERSION,summary=summary,scenarios=results,
                snapshot_sha256=hashlib.sha256(base.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in HERE.glob('*.py')})
    (OUT/'comparison.json').write_text(json.dumps(output,ensure_ascii=False,separators=(',',':'))+'\n')
    lines=['# 当前场景评价入口','',
        '目标是使同一手牌与场面输入同时产生整卡资源报价、可支付行动覆盖、当前Haste选择和玩家/卡牌死亡结果。已交付evaluate_situation.py；当前支持已知monster手牌，spell和多卡顺序尚未接入。','',
        '本次11组实际输入、31行卡牌结果全部保留于comparison.json/CSV；每组输入有独立.input.json，可直接修改数值再运行入口。敌方就绪与回应权重是caller情景，未来自实测。','',
        '| 场景 | 卡牌 | 当前net报价 | 可付费 | 动作闭合 | 当前推荐 | 己方死亡 | 敌方败北 | 卡死亡 |',
        '|---|---|---:|---|---|---|---:|---:|---:|']
    def fmt(value):return '未知' if value is None else f'{value:.3f}'
    for r in summary:
        lines.append(f'| {r["scenario"]} | {r["name"]} | {fmt(r["current_net_quote"])} | '
                     f'{r["payable_now"]} | {r["action_window_known"]} | {r["recommended_action"] or "—"} | '
                     f'{fmt(r["own_player_death"])} | {fmt(r["enemy_player_defeat"])} | {fmt(r["candidate_death"])} |')
    lines+=['','## 从结果保留的差异','',
        '- 缺金币时仍显示条件行动路径，但不给可执行推荐。4G首次支付为己方turn2，可输入先后手不同的已知余额；before-turn3事件风险仅外推最早设计先验，未声称校准。',
        '- 资源Gold不用于定价死亡/胜利：闭合窗口出现终局时整卡Gold headline留空，资源小计仅诊断。普通身体也遵守当前入口的终局边界；确定可打脸获胜的后续动作优先于保留资源。',
        '- “己方玩家死”“敌玩家败北”“这张卡死”单开字段。survival-first是公开调用方目标，在隐藏回应前选择当前动作；未来普通攻击随后观察回应，并优先立即获胜。',
        '- Need false不会禁止出场，仍保留独立Haste；Need unknown不会偷补true。未闭合后续机制的完整动作窗口留空，禁止把隔离Haste结果冒充完整卡牌。',
        '- 只输入当前手牌时，Lesser Dog未来减费缺支付证据为unknown；显式提供branch-local未来付款后才报价。Ferry的现金不依赖未来用牌，但当前动作层尚未闭合其Dust生命周期。',
        '- 卡牌互补通过同一状态行动并集表达。不同阈值、现金和未实现机制仍会改变覆盖结果；当前净资源低不自动等于必须丢弃。','',
        '## 可运行示例','',
        '```sh',
        'python analysis/monster-value-heuristic/evaluate_situation.py --input analysis/monster-value-heuristic/experiments/current-situation-v01/two_ready_emergency.input.json --output /tmp/current-hand.json',
        'python analysis/monster-value-heuristic/build_situation_comparison.py',
        '```','',
        '## 尚未完成的重点','',
        '下一推进目标是使已知伤害Magic与Haste的同一目标/行动选择接入动作终局维度，然后比较单牌/组合、现在打/等待一回合的明确场面轨迹。当前对手固定强攻优先；真实防御、进攻顺序、未知未来场面转移和根身体F的普通风险仍缺校准。成熟卡组不是当前前置条件，之后用于校准机会频率、手牌质量和出牌机会成本。','']
    (OUT/'comparison.md').write_text('\n'.join(lines))
    print(json.dumps(dict(scenarios=len(results),rows=len(summary),closed_windows=sum(r['action_window_known'] for r in summary))))
    return output


if __name__=='__main__':
    build()