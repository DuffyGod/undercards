"""Already-Silenced observations differ from applying a new Silence event."""
import unittest
import paid_board_tactics as paid
import score_cards


class SilencedObservationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def engine(self,row):
        return paid.PaidSearch(self.cards,dict(hand_ids=[],gold_before_play=0,max_plays=0,
            own_player_hp=1,enemy_player_hp=4,opponent_hand_ids=[],opponent_hand_known=True,
            enemy_bodies=[row],horizon='enemy_attack'))

    def test_known_identity_retains_printed_cost_without_inventing_current_or_base(self):
        e=self.engine(dict(card_id=270,attack=4,health=4,max_health=4,silenced=True));u=e.root().enemy[0]
        self.assertEqual((u.card_id,u.printed_cost),(270,3));self.assertIsNone(u.current_card_cost);self.assertIsNone(u.base_cost)
        e=self.engine(dict(attack=4,health=4,max_health=4,silenced=True,current_card_cost=3,base_cost=3));u=e.root().enemy[0]
        self.assertEqual(u.card_id,-1);self.assertIsNone(u.printed_cost)

    def test_explicit_regranted_statuses_survive_observation_but_a_new_silence_removes_them(self):
        e=self.engine(dict(card_id=270,attack=4,health=4,max_health=4,silenced=True,
            taunt=True,armor=True,dodge=2,transparency=True));u=e.root().enemy[0]
        self.assertEqual((u.taunt,u.armor,u.dodge,u.transparency),(True,True,2,True))
        reset=e.silence(u);self.assertEqual((reset.taunt,reset.armor,reset.dodge,reset.transparency),(False,False,0,False))
        self.assertEqual(reset.printed_cost,3)

    def test_omitted_status_does_not_restore_printed_taunt(self):
        e=self.engine(dict(card_id=1,attack=0,health=4,max_health=4,silenced=True));u=e.root().enemy[0]
        self.assertFalse(u.taunt);self.assertEqual(u.printed_cost,1)

    def test_enemy_regranted_taunt_prevents_false_guaranteed_face_lethal(self):
        e=self.engine(dict(card_id=270,attack=4,health=5,max_health=5,silenced=True,taunt=True))
        d=dict(e.data,ally_bodies_before_play=[dict(card_id=15,attack=4,health=4,max_health=4,ready=True)],
            purpose_constraints=dict(min_own_player_hp=1,max_enemy_player_hp=0))
        other=paid.PaidSearch(self.cards,d);r=other.solve(other.root(),'purpose')
        self.assertTrue(r['search_complete']);self.assertFalse(r['purpose_guaranteed'])
        self.assertFalse(any(a.get('kind')=='attack' and a.get('target')=='face' and a.get('side')=='own'
            for a,s in other.attacks(other.root())))


if __name__=='__main__':unittest.main()