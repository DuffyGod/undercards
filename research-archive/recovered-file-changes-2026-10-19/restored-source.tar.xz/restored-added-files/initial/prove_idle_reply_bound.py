"""Cheap negative clear-goal certificate, never a scalar card valuation.

Enumerate every current own action, then fix one legal opponent strategy:
stop attacking and casting. In the next own attack phase, each eligible unit
can deal at most its ATK once. With no live extra damage/death/end callbacks,
insufficient total damage proves a remaining enemy. This one counterstrategy
can disprove a universal clear guarantee without searching every reply.
"""
import hashlib
from pathlib import Path
import board_tactics as board
import paid_board_tactics as paid
import score_cards


def prove(data,cards=None):
    cards=score_cards.load_cards() if cards is None else cards
    engine=paid.PaidSearch(cards,data);root=engine.root()
    if engine.horizon!='next_own_attack':raise ValueError('Next own attack horizon required')
    if engine.unknown or any(spec['unknown'] for _,spec in engine.hand+engine.enemy_hand):
        return dict(bound_complete=False,unknown=['Source mechanics for this counterstrategy remain unclosed'])
    seen=set();leaves=[];unknown=[]
    def visit(state):
        if state in seen:return
        seen.add(state)
        if len(seen)>engine.node_limit:raise paid.UnknownMechanic('Current-action certificate state budget exhausted')
        if engine.terminal(state):
            if state.own_hp<=0:return
            raise paid.UnknownMechanic('Current action already ends game; attack-budget certificate does not apply')
        reply=engine.boundary(state)
        endpoint=engine.boundary(reply)  # One legal response: no cast, no attack.
        if endpoint.phase!=2 or engine.terminal(endpoint):
            raise paid.UnknownMechanic('Counterstrategy does not reach a live next own attack phase')
        living=[u for u in endpoint.own if u.health>0]
        if any(u.dust or u.end or u.before_attack_face for u in living):
            raise paid.UnknownMechanic('Live future callback can invalidate the simple attack-damage bound')
        attack=sum(u.attack for u in living if u.ready and not u.attacked and not u.paralyze_owner_starts_remaining)
        health=sum(u.health for u in endpoint.enemy if u.health>0)
        if attack>=health:
            raise paid.UnknownMechanic('Attack budget cannot exclude a successful clear; this bound is insufficient')
        leaves.append(dict(eligible_attack_upper=attack,enemy_health_required=health))
        for _,child in list(engine.attacks(state))+list(engine.deploys(state)):visit(child)
    try:visit(root)
    except paid.UnknownMechanic as error:unknown.append(str(error))
    complete=not unknown and bool(leaves)
    here=Path(__file__).resolve().parent
    return dict(bound_complete=complete,unknown=unknown,
        any_policy_can_guarantee_clear=False if complete else None,
        counterstrategy='Enemy ends its turn without optional attacks or casts, for every current own route.',
        current_own_states=len(seen),checked_endpoints=len(leaves),
        max_eligible_attack_upper=max((x['eligible_attack_upper'] for x in leaves),default=None),
        min_enemy_health_required=min((x['enemy_health_required'] for x in leaves),default=None),
        endpoint_bounds=leaves,input=data,
        source_hashes={f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in
            ('prove_idle_reply_bound.py','paid_board_tactics.py','queued_delay.py','board_tactics.py')},
        limitations=['Negative sufficient bound for the declared no-future-Play attack window only.',
            'Insufficient bound or unknown mechanics yield unknown, never false guarantee or zero card value.',
            'No empirical response likelihood is assigned; one legal counterstrategy disproves a universal clear goal.'])