"""Real public API/CLI and current scalar proof for paid0.25 integration."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import conditional_card_score as score
import evaluate_situation as api
import paid_board_tactics as paid
import scalar_task_score as scalar

HERE=Path(__file__).resolve().parent
OUT=HERE/'research-runs/targeted-hand-production-v01'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,data):(OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

def public_input(scene):
    obs={k:copy.deepcopy(scene.get(k,[] if 'bodies' in k else 0)) for k in ('hand_ids','gold_before_play',
        'opponent_gold_before_response','own_player_hp','enemy_player_hp','ally_bodies_before_play','enemy_bodies')}
    params={k:copy.deepcopy(v) for k,v in scene.items() if k not in obs and k not in ('own_player_max_hp','enemy_player_max_hp','hand_costs')}
    params.pop('opponent_hand_known',None)
    return dict(obs,role='midrange',own_turn=9,paid_board_scenario=params,
        callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30))

def main():
    bindings=score.source_bindings(Path(__file__));rows=[]
    for label,objective in [('endo-dog','guaranteed_hp'),('sugar-dog','purpose')]:
        raw=json.loads((OUT/(label+'.json')).read_text());scene=raw['input']
        scene['objectives']=[objective]
        if objective=='purpose':scene['purpose_constraints']={'min_own_player_hp':1,**raw['tasks']['buddy']['constraints']}
        public=public_input(scene);write(label+'.api.input.json',public)
        direct=paid.evaluate(scene);value=api.evaluate(public)
        assert direct['complete_in_declared_scope'] and value['paid_board_tactics']==direct
        cmd=[sys.executable,str(HERE/'evaluate_situation.py'),'--input',str(OUT/(label+'.api.input.json')),
            '--output',str(OUT/(label+'.api.cli.json'))]
        run=subprocess.run(cmd,capture_output=True,text=True,cwd=HERE)
        (OUT/(label+'.api.stdout.log')).write_text(run.stdout);(OUT/(label+'.api.stderr.log')).write_text(run.stderr)
        assert run.returncode==0
        cli=json.loads((OUT/(label+'.api.cli.json')).read_text())
        assert cli==json.loads(score.canonical(value))
        vector=direct['objectives'][0]['objective_vector'];expected=raw['results']['hp' if objective=='guaranteed_hp' else 'buddy']['search']['objective_vector']
        if objective=='guaranteed_hp':assert tuple(vector)==tuple(expected)
        else:assert direct['objectives'][0]['purpose_guaranteed'] and direct['objectives'][0]['metrics']['own_player_hp']==9
        rows.append(dict(label=label,objective=objective,api_direct_cli_complete_json_equal=True,
            guaranteed_hp=direct['objectives'][0]['metrics']['own_player_hp'],command=cmd,
            public_input_sha256=sha(OUT/(label+'.api.input.json')),cli_output_sha256=sha(OUT/(label+'.api.cli.json'))))
    # The previously independent sandwich is tied to exactly this resource
    # input and unchanged cards. Re-execute its scalar claim with current core.
    old=HERE/'research-runs/scalar-objective-v01';payload=json.loads((old/'public-card30.input.json').read_text())
    current=scalar.evaluate(payload['scene'],payload['task'],focal_index=0,geometry='certified_quotient')
    assert current['known'] and current['guaranteed_player_hp']==4
    write('current-resource-burger-scalar.json',current)
    proof=json.loads((old/'independent-bounds.json').read_text())
    assert proof['policy_lower_bound']==proof['adversary_upper_bound']==4
    assert sha(score.score_cards.DEFAULT_SNAPSHOT)==proof['source_snapshot_sha256']
    original=json.loads((HERE/'research-runs/targeted-hand-v01/index.json').read_text())
    new=json.loads((OUT/'index.json').read_text())
    def numeric(row):return {k:row[k] for k in ('label','task','known','feasible','hp')}
    assert [numeric(r) for r in original['rows']]==[numeric(r) for r in new['rows']]
    assert bindings==score.source_bindings(Path(__file__))
    write('api-verification.json',dict(passed=True,source_hashes=bindings,source_stable=True,
        public_cases=rows,actual_paid_objective_searches=6,actual_current_scalar_searches=1,
        prototype_numeric_comparisons_unchanged=len(new['rows']),
        scalar_resource_hp=4,independent_scalar_proof_sha256=sha(old/'independent-bounds.json'),
        original_full_physical_unknown_preserved=True,
        model_versions=dict(paid=paid.VERSION,api=api.VERSION,scorer=score.VERSION),
        provenance_fix='Hidden reply source binding now recursively includes literal, choice and held extension modules.'))
    print(json.dumps(dict(passed=True,public_cases=2,prototype_matches=len(new['rows']),current_scalar_hp=4)))

if __name__=='__main__':main()