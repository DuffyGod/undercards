"""Cross-card task comparisons for periodic healing, geometry and actual clog."""
from concurrent.futures import ProcessPoolExecutor,as_completed
import copy
import csv
import hashlib
import json
from pathlib import Path
import time

import conditional_card_score as score
import build_conditional_scores as base
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/periodic-spatial-v01'


def tasks():
    return {'body2_2':dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=2,min_own_body_health=2)),
        'body3_2':dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=3,min_own_body_health=2)),
        'body3_3':dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=3,min_own_body_health=3)),
        'clear':dict(kind='joint',constraints=dict(max_enemy_living_count=0))}


def configurations():
    cards=score_cards.load_cards();by={c['id']:c for c in cards};items=[]
    for gems in (0,1,2):
        for hp in (3,30):
            d=base.scene3(hp);d.update(opponent_hand_ids=[598]*gems,opponent_gold_before_response=gems)
            items.append((f'healing-gems{gems}-enemyhp{hp}',dict(scene=d,candidate_ids=[107,187,22,390,56,377,9,53],
                tasks=tasks(),reference_card_id=187,include_delay=True)))
    for mode,amount in [('late',True),('no-hero',False),('range-unknown','unknown')]:
        d=base.scene3(30)
        if mode=='late':d.update(next_max_plays=1,next_own_gold_income=0)
        else:d['allies_include_player']=amount
        items.append(('healing-'+mode,dict(scene=d,candidate_ids=[107,187,22],tasks=tasks(),include_delay=True)))
    for maximum in (29,30):
        d=base.scene3(30);d['own_player_hp']=maximum
        items.append((f'healing-initialhp{maximum}',dict(scene=d,candidate_ids=[107,187,22],tasks={},include_delay=False)))
    d=dict(gold_before_play=3,own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
        opponent_hand_ids=[],opponent_hand_known=True,max_plays=1,horizon='enemy_attack',physical_slots=True,
        front_slot_map=[0,1,2,3],front_missing_policy='fizzle',
        enemy_bodies=[dict(card_id=270,attack=4,health=4,max_health=4,slot=0),
            dict(card_id=270,attack=4,health=4,max_health=4,slot=1)])
    for cid,attack,health in [(1,0,4),(196,1,1)]:
        scene=dict(d,ally_bodies_before_play=[dict(card_id=cid,attack=attack,health=health,max_health=health,ready=False,slot=1)])
        items.append((f'spatial-background-{cid}',dict(scene=scene,candidate_ids=[114,122,147,5,144,390,187,107],
            reference_card_id=187,tasks=tasks(),include_delay=True)))
    # Same background, only the physical slot changes. Janitor cannot grant HP
    # to a body on the far right because no slot exists to its right.
    scene=copy.deepcopy(d);scene['ally_bodies_before_play']=[dict(card_id=1,attack=0,health=4,max_health=4,ready=False,slot=3)]
    items.append(('spatial-dummy-rightmost',dict(scene=scene,candidate_ids=[114,122,147],tasks=tasks(),include_delay=False)))
    scene=copy.deepcopy(d);scene['enemy_bodies'][0]['health']=3
    scene['enemy_bodies'][0]['max_health']=4
    scene['enemy_bodies']=scene['enemy_bodies'][:1]
    items.append(('spatial-front-health3',dict(scene=scene,candidate_ids=[114,122,147],tasks=tasks(),include_delay=False)))
    # Existing ready Charge can win only after enemy Taunt is legally removed.
    scene=dict(gold_before_play=3,own_player_hp=15,own_player_max_hp=30,enemy_player_hp=3,enemy_player_max_hp=30,
        opponent_hand_ids=[],opponent_hand_known=True,max_plays=1,horizon='enemy_attack',
        ally_bodies_before_play=[dict(card_id=9,attack=3,health=1,max_health=1,ready=True)],
        enemy_bodies=[dict(card_id=14,attack=4,health=7,max_health=7,current_card_cost=5,base_cost=5)])
    items.append(('silence-opens-victory',dict(scene=scene,candidate_ids=[144,390,187,22],tasks=tasks(),include_delay=True)))
    scene=dict(scene,enemy_player_hp=30,ally_bodies_before_play=[],
        enemy_bodies=[dict(card_id=632,attack=2,health=5,max_health=5,current_card_cost=4,base_cost=4)])
    items.append(('silence-dynamic-enemy',dict(scene=scene,candidate_ids=[144,390,187,22],
        tasks={'suppress2':dict(kind='joint',constraints=dict(max_enemy_board_attack=2))},include_delay=True)))
    background=[14,15,49,509,534,21]
    scene=dict(gold_before_play=0,own_player_hp=10,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
        enemy_bodies=[dict(card_id=270,attack=4,health=4,max_health=4)],opponent_hand_ids=[],opponent_hand_known=True,
        own_deck_ids=[22],opponent_deck_ids=[],max_plays='all_physical',next_max_plays='all_physical',
        next_natural_draw_count=1,next_own_gold_income=3,own_fatigue_next=1,
        next_opponent_gold_income=0,next_opponent_natural_draw_count=0,horizon='next_enemy_attack')
    held=[dict(card_id=i,current_cost=by[i]['cost'],base_cost=by[i]['cost']) for i in background]
    for count in (5,6):
        items.append((f'hand-{count}-draw-clog',dict(scene=scene,candidate_ids=[8,196],background_hand=held[:count],
            tasks={},reference_card_id=8,include_delay=True)))
    all3=[c['id'] for c in cards if c['card_type']=='monster' and c['pool_category']=='ordinary_non_token' and c['cost']==3]
    scene=base.scene3();scene.update(physical_slots=True,front_slot_map=[0,1,2,3],front_missing_policy='fizzle')
    scene['enemy_bodies'][0]['slot']=1
    items.append(('all3g-physical-observation',dict(scene=scene,candidate_ids=all3,reference_card_id=187,
        include_delay=False)))
    return items


def one(item):
    name,cfg=item;started=time.monotonic();result=score.compare(cfg)
    for suffix,value in [('.input.json',cfg),('.json',result)]:
        (OUT/(name+suffix)).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    return name,result,round(time.monotonic()-started,3)


def main():
    OUT.mkdir(exist_ok=True);frozen=score.source_bindings(Path(__file__));results=[]
    with ProcessPoolExecutor(max_workers=3) as pool:
        for future in as_completed([pool.submit(one,cfg) for cfg in configurations()]):
            name,r,seconds=future.result();results.append((name,r))
            print(json.dumps(dict(case=name,candidates=len(r['rows']),known_hp=sum(c['scores']['hp']['known'] for c in r['rows']),
                choice=r['selection']['best_supported_candidate_ids'],seconds=seconds)),flush=True)
    assert frozen==score.source_bindings(Path(__file__)),'Source changed during batch'
    summaries=[]
    with (OUT/'scores.csv').open('w',newline='') as f:
        fields=['case','card_id','name','task','known','feasible','joint_hp','task_hp_sacrificed','removal_hp_difference',
            'same_slot_hp_difference','current_deployment_hp','current_deployment_feasibility','unknown']
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for name,r in sorted(results):
            summaries.append(dict(case=name,artifact=name+'.json',candidate_count=len(r['rows']),
                known_hp=sum(c['scores']['hp']['known'] for c in r['rows']),selection=r['selection'],leaders=r['diagnostic_task_leaders']))
            for card in r['rows']:
                for task,v in card['scores'].items():
                    right=card['current_deployment_right_value'].get(task,{})
                    writer.writerow(dict(case=name,card_id=card['card_id'],name=card['name'],task=task,known=v['known'],
                        feasible=v['feasible'],joint_hp=v['guaranteed_player_hp'],
                        task_hp_sacrificed=card['purpose_player_hp_tradeoff'][task]['player_hp_sacrificed'],
                        removal_hp_difference=card['contribution_over_removed_copy'][task].get('hp_difference'),
                        same_slot_hp_difference=card['same_slot_reference_difference'][task].get('hp_difference'),
                        current_deployment_hp=right.get('hp_difference'),current_deployment_feasibility=right.get('feasibility_change'),
                        unknown='; '.join(v.get('unknown',[]))))
    (OUT/'index.json').write_text(json.dumps(dict(version=score.VERSION,source_hashes=frozen,cases=summaries,
        candidate_context_rows=sum(len(r['rows']) for name,r in results),
        limits=['Fixed input conditional guarantees; no frequency or Gold calibration.',
            'Spatial queries declare fixed observed slots, orientation mapping and empty-front fizzle interpretation.',
            'Negative possession contribution may be real hand capacity loss; it is not a forced bad deployment.']),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(cases=len(results),candidate_context_rows=sum(len(r['rows']) for name,r in results))))


if __name__=='__main__':main()