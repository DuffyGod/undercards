// Execute page code against a minimal DOM; no browser layout claim.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const here=__dirname,html=fs.readFileSync(path.join(here,'resistance-explorer.html'),'utf8');
const encoded=html.match(/<script type="application\/json" id="data">([\s\S]*?)<\/script>/)[1],data=JSON.parse(encoded);
const raw=JSON.parse(fs.readFileSync(path.resolve(here,'../../research-runs/alternative-goal-v01/resistance-frontier.json'),'utf8'));
assert.deepStrictEqual(data.rows,raw.rows);
class Element{
 constructor(){this.children=[];this.listeners={};this.value='';this.textContent='';this.className='';}
 append(...children){this.children.push(...children);}replaceChildren(...children){this.children=[...children];}
 addEventListener(name,fn){(this.listeners[name]??=[]).push(fn);}fire(name){for(const fn of this.listeners[name]??[])fn();}
}
const elements={};for(const id of ['data','reply','floor','summary','rows','links','detail','provenance'])elements[id]=new Element();
elements.data.textContent=encoded;
const document={getElementById:id=>{assert(elements[id]);return elements[id];},createElement:()=>new Element()};
vm.runInContext(html.split('</script><script>')[1].split('</script>')[0],vm.createContext({document}));
let selectors=0,rows=0,links=0;
for(const reply of ['none','gem1','gem3','gem4','headshot6'])for(const floor of ['4_1','4_2','8_1']){
 elements.reply.value=reply;elements.floor.value=floor;elements.floor.fire('change');selectors++;
 const [attack,hp]=floor.split('_').map(Number),shown=raw.rows.filter(r=>r.reply===reply&&r.body_attack===attack&&r.body_health===hp);
 assert.equal(elements.rows.children.length,6);const ids=new Set();
 const best=Math.max(...shown.filter(r=>r.known&&r.feasible).map(r=>r.hp));
 for(const tr of elements.rows.children){
  const id=Number(tr.children[0].textContent.match(/#(\d+)$/)[1]),row=shown.find(r=>r.card_id===id);assert(row);ids.add(id);
  assert.equal(tr.children[0].textContent,row.name+' #'+id);
  assert.equal(tr.children[1].textContent,String(data.cards[String(id)].cost));
  assert.equal(tr.children[2].textContent,!row.known?'未知':row.feasible?String(row.hp):'不可保证');
  assert.equal(tr.className==='best',row.known&&row.feasible&&row.hp===best);
  tr.fire('click');const detail=JSON.parse(elements.detail.textContent);assert.deepStrictEqual(detail.score,row);
  assert.deepStrictEqual(detail.required_body,[attack,hp]);assert(detail.same_policy_for_goal_and_hp);rows++;
  for(const a of elements.links.children){assert(fs.existsSync(path.resolve(here,a.href)));links++;}
 }assert.equal(ids.size,6);
}
assert.equal(selectors,15);assert.equal(rows,90);
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const report={passed:true,selector_states:selectors,rows_and_details_checked:rows,raw_links_checked:links,
 html_sha256:sha(path.join(here,'resistance-explorer.html')),checker_sha256:sha(__filename),
 dom_substitute:true,browser_layout_tested:false,model_search_calls:0};
fs.writeFileSync(path.join(here,'delivery-verification.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));