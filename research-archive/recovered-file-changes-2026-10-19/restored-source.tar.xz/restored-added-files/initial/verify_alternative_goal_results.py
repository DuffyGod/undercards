"""Actual CLI and generated vanilla comparator for the disjunctive objective."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import alternative_goal_score as alt
import conditional_card_score as score

HERE = Path(__file__).resolve().parent
OUT = HERE / 'research-runs/alternative-goal-v01'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def main():
    bindings = score.source_bindings(Path(__file__))
    native = json.loads((OUT/'card110.json').read_text())
    scene = dict(native['input'],hand_ids=[270],hand_costs=[3],hand_base_costs=[3])
    results={}
    for name, task in native['tasks'].items():
        results[name]=(alt.evaluate(scene,task,focal_index=0) if task['kind']=='any'
            else score.task_score(scene,task,focal_index=0))
    assert results['hp']['guaranteed_player_hp']==11
    assert results['clear_or_focal4_1']['known'] and not results['clear_or_focal4_1']['feasible']
    write('generated-thrashing-reference.json',dict(input=scene,card_id=270,
        scope='Generated vanilla4/4 scene reference, not a native construction recommendation.',
        results=results,tasks=native['tasks']))
    cases=[]
    for label in ('card110','headshot-cash6'):
        raw=json.loads((OUT/(label+'.json')).read_text())
        payload=dict(scene=raw['input'],task=raw['tasks']['clear_or_focal4_1'],focal_index=0)
        write(label+'.cli.input.json',payload)
        cmd=[sys.executable,str(HERE/'alternative_goal_score.py'),str(OUT/(label+'.cli.input.json')),
            '--output',str(OUT/(label+'.cli.output.json'))]
        run=subprocess.run(cmd,cwd=HERE,capture_output=True,text=True)
        (OUT/(label+'.cli.stdout.log')).write_text(run.stdout)
        (OUT/(label+'.cli.stderr.log')).write_text(run.stderr)
        assert run.returncode==0
        actual=json.loads((OUT/(label+'.cli.output.json')).read_text())
        assert actual==json.loads(score.canonical(raw['results']['clear_or_focal4_1']))
        cases.append(dict(context=label,command=cmd,full_json_equal=True,
            input_sha256=sha(OUT/(label+'.cli.input.json')),output_sha256=sha(OUT/(label+'.cli.output.json'))))
    assert bindings==score.source_bindings(Path(__file__))
    write('cli-verification.json',dict(passed=True,source_hashes=bindings,cases=cases,
        actual_generated_reference_tasks=4,actual_cli_core_searches=2,source_stable=True))
    print(json.dumps(dict(passed=True,reference_tasks=4,real_cli_queries=2)))


if __name__=='__main__':main()