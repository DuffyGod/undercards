"""Actual retained-card opportunity loss through the seven-card draw cap."""
import copy
import unittest
import build_periodic_spatial_scores as examples
import conditional_card_score as score


class CapacityOpportunityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.configs={name:cfg for name,cfg in examples.configurations() if name.startswith('hand-')}

    def test_full_hand_can_make_optional_possession_worse(self):
        r=score.compare(self.configs['hand-6-draw-clog']);a,z=r['rows']
        self.assertEqual(r['removal_baseline']['scores']['hp']['guaranteed_player_hp'],6)
        self.assertEqual([c['scores']['hp']['guaranteed_player_hp'] for c in (a,z)],[2,6])
        self.assertEqual(a['contribution_over_removed_copy']['hp']['hp_difference'],-4)
        self.assertEqual(a['scores']['hp']['search']['draw_accounting']['cards_burned'],1)
        self.assertEqual(z['scores']['hp']['search']['draw_accounting']['cards_burned'],0)
        self.assertEqual(a['scores']['hp']['search']['payment_accounting']['current_paid_gold'],0)
        self.assertEqual(a['scores']['hp']['search']['payment_accounting']['next_paid_gold'],0)
        self.assertEqual(z['scores']['hp']['search']['payment_accounting']['next_paid_gold'],3)

    def test_one_free_hand_slot_removes_this_specific_clog_cost(self):
        r=score.compare(self.configs['hand-5-draw-clog']);a=r['rows'][0]
        self.assertEqual(a['scores']['hp']['guaranteed_player_hp'],6)
        self.assertEqual(a['contribution_over_removed_copy']['hp']['hp_difference'],0)
        self.assertEqual(a['scores']['hp']['search']['draw_accounting']['cards_burned'],0)

    def test_burning_a_useless_draw_has_no_invented_fixed_penalty(self):
        cfg=copy.deepcopy(self.configs['hand-6-draw-clog']);cfg['scene']['own_deck_ids']=[196]
        r=score.compare(cfg);a=r['rows'][0]
        self.assertEqual(a['scores']['hp']['guaranteed_player_hp'],2)
        self.assertEqual(a['contribution_over_removed_copy']['hp']['hp_difference'],0)


if __name__=='__main__':unittest.main()