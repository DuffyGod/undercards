import unittest
import paid_board_tactics as paid


class PlayerHpObservationTests(unittest.TestCase):
    def test_omitted_maximum_is_disclosed_and_changes_a_real_heal_decision(self):
        data=dict(hand_ids=[22],gold_before_play=3,own_player_hp=3,max_plays=1,
            enemy_bodies=[dict(card_id=15,attack=6,health=5)],
            horizon='enemy_attack',objectives=['guaranteed_hp'])
        assumed=paid.evaluate(data)
        self.assertTrue(assumed['complete_in_declared_scope'])
        self.assertEqual(assumed['player_hp_caps']['own']['input_assumption'],'maximum_equals_current_hp')
        self.assertEqual(assumed['objectives'][0]['metrics']['own_player_hp'],0)
        observed=paid.evaluate(dict(data,own_player_max_hp=30))
        self.assertEqual(observed['objectives'][0]['metrics']['own_player_hp'],1)
        self.assertTrue(observed['player_hp_caps']['own']['explicitly_supplied'])
        self.assertIsNone(observed['player_hp_caps']['own']['input_assumption'])


if __name__=='__main__':unittest.main()