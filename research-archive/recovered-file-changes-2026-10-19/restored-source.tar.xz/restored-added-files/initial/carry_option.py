"""An observed-state, finite entry-opportunity option, with one held card.

Deployment rewards are supplied local net quotations, not full-match returns.
Waiting is chosen before the next observation. An unused card pays no mana.
Capacity bookkeeping pairs the occupied hand with one initially empty slot;
after that slot fills, it must not be priced as empty at every future draw.
"""
import math
from functools import lru_cache

VERSION='finite-carry-option-0.1.0'


def number(value,name,minimum=None):
    if type(value) not in (int,float) or not math.isfinite(value) or (minimum is not None and value<minimum):
        raise ValueError(name+' must be finite'+(' and >= '+str(minimum) if minimum is not None else ''))
    return value


def validate(scenario):
    required={'root_id','last_deployment_own_turn','initial_hand_size','draw_option_value_model_gold','nodes'}
    if not isinstance(scenario,dict) or not required<=set(scenario):
        raise ValueError('Carry scenario requires '+', '.join(sorted(required)))
    h=scenario['initial_hand_size'];deadline=scenario['last_deployment_own_turn']
    if type(h) is not int or not 1<=h<=7 or type(deadline) is not int or deadline<1:
        raise ValueError('Carry hand size 1..7 and positive fixed last-deployment turn required')
    number(scenario['draw_option_value_model_gold'],'Draw option prior',0)
    number(scenario.get('discount_rate_per_turn',0.),'Discount rate',0)
    nodes=scenario['nodes']
    if not isinstance(nodes,list) or not nodes or any(not isinstance(n,dict) for n in nodes):
        raise ValueError('Carry nodes must be a nonempty list')
    ids=[n.get('id') for n in nodes]
    if any(not isinstance(i,str) or not i for i in ids) or len(set(ids))!=len(ids):
        raise ValueError('Unique nonempty observation node IDs required')
    by=dict(zip(ids,nodes))
    if scenario['root_id'] not in by:raise ValueError('Unknown carry root')
    for n in nodes:
        if type(n.get('own_turn')) is not int or not 1<=n['own_turn']<=deadline:
            raise ValueError('Every opportunity must be within the fixed deployment horizon')
        edges=n.get('transitions',[])
        if not isinstance(edges,list):raise ValueError('Transitions must be a list')
        for e in edges:
            required_edge={'child_id','probability','cards_from_deck','other_plays','foregone_value_model_gold'}
            if not isinstance(e,dict) or not required_edge<=set(e) or e['child_id'] not in by:
                raise ValueError('Transitions require an existing child, probability and explicit draw/play/foregone facts')
            number(e['probability'],'Transition probability',0)
            number(e['foregone_value_model_gold'],'Declared foregone opportunity',0)
            if any(type(e[k]) is not int or e[k]<0 for k in ('cards_from_deck','other_plays')):
                raise ValueError('Drawn cards and other plays must be nonnegative integers')
            if by[e['child_id']]['own_turn']<=n['own_turn']:
                raise ValueError('Observations must advance time; no rolling horizon or cycles')
        if edges and not math.isclose(math.fsum(e['probability'] for e in edges),1.,abs_tol=1e-10):
            raise ValueError('Transition probabilities must sum to one without favorable-state renormalization')
    return by


def evaluate(scenario,quote):
    """quote(node, occupied_hand_size) returns legal/known/net/paid/reasons.

    Unknown legal deployment rewards have no invented finite upper bound.
    Known waiting/unused paths are feasible lower bounds, not a full verdict.
    """
    by=validate(scenario);prior=scenario['draw_option_value_model_gold']
    rate=scenario.get('discount_rate_per_turn',0.)
    decisions=[]

    @lru_cache(None)
    def solve(node_id,occupied,empty_reference):
        node=by[node_id];local=quote(node,occupied)
        edges=[e for e in node.get('transitions',[]) if e['probability']>0]
        wait_value=wait_cost=wait_spent=wait_used=wait_turn=0.;wait_upper=0.;unknown=[]
        paths=[]
        for e in edges:
            other=e['other_plays']
            if other>min(occupied-1,empty_reference):
                raise ValueError('Common other plays cannot consume the reserved card or unavailable hand cards')
            own_before=occupied-other;ref_before=empty_reference-other;draw=e['cards_from_deck']
            own_kept=min(draw,7-own_before);ref_kept=min(draw,7-ref_before)
            lost=ref_kept-own_kept
            if lost<0:raise ValueError('Empty-slot reference cannot retain fewer cards')
            cost=lost*prior+e['foregone_value_model_gold']
            child=solve(e['child_id'],own_before+own_kept,ref_before+ref_kept)
            discount=(1+rate)**-(by[e['child_id']]['own_turn']-node['own_turn'])
            mass=e['probability']
            wait_value+=mass*discount*(child['lower']-cost)
            if wait_upper is not None:
                wait_upper=None if child['upper'] is None else wait_upper+mass*discount*(child['upper']-cost)
            wait_cost+=mass*discount*(child['holding_cost']+cost)
            wait_spent+=mass*child['spent'];wait_used+=mass*child['used'];wait_turn+=mass*child['weighted_turn']
            unknown.extend(child['unknown'])
            paths.append(dict(child_id=e['child_id'],probability=mass,discount=discount,
                holding_cost_model_gold=cost,extra_burned_cards=lost,
                occupied_hand_after=own_before+own_kept,empty_reference_hand_after=ref_before+ref_kept))
        # At expiry, retaining an unusable card contributes zero deployment
        # surplus. There is no forced body play or fee equal to its mana cost.
        best=dict(action='wait' if edges else 'unused_at_deadline',lower=wait_value,upper=wait_upper,
            holding_cost=wait_cost,spent=wait_spent,used=wait_used,weighted_turn=wait_turn,
            expected_discounted_deployment_surplus=wait_value+wait_cost,unknown=unknown)
        if local['legal']:
            if local['known']:
                reward=number(local['net_model_gold'],'Deployment net value')
                if reward>best['lower']+1e-12:
                    best.update(action='deploy',lower=reward,holding_cost=0.,spent=local['paid_gold'],
                        used=1.,weighted_turn=node['own_turn'],expected_discounted_deployment_surplus=reward)
                best['upper']=None if wait_upper is None else max(wait_upper,reward)
            else:
                best['upper']=None
                best['unknown']=best['unknown']+[dict(node_id=node_id,reasons=local.get('unknown',[]))]
        decision=dict(node_id=node_id,own_turn=node['own_turn'],occupied_hand_size=occupied,
            empty_reference_hand_size=empty_reference,local_quote=local,
            selected_known_action=best['action'],known_wait_value_model_gold=wait_value,
            value_bounds_model_gold=[best['lower'],best['upper']],continuation=paths)
        decisions.append(decision)
        return best

    h=scenario['initial_hand_size'];r=solve(scenario['root_id'],h,h-1)
    known=r['upper'] is not None and math.isclose(r['lower'],r['upper'],abs_tol=1e-10)
    return dict(version=VERSION,pricing_supported=known,
        option_value_model_gold=r['lower'] if known else None,
        value_bounds_model_gold=[r['lower'],r['upper']],
        best_known_policy_value_model_gold=r['lower'],root_known_action=r['action'],
        policy_statistics_are_optimal=known,
        deployed_probability=r['used'],unused_probability=1-r['used'],
        expected_actual_mana_paid=r['spent'],
        mean_deployment_own_turn_when_used=r['weighted_turn']/r['used'] if r['used'] else None,
        expected_discounted_holding_cost_model_gold=r['holding_cost'],
        expected_discounted_deployment_surplus_model_gold=r['expected_discounted_deployment_surplus'],
        policy=decisions,unknown=r['unknown'],last_deployment_own_turn=scenario['last_deployment_own_turn'],
        assumptions=[
            'A single already-drawn deck slot; arrivals and future visible states are explicit conditional scenarios, not empirical frequencies.',
            'Deploy or keep the card; mana is paid only on deployment. Expired unused cards have zero deployment surplus.',
            'Waiting is chosen before observing children; local target/action quotes likewise commit before their hidden reply.',
            'Local deployment rewards are consumed once; no sum of overlapping combat-window quotes or future uses of this card.',
            'One paired hand-capacity ledger: the initially empty reference slot may fill, so repeated draws cannot repeatedly count it as empty.',
            'Other plays and foregone values describe a common background policy; no free discard, automatic partner use or newly drawn identity.',
            'Discounting is an explicit entry-time preference for local rewards; this is not a complete match rollout.'])