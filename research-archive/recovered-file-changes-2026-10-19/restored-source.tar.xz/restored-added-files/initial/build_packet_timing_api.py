"""Expose paid waiting and physical hand support through the public CLI."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import build_packet_timing as timing
import evaluate_situation as api
import paid_board_tactics as paid

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/damage-packet-v01'


def main():
    rows=[]
    for background in (False,True):
        scene=timing.scenario(187,background)
        scene.update(objectives=['purpose'],purpose_constraints=dict(
            min_own_player_hp=11,min_own_body_attack=2,min_own_body_health=2))
        root=('hand_ids','gold_before_play','own_player_hp','enemy_player_hp',
              'ally_bodies_before_play','enemy_bodies','opponent_gold_before_response')
        data={k:copy.deepcopy(scene[k]) for k in root}
        data.update(role='midrange',own_turn=5,condition_state=scene['condition_known_state'],
            response_weights={'enemy_face':1},
            callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30))
        ignored=set(root)|{'own_player_max_hp','enemy_player_max_hp','condition_known_state'}
        data['paid_board_scenario']={k:copy.deepcopy(v) for k,v in scene.items() if k not in ignored}
        result=api.evaluate(data)
        direct=paid.evaluate(dict(scene,hand_costs=[3,1] if background else [3]))
        assert result['paid_board_tactics']==direct
        assert direct['complete_in_declared_scope']
        objective=direct['objectives'][0]
        assert objective['purpose_guaranteed'] is background
        if background:
            ledger=objective['payment_accounting']
            assert ledger['current_paid_gold']==1 and ledger['next_paid_gold']==3
        name='timing-dummy' if background else 'timing-alone'
        ip=OUT/(name+'.input.json');op=OUT/(name+'.result.json')
        ip.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        p=subprocess.run([sys.executable,str(HERE/'evaluate_situation.py'),'--input',str(ip),
            '--output',str(op)],cwd=HERE,capture_output=True,text=True)
        assert p.returncode==0,(p.stdout,p.stderr)
        assert json.loads(op.read_text())==json.loads(json.dumps(result))
        rows.append(dict(case=name,purpose_guaranteed=objective['purpose_guaranteed'],
            api_equals_paid=True,cli_equals_api=True,
            input_sha256=hashlib.sha256(ip.read_bytes()).hexdigest(),
            output_sha256=hashlib.sha256(op.read_bytes()).hexdigest()))
    record=dict(cases=rows,api_version=api.VERSION,paid_version=paid.VERSION,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('build_packet_timing_api.py','build_packet_timing.py','build_damage_packet_comparison.py',
             'evaluate_situation.py','paid_board_tactics.py','board_tactics.py')},
        scope='Actual API/CLI equality for declared hands, decks, incomes and two-response window; not matchup frequency or server validation.')
    (OUT/'timing-api-verification.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(rows))


if __name__=='__main__':main()