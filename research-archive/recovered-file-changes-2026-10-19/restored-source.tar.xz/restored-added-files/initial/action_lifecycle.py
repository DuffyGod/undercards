"""Bind deferred Dust hand payments to the SAME simulated death path.

Scenario probabilities are not averaged again. Only the actual event date is
matched; missing future hand/payment observations remain unknown.
"""
import copy
import realization_window

VERSION='actual-action-dust-realization-0.1.0'


def evaluate(state,ctx):
    pending=state.get('deferred_dust_effects',[])
    result=dict(version=VERSION,model_gold=0.,known=True,terms=[],unknown=[],
        scope='Actual actor death binds Dust; no independent phase probability or extra candidate-death penalty.')
    if not pending:return result
    timing=ctx.get('dust_timing')
    if not isinstance(timing,dict):
        return dict(result,known=False,model_gold=None,unknown=['Actual Dust discount requires future timing/hand/payment observations'])
    if len(pending)>1:
        return dict(result,known=False,model_gold=None,unknown=['Multiple Dust discount modules need a single shared payment frontier'])
    for deferred in pending:
        stage=deferred['stage']
        event_turn=ctx['own_turn']+(stage=='next_own')
        matches=[b for b in timing.get('branches',[]) if b.get('event')=='ordinary_death'
            and b.get('event_turn')==event_turn and b.get('event_stage',stage)==stage]
        if len(matches)!=1:
            result['unknown'].append('No unique declared future hand/payment plan matching actual Dust '+stage+' on own turn '+str(event_turn))
            continue
        branch=copy.deepcopy(matches[0]);branch['probability']=1.
        if timing['horizon']<event_turn:
            # The effect lies outside this absolute scenario deadline.
            result['terms'].append(dict(stage=stage,event_turn=event_turn,model_gold=0.,outside_deadline=True));continue
        evaluated=realization_window.evaluate(deferred['module'],[branch],timing['horizon'],
            timing.get('discount_rate',0.),timing.get('origin_turn',ctx['own_turn']))
        value=evaluated['expected_present_value_model_gold']
        result['terms'].append(dict(stage=stage,event_turn=event_turn,model_gold=value,details=evaluated))
        if value is None:result['unknown'].extend(evaluated['unknown'])
        else:result['model_gold']+=value
    if result['unknown']:result.update(known=False,model_gold=None)
    return result