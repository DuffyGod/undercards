"""Finite Gem/attacker allocation, independent of the production model."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    index=json.loads((HERE/'index.json').read_text());checks=[]
    for row in index['rows']:
        source=json.loads((HERE/row['cards_source']).read_text())['cards'];cards={c['id']:c for c in source}
        native={c['id']:c for c in json.loads((HERE/'native-snapshot.json').read_text())['cards']}
        changes=[(cid,k,native[cid].get(k),c.get(k)) for cid,c in cards.items() for k in set(c)|set(native[cid]) if c.get(k)!=native[cid].get(k)]
        assert changes==[(row['changed_card_id'],row['field'],row['old'],row['new'])]
        h=cards[14]['health'];a=cards[509]['attack']
        assert cards[14]['effect_readable']=='Taunt. This takes 1 less DMG from monsters costing 4 or less GOLD.'
        assert cards[509]['cost']==5 and cards[270]['cost']==3
        assert cards[30]['effect_readable']=='Taunt. Turn end: Both players earn 5 GOLD.'
        assert cards[598]['effect_readable']=='Deal 1 DMG.'
        allocations=[dict(strategy='Both attacks needed or no final clear',face_damage=4+2)]
        # Fixed lower policy: Burger now, Jerry next, no own attacks. If Long
        # killed Burger, Thrashing first faces4. In the final reply exactly
        # one big attacker can face only if the other+remaining Gems clear
        # Jerry. All Gems not used on Jerry may hit our player either turn.
        for clearer,damage,face in [('Long',a,4),('Thrashing',4-1,a)]:
            required=max(0,h-damage)
            if required<=2:
                allocations.append(dict(strategy=clearer+' clears Jerry',gems_to_jerry=required,
                    face_damage=4+face+(2-required)))
        maximum_damage=max(r['face_damage'] for r in allocations)
        # Other first-turn responses either leave the original Taunt or
        # remove Thrashing via Burger4 retaliation, hence cause <=6 total
        # player damage against the fixed policy. This loose bound suffices.
        lower=15-max(6,maximum_damage)
        # Same Gem allocation is a legal enemy reply against current Burger
        # and next Jerry. Own cannot attack with newly deployed Jerry.
        # Holding Burger now leaves5G Jerry unpayable and permits<=5HP;
        # omitting Jerry after early Burger cannot improve protection.
        upper=max(5,15-maximum_damage)
        value=json.loads((HERE/row['artifact']).read_text())['result']
        assert value['known'] and value['guaranteed_player_hp']==lower==upper
        checks.append(dict(label=row['label'],jerry_health=h,long_attack=a,lower=lower,upper=upper,
            production_hp=value['guaranteed_player_hp'],allocations=allocations,
            result_sha256=sha(HERE/row['artifact']),cards_source_sha256=sha(HERE/row['cards_source'])))
    result=dict(imports_production_model=False,matching_bounds=len(checks),checks=checks,
        builder_sha256=sha(Path(__file__)),parent_index_sha256=sha(HERE/'index.json'),
        qualification='These are conditional finite HP tasks and explicit hypothetical card sources, not live balance changes or a global synergy scale.')
    (HERE/'independent-bounds.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()