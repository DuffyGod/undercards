"""Common finite Dust scenario adapter; no inferred death or hand policy.

The deadline belongs to the original observation, not each candidate wait.
Declared usage masks are replayed earliest-affordably with shared cash/caps;
they are scenario inputs, never identities revealed to a waiting decision.
"""
from __future__ import annotations
import copy
import math

import context_value as ledger
import heuristic_contexts as contexts

VERSION='fixed-deployment-deadline-0.1.0'


def validate_policy(policy):
    if policy is None:  # Explicit reproducibility switch for the old ledger.
        return
    if not isinstance(policy,dict) or set(policy)!={'horizon_extra_turns','event_delay_turns','discount_rate'}:
        raise ValueError('Dust timing policy fields must be explicit')
    for key in ('horizon_extra_turns','event_delay_turns'):
        value=policy[key]
        if type(value) is not int or not 0<=value<=10:
            raise ValueError(key+' must be an integer 0..10')
    rate=policy['discount_rate']
    if type(rate) not in (int,float) or not math.isfinite(rate) or rate<0:
        raise ValueError('Dust discount rate must be finite nonnegative')


def _matched_plan(costs,used,windows,carry):
    """No new option quotes: pay declared wanted cards when cash permits."""
    hand=[dict(cost=cost,use_turn=None) for cost in costs]
    available=carry
    for window in windows:
        available+=window['income']
        left=window['max_plays']
        for i,(cost,wanted) in enumerate(zip(costs,used)):
            if wanted and hand[i]['use_turn'] is None and left and cost<=available+1e-9:
                hand[i]['use_turn']=window['turn']
                available-=cost
                left-=1
    return hand


def dust_context(origin,deployment,profile,event_scale=1.):
    policy=profile['dust_timing_policy']
    validate_policy(policy)
    if policy is None:
        return None
    horizon=origin['own_turn']+policy['horizon_extra_turns']
    event_turn=deployment['own_turn']+policy['event_delay_turns']
    # Frozen origin-phase risk: waiting cannot improve its death prior for free.
    weights=ledger.event_weights(origin,event_scale)
    window=deployment['resource_use_window']
    caps=deployment.get('future_payment_play_caps',[7,7])
    if len(caps) not in (2,3):
        raise ValueError('Dust payment caps must describe two or three scenario windows')
    windows=[dict(turn=event_turn+i+1,
                  income=contexts.base_income(event_turn+i+1,profile['second_player'])*profile['future_income_available_fraction'],
                  max_plays=cap) for i,cap in enumerate(caps)]
    carry=window['assumed_carry_gold']
    if 'death_event_hand_quotes' in deployment:
        hand=copy.deepcopy(deployment['death_event_hand_quotes'])
        if [row['cost'] for row in hand]!=deployment['death_event_hand_costs']:
            raise ValueError('Dust quotes must bind the declared event hand')
    else:
        hand=_matched_plan(deployment['death_event_hand_costs'],deployment['actually_used_mask'],windows,carry)
    branches=[dict(id='ordinary',event='ordinary_death',probability=weights['ordinary_death'],
                   event_turn=event_turn,hand_at_event=hand,payment_windows=windows,initial_gold=carry),
              dict(id='silenced',event='silenced_before_death',probability=weights['silenced_before_event']),
              dict(id='removed',event='nondeath_removal',probability=weights['other_non_death_removal']),
              dict(id='none',event='none',probability=weights['no_event_in_window'])]
    return dict(branches=branches,horizon=horizon,
                origin_turn=min(deployment['own_turn'],horizon),discount_rate=policy['discount_rate'],
                scenario_metadata=dict(version=VERSION,observation_turn=origin['own_turn'],
                    deployment_turn=deployment['own_turn'],event_delay_turns=policy['event_delay_turns'],
                    deadline_does_not_roll=True,event_prior_frozen_at_origin=True,
                    policy='Earliest-affordable declared usage, original hand order; quoted hand instead uses its explicit optimized frontier.',
                    carry_is_declared_scenario_not_candidate_cash=True,
                    pending='Death delay, event risks, future hands and usage policies are unverified design inputs.'))