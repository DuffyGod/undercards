"""Persist one current-code regression run and active artifact source audit.

Frozen historical reports are deliberately outside this explicit active list.
Success checks implementation and provenance, not real-match validity.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
MODULES = ['test_board_tactics','test_paid_board_tactics','test_second_enemy_reply',
    'test_first_enemy_draw','test_control_timing','test_single_dust_damage',
    'test_compound_magic','test_hand_cost_death','test_next_turn_payment',
    'test_draw_integration','test_turn_end_effects','test_player_hp_observations',
    'test_situation_evaluator','test_hand_hp_certificate','test_hidden_reply_policy',
    'test_hidden_choice_boundaries','test_new_mechanic_search','test_cost_damage_resistance',
    'test_transparency','test_generic_enemy_magic','test_hand_magic',
    'test_body_hp_observations','test_future_draw_policy','test_replacement_slots',
    'test_physical_play_scope']
ACTIVE = ['paid-standing-v01/comparison.json','standing-objectives-v01/comparison.json',
    'body-hp-cap-v01/comparison.json','hand-magic-v01/comparison.json',
    'transparency-v01/comparison.json','cost-damage-v01/comparison.json',
    'hand-cost-death-v01/comparison.json','first-enemy-draw-v01/comparison.json',
    'control-dust-v01/comparison.json','compound-magic-v01/comparison.json',
    'hidden-reply-v01/comparison.json','hidden-choice-v01/comparison.json',
    'hidden-reply-v01/api-verification.json','second-reply-v01/api-verification.json',
    'future-draw-v01/comparison.json','future-draw-v01/api-verification.json',
    'replacement-slot-v01/comparison.json']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit():
    checked, errors = [], []
    for name in ACTIVE:
        path=HERE/'experiments'/name
        if not path.exists():
            errors.append(dict(artifact=name,error='missing'))
            continue
        document=json.loads(path.read_text())
        bindings={}
        def visit(value):
            if isinstance(value,dict):
                for key,item in value.items():
                    if key in ('source_hashes','source_sha256') and isinstance(item,dict):
                        for source,expected in item.items():
                            bindings.setdefault(source,set()).add(expected)
                    else:visit(item)
            elif isinstance(value,list):
                for item in value:visit(item)
        visit(document)
        for source,expected in bindings.items():
            target=HERE/source
            if not target.is_file():
                errors.append(dict(artifact=name,source=source,error='source_missing'))
            elif expected != {sha(target)}:
                errors.append(dict(artifact=name,source=source,error='source_hash_mismatch',
                                   expected=sorted(expected),actual=sha(target)))
        checked.append(dict(artifact=name,sha256=sha(path),bound_source_files=len(bindings)))
    return dict(artifacts=checked,errors=errors,all_bound_sources_current=not errors,
        scope='Explicit active reports only; frozen historical snapshots are not rewritten or audited as current.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audit-only',action='store_true')
    args=parser.parse_args()
    command=[sys.executable,'-m','unittest',*MODULES]
    hashes={p.name:sha(p) for p in HERE.glob('*.py')}
    run=dict(started_at_utc=datetime.now(timezone.utc).isoformat(),source_hashes=hashes,
        command=command,tests_executed=not args.audit_only)
    if not args.audit_only:
        process=subprocess.run(command,cwd=HERE,capture_output=True,text=True)
        output=process.stdout+process.stderr
        match=re.search(r'Ran (\d+) tests in ([\d.]+)s',output)
        run.update(exit_code=process.returncode,output=output,
            test_count=int(match[1]) if match else None,
            runner_seconds=float(match[2]) if match else None,
            passed=process.returncode==0 and match is not None and int(match[1])>0)
        print(output,end='',flush=True)
    run['artifact_audit']=audit()
    run['finished_at_utc']=datetime.now(timezone.utc).isoformat()
    run['source_unchanged_during_run']=all(sha(HERE/name)==digest for name,digest in hashes.items())
    run['interpretation']='Regression and source binding evidence only; shared mechanism primitives are not server-rule or real-match validation.'
    path=HERE/'experiments/current-integration-verification.json'
    previous=json.loads(path.read_text()) if path.exists() else dict(runs=[])
    previous['runs'].append(run)
    path.write_text(json.dumps(previous,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(tests=run.get('test_count'),passed=run.get('passed'),
        artifact_hash_errors=run['artifact_audit']['errors'],
        source_unchanged=run['source_unchanged_during_run']),ensure_ascii=False),flush=True)
    if not run['source_unchanged_during_run'] or run['artifact_audit']['errors'] \
            or (not args.audit_only and not run.get('passed')):
        sys.exit(1)


if __name__=='__main__':main()