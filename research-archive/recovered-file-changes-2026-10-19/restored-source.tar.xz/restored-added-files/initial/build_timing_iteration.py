"""Compare deadline and opponent-turn changes under identical common states."""
from __future__ import annotations
import csv
import hashlib
import json
from pathlib import Path

import combat_increment as combat
import context_value as ledger
import score_cards as base
import unified_value as unified

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/deployment-timing-v01'


def dump(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    baseline_path=HERE/'experiments/growth-window-v01/current-pool.json'
    before=json.loads(baseline_path.read_text())
    old={row['card_id']:row for row in before['scores']}
    cards=base.load_cards(); by_id={c['id']:c for c in cards}
    reference,_=base.make_reference(cards)
    profile=unified.normalize_profile()
    current=[unified.score(by_id[cid],reference,profile,include_rows=False) for cid in old]
    dump(OUT/'current-pool.json',dict(version=unified.VERSION,ledger_version=ledger.VERSION,
         combat_version=combat.VERSION,profile=profile,scores=current))
    changed=[]
    rows=[]
    for new in current:
        left=old[new['card_id']]
        a,b=left['value_margin_model_gold'],new['value_margin_model_gold']
        row=dict(card_id=new['card_id'],name=new['name'],old_margin=a,new_margin=b,
                 delta=None if a is None or b is None else b-a,
                 old_status=left['support_status'],new_status=new['support_status'])
        rows.append(row)
        if row['delta'] is not None and abs(row['delta'])>1e-9 or row['old_status']!=row['new_status']:
            changed.append(row)
    with (OUT/'pool-comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    supported=[r['card_id'] for r in current if r['value_margin_model_gold'] is not None]
    ablations=[]
    policies={'legacy':{'dust_timing_policy':None,'enemy_attack_limit':1},
              'deadline_only':{'enemy_attack_limit':1},
              'all_attackers_only':{'dust_timing_policy':None},'both':{}}
    for name,changes in policies.items():
        for cid in supported:
            r=unified.score(by_id[cid],reference,changes,include_rows=False)
            ablations.append(dict(scenario=name,card_id=cid,name=by_id[cid]['name'],
                                 margin=r['value_margin_model_gold'],status=r['support_status']))
    reproduction_error=max(abs(r['margin']-old[r['card_id']]['value_margin_model_gold'])
                           for r in ablations if r['scenario']=='legacy')
    if reproduction_error>1e-9:
        raise ValueError('Legacy intervention no longer reproduces frozen supported scores')
    counterfactuals=[]
    lookup={r['card_id']:r for r in current}
    for cid in supported:
        for field,delta in (('attack',1),('health',1),('cost',-1)):
            r=unified.score(dict(by_id[cid],**{field:by_id[cid][field]+delta}),reference,include_rows=False)
            value=r['value_margin_model_gold']
            counterfactuals.append(dict(card_id=cid,name=by_id[cid]['name'],field=field,
                intervention=delta,margin=value,delta=None if value is None else value-lookup[cid]['value_margin_model_gold']))
    with (OUT/'numeric-counterfactuals.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(counterfactuals[0]));writer.writeheader();writer.writerows(counterfactuals)
    need=[]
    for spent in (0,1):
        trajectory={str(d):{'last_turn_gold_spent_on_spells':spent} for d in range(4)}
        for cid in (438,582):
            r=unified.score(by_id[cid],reference,{'condition_state_by_wait':trajectory},include_rows=False)
            need.append(dict(card_id=cid,name=by_id[cid]['name'],declared_spell_gold_each_previous_turn=spent,
                             margin=r['value_margin_model_gold'],status=r['support_status']))
    timing=[]
    origin=next(s for s in unified.make_panel(profile) if s['context_id']=='midrange-t3-reserved-pressured')
    for changes_name,changes in policies.items():
        p=unified.normalize_profile(changes)
        for cid in (43,138):
            r=unified.quote_state(by_id[cid],origin,reference,p)
            timing.append(dict(scenario=changes_name,card_id=cid,name=by_id[cid]['name'],
                               origin_context=origin,selected_wait=r['chosen_extra_wait'],
                               options=r['deployment_options'],selected_ledger=r['ledger']))
    violations=[r for r in counterfactuals if r['delta'] is None or r['delta']<-1e-9]
    report=dict(version=unified.VERSION,ledger_version=ledger.VERSION,combat_version=combat.VERSION,
                shared_states=72,shared_weight_sum=1,whole_card_supported=len(supported),
                changed=changed,ablations=ablations,numeric_counterfactuals=counterfactuals,
                marginal_diagnostics=violations,need_condition_scenarios=need,timing_scenarios=timing,
                legacy_reproduction_max_error=reproduction_error,
                assumptions=unified.LIMITATIONS,
                provenance=dict(snapshot_sha256=hashlib.sha256(base.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
                  baseline_sha256=hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
                  source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in HERE.glob('*.py')}))
    dump(OUT/'comparison.json',report)
    lines=['# 固定兑现截止与完整敌方攻击窗口','',
           f'同一404张池、72共同设计状态，完整局部报价仍支持{len(supported)}张。其余卡的整卡数值保留未知。数值为model-G报价减费，不是胜率；风险没有逐卡额外倍扣。','',
           '| 卡牌 | 前次 | 当前 | 差值 |','|---|---:|---:|---:|']
    for r in changed:
        fmt=lambda x:'未知' if x is None else f'{x:.4f}'
        lines.append(f'| {r["name"]} #{r["card_id"]} | {fmt(r["old_margin"])} | {fmt(r["new_margin"])} | {fmt(r["delta"])} |')
    lines+=['','## 独立干预与反事实','',
            'legacy同时恢复旧的单敌攻击和滚动Dust窗口；deadline_only只固定兑现截止；all_attackers_only只修正敌方攻击次数；both同时启用。全部已支持卡的四种分数见comparison.json。',
            f'legacy与冻结前次分数最大误差：{reproduction_error:.3g}。同一共同状态下进行{len(counterfactuals)}次ATK+1/HP+1/费用−1反事实，未知或负边际诊断共{len(violations)}项，详见CSV。','',
            'Dust默认截止为原观察己方回合+2，ordinary-death默认发生在部署回合付款之后，事件风险冻结于原观察阶段；等待不能重开窗口，也不能免费提高死亡先验。未付款的减费不变成现金，Ferry在截止当时仍到账。',
            '默认贴现率0、未来carry0、事件时手牌与usage mask、每个付款窗口最多7张均为公开场景输入。公共策略按原手牌顺序在首次可支付时回放既定使用；没有gross quotes时不编造解锁收益。',
            'Haste依旧仅允许当回合打怪；新敌方窗口中活正攻击单位各攻击一次，最强优先、slot稳定打破平局；在actor死亡后其余单位进脸，终局立即停止。攻击就绪、对手顺序和其他友军防御尚未来自成熟卡组或服务器模拟。','',
            '## Need激活情景','',
            '| 卡 | 每次声明的前回合咒术实付G | margin |','|---|---:|---:|']
    for r in need:
        lines.append(f'| {r["name"]} | {r["declared_spell_gold_each_previous_turn"]} | {r["margin"]:.4f} |')
    lines+=['','这些是完整条件轨迹的两种干预，不能把高收益列冒充一般得分。Need false保留可部署身体及独立Haste；缺失未来历史仍unknown，不从今天复制。','',
            '固定Dust分支保留触发概率、真正兑现概率和方差；terminal胜负保留独立结果，不拟成巨额Gold。手牌覆盖和持续产品数量见opportunity-fit-v01，其意义与整卡margin不同。','',
            '复现：`python build_timing_iteration.py`。基线文件不覆写。']
    (OUT/'comparison.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(dict(supported=len(supported),changed=len(changed),counterfactuals=len(counterfactuals),
                         marginal_diagnostics=len(violations),legacy_reproduction_error=reproduction_error)))


if __name__=='__main__':
    main()