import unittest

import evaluate_situation as situation
import score_cards as base


def probe(hand=None):
    return dict(hand_ids=[115,438] if hand is None else hand,role='midrange',own_turn=5,
        gold_before_play=12,opponent_gold_before_response=0,own_player_hp=8,enemy_player_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[dict(attack=6,health=6),dict(attack=3,health=3)],
        condition_state={'last_turn_gold_spent_on_spells':0},response_weights={'enemy_face':1})


class SituationEvaluatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards=base.load_cards()
        cls.reference,_=base.make_reference(cls.cards)

    def evaluate(self,data):
        return situation.evaluate(data,self.reference,self.cards)

    def test_emergency_survival_and_gold_headline_are_separate(self):
        r=self.evaluate(probe())
        spider,battleflies=r['action_windows']
        self.assertTrue(spider['window_known'])
        self.assertTrue(battleflies['window_known'])
        self.assertEqual(spider['death_probability'],1)
        self.assertEqual(battleflies['death_probability'],0)
        self.assertIsNone(r['card_quotes'][1]['net_model_gold'])
        self.assertEqual(battleflies['recommended_action'],'attack-1')

    def test_first_four_gold_turn_is_evaluable_without_invented_income(self):
        data=probe([438])
        data.update(own_turn=2,gold_before_play=4,own_player_hp=30,enemy_bodies=[dict(attack=2,health=2)])
        r=self.evaluate(data)
        self.assertTrue(r['card_quotes'][0]['pricing_supported'])
        self.assertTrue(r['action_windows'][0]['deployment_legal_now'])
        self.assertEqual(r['declared_current_state']['cumulative_base_gold_cap'],4)

    def test_observed_nonbase_gold_does_not_become_free_candidate_payment(self):
        data=probe([438])
        data.update(own_turn=2,gold_before_play=12,own_player_hp=30,enemy_bodies=[])
        r=self.evaluate(data)
        self.assertEqual(r['declared_current_state']['gold_before_play'],12)
        self.assertFalse(r['action_windows'][0]['actual_payment_made'])
        self.assertTrue(r['action_windows'][0]['deployment_legal_now'])

    def test_missing_future_dust_hand_is_unknown_not_zero(self):
        data=probe([43,138])
        data.update(own_player_hp=30,enemy_bodies=[])
        r=self.evaluate(data)
        self.assertFalse(r['card_quotes'][0]['pricing_supported'])
        self.assertTrue(any('hand_at_event' in x for x in r['card_quotes'][0]['unsupported']))
        self.assertTrue(r['card_quotes'][1]['pricing_supported'])
        self.assertFalse(r['action_windows'][1]['window_known'])

    def test_response_weights_apply_to_quote_and_action_paths(self):
        data=probe([115])
        data.update(own_player_hp=30)
        r=self.evaluate(data)
        self.assertEqual(r['action_windows'][0]['response_weights'],{'enemy_face':1})
        data['response_weights']={'none':1}
        z=self.evaluate(data)
        self.assertNotAlmostEqual(r['card_quotes'][0]['net_model_gold'],z['card_quotes'][0]['net_model_gold'])

    def test_unpayable_diagnostics_do_not_manufacture_legal_recommendation(self):
        data=probe([438]);data['gold_before_play']=3
        r=self.evaluate(data)
        self.assertFalse(r['action_windows'][0]['deployment_legal_now'])
        self.assertIsNone(r['action_windows'][0]['recommended_action'])


if __name__=='__main__':
    unittest.main()