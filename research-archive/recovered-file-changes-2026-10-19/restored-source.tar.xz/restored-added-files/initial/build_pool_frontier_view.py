"""Render paid cost-bucket comparisons without inventing a common scalar."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'research-runs/pool-frontier-v01'
OUT=HERE/'experiments/pool-frontier-v01'

HTML=r'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Undercards · 各费用的用途选择</title><style>
body{max-width:1200px;margin:30px auto;padding:0 20px;font:15px system-ui;color:#263548;background:#f5f7fa}p{line-height:1.7}.panel{padding:20px;margin:18px 0;background:white;border:1px solid #d8e0e8;border-radius:8px}select{padding:8px;margin:5px 15px 5px 0}table{border-collapse:collapse;width:100%;font-size:14px}td,th{padding:10px;border-bottom:1px solid #dde5ee;text-align:left}tr.leader{background:#e9f7ed}tr.unknown{color:#6c7782}tbody tr{cursor:pointer}pre{white-space:pre-wrap;overflow-wrap:anywhere;max-height:450px;overflow:auto}a{color:#07649c}.scroll{overflow-x:auto}.muted{color:#586c7e}
</style><h1>各费用的用途选择</h1>
<p>同一费用桶、同一真实现金和敌方回应下，比较<strong>保证用途时可共同保证的玩家HP</strong>。保命、清场、身体各自可以使用不同打法；不把这些列相加。若能保证获胜，推荐优先获胜。</p>
<p class="muted">8个原生费用桶含565张候选，60张在此输入闭合、505张未知；另列9/10G共同预算下的7个实际低费替代。<a href="README.md">方法与限制</a> · <a href="../../research-runs/pool-frontier-v01/scores.csv">四目标原始CSV</a> · <a href="../../research-runs/pool-frontier-v01/frontiers.json">含获胜的完整结果</a></p>
<section class="panel"><label>费用与范围 <select id="scene"></select></label><label>用途 <select id="task"></select></label><label><input type="checkbox" id="known" checked>只显示已闭合</label>
<p id="facts" class="muted"></p><p id="summary"></p><div class="scroll"><table><thead><tr><th>卡牌</th><th>印刷/当前价格</th><th>用途与联合HP</th><th>用途的HP代价</th><th>当前用途菜单</th></tr></thead><tbody id="rows"></tbody></table></div><p id="count" class="muted"></p></section>
<section class="panel"><p id="links"></p><pre id="detail"></pre></section>
<script type="application/json" id="data">__DATA__</script><script>
'use strict';
const DATA=JSON.parse(document.getElementById('data').textContent),el=id=>document.getElementById(id);
const opt=(target,value,label)=>{const x=document.createElement('option');x.value=value;x.textContent=label;target.append(x);};
const current=()=>DATA.groups.find(g=>g.key===el('scene').value);
const taskName=t=>({hp:'保命：玩家HP',win:'保证获胜',clear:'保命并清空敌场',focal_1_1:'焦点同体≥1攻1血',focal_2_2:'焦点同体≥2攻2血'}[t]);
function detail(g,r,t){
 el('links').replaceChildren();
 if(r.artifact){const a=document.createElement('a');a.href='../../research-runs/pool-frontier-v01/'+r.artifact;a.textContent='完整输入、支付与最坏路径';el('links').append(a);}
 el('detail').textContent=JSON.stringify({card:r.name,card_id:r.card_id,source:DATA.card_sources[String(r.card_id)],budget:g.budget,task:DATA.tasks[t],score:r.scores[t],menu_dominators:g.menu_dominators?.[String(r.card_id)]??null,independent_task_policies:true},null,2);
}
function render(){
 const g=current(),t=el('task').value,s=g.selections_by_task[t],all=g.rows,shown=all.filter(r=>!el('known').checked||r.scores[t].known);
 const names=ids=>ids.map(id=>all.find(r=>r.card_id===id).name).join('、')||'无';
 el('facts').textContent='共同现金'+g.budget+'G；己15/30HP、敌30HP；敌4攻4血与可付两张1G Gem；当前手牌只有候选，截止下一己方攻击结束。未来不能部署，无自然抽牌，位置与前方规则明确声明。';
 el('summary').textContent=(s.guaranteed_victory_takes_precedence?'获胜优先：':'本用途已支持领先：')+names(s.best_supported_candidate_ids)+'。'+(s.unresolved_candidate_ids.length?s.unresolved_candidate_ids.length+'张未知候选仍阻断全候选最优认证。':'仅在列出候选与本输入内闭合。')+(g.label==='shared-budget'?' 此组含不同原生费用，只比较相同现金下这些手持选项，不是原生费用桶冠军。':'');
 el('rows').replaceChildren();
 for(const r of [...shown].sort((a,b)=>Number(b.scores[t].known)-Number(a.scores[t].known)||Number(b.scores[t].feasible)-Number(a.scores[t].feasible)||(b.scores[t].guaranteed_player_hp??-Infinity)-(a.scores[t].guaranteed_player_hp??-Infinity)||a.card_id-b.card_id)){
  const v=r.scores[t],tr=document.createElement('tr');if(!v.known)tr.className='unknown';if(s.best_supported_candidate_ids.includes(r.card_id))tr.classList.add('leader');
  const cost=v.known&&v.guaranteed_player_hp!==null&&r.scores.hp.known?r.scores.hp.guaranteed_player_hp-v.guaranteed_player_hp:'—';
  const menu=!v.known?'未知':g.menu_frontier_ids?.includes(r.card_id)?'已知子集非支配菜单':g.menu_dominators?.[String(r.card_id)]?.length?'此输入有可替代菜单':'—';
  const value=!v.known?'未知':v.guaranteed_player_hp!==null?(t==='hp'?'玩家 ':'用途成立 · 玩家 ')+v.guaranteed_player_hp+'HP':'不能保证';
  for(const x of [r.name+' #'+r.card_id,r.printed_cost+' / '+r.printed_cost,value,cost,menu]){const td=document.createElement('td');td.textContent=x;tr.append(td);}
  tr.addEventListener('click',()=>detail(g,r,t));el('rows').append(tr);
 }
 el('count').textContent='闭合'+all.filter(r=>r.scores[t].known).length+'/'+all.length+'，当前显示'+shown.length+'。菜单非支配仅针对这些已查询用途；不是整卡永久支配。';
 if(shown.length)detail(g,shown[0],t);else{el('links').replaceChildren();el('detail').textContent='此原生费用桶当前没有闭合结果；展开未知可查看卡源。';}
}
for(const g of DATA.groups)opt(el('scene'),g.key,g.budget+'G · '+(g.label==='native'?'原生费用全部候选':'实际手持替代'));
for(const t of Object.keys(DATA.tasks))opt(el('task'),t,taskName(t));
el('scene').value='native-5';el('task').value='focal_2_2';
for(const id of ['scene','task','known'])el(id).addEventListener('change',render);render();
</script></html>'''


def main():
    result=json.loads((SOURCE/'frontiers.json').read_text())
    for name,expected in result['artifact_sha256'].items():
        assert hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()==expected
    inventory=json.loads((SOURCE/'inventory.json').read_text())
    for group in result['groups']:group['key']=group['label']+'-'+str(group['budget'])
    data=dict(groups=result['groups'],tasks=result['tasks'],card_sources={str(r['card_id']):r['source'] for r in inventory['rows']})
    encoded=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    html=HTML.replace('__DATA__',encoded);OUT.mkdir(exist_ok=True)
    (OUT/'score-explorer.html').write_text(html)
    receipt=dict(builder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        frontiers_sha256=hashlib.sha256((SOURCE/'frontiers.json').read_bytes()).hexdigest(),
        inventory_sha256=hashlib.sha256((SOURCE/'inventory.json').read_bytes()).hexdigest(),
        output_sha256=hashlib.sha256(html.encode()).hexdigest(),groups=len(data['groups']),
        candidate_context_rows=sum(len(g['rows']) for g in data['groups']))
    (OUT/'view-provenance.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))


if __name__=='__main__':main()