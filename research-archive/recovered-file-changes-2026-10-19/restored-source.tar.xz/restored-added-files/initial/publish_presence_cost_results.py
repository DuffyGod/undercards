"""Assemble executed production evidence without rerunning its searches."""
import csv
import hashlib
import json
from pathlib import Path

import conditional_card_score as score
import evaluate_situation as api
import paid_board_tactics as paid
import verify_research_integration as integration

HERE = Path(__file__).resolve().parent
RUN = HERE / 'research-runs/presence-magic-production-v01'
COST = HERE / 'research-runs/cost-magic-production-v01'
OUT = HERE / 'experiments/presence-magic-production-v01'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    OUT.mkdir(exist_ok=True)
    presence, cost = read(RUN / 'index.json'), read(COST / 'index.json')
    public = read(RUN / 'api-verification.json')
    regression = read(RUN / 'final-regression.json')
    first = read(RUN / 'final-paid027-regression.json')
    bounds = [read(root / 'independent-bounds.json') for root in (RUN, COST)]
    observation = read(HERE / 'research-runs/observed-status-fix-v01/verification.json')
    for document in (presence, cost, public, regression):
        for name, digest in document['source_hashes'].items():
            assert sha(HERE / name) == digest, name
    assert regression['passed'] and regression['current_source_test_coverage'] == 601
    assert regression['test_count'] == 13 and first['test_count'] == 542 and not first['passed']
    assert public['passed'] and observation['actual_frozen_source_execution']
    assert presence['source_stable'] and cost['source_stable']
    assert [b['matching_context_cells'] for b in bounds] == [26, 46]
    source = score.source_bindings(Path(__file__))
    common = dict(source_hashes=source, model_versions=dict(paid=paid.VERSION, api=api.VERSION, scorer=score.VERSION))
    write(OUT / 'comparison.json', dict(**common, presence=presence, target_cost=cost,
        meaning='Conditional jointly guaranteed hero HP; tasks may require different policies.',
        current_pool_view='pool-frontier-v03 remains explicitly frozen at paid0.25, not relabelled current.',
        global_gold=None, empirical_scene_probabilities=None, real_match_reliability_established=False))
    references = [RUN / 'index.json', COST / 'index.json', RUN / 'api-verification.json',
        RUN / 'final-regression.json', RUN / 'final-paid027-regression.json',
        RUN / 'independent-bounds.json', COST / 'independent-bounds.json',
        HERE / 'research-runs/observed-status-fix-v01/verification.json']
    write(OUT / 'verification.json', dict(**common, passed=True,
        regression=dict(current_registered_coverage=601, first_run_tests=542,
            first_run_failed_stale_transparency_expectation=True, first_run_successful_tests=529,
            corrected_module_actual_retest=13, source_identical_earlier_reuse=59,
            interpretation='529 + 13 + 59; not 601 freshly executed or a passing first 542-test suite.'),
        actual_production_probe_searches=presence['actual_queries'] + cost['actual_queries'],
        independent_context_cells=72, independent_single_card_pool_cells=12,
        full_vector_exhaustive_matches=presence['vector_matches'] + cost['full_vector_matches'],
        public_api_cli=public, actual_frozen_decoder_replay=True, observation_matrix_queries=30,
        evidence_sha256={str(p.relative_to(HERE)): sha(p) for p in references},
        limits=['Finite declared adversarial menus and horizons only.',
            'Rule hypotheses remain explicit; no server or empirical win-rate calibration.',
            'Prototype and production agreement checks integration, not independent numerical truth.']))
    with (OUT / 'scores.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=['family', 'context', 'card_id', 'task', 'known', 'feasible', 'hp'])
        writer.writeheader()
        for family, document in [('presence', presence), ('target_cost', cost)]:
            for row in document['rows']:
                writer.writerow(dict(family=family, **{k: row.get(k, '') for k in writer.fieldnames[1:]}))
    journal = HERE / 'experiments/current-integration-verification.json'
    old = read(journal)
    if not any(r.get('baseline_sha256') == regression['baseline_sha256'] for r in old['runs']):
        old['runs'].append(regression)
        write(journal, old)
    audit = integration.audit()
    assert audit['all_bound_sources_current'], audit['errors']
    write(OUT / 'active-source-audit.json', audit)
    print(json.dumps(dict(passed=True, coverage=601, probe_searches=95, independent_cells=84, active_source_errors=0)))


if __name__ == '__main__':
    main()