"""Resolve useful components before asking for a full future result vector."""
import hashlib
import json
from pathlib import Path
import build_delay_history_comparison as scenes
import paid_board_tactics as paid
import prove_idle_reply_bound as bounds
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/delay-history-v01'


def main():
    data=scenes.scene(spell=True,horizon='next_own_attack');data['max_plays']=4
    current=dict(data,horizon='enemy_attack',next_natural_draw_count=0,objectives=['guaranteed_hp'])
    record=dict(input=current,result=paid.evaluate(current))
    if not record['result']['complete_in_declared_scope']:raise AssertionError(record['result']['unknown'])
    negative=bounds.prove(data)
    hp=bounds.extend_guaranteed_hp(data,record)
    if not negative['bound_complete'] or not hp['hp_invariance_proved']:raise AssertionError((negative,hp))
    result=dict(input=data,current_search=record,counterstrategy_bound=negative,hp_extension=hp,
        purpose_resolution=dict(purpose_guaranteed=False,complete_for_requested_predicate=True),
        full_future_vector_optimized=False,
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        source_hashes={f:hashlib.sha256((HERE/f).read_bytes()).hexdigest() for f in
            ('build_multi_play_goal_resolution.py','build_delay_history_comparison.py','prove_idle_reply_bound.py',
             'paid_board_tactics.py','queued_delay.py','board_tactics.py')})
    (OUT/'multi-play-goal-resolution.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(guaranteed_hp=hp['guaranteed_hp_at_next_own_attack'],
        can_guarantee_joint_clear=False,eligible_attack_upper=negative['max_eligible_attack_upper'],
        enemy_health_minimum=negative['min_enemy_health_required'],full_future_vector_optimized=False)))


if __name__=='__main__':main()