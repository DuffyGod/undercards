"""Expose integer action truncation with unchanged native spell copies."""
import hashlib
import json
from pathlib import Path

import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/physical-play-scope-v01'


def main():
    cards=score_cards.load_cards()
    current=dict(own_player_hp=7,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
        hand_ids=[81]*5+[8],hand_base_costs=[0]*5+[8],gold_before_play=3,own_deck_ids=[],
        enemy_bodies=[dict(card_id=15,attack=12,health=5,max_health=5,current_card_cost=5,base_cost=5)],
        opponent_hand_ids=[],opponent_gold_before_response=0,horizon='enemy_attack',node_limit=20000,
        objectives=['guaranteed_hp','purpose'],
        purpose_constraints=dict(min_own_player_hp=1,min_own_board_attack=6,min_own_board_health=4))
    future=dict(current,hand_ids=[81]*5+[108],hand_base_costs=[0]*5+[6],gold_before_play=1,
        enemy_bodies=[],max_plays=0,horizon='next_own_attack',next_own_gold_income=0,
        next_natural_draw_count=0,
        purpose_constraints=dict(min_own_player_hp=1,min_own_board_attack=3,min_own_board_health=6))
    cases=[]
    for name,scene,field in [('current',current,'max_plays'),('future',future,'next_max_plays')]:
        for limit in (4,'all_physical'):
            data=dict(scene,**{field:limit})
            alpha=paid.evaluate(data,cards)
            exhaustive=paid.evaluate(dict(data,search_algorithm='exhaustive'),cards)
            if not alpha['complete_in_declared_scope'] or not exhaustive['complete_in_declared_scope']:
                raise AssertionError((name,limit,alpha['unknown'],exhaustive['unknown']))
            if [o['objective_vector'] for o in alpha['objectives']] != [o['objective_vector'] for o in exhaustive['objectives']]:
                raise AssertionError('Full vector mismatch')
            cases.append(dict(window=name,declared_limit=limit,input=data,result=alpha,
                exhaustive_full_vector_equal=True,
                guaranteed_hp=alpha['objectives'][0]['metrics']['own_player_hp'],
                purpose_guaranteed=alpha['objectives'][1]['purpose_guaranteed']))
    result=dict(version='native-physical-play-scope-probe-0.1.0',cases=cases,
        source_hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in
            ('build_physical_play_scope_comparison.py','paid_board_tactics.py','board_tactics.py','alpha_beta_search.py')},
        limitations=['Five native Fortune physical copies are an action/copy-accounting probe, not a legal ordinary deck-copy-limit claim.',
            'Source card stats and text are unchanged. Fortune also grants real enemy cash; the declared enemy hand remains explicitly empty.',
            'Known physical copy coverage does not implement unknown generated-hand cards or recycling.',
            'No empirical scene frequencies, universal prices or whole-game victory probability are inferred.'])
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    lines=['# 出牌上限不能等同实际完整回合','',
        '旧整数最多4次保持兼容；新增all_physical用所有已知物理手牌/库副本形成有限界，未来副本仍必须实际抽到，不能预加载或复用。',
        '', '| 窗口 | 上限 | 保证HP | 目的保证 |','|---|---|---:|---|']
    for case in cases:
        lines.append('| '+case['window']+' | '+str(case['declared_limit'])+' | '+str(case['guaranteed_hp'])+' | '+str(case['purpose_guaranteed'])+' |')
    lines += ['', '当前窗口是7/30HP、3G、五张原生Fortune（0G双方各+1G）和Toriel，敌12/5 Aaron、空敌手；四次不足以凑8G出Toriel，全物理模式真实支付五次Fortune后Toriel8G，保6HP并留压力。未来窗口改1G、空敌场、五Fortune和Rock6G，当前禁出牌，下一收入0，六次真实付款才能兑现Rock身体。',
        '', '五张同牌是物理副本/行动原语探针，不宣称普通构筑允许五张同牌；没有合成卡牌数值。实际合法三张手牌的独立用途反例见[卡位替换](../replacement-slot-v01/comparison.md)：等待后Kawkaw+Toriel或Jerry+Kawkaw双付改变压力保证，HP却不变。',
        '', '全部四场景的两个完整向量与exhaustive一致。库抽入、仅用一次、费用/现金和预算失败另有回归检查；算法一致不证明服务器实现或实战分布。',
        '', '`python analysis/monster-value-heuristic/build_physical_play_scope_comparison.py`','']
    (OUT/'comparison.md').write_text('\n'.join(lines))
    print([(c['window'],c['declared_limit'],c['guaranteed_hp'],c['purpose_guaranteed']) for c in cases])


if __name__=='__main__':main()