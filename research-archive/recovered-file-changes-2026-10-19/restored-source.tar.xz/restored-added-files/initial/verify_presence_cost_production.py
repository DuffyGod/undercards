"""Public API, real CLI and focal-copy scores after the observation repair."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import conditional_card_score as score
import evaluate_situation as api
import paid_board_tactics as paid

HERE=Path(__file__).resolve().parent
OUT=HERE/'research-runs/presence-magic-production-v01'
COST=HERE/'research-runs/cost-magic-production-v01'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def public_input(scene):
    obs={k:copy.deepcopy(scene.get(k,[] if 'bodies' in k else 0)) for k in ('hand_ids','gold_before_play',
        'opponent_gold_before_response','own_player_hp','enemy_player_hp','ally_bodies_before_play','enemy_bodies')}
    params={k:copy.deepcopy(v) for k,v in scene.items() if k not in obs and k not in
        ('own_player_max_hp','enemy_player_max_hp','hand_costs','opponent_hand_known')}
    return dict(obs,role='midrange',own_turn=10,hand_costs=scene['hand_costs'],paid_board_scenario=params,
        callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30))

def main():
    bindings=score.source_bindings(Path(__file__));cases=[]
    sources=[('bird-dummy5',OUT/'bird-dummy5.json','win',dict(min_own_player_hp=1,max_enemy_player_hp=0),1),
        ('dogs-gem',OUT/'dogs-gem.json','body8_4',dict(min_own_player_hp=1,min_own_body_attack=8,min_own_body_health=4),14),
        ('cost-native',COST/'single-cost3-card443.json','body4_8',dict(min_own_player_hp=1,min_own_body_attack=4,min_own_body_health=8),15)]
    for label,path,task,constraints,hp in sources:
        raw=json.loads(path.read_text());scene=copy.deepcopy(raw['input']);scene.update(objectives=['purpose'],purpose_constraints=constraints)
        incoming=public_input(scene);write(label+'.api.input.json',incoming)
        direct=paid.evaluate(scene);value=api.evaluate(incoming)
        assert direct['complete_in_declared_scope'] and value['paid_board_tactics']==direct
        result=direct['objectives'][0];assert result['purpose_guaranteed'] and result['metrics']['own_player_hp']==hp
        assert raw['results'][task]['guaranteed_player_hp']==hp
        cmd=[sys.executable,str(HERE/'evaluate_situation.py'),'--input',str(OUT/(label+'.api.input.json')),
            '--output',str(OUT/(label+'.api.cli.json'))]
        run=subprocess.run(cmd,capture_output=True,text=True,cwd=HERE)
        (OUT/(label+'.api.stdout.log')).write_text(run.stdout);(OUT/(label+'.api.stderr.log')).write_text(run.stderr)
        assert run.returncode==0 and json.loads((OUT/(label+'.api.cli.json')).read_text())==json.loads(score.canonical(value))
        cases.append(dict(case=label,hp=hp,api_direct_cli_full_json_equal=True,command=cmd,
            input_sha256=sha(OUT/(label+'.api.input.json')),output_sha256=sha(OUT/(label+'.api.cli.json'))))
    raw=json.loads((OUT/'later-dog-outlet.json').read_text());scene=copy.deepcopy(raw['input'])
    for key in ('hand_ids','hand_costs','hand_base_costs'):scene.pop(key)
    config=dict(scene=scene,candidate_ids=[43],background_hand=[dict(card_id=i,current_cost=6,base_cost=6) for i in (47,46)],
        tasks=dict(body7_7=raw['tasks']['body7_7']),include_delay=False,selection_task='body7_7')
    write('focal-later.input.json',config);direct=score.compare(config)
    cmd=[sys.executable,str(HERE/'conditional_card_score.py'),'--input',str(OUT/'focal-later.input.json'),
        '--output',str(OUT/'focal-later.cli.json')]
    run=subprocess.run(cmd,capture_output=True,text=True,cwd=HERE)
    (OUT/'focal-later.stdout.log').write_text(run.stdout);(OUT/'focal-later.stderr.log').write_text(run.stderr)
    assert run.returncode==0
    cli=json.loads((OUT/'focal-later.cli.json').read_text());assert cli==json.loads(score.canonical(direct))
    focal=cli['rows'][0]['scores']['body7_7'];assert focal['guaranteed_player_hp']==11
    assert focal['search']==json.loads(score.canonical(raw['results']['body7_7']['search']))
    all_scores=list(cli['removal_baseline']['scores'].values())+[v for row in cli['rows'] for v in row['scores'].values()]
    actual_attempts=sum(v.get('search') is not None for v in all_scores)
    assert cli['actual_search_queries']==6 and actual_attempts==5
    assert bindings==score.source_bindings(Path(__file__))
    presence=json.loads((OUT/'index.json').read_text());cost=json.loads((COST/'index.json').read_text())
    old_presence=json.loads((HERE/'research-runs/presence-magic-v01/index.json').read_text())
    old_cost=json.loads((HERE/'research-runs/cost-magic-v01/index.json').read_text())
    shape=lambda r:{k:r[k] for k in ('known','feasible','hp')}
    assert [shape(r) for r in presence['rows']]==[shape(r) for r in old_presence['rows']]
    assert [shape(r) for r in cost['rows']]==[shape(r) for r in old_cost['rows']]
    observation=json.loads((HERE/'research-runs/observed-status-fix-v01/verification.json').read_text())
    assert observation['actual_frozen_source_execution'] and observation['old_guaranteed_win'] and not observation['current_guaranteed_win']
    write('api-verification.json',dict(passed=True,source_hashes=bindings,source_stable=True,
        models=dict(paid=paid.VERSION,api=api.VERSION,scorer=score.VERSION),public_cases=cases,
        actual_public_paid_objective_searches=9,focal_compare_cli_full_json_equal=True,
        focal_actual_task_evaluations=2*cli['actual_search_queries'],focal_actual_core_search_attempts=2*actual_attempts,
        focal_absent_copy_evaluations_without_search=2,guaranteed_focal_body_hp=11,
        prototype_presence_cells_unchanged=len(presence['rows']),prototype_cost_cells_unchanged=len(cost['rows']),
        observation_fix_sha256=sha(HERE/'research-runs/observed-status-fix-v01/verification.json'),
        note='Public paid body clauses are board-scoped; these three cases have exactly one body able to meet their threshold. Focal later-Dog uses the real conditional scorer CLI and exact physical index2.'))
    print(json.dumps(dict(passed=True,public_cases=3,focal_cli_hp=11,presence_cells=len(presence['rows']),cost_cells=len(cost['rows']))))

if __name__=='__main__':main()