# 费用、联合目的与可追溯的模型反馈

2026-10-11。公共入口 `evaluate_situation.py` 0.8.1，付费搜索核 0.2.0。此次结果是条件对战判断；没有给预设场景赋实战频率，也没有宣布通用Gold标准已完成。

## 完整2G桶的条件最优

共同条件：我方3/30HP、空场、2G、仅候选一张手牌、最多一个当前Play；空库、下次疲劳1、无自然抽牌。候选非Generated且无身材修改，双方墓地空、本回合及上回合无己方Play/spell，新怪物场上回合计数从0开始；无SOUL/神器/槽附魔效果。敌玩家30HP，6/5 Aaron，可另有2/3 Froggit；敌方没有新怪物部署。法术面板额外声明敌持有Punishment且能支付3G。

全部51张普通2G怪物均纳入来源证明，包括资源、随机、Loop、Dust及未完整模拟的卡。卡文、生成物引用、上下界与尚缺裁定逐条保存；不能把目标证明当作整卡完整模拟。

| 共同窗口中的敌方条件 | 全2G桶最优保证HP | 确定达到者 |
|---|---:|---|
| 单敌，无新法术 | 3 | Certificate、Ralsei Dummy、Pixel Vase |
| 双敌，无新法术 | 2 | **Pixel Vase，唯一** |
| 单敌，Punishment＋3G | 0 | 没有2G保命者 |
| 双敌，Punishment＋3G | 0 | 没有2G保命者 |

Pixel Vase的双敌打法是将弱敌2/3变成1/2。若强敌先撞死2/2 Taunt，弱敌打脸1，我方保2；若弱敌先撞，弱敌死、Vase剩1HP，强敌再撞，我方保3。对手可选择前者，所以保证为2。削弱强敌则存在致死回应。

Snow Poff的空库过滤Draw仍未知，单敌保留[0,2]；上界不够推翻3HP冠军。Bridge Seed普通Draw消耗疲劳1后，只能保2。Worm、Dog Cone、Mizzle至多把玩家治疗到5HP，无法阻止6攻直接打脸；这些目标失败证明不依赖完整模拟其无关后续资源。

四种面板下，全部2G候选均不能保证“存活且清掉Aaron”，双敌时也不能保证存活且清掉两敌。保护源没有足够的即时攻击或强制反击来清强敌；不把不同路线的保命、伤害结果拼接。

[完整来源审查](two-cost-source-review.md)，以及 `two-cost-*.json` 的复算、上下界及运行时未知。来源发生任何费用、身材、文字或引用生成物变化，证书拒绝沿用。更便宜的1G Kawkaw在双敌Punishment窗口仍保1，说明本目的下2G并不比1G有效；该结论仍不说明长期构筑价值。

## 同一手牌的条件推荐怎样变化

手牌固定为Dummy、Kawkaw、Pixel Vase、Tiny Bookshelf、Battleflies；4G、3HP、空场、最多一个Play、两个Need均成立。敌初始6/5＋2/3，玩家30HP。每张首出保留同一完整物理手牌；先选Magic目标，再面对所有合法施法/攻击交错。这里敌玩家不会被这些单Play路线击败，因此保命排序中的HP有该窗口的下界意义。

| 敌方条件 / 唯一干预 | Dummy | Kawkaw | Pixel Vase | Tiny Bookshelf | Battleflies | 保命主推荐 |
|---|---:|---:|---:|---:|---:|---|
| 没有法术 | 1 | 1 | 2 | 3 | 1 | Tiny Bookshelf |
| 有Punishment，只有2G | 1 | 1 | 2 | 3 | 1 | Tiny Bookshelf |
| 有Punishment，3G | 0 | 1 | 0 | 1 | 1 | Battleflies |
| 上行仅大怪HP从5到6 | 0 | 1 | 0 | 1 | 0 | Tiny Bookshelf |
| 3G法术基准仅小怪ATK从2到3 | 0 | 0 | 0 | 0 | 0 | **此手牌没有保命路线** |
| 3G法术基准仅小怪ATK从2到1 | 0 | 2 | 0 | 2 | 2 | Battleflies |

0表示敌能致死。保命HP平局之后，公开排序偏好清除敌攻击，所以付费基准选择Battleflies；这不是经过实战校准的构筑价值。小怪多1攻击时，程序仍可给出败局中的最佳动作，但不得把该动作称为救命建议。

该表检验三个通用机制：法术必须实际付得起；Haste必须达到击杀阈值；另一敌人的脸伤必须低于剩余生命。改变一个数值会影响多张卡的生命保证与主推荐，没有按卡名调惩罚分。原始输入、所有首出目标分支及最坏轨迹见 `hand-decision-boundaries.json`。

## 搜索目标的两项修正

新增 `purpose_constraints`＋`objectives:["purpose"]`，直接最大化对目标的保证。支持最低己方HP、最高敌方HP、最高敌攻击总和、最高敌存活数、最低己方存活数；要求全部约束在同一个终点成立，并要求我方存活。对手先寻找能破坏任一约束的路线。未定机制仍阻止完整保证。

例如 `{"min_own_player_hp":3,"max_enemy_living_count":0}`，表示保全3HP并清场。此前完整七张手牌的预算比较已经改用这个联合谓词逐预算搜索，最低3G全保命、7G全保命并清场，以及Need假/敌HP+1时8G的结论仍成立；[输入与策略](../reliable-defense-v01/comparison.md)保留。

新增 `objectives:["guaranteed_hp"]`，直接最大化终点HP下界。旧`survive`仍优先胜负：反例中敌可选择杀掉我方待命怪物，留下未结束的3HP路线；也可打脸2，让我下回合赢但只剩1HP。胜负优先的敌排序挑前者，其HP列不能声称是独立下界。直接HP目标得到1。两者是不同目的，不能隐式混用。自动逐卡比较已经使用直接HP目标。

## 已反馈的真实缺陷与没有改动的分数

旧`hand_survival`在上述付费窗口仍偏好Dummy；Dummy会死，同费Kawkaw能活。这是响应抽象缺口，而非价格差造成的表面冲突。公共入口0.8.1保留旧固定回应计算为`diagnostic_only`，把其原推荐移入`legacy_best_known_death_reducing_hand_index`，撤销当前推荐字段；CLI也不再将旧概率、旧路线摘要并排当作当前建议。是否能建议行动由付费搜索决定；其未知时不回退为旧模型的确定建议。

原始失败记录 `heuristic-feedback.json`冻结；`heuristic-feedback.current.json`记录修复后的接口及同样的物理结果。完整Gold报价在此探针中都为null，因此没有据此拟合某牌加减几Gold。后续有完整可比报价时，这些条件真值才可检验其是否解释解牌导致的排序翻转。

## 场景合理性与效率检查

**当前场景不够代表真实对局。** 它们偏重空场、低血、单次Play、已知敌手、空库，以及短攻击窗。暂未验证常见健康生命、正常牌库、双方已有场面、等待与携带、多回合付费，以及SOUL/神器等场景的实际频率。数值反事实验证机制，不能验证天梯代表性；没有真实联合数据时不补场景权重。

本轮效率检查产生了三个具体调整：

- 联合目的直接搜索，避免长期积累无法拼接的分项表；同时单独提供真正的HP保证。
- 新增 `compare_monster_purposes.py`，按费用自动遍历完整候选，不依赖手选代表卡。已实际遍历2–4G、两个声明敌手面板；未实现的候选仍在结果中，阻止全桶冠军。支持子集的领先者只作诊断。
- 来源目标上界可排除无关复杂机制，不为证明一次保命实现所有未来资源。完整2G因此得到实际结论；3–4G历史与位置条件仍能推翻当前排名，优先解决这些实质阻塞，暂停发布无条件冠军。

Totemic Guard的Delay可能根据墓地6G怪物治疗5；空库不表示墓地空。Chessboard根据Piece墓地召唤Ponman并明文触发Magic，可能产生治疗、Haste和多重保护。这些历史不能被不含墓地的预设场景抹去。Delay确实是Play时入队、回合末执行、来源提前死亡也执行；条件检查时点、COST筛选字段、位置及召唤顺序等缺裁定的部分继续列为未知，不能把Delay实现为普通留场Turn end。

下一优先是补足这些会改变冠军的历史/位置条件与队列，并接回已有共同绝对终点下的未来付款、等待选择。真实场景校准需要版本化对局中的手牌、金币、场面、历史、SOUL/神器和行动结果；这影响频率与构筑强度校准，不阻止继续实现机制。每次效率检查应促成可验证决策或淘汰方案，不以新增行数、检查数作为进度。

## 复算

仓库根目录：

```sh
python analysis/monster-value-heuristic/certify_two_fee_rescue.py --panel two_attacks --output /tmp/two-cost-certificate.json
python analysis/monster-value-heuristic/compare_monster_purposes.py --input analysis/monster-value-heuristic/experiments/fee-purpose-v02/two-attacks-paid.input.json --output /tmp/purpose-pool.json
python analysis/monster-value-heuristic/build_hand_decision_boundaries.py
python analysis/monster-value-heuristic/experiments/fee-purpose-v02/heuristic-feedback.py
```

两个逐卡遍历输入可改已观察场面和目标；缺省预算是候选印刷费用，也可明确共同余额。实际动态手费须由`candidate_actual_costs`声明，印刷价不能冒充手费。来源证书是固定条件入口，不自动适用于改写后的任意场景。此次相关检查通过；这些检查和来源审查不能充当服务器规则或真实对局有效性的独立验证。