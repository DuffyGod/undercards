"""A finite strategy sandwich for richer Burger, with no search imports."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    raw=json.loads((HERE/'public-card30.input.json').read_text());data=raw['scene']
    cards={c['id']:c for c in json.loads((HERE/'native-snapshot.json').read_text())['cards']}
    assert (cards[196]['attack'],cards[196]['health'],cards[196]['cost'],cards[196]['effect_readable'])==(1,1,0,'')
    assert (cards[270]['attack'],cards[270]['health'],cards[270]['cost'],cards[270]['effect_readable'])==(4,4,3,'')
    assert cards[30]['effect_readable']=='Taunt. Turn end: Both players earn 5 GOLD.'
    assert (cards[509]['cost'],cards[509]['attack'],cards[509]['health'],cards[509]['effect_readable'])==(
        5,4,6,"Haste. Turn end: If this didn't attack this turn, heal 3 HP to you.")
    assert cards[598]['effect_readable']=='Deal 1 DMG.'
    rules=ROOT.parents[1]/'skills/undercards/references/rules.md'
    assert 'Haste 只打怪物' in rules.read_text()
    assert data['hand_ids']==[30] and data['own_deck_ids']==[196] and data['opponent_deck_ids']==[196,196]
    assert data['next_own_gold_income']==3 and data['next_opponent_gold_income']==4
    assert data['opponent_gold_before_response']==2 and data['own_player_hp']==15
    assert [data[k] for k in ('first_opponent_natural_draw_count','next_natural_draw_count','next_opponent_natural_draw_count')]==[1,1,1]
    # Lower strategy: never deploy. No source can buff an enemy or damage us
    # except Thrashing twice, the first Tiny once, and the two single Gems.
    # No current Burger => Long costs5 > enemy2 in its first turn. When it
    # becomes payable in its second turn, fresh Haste cannot hit the hero.
    lower=15-(4+4+1+1+1)
    # Upper reply branches cover every legal own action in this two-card
    # hand. The initial Tiny is not drawn until the next own start.
    upper_branches={
        'Hold current, hold next or deploy only drawn Tiny':15-(4+2)-(4+1),
        'Hold current, deploy Burger next, optionally drawn Tiny':15-(4+2)-(4+1),
        'Deploy Burger current, enemy Long kills it before next own turn':max(0,15-(4+2)-(4+4+1)),
    }
    # Enemy first draws and pays Tiny0 and both Gems. With early Burger it
    # also pays Long5 from the real7; otherwise waits with that Long. In the
    # late-Burger branch its next4 income plus Burger5 pays Long5, whose
    # fresh monster-only Haste removes Taunt. Existing Thrashing+Tiny face5.
    upper=max(upper_branches.values());assert lower==upper==4
    result=json.loads((HERE/'public-card30.json').read_text())
    assert result['known'] and result['guaranteed_player_hp']==4
    output=dict(imports_production_model=False,policy_lower_bound=lower,adversary_upper_bound=upper,
        matched_production_hp=4,upper_branches=upper_branches,builder_sha256=sha(Path(__file__)),
        source_snapshot_sha256=sha(HERE/'native-snapshot.json'),haste_rules_sha256=sha(rules),
        result_sha256=sha(HERE/'public-card30.json'),
        assumptions=['Same declared current and next turns, no further rounds or library unknowns.',
            'Haste permits fresh monster attacks, not fresh player attacks.',
            'Every income, draw, original/source cost and payment stays as declared.',
            'All involved effects are position blind; original physical unknown is not erased.'],
        scalar_only=True,whole_vector_or_real_match_claim=False)
    (HERE/'independent-bounds.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(output,ensure_ascii=False))

if __name__=='__main__':main()