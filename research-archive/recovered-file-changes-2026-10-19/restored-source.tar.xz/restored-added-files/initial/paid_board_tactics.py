"""Exact declared-hand punishment and attack search, extending board_tactics.

Both players spend real currency and physical spell copies. Spells and attacks
can interleave; enemy payments are never credited to us. No response frequency
or arbitrary punishment surcharge is fitted here.
"""
from __future__ import annotations

import argparse
import copy
from dataclasses import dataclass, replace
import json
from pathlib import Path
import re

import board_tactics as board
import finite_conditions
import score_cards
import spell_window

VERSION = 'declared-paid-board-search-0.1.0'


class UnknownMechanic(Exception):
    pass


@dataclass(frozen=True)
class PaidState(board.State):
    enemy_hand: tuple = ()


def spell_spec(card):
    text = card.get('effect_readable', '').strip()
    extra = {
        'Silence a monster.': ('silence', 'monster'),
        'Silence and kill a monster.': ('silence_kill', 'monster'),
    }
    if text in extra:
        kind, target = extra[text]
        return {'spell': [dict(kind=kind, target=target)], 'unknown': []}
    effects, unknown = spell_window.parse(card)
    return {'spell': effects, 'unknown': unknown}


class PaidSearch(board.BoardSearch):
    def __init__(self, cards, data):
        by = {c['id']: c for c in cards}
        ids = data.get('hand_ids', [])
        costs = data.get('hand_costs', [])
        if not isinstance(ids, list) or len(ids) > 7 or (costs and len(costs) != len(ids)):
            raise ValueError('At most seven known physical own hand copies and matching costs')
        if any(type(cid) is not int or cid not in by for cid in ids):
            raise ValueError('Known card IDs required')
        monster_indexes = [i for i, cid in enumerate(ids) if by[cid]['card_type'] == 'monster']
        initial = dict(data, hand_ids=[ids[i] for i in monster_indexes])
        initial['hand_costs'] = [costs[i] for i in monster_indexes] if costs else []
        super().__init__(cards, initial)
        self.data = copy.deepcopy(data)
        monster_specs = iter(self.hand)
        self.hand = []
        for i, cid in enumerate(ids):
            if by[cid]['card_type'] == 'monster':
                self.hand.append(next(monster_specs))
            elif by[cid]['card_type'] == 'spell':
                c = copy.deepcopy(by[cid])
                if costs:
                    c['cost'] = board.finite_number(costs[i], 'actual spell cost')
                self.hand.append((c, spell_spec(c)))
            else:
                raise ValueError('Only monster and spell hand cards supported')
        eids = data.get('opponent_hand_ids', [])
        ecosts = data.get('opponent_hand_costs', [])
        if not isinstance(eids, list) or len(eids) > 7 or (ecosts and len(ecosts) != len(eids)):
            raise ValueError('At most seven known physical opponent hand copies and matching costs')
        self.enemy_hand = []
        for i, cid in enumerate(eids):
            if type(cid) is not int or cid not in by:
                raise ValueError('Known opponent card IDs required')
            c = copy.deepcopy(by[cid])
            if ecosts:
                c['cost'] = board.finite_number(ecosts[i], 'opponent actual spell cost')
            if c['card_type'] == 'spell':
                spec = spell_spec(c)
            else:
                spec = {'unknown': ['Opponent monster deployment remains unimplemented']}
            self.enemy_hand.append((c, spec))

    def spec(self, c, observed=False, collect_unknown=True):
        # Reuse the established three-valued Need registry. It controls Magic,
        # not whether the body may be deployed. This adapter has current plays
        # only, so last-turn history cannot silently move with a future turn.
        changed = copy.deepcopy(c)
        text = changed.get('effect_readable', '')
        need = finite_conditions.parse_need(text)
        condition = None
        if need is not None and not observed:
            condition = finite_conditions.evaluate_condition(need, self.data.get('condition_known_state', {}))
            if condition['value'] is not None:
                for clause in finite_conditions.NEED_CLAUSES:
                    text = text.replace(clause + ' ', '').replace(clause, '')
                if not condition['value']:
                    text = re.sub(r'Magic:.*$', '', text).strip()
                changed['effect_readable'] = text
        result = super().spec(changed, observed=observed, collect_unknown=False)
        if result['unknown']:
            prefix = re.match(r'((?:(?:Haste|Taunt|Charge|Armor|Dodge \(\d+\))\. )*)', text)[0]
            rest = text[len(prefix):]
            if (m := re.fullmatch(r'Magic: Gain \+(\d+) ATK(?: and (Taunt))?\.', rest)):
                result['magic'] = ('self_atk_taunt', int(m[1]), bool(m[2]))
                result['unknown'] = []
        if condition is not None:
            result['condition'] = condition
            if condition['value'] is None:
                result['unknown'].append('Need unknown: ' + condition['reason'])
        result['evidence'] = c.get('effect_readable', '')
        if collect_unknown:
            self.unknown.extend('Card ' + str(c['id']) + ': ' + x for x in result['unknown'])
        return result

    def root(self):
        original = super().root()
        # Enemy damage spells now can kill multiple OWN summoners at once.
        summoners = [u for u in original.own if u.dust and u.dust[0] in ('summon', 'summon_many')]
        if len(summoners) > 1 and any(u.dust[0] == 'summon_many' and u.dust[1] > 1 for u in summoners):
            self.unknown.append('Multiple own Dust summoners competing after enemy AoE: queue unknown')
        return PaidState(**original.__dict__, enemy_hand=tuple(range(len(self.enemy_hand))))

    def magic(self, s, i, u, spec):
        if spec['magic'] and spec['magic'][0] == 'self_atk_taunt':
            _, amount, taunt = spec['magic']
            own = tuple(replace(v, attack=v.attack+amount, taunt=v.taunt or taunt) if v.key == u.key else v for v in s.own)
            return [(dict(kind='deploy', hand_index=i, card_id=u.card_id, magic=spec['magic']), replace(s, own=own))]
        return super().magic(s, i, u, spec)

    def silence(self, u, *, also_kill=False):
        # Ability-only reset is verified by the status rule. Removing modified
        # stats (especially injured max HP) has no complete source ruling yet.
        # Do not guess, or silently omit that legal enemy branch.
        if not also_kill:
            base = self.by.get(u.card_id)
            if base and (u.attack != base['attack'] or u.max_health != base['health']):
                raise UnknownMechanic('Silence stat reset on modified body ' + u.key + ' is unverified')
        return replace(u, taunt=False, armor=False, dodge=0, start=None, end=None, dust=None,
                       before_attack_face=0, health=0 if also_kill else u.health)

    @staticmethod
    def targets(s, target, caster):
        other = 'own' if caster == 'enemy' else 'enemy'
        bodies = lambda side: [(side, i) for i, u in enumerate(getattr(s, side)) if u.health > 0]
        allies, enemies = bodies(caster), bodies(other)
        owner = (caster + '_player', None)
        opponent = (other + '_player', None)
        if target.startswith('all_'):
            return [enemies if target == 'all_enemy_monsters' else enemies+[opponent] if target == 'all_enemies'
                    else allies+enemies if target == 'all_monsters' else allies]
        if target == 'opponent': return [[opponent]]
        if target in ('owner', 'both'): return [[owner] if target == 'owner' else [owner, opponent]]
        choices = enemies[:]
        if target in ('monster', 'monster_or_owner', 'wide_entity'): choices += allies
        if target in ('monster_or_owner', 'wide_entity'): choices += [owner]
        if target in ('enemy_entity', 'wide_entity'): choices += [opponent]
        return [[x] for x in choices]

    def casts(self, s, caster):
        physical = s.enemy_hand if caster == 'enemy' else s.hand
        menu = self.enemy_hand if caster == 'enemy' else self.hand
        balance = 'enemy_gold' if caster == 'enemy' else 'gold'
        handfield = 'enemy_hand' if caster == 'enemy' else 'hand'
        for i in physical:
            card, spec = menu[i]
            if card['card_type'] != 'spell' or spec['unknown'] or card['cost'] > getattr(s, balance): continue
            effect = spec['spell'][0]  # parser admits one complete primitive
            for targets in self.targets(s, effect['target'], caster):
                changes = {balance: getattr(s, balance)-card['cost'], handfield: tuple(j for j in physical if j != i)}
                if caster == 'own': changes['plays'] = s.plays+1
                paid = replace(s, **changes)
                child = paid
                for side, j in targets:
                    if side.endswith('_player'):
                        key = 'own_hp' if side == 'own_player' else 'enemy_hp'
                        if effect['kind'] == 'gold':
                            cash = 'gold' if side == 'own_player' else 'enemy_gold'
                            child = replace(child, **{cash: getattr(child, cash)+effect['amount']})
                        else:
                            child = replace(child, **{key: max(0, getattr(child, key)-effect['amount'])})
                    else:
                        units = list(getattr(child, side)); u = units[j]
                        if effect['kind'] == 'damage': u = board.hurt(u, effect['amount'])
                        elif effect['kind'] == 'kill': u = replace(u, health=0)
                        elif effect['kind'] in ('silence', 'silence_kill'):
                            u = self.silence(u, also_kill=effect['kind'] == 'silence_kill')
                        elif effect['kind'] == 'buff':
                            u = replace(u, attack=u.attack+effect['attack'], health=u.health+effect['health'],
                                        max_health=u.max_health+effect['health'])
                        units[j] = u
                        child = replace(child, **{side: tuple(units)})
                child = self.deaths(paid, child)
                yield dict(kind='cast_spell', side=caster, hand_index=i, card_id=card['id'],
                           paid_gold=card['cost'], targets=targets), child

    def deploys(self, s):
        if s.phase == 1:
            yield from self.casts(s, 'enemy')
        elif s.phase == 0 and s.plays < self.max_plays:
            # A full board blocks monsters but never blocks a spell.
            yield from self.casts(s, 'own')
            if sum(u.health > 0 for u in s.own) < 4:
                for i in s.hand:
                    c, spec = self.hand[i]
                    if c['card_type'] != 'monster' or c['cost'] > s.gold or spec['unknown']: continue
                    u = self.unit(c, spec, 'hand:'+str(i))
                    child = replace(s, own=s.own+(u,), gold=s.gold-c['cost'],
                                    hand=tuple(j for j in s.hand if j != i), plays=s.plays+1)
                    yield from self.magic(child, i, u, spec)

    def solve(self, root, mode):
        try:
            return super().solve(root, mode)
        except UnknownMechanic as error:
            return dict(search_complete=False, objective=mode, visited_states=self.nodes,
                        unknown=[str(error)], metrics=None, principal_variation=[])


def evaluate(data, cards=None):
    cards = score_cards.load_cards() if cards is None else cards
    search = PaidSearch(cards, data)
    root = search.root()
    unknown = list(search.unknown)
    # Conservative reachability upper bounds: end income occurs after current
    # own casts, but own end income is available in the enemy cast phase.
    dustcash = lambda u: u.dust[1] if u.dust and u.dust[0] == 'cash' else 0
    spellcash = lambda spec: sum(e['amount'] for e in spec.get('spell', []) if e['kind'] == 'gold')
    own_upper = root.gold + sum(dustcash(u) for u in root.own)
    own_upper += sum(spec.get('dust', (None, 0))[1] if spec.get('dust') and spec['dust'][0] == 'cash' else spellcash(spec)
                     for _, spec in search.hand)
    enemy_upper = root.enemy_gold + sum(dustcash(u) for u in root.enemy)
    enemy_upper += sum(u.end[1] for u in root.own if u.end and u.end[0] == 'both_cash')
    enemy_upper += sum(spellcash(spec) for _, spec in search.enemy_hand)
    for c, spec in search.hand:
        if search.max_plays and c['cost'] <= own_upper:
            unknown += ['Own card '+str(c['id'])+': '+x for x in spec['unknown']]
    for c, spec in search.enemy_hand:
        if c['cost'] <= enemy_upper:
            unknown += ['Enemy card '+str(c['id'])+': '+x for x in spec['unknown']]
    modes = data.get('objectives', list(board.OBJECTIVES))
    if not isinstance(modes, list) or not modes or len(set(modes)) != len(modes) or any(m not in board.OBJECTIVES for m in modes):
        raise ValueError('Unique nonempty objective subset required')
    outcomes = [] if unknown else [search.solve(root, mode) for mode in modes]
    unknown += [x for r in outcomes for x in r.get('unknown', [])]
    assumptions = [x for x in board.LIMITATIONS if not x.startswith('No new enemy plays') and not x.startswith('Current known monster')]
    assumptions += [
        'Known physical own monsters/spells and enemy spells; enemy monster deployments remain unknown.',
        'Opponent declared hand is perfect information; separate reply panels are conditional comparisons, not hidden-hand probabilities.',
        'No natural draws, SOUL, artifacts or future own plays; next own horizon refreshes attacks only.',
        'Modified-stat Silence remains unknown. Headshot removes abilities before killing; previously resolved effects on other entities persist.',
    ]
    return dict(version=VERSION, complete_in_declared_scope=not unknown and all(r['search_complete'] for r in outcomes),
                scope='declared_hand_paid_combat_subgame', unknown=sorted(set(unknown)),
                initial_metrics=board.metrics(root), objectives=outcomes, assumptions=assumptions,
                model_gold=None, empirical_win_probability=None, full_card_value_evaluated=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = json.dumps(evaluate(json.loads(args.input.read_text())), ensure_ascii=False, indent=2)+'\n'
    if args.output: args.output.write_text(result)
    else: print(result, end='')


if __name__ == '__main__': main()