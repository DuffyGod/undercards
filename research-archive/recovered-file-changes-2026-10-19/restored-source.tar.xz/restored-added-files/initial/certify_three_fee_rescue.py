"""Reviewed whole-3G HP bounds, plus actual queued-Delay winner searches."""
import argparse
import hashlib
import json
from pathlib import Path
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
PROOF=HERE/'experiments/delay-history-v01/three-cost-upper-bound-review.json'
RULES=HERE.parents[1]/'skills/undercards/references/rules.md'


def certify(panel='two_attacks',cards=None):
    if panel not in ('one_attack','two_attacks'): raise ValueError('Unsupported reviewed panel')
    cards=score_cards.load_cards() if cards is None else cards
    proof=json.loads(PROOF.read_text())
    if proof['snapshot_sha256']!=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest():
        raise ValueError('Reviewed snapshot changed')
    if proof['rules_sha256']!=hashlib.sha256(RULES.read_bytes()).hexdigest():
        raise ValueError('Reviewed rules changed')
    by={c['id']:c for c in cards}
    candidates={c['id'] for c in cards if c['card_type']=='monster'
        and c['pool_category']=='ordinary_non_token' and c['cost']==3}
    if candidates!={r['card_id'] for r in proof['rows']}: raise ValueError('Full 3G inventory changed')
    for binding in proof['source_bindings']:
        if binding['id'] not in by or any(binding[k]!=by[binding['id']].get(k) for k in proof['source_binding_fields']):
            raise ValueError('Reviewed source changed: '+str(binding['id']))
    pool=sorted(c['id'] for c in cards if c['card_type']=='monster' and 'LOST_SOUL' in c['tribes'])
    if pool!=proof['semantic_pool_bindings']['crystal_cheese_lost_soul_ids']:
        raise ValueError('Lost Soul semantic pool changed')
    data=dict(hand_ids=[],hand_base_costs=[3],hand_silenced=[False],gold_before_play=3,
        own_player_hp=3,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[dict(card_id=15,attack=6,health=5)],
        own_dustpile_monsters=[dict(card_id=108,current_cost=6,base_cost=6)]*3,
        own_deck_ids=[196],own_fatigue_next=1,next_natural_draw_count=0,
        opponent_hand_ids=[],opponent_gold_before_response=0,max_plays=1,horizon='enemy_attack',
        condition_known_state={'last_turn_gold_spent_on_spells':0},objectives=['guaranteed_hp'])
    if panel=='two_attacks':data['enemy_bodies'].append(dict(card_id=2,attack=2,health=3))
    rows=[]
    for reviewed in proof['rows']:
        bounds=reviewed['guaranteed_endpoint_hp_bounds'][panel]
        result=paid.evaluate(dict(data,hand_ids=[reviewed['card_id']]),cards)
        if result['complete_in_declared_scope']:
            value=result['objectives'][0]['metrics']['own_player_hp']
            if not bounds[0]<=value<=bounds[1]:raise AssertionError('Runtime/source bound disagreement '+str(reviewed['card_id']))
        rows.append(dict(reviewed,source_goal_bounds=bounds,runtime=result,
            full_state_simulated=result['complete_in_declared_scope']))
    lower=max(r['source_goal_bounds'][0] for r in rows)
    upper=max(r['source_goal_bounds'][1] for r in rows)
    winners=[r['card_id'] for r in rows if r['source_goal_bounds']==[lower,lower]]
    if lower!=upper or winners!=[580]:raise AssertionError('Goal proof did not close')
    winner=next(r for r in rows if r['card_id']==580)
    if not winner['runtime']['complete_in_declared_scope'] or winner['runtime']['objectives'][0]['metrics']['own_player_hp']!=lower:
        raise AssertionError('Optimal feasible witness not executable')
    return dict(version='complete-3G-history-goal-certificate-0.1.0',panel=panel,
        all_candidate_ids=sorted(candidates),reviewed_conditions=proof['conditions'],common_runtime_input=data,
        cards=rows,optimal_guaranteed_hp_bounds=[lower,upper],optimum_certified=True,
        known_optimal_card_ids=winners,unknown_possible_winners_or_ties=[],
        reviewed_proof_sha256=hashlib.sha256(PROOF.read_bytes()).hexdigest(),
        snapshot_sha256=proof['snapshot_sha256'],rules_sha256=proof['rules_sha256'],
        source_hashes={f:hashlib.sha256((HERE/f).read_bytes()).hexdigest() for f in
            ('certify_three_fee_rescue.py','paid_board_tactics.py','queued_delay.py','board_tactics.py')},
        limitations=['Complete bucket goal bounds and a searched winner, not complete-state simulation for every card.',
            'All reviewed history, ability, body, hand, deck and enemy-hand conditions are required.',
            'No paid-enemy-spell-panel certificate, empirical scene weights, universal Gold price or whole-match claim.'])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--panel',choices=['one_attack','two_attacks'],default='two_attacks')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();result=certify(args.panel)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('panel','optimal_guaranteed_hp_bounds','known_optimal_card_ids')}))


if __name__=='__main__':main()