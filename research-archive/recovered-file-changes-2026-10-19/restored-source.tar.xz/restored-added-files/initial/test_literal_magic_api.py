"""The new literal mechanisms use the actual paid core and public entry."""
import copy
import unittest

import paid_board_tactics as paid
import evaluate_situation as api


class LiteralPublicTests(unittest.TestCase):
    def scene(self,cid=494,**changes):
        data=dict(hand_ids=[cid],gold_before_play=3,opponent_gold_before_response=0,
            own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
            ally_bodies_before_play=[],enemy_bodies=[dict(card_id=270,attack=4,health=1,max_health=4)],
            max_plays=1,horizon='enemy_attack',opponent_hand_ids=[],objectives=['guaranteed_hp'])
        data.update(changes);return data

    def entry(self,scene):
        observations={k:copy.deepcopy(scene[k]) for k in ('hand_ids','gold_before_play','opponent_gold_before_response',
            'own_player_hp','enemy_player_hp','ally_bodies_before_play','enemy_bodies')}
        params={k:copy.deepcopy(v) for k,v in scene.items() if k not in observations and k not in ('own_player_max_hp','enemy_player_max_hp')}
        return dict(observations,role='tempo',own_turn=3,paid_board_scenario=params,
            callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30))

    def test_source_atk_reaches_public_api_and_real_payment(self):
        data=self.scene();direct=paid.evaluate(data)
        result=api.evaluate(self.entry(data))['paid_board_tactics']
        self.assertTrue(direct['complete_in_declared_scope']);self.assertTrue(result['complete_in_declared_scope'])
        self.assertEqual(direct['objectives'][0]['objective_vector'],result['objectives'][0]['objective_vector'])
        self.assertEqual(result['objectives'][0]['metrics']['own_player_hp'],15)
        self.assertEqual(result['objectives'][0]['payment_accounting']['current_paid_gold'],3)

    def test_physical_extremes_reach_public_api_without_changing_old_goal_order(self):
        data=self.scene(244,physical_slots=True,front_slot_map=[0,1,2,3],
            enemy_bodies=[dict(card_id=270,attack=4,health=1,max_health=4,slot=i) for i in (0,3)])
        direct=paid.evaluate(data);result=api.evaluate(self.entry(data))['paid_board_tactics']
        self.assertTrue(result['complete_in_declared_scope'],result['unknown'])
        self.assertEqual(result['objectives'][0]['metrics']['own_player_hp'],15)
        self.assertEqual(direct['objectives'][0]['objective_vector'],result['objectives'][0]['objective_vector'])
        self.assertIn('physical_slots',result['objectives'][0])

    def test_unresolved_packet_count_stays_unknown_in_public_api(self):
        tem=dict(card_id=172,attack=1,health=3,max_health=3,ready=False)
        # Read native stats rather than treating this observation as source.
        import score_cards
        card=next(c for c in score_cards.load_cards() if c['id']==172)
        tem.update(attack=card['attack'],health=card['health'],max_health=card['health'])
        data=self.scene(172,ally_bodies_before_play=[dict(tem),dict(tem)],
            enemy_bodies=[dict(card_id=2,attack=1,health=3,max_health=3,armor=True)])
        result=api.evaluate(self.entry(data))['paid_board_tactics']
        self.assertFalse(result['complete_in_declared_scope']);self.assertFalse(result['recommendations'])
        self.assertTrue(any('aggregate' in u for u in result['unknown']))


if __name__=='__main__':unittest.main()