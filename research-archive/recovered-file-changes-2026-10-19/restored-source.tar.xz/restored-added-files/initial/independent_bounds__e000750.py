"""Source arithmetic and strategy bounds; imports no game/search program."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    cards={c['id']:c for c in json.loads((HERE/'native-snapshot.json').read_text())['cards']}
    assert (cards[43]['attack'],cards[43]['health'],cards[43]['cost'])==(5,5,6)
    assert cards[253]['effect_readable']=='Magic: Give a Dog in your hand ATK +1/HP +1 and Taunt.'
    assert cards[406]['effect_readable']=='Magic: Give a monster in your hand ATK +2/HP +2.'
    assert cards[436]['effect_readable']=='Haste. Magic: Give a Haste monster in your hand +1 ATK.'
    assert cards[33]['effect_readable']=='Magic: Give a Dog in your hand +1 ATK and Haste or an Amalgamate in your hand +1 HP and Taunt.'
    assert (cards[509]['attack'],cards[509]['health'],cards[509]['cost'])==(4,6,5)
    expected={
        'endo-dog':(15,False,'Pay4+6; Haste6 kills the5HP enemy before face damage. Enemy6 can always deny original5HP Dog survival.'),
        'bone-dog':(15,False,'Pay3+6; Taunt6/6 absorbs the sole6ATK attack and deals lethal6 back. Enemy may kill that exact original.'),
        'sugar-dog':(9,True,'Pay4+6; Dog7/7 survives enemy6 with1HP. No Taunt/Haste: legal face6 bounds HP9.'),
        'sugar-short-cash':(9,False,'4+6>9: cannot pay both; no available individual source has6ATK or immediate face protection.'),
        'sugar-enemy-attack7':(8,False,'Legal face7 bounds HP8; legal body7 kills the buffed7HP original and denies the body goal.'),
        'town-long-cash8':(15,True,'Pay3+5; held Haste Long becomes5/6, attacks4/4 and retains5/2. No-attack heal3 permits face4, only14.'),
        'town-long-cash7':(15,False,'3+5>7, no other buff; native Long4/6 alone can kill4/4 but cannot meet5ATK.'),
        'dog-alone-cash10':(9,False,'Native non-Taunt5/5 cannot prevent face6 or meet6ATK.'),
        'dog-alone-cash9':(9,False,'Same native Dog, actual6 payable; extra cash cannot add a nonexistent card.'),
        'dog-alone-enemy7':(8,False,'Native Dog cannot prevent face7 or reach6ATK.'),
        'long-alone-cash8':(15,False,'Haste4 trades into4/4, leaves4/2; no way to get5ATK.'),
        'long-alone-cash7':(15,False,'Same native Haste4/6 remains payable; no5ATK source.'),
    }
    checks=[]
    for label,(hp,body,reason) in expected.items():
        artifact=HERE/(label+'.json');raw=json.loads(artifact.read_text());scores=raw['results']
        assert scores['hp']['known'] and scores['buddy']['known']
        assert scores['hp']['guaranteed_player_hp']==hp
        assert scores['buddy']['feasible']==body
        assert scores['buddy']['guaranteed_player_hp']==(hp if body else None)
        checks.append(dict(label=label,hp_lower=hp,hp_upper=hp,buddy_feasible=body,reason=reason,artifact_sha256=sha(artifact)))
    pool=[]
    for cid in (33,253,406,436):
        artifact=HERE/f'pool-card{cid}.json';raw=json.loads(artifact.read_text());r=raw['results'];value=9 if cid==33 else 5
        assert r['hp']['known'] and r['hp']['guaranteed_player_hp']==value
        assert r['clear']['feasible']==(cid==33) and r['clear']['guaranteed_player_hp']==(9 if cid==33 else None)
        assert not r['win']['feasible'] and not r['focal_2_2']['feasible']
        pool.append(dict(card_id=cid,hp=value,clear=cid==33,win=False,focal_2_2=False,artifact_sha256=sha(artifact)))
    report=dict(imports_production_model=False,builder_sha256=sha(Path(__file__)),checks=checks,pool=pool,
        matching_buddy_contexts=12,matching_hp_values=12,pool_cells_matched=16,
        pool_strategy_bounds='With no other held targets the helpers fizzle. Endogeny4 can trade Thrashing4/4 before its second attack, giving15-4-2=9 and clear. Others3 cannot clear a4HP body: a trade dies to4 retaliation after at most3 damage. Holding ensures15-4-4-2=5; face replies attain it. Every original body can be killed by the enemy4 attack; none deals30 hero damage.',
        assumptions=['Explicit fizzle and eligible-branch hypotheses, no server trace.',
            'Same physical hand copies, real cash and supplied deadlines.',
            'Buddy purpose refers to the target copy, not the helper or an unrelated background body.'])
    (HERE/'independent-bounds.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(contexts=12,hp_matches=12,pool_cells=16)))

if __name__=='__main__':main()