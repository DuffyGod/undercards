"""An enemy death can unlock its physical punishment before the turn ends."""
import copy
import hashlib
import json
from pathlib import Path

import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/death-discount-resistance-v01'
PURPOSES=dict(durable_pressure=dict(min_own_player_hp=1,min_own_board_attack=4,min_own_board_health=3),
              live_and_clear=dict(min_own_player_hp=1,max_enemy_living_count=0))


def scene(attack=2,cash=2,**updates):
    data=dict(hand_ids=[103,14],hand_base_costs=[5,5],gold_before_play=5,max_plays='all_physical',
        own_deck_ids=[],own_player_hp=7,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
        enemy_bodies=[dict(card_id=43,attack=attack,health=5,max_health=5,current_card_cost=6,base_cost=6)],
        opponent_hand_ids=[96],opponent_hand_base_costs=[3],opponent_gold_before_response=cash,
        first_opponent_natural_draw_count=0,horizon='enemy_attack',node_limit=10000)
    data.update(updates)
    return data


def solve(data,cards):
    searches={}
    checks=[]
    for name,constraints in [('guaranteed_hp',None),*PURPOSES.items()]:
        query=dict(data,objectives=['guaranteed_hp' if constraints is None else 'purpose'])
        if constraints:query['purpose_constraints']=constraints
        fast=paid.evaluate(query,cards)
        full=paid.evaluate(dict(query,search_algorithm='exhaustive'),cards)
        if not fast['complete_in_declared_scope'] or not full['complete_in_declared_scope']:
            raise AssertionError((name,fast['unknown'],full['unknown']))
        if fast['objectives'][0]['objective_vector']!=full['objectives'][0]['objective_vector']:
            raise AssertionError((name,'Full vector mismatch'))
        searches[name]=fast;checks.append(dict(objective=name,full_vector_equal=True))
    return searches,checks


def build():
    cards=score_cards.load_cards()
    no_dust=copy.deepcopy(cards)
    dog=next(c for c in no_dust if c['id']==43)
    old_text=dog['effect_readable'];dog['effect_readable']=''
    probes=[('enemy_cash_1',scene(cash=1),cards,[]),
        ('enemy_cash_2',scene(),cards,[]),
        ('enemy_attack_3',scene(attack=3),cards,[]),
        ('remove_enemy_dust',scene(),no_dust,[dict(card_id=43,before=old_text,after='',kind='source_text_intervention')])]
    rows=[]
    for name,data,catalogue,edits in probes:
        results,checks=solve(data,catalogue)
        candidates=[]
        for cid in (103,14):
            individual=dict(data,hand_ids=[cid],hand_base_costs=[5])
            compared,independent=solve(individual,catalogue)
            candidates.append(dict(card_id=cid,input=individual,searches=compared,algorithm_checks=independent))
        rows.append(dict(case=name,input=data,searches=results,candidate_slot_comparisons=candidates,
            algorithm_checks=checks,source_edits=edits,
            cards_canonical_sha256=hashlib.sha256(json.dumps(catalogue,sort_keys=True,ensure_ascii=False,
                separators=(',',':')).encode()).hexdigest()))
    return dict(version='enemy-death-discount-punishment-resistance-0.1.0',cases=rows,purposes=PURPOSES,
        source_hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in
            ('build_death_discount_resistance_comparison.py','paid_board_tactics.py','board_tactics.py','alpha_beta_search.py')},
        limitations=['Lesser Dog is an observed2/5 or3/5 body with known maximum and unmodified6G costs, not its printed5ATK.',
            'Known physical enemy Punishment is held before the death; actual Dust changes only its current payment price3→2, not base/printed3.',
            'Current own plays are optional and cover all physical copies at the shared5G cash. Background and declared enemy reply match.',
            'Each purpose searches its full conjunction separately. One printed worst path is not a complete adaptive policy.',
            'Removing Dust is a source/card-catalogue intervention, not another native card or a server-rule claim.',
            'No frequency weights, hidden-hand priors, whole-game card prices or empirical match probability inferred.'])


def main():
    record=build();OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    lines=['# 击杀会打开对手手中的付费惩罚','',
        '己7/30HP、5G，真实手牌Muffet’s Pet与Jerry各5G，全部物理出牌可选；敌已观察Lesser Dog ATK2/HP5/max5、cost6，手里一张Punishment3G，回应现金1或2G。没有额外首抽。各目的直接对合法施法、攻击、次序和停止搜索。',
        '', '| 干预 | 最大保证HP / 首行动 | 持续压力 / 首行动 / 该目的HP | 保命清场 / 首行动 |',
        '|---|---|---|---|']
    for row in record['cases']:
        values=[]
        for name in ('guaranteed_hp','durable_pressure','live_and_clear'):
            o=row['searches'][name]['objectives'][0]
            first=o['principal_variation'][0];first=first.get('card_id',first['kind'])
            values.append(str(o['metrics']['own_player_hp'] if name=='guaranteed_hp' else o['purpose_guaranteed'])+' / '+str(first)+
                (' / '+str(o['metrics']['own_player_hp']) if name=='durable_pressure' else ''))
        lines.append('| '+row['case']+' | '+' | '.join(values)+' |')
    lines+=['', '现金2G时，Pet把同目标ATK2降到0并击杀，敌Lesser Dust立即把原本不能支付的Punishment3G降到2G。敌可实际付款打Pet4点，使5HP身体只余1HP，持续压力不能保证；Jerry则可以承受Dog2伤、反击4使Dog剩1HP，未打开该死亡折扣，保留4ATK/3HP。最大HP与清场选Pet，持续压力选Jerry，两个选择都有7HP保证。',
        '', '将敌现金2→1G，或仅删去敌Dust，Pet重新能保证持续压力。将敵DogATK2→3，Pet减到1不击杀、不开放折扣，Pet压力由false转true但玩家HP7→6；Jerry仍保7HP，却最多只余2HP而不保证≥3HP压力。更强敌ATK并不在所有目的下都恶化同一候选：必须保留条件、物理付款与终点目标。',
        '', 'JSON保留整手选择以及相同预算的单槽Pet/Jerry替代，每个目的的完整向量均与穷举一致。不给“触发敌Dust”定一个固定负Gold；惩罚是否可支付、身体余HP是否跨目标阈值共同决定后果。',
        '', '`python analysis/monster-value-heuristic/build_death_discount_resistance_comparison.py`','']
    (OUT/'comparison.md').write_text('\n'.join(lines))
    print([(r['case'],[(g,o['objectives'][0]['metrics']['own_player_hp'],o['objectives'][0].get('purpose_guaranteed'))
        for g,o in r['searches'].items()]) for r in record['cases']])


if __name__=='__main__':main()