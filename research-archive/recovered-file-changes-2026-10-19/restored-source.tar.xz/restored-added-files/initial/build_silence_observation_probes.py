"""Keep failed observation probes and add source-checked native counterparts.

The first grid deliberately remains traceable. Its incomplete COST and modified
stat Silence branches are unknown, not zero. These counterparts state all facts
needed for an actual native comparison, including the effective-ATK owner clock.
"""
import copy
import csv
import hashlib
import json
from pathlib import Path

import conditional_card_score as score
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/periodic-spatial-v01'


def main():
    index=json.loads((OUT/'index.json').read_text());cards={c['id']:c for c in score_cards.load_cards()}
    predecessor=hashlib.sha256((OUT/'index.json').read_bytes()).hexdigest()
    original=json.loads((OUT/'silence-opens-victory.input.json').read_text())
    corrected=copy.deepcopy(original)
    body=corrected['scene']['enemy_bodies'][0]
    body['health']=body['max_health']=cards[14]['health']
    ally=corrected['scene']['ally_bodies_before_play'][0]
    ally['current_card_cost']=ally['base_cost']=cards[9]['cost']
    dynamic=json.loads((OUT/'silence-dynamic-enemy.input.json').read_text())
    trashy=copy.deepcopy(dynamic)
    # At the root it is OUR turn, which is the enemy Trashy's opponent turn.
    trashy['scene']['enemy_bodies'][0]['attack']=cards[632]['attack']+2
    carbed=copy.deepcopy(dynamic)
    carbed['scene']['enemy_bodies']=[dict(card_id=534,attack=5,health=3,max_health=5,
        current_card_cost=cards[534]['cost'],base_cost=cards[534]['cost'])]
    cases=[('silence-native-taunt-window',corrected),('silence-native-trashy-clock',trashy),
        ('silence-native-damaged-carbed',carbed)]
    new_names={name for name,cfg in cases}
    index['cases']=[c for c in index['cases'] if c['case'] not in new_names]
    appended=[]
    with (OUT/'scores.csv').open() as f:
        reader=csv.DictReader(f);fields=reader.fieldnames;csv_rows=[row for row in reader if row['case'] not in new_names]
    for name,cfg in cases:
        result=score.compare(cfg)
        for suffix,value in [('.input.json',cfg),('.json',result)]:
            (OUT/(name+suffix)).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
        summary=dict(case=name,artifact=name+'.json',candidate_count=len(result['rows']),
            known_hp=sum(c['scores']['hp']['known'] for c in result['rows']),selection=result['selection'],
            leaders=result['diagnostic_task_leaders'])
        index['cases'].append(summary);appended.append(summary)
        for card in result['rows']:
            for task,v in card['scores'].items():
                right=card['current_deployment_right_value'].get(task,{})
                csv_rows.append(dict(case=name,card_id=card['card_id'],name=card['name'],task=task,known=v['known'],
                    feasible=v['feasible'],joint_hp=v['guaranteed_player_hp'],
                    task_hp_sacrificed=card['purpose_player_hp_tradeoff'][task]['player_hp_sacrificed'],
                    removal_hp_difference=card['contribution_over_removed_copy'][task].get('hp_difference'),
                    same_slot_hp_difference=card['same_slot_reference_difference'][task].get('hp_difference'),
                    current_deployment_hp=right.get('hp_difference'),current_deployment_feasibility=right.get('feasibility_change'),
                    unknown='; '.join(v.get('unknown',[]))))
        print(json.dumps(dict(case=name,known=summary['known_hp'],choice=summary['selection']['best_supported_candidate_ids'],
            values=[(c['card_id'],c['scores']['hp']['guaranteed_player_hp'],c['scores']['win']['guaranteed_player_hp']) for c in result['rows']])),flush=True)
    with (OUT/'scores.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(csv_rows)
    index['cases'].sort(key=lambda c:c['case'])
    index['candidate_context_rows']=sum(c['candidate_count'] for c in index['cases'])
    index['observation_counterfactuals']=dict(source_hashes=score.source_bindings(Path(__file__)),
        predecessor_index_sha256=predecessor,added_cases=[c['case'] for c in appended],
        original_diagnostic_cases_preserved=['silence-opens-victory','silence-dynamic-enemy'],
        corrections=['Jerry observed7HP was modified, native maximum is5. The old probe also omitted Ice current/base COST.',
            'Enemy Trashy is4 effectiveATK at our-turn root; observed2 implies a modified persistent base, not native2.',
            'Damaged Carbed observes5 effectiveATK and native base2/max5; Silence removes its conditional bonus.'])
    (OUT/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()