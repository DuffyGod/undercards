"""Reject certificates made after a cached dependency's source was replaced."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import loaded_sources


class LoadedSourceTests(unittest.TestCase):
    def test_recorded_file_cannot_take_a_later_hash(self):
        with tempfile.TemporaryDirectory() as folder,patch.dict(loaded_sources._EXECUTED,{},clear=True):
            p=Path(folder)/'child.py';p.write_text('value=1\n');loaded_sources.record('child',p)
            loaded_sources.verify();p.write_text('value=2\n')
            with self.assertRaises(RuntimeError):loaded_sources.verify()
            with self.assertRaises(RuntimeError):loaded_sources.record('child',p)

    def child(self,change):
        with tempfile.TemporaryDirectory() as folder:
            for p in Path(__file__).resolve().parent.glob('*.py'):shutil.copy2(p,Path(folder)/p.name)
            code='''from pathlib import Path
import conditional_card_score
CHANGE
import alternative_goal_score as alt
task=dict(kind='any',clauses=[dict(constraints=dict(min_own_player_hp=1)),dict(constraints=dict(max_enemy_living_count=0))])
try:
    result=alt.evaluate(dict(hand_ids=[],gold_before_play=0),task,cards=[])
except RuntimeError as error:
    print('blocked:'+str(error))
else:
    print('accepted:'+str(result['known']))
'''.replace('CHANGE',"p=Path('held_magic_extensions.py');p.write_text(p.read_text()+'\\n# changed after child import\\n')" if change else 'pass')
            result=subprocess.run([sys.executable,'-B','-c',code],cwd=folder,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            return result.stdout

    def test_real_parent_import_after_changed_cached_child_is_blocked(self):
        self.assertIn('blocked:Loaded source differs from disk',self.child(True))

    def test_unchanged_import_order_still_executes(self):
        self.assertIn('accepted:True',self.child(False))


if __name__=='__main__':unittest.main()