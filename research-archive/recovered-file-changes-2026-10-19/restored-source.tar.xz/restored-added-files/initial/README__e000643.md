# 动态身体家族与卡组模拟的下一门槛

2026-10-14，paid0.21.0 / board0.4.0 / API0.23.0。接入 Carbed 的受损ATK谓词，以及 Trashy 的真实敌回合ATK和直接攻击免伤。按全文参数模板识别，不按卡名加分。永久ATK、当前有效ATK和真实回合拥有者分离；搜索截止时跳phase不制造回合切换。观察attack表示当时有效值，需完整状态才能反推永久部分。

[全部比较家族与对战阶段](../../COMPARISON_FAMILIES.md)清点11个已执行家族。完整对局无需等全卡池；可以先选闭合的牌组，用持续状态driver交替回合、实际付款/抽牌/死亡/收入，明确开局与终局，先运行公开信息研究子游戏，再加入隐藏信息策略。当前仍只有固定短窗口，没有完整match driver，不能称已完成卡组对战。

## 本轮可比较结果

[38个根的同费比较](comparison.md)覆盖Carbed/Aaron/Jerry/Long Sink与Trashy/Woshua/Pyrope/Bloody Tree。两个目的完整向量均与穷举一致；另有7个已固定合法交换。等候也属于当前策略，后续部署须真的付款，没有未来收入或自然抽牌免费补偿。

| 同费用途 | 关键反事实 | 结果 |
|---|---|---|
| 已有攻击权的4G身体交换 | 主动攻击6攻/2血 | Trashy留5血；Woshua/Pyrope/Bloody Tree死亡，Pyrope另打脸3 |
| 新部署后的双回应保命 | 相同敌6/2、玩家起15 | Trashy保玩家9；其有利主动交换可被敌先打身体或打脸规避 |
| 同5G、留同体4攻/3血并存活 | 敌2攻/3血→3攻/3血 | Carbed/Aaron/Jerry可行→不可行；Long Sink保持可行 |
| Carbed健康首击 | 目标3血，反击1→2→3 | 首击均只造成2，余体血5/4/3，有效攻2/5/5；不能追溯将本次伤害改5 |
| 实付Pancakes5治疗受损Carbed | 身体4/5→5/5、玩家15→16 | 当前有效攻5→2；已有永久+2则7→4，不把永久buff抹掉 |

高身体目的8根与2条真实付款治疗前缀见[用途门槛](purpose-boundaries.md)。主程序和不导入战斗/搜索/付款原语的独立算术程序[19项结果](independent-verification.json)逐项匹配；共享的攻击前采样/同时交换解释仍非服务器证据。

## 离假想卡组更近的阶段性输入

新程序[deck_component_challenge.py](../../deck_component_challenge.py)把候选放入主牌副本结构合法的25张怪物列表，固定24背景副本，替换同一个3G槽。源稀有度限额、普通怪物范围、当前物理手和下一自然抽牌均执行；初始3手牌与收入是声明中途检查点，不是已核实的标准起手。没有完整敌方主牌、SOUL/神器或全程终局driver。

[9个组件输入](../deck-components-v01/comparison.md)的共同手牌保证：

| 焦点槽位置 | Candy / Shyren / Napstablook 玩家HP | 同体≥2攻/3血目的 |
|---|---|---|
| 当前持有 | 11 / 15 / 11 | 三者均可行 |
| 下一自然抽到 | 12 / 16 / 12 | 三者均可行 |
| 本窗口抽不到 | 12 / 12 / 12 | 三者均不可行 |

这里的身体可以来自整个手牌，不保证必是焦点卡。每个位置内背景完全一致；移动焦点位置还会改变背景牌到手时间，不能把后抽多1HP全归给焦点“晚出奖励”。不可到手时三种替换产生相同完整向量，库里的牌没有被提前当成手牌动作。未知真实牌序/场景频率继续保留，不能平均这9行得到构筑Gold。

该试验暴露效率门槛：9个输入、每个2目的，alpha-beta在3,571–31,375个访问状态内完成根证明；同60,000预算的穷举每个目的都耗尽。保留18个失败，不称算法交叉验证成功。较小的38+8家族输入另完成穷举验证；大输入仍需独立界与未来多策略/成对牌序验证，不用一致意见补证。

因此全程模拟应采用明确的计算预算和可替换策略，记录超预算/未知规则导致的中止；先验证持续状态及合法行动，再比较配对牌序下多个策略之间的替换效果。不能要求逐回合全局穷举，也不能把固定机器人的模拟胜率直接当真实强度。

## 运行与验证

在分析目录执行：

```bash
python evaluate_situation.py --input experiments/dynamic-body-v01/card-534.input.json --output /tmp/carbed.json
python evaluate_situation.py --input experiments/dynamic-body-v01/card-632.input.json --output /tmp/trashy.json
python build_dynamic_purpose_boundaries.py
python deck_component_challenge.py
```

两条真实公共API/CLI与直接paid调用一致，见[API记录](api-verification.json)。核心417检查228.818s通过且运行期间源不变；新增独立报告和目录登记后只核验来源，不重复未改核心测试。43旧报告实际执行43重算命令，未仅修改hash，旧源/结果冻结在research-runs/dynamic-body-v01/before。全404面板短51闭合/353未知、长52/352；3G仍13/93；新增完整动态模板不等于全池或任意互动已支持。

继续保留的明确未知：Trashy杀NEO后的Dust是否属于攻击期间；免伤与Dodge先后；动态ATK设值/交换、减攻floor与临时奖励产生不同结果；Carbed观察缺maxHP；永久修改体沉默重置。复杂攻击窗口没有只免反击后假装Dust已裁定。继承的同时交换/攻击前取双方ATK、Dodge先Armor也只是公开解释。

失败及修正另见[validation-history.json](../../research-runs/dynamic-body-v01/validation-history.json)。研究总Goal未完成，真实机会频率、隐信息长期策略、标准SOUL/神器和服务器事件裁定尚有缺口。