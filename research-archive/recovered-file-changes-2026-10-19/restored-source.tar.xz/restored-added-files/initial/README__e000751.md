# 手内定向增益：真实支付、身体用途与时机门槛

paid0.24上的独立原型，生产核未改动。完整文本通用模板实际新增4张：Endogeny33、Bone Painting253、Sugar Pot406、Town Hall Guy436。数值增益复用原物理副本账本，Taunt/Haste另用不可变状态tuple按双方/副本index持有，真实出场后转移并消费；后来抽到的新副本不追溯。

## 同手牌、同现金的可比较结果

现金10G、己15HP、敌单只6/5 Aaron，自己真实手持辅助＋6G Lesser Dog。所有出场实际付款，截止一次敌回应。身体用途指那张Dog同时≥6攻1血，不是辅助本体或背景替代。

| 真实手牌 | 保命HP | 保Dog≥6/1时HP |
| --- | ---: | ---: |
| Endogeny＋Lesser Dog | 15 | 不可保证 |
| Bone Painting＋Lesser Dog | 15 | 不可保证 |
| Sugar Pot＋Lesser Dog | 9 | 9 |
| 只有Lesser Dog，同现金 | 9 | 不可保证 |

Endogeny先付4，Dog再付6，获得6攻与Haste，当前就能换掉5HP敌；Bone先付3，6/6 Taunt Dog迫使敌打它；二者Dog都可死亡，不能把保命最优路线误读成厚体保证。Sugar给Dog到7/7，没有即时Haste或Taunt，敌可打脸6，故仅保9HP；敌改打Dog时它余1HP，因此身体用途反而可保证。

同Sugar手牌现金10→9，无法同时付4＋6，身体用途消失；现金不变而敌攻击6→7，7/7 Dog可被击杀，身体保证也消失，纯HP9→8。Town Hall Guy＋Long Sink的同一活体5攻1血目的，在现金8时Q15、现金7时不可保；纯保命两者却都15。先付Town3、给仍在手的Haste Long增1ATK、再真付Long5，才能跨过5攻门槛。

12个真实手牌/现金/敌数值输入×2用途，24查询全闭合；4个预声明小边界的完整向量与穷举一致。没有固定按卡名或“有配合”加分。

## 原双敌轮输入中的覆盖增量

原v02每个费用桶的场景不变，仅对新家族显式加入下述规则解释。4张均从原核心HP未知变为四用途闭合，共16个新用途查询：Endogeny保命/清场Q9，另外三张保命Q5、清场不可保；四张均不保证获胜或本体2/2。这里没有其他持牌目标，不能把有Dog配合的表值填进单牌表。旧v02仍固定来源，不改写其未知。

## 证据和公开假设

15项专项测试1.904s通过，按依赖复用558项，实验覆盖573；原生产注册仍530。实际查询49=24手牌用途＋4穷举＋4原核HP未知复核＋16跨费用途＋1真实CLI。CLI完整JSON相同，`index.json`保存各输入、来源、预算与账本。独立标准库策略界核对12个HP、12个身体可行性及16个跨费用单元，见`independent-bounds.json`。算法一致不等于服务器裁定。

- 无匹配目标按fizzle：显式`targeted_hand_empty=fizzle`，尚无服务器执行验证；默认unknown会拒绝，不自动省略。
- Endogeny两种选项仅可选有匹配手牌目标的分支：显式`targeted_hand_choice=eligible_targets`，也保留为假设。
- Charge与Haste的目标分类保守未知；原型不擅自分类。
- 新辅助牌自身的Draw仍被原核心held/draw回调注册拒绝。已知普通目标后来Draw则不继承早先buff。生产集成需正面扩展完整Play回调分类，不能临时关掉所有Draw守卫。
- 原型不进入位置商；扩展的关键词状态须独立审查后才能加入位置证书白名单。

```sh
python research-runs/targeted-hand-v01/build_probes.py
python research-runs/targeted-hand-v01/independent_bounds.py
python targeted_hand_magic.py research-runs/targeted-hand-v01/cli.input.json --output /tmp/targeted-hand.json
```

本目录是paid0.24原型的冻结证据；后续生产集成应另存结果，不重新标注本目录来源。