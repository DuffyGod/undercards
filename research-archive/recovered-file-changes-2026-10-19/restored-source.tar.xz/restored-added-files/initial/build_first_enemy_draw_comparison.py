"""Incoming reply timing is a physical birth-time observation, not preloading."""
import copy
import hashlib
import json
from pathlib import Path
import paid_board_tactics as paid
import score_cards
from certify_hand_hp import cards_digest

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/first-enemy-draw-v01'


def build():
    cards=score_cards.load_cards();rows=[]
    def run(name,scene,hp,enemy_hp=None):
        result=paid.evaluate(scene,cards)
        if not result['complete_in_declared_scope']:raise AssertionError((name,result['unknown']))
        objective=result['objectives'][0]
        if objective['metrics']['own_player_hp']!=hp:raise AssertionError((name,objective['metrics']))
        if enemy_hp is not None and objective['metrics']['enemy_player_hp']!=enemy_hp:
            raise AssertionError((name,objective['metrics']))
        exhaustive=paid.evaluate(dict(scene,search_algorithm='exhaustive'),cards)
        if not exhaustive['complete_in_declared_scope'] or objective['objective_vector']!=exhaustive['objectives'][0]['objective_vector']:
            raise AssertionError('Independent exhaustive mismatch: '+name)
        rows.append(dict(case=name,input=copy.deepcopy(scene),result=result,
            full_objective_vector_matches_exhaustive=True,
            exhaustive_states=exhaustive['objectives'][0]['visited_states']))
    base=dict(hand_ids=[1],gold_before_play=1,max_plays=1,own_player_hp=30,own_player_max_hp=30,
        enemy_player_hp=30,enemy_player_max_hp=30,enemy_bodies=[dict(card_id=15,attack=6,health=5)],
        opponent_hand_ids=[],opponent_deck_ids=[96],opponent_gold_before_response=3,
        horizon='enemy_attack',objectives=['guaranteed_hp'])
    run('declared_no_added_draw',base,30)
    run('actual_first_draw_punishment',dict(base,first_opponent_natural_draw_count=1),24)
    run('actual_first_draw_unpayable',dict(base,first_opponent_natural_draw_count=1,
        opponent_gold_before_response=2),30)
    two=dict(base,hand_ids=[1,1],gold_before_play=2,first_opponent_natural_draw_count=1,
        horizon='next_enemy_attack',next_max_plays=1,next_own_gold_income=0,next_natural_draw_count=0,
        next_opponent_gold_income=3,next_opponent_natural_draw_count=1,opponent_deck_ids=[96,96])
    run('two_physical_draws_two_payments',two,18)
    timing=dict(hand_ids=[598,1],hand_costs=[0,1],gold_before_play=1,
        own_player_hp=3,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,max_plays=2,
        horizon='enemy_attack',enemy_bodies=[dict(card_id=43,attack=5,health=1,max_health=5),
            dict(card_id=15,attack=6,health=5)],opponent_gold_before_response=2,objectives=['guaranteed_hp'])
    actual=dict(timing,opponent_hand_ids=[],opponent_deck_ids=[96],first_opponent_natural_draw_count=1)
    preload=dict(timing,opponent_hand_ids=[96],first_opponent_natural_draw_count=0)
    run('actual_draw_after_enemy_lesser_death',actual,3)
    run('incorrectly_preloaded_future_card',preload,0)
    traces=[]
    for name,scene in [('actual_draw',actual),('preloaded_approximation',preload)]:
        engine=paid.PaidSearch(cards,scene);root=engine.root()
        gem,dead=next((a,s) for a,s in engine.casts(root,'own') if a['hand_index']==0 and a['targets']==[('enemy',0)])
        dummy,deployed=next((a,s) for a,s in engine.deploys(dead) if a.get('hand_index')==1)
        reply=engine.boundary(deployed)
        casts=[a for a,s in engine.casts(reply,'enemy')]
        traces.append(dict(case=name,forced_same_legal_own_prefix=[gem,dummy,dict(kind='end_turn',phase=0)],
            root_enemy_hand=engine.describe_hand_costs(root,'enemy'),
            enemy_held_after_lesser_death=engine.describe_hand_costs(dead,'enemy'),
            reply_enemy_hand=engine.describe_hand_costs(reply,'enemy'),
            enemy_cash=reply.enemy_gold,punishment_payable=any(a['card_id']==96 for a in casts),
            enemy_death_reduction_events=reply.enemy_hand_cost_reduction_events))
    fatigue=dict(base,hand_ids=[],gold_before_play=0,max_plays=0,enemy_player_hp=1,
        first_opponent_natural_draw_count=1,opponent_deck_ids=[],opponent_fatigue_next=1)
    run('first_fatigue_terminal_before_attacks',fatigue,30,0)
    burn=dict(base,opponent_hand_ids=[196]*7,first_opponent_natural_draw_count=1)
    run('full_hand_burns_punishment',burn,30)
    return dict(version='physical-first-enemy-draw-comparison-0.1.0',cases=rows,
        birth_time_counterfact_traces=traces,
        cards_canonical_sha256=cards_digest(cards),
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        source_hashes={f:hashlib.sha256((HERE/f).read_bytes()).hexdigest() for f in
            ('build_first_enemy_draw_comparison.py','paid_board_tactics.py','board_tactics.py',
             'alpha_beta_search.py','finite_conditions.py','score_cards.py')},
        limitations=['Default first_opponent_natural_draw_count=0 is a declared complete incoming response menu, not a real no-draw server rule.',
            'Mode 1 observes current enemy hand and draws from the same ordered physical library at its first reached start.',
            'The preload case deliberately changes card birth time and observed hand count; it is an incorrect approximation, not the same physical input.',
            'TOKEN Gem is a declared held generated card, not an ordinary construction candidate.',
            'First enemy cash is the declared response budget; no unobserved first-turn income is invented.',
            'Unknown draw/held callbacks, ambiguous owner-start draw order and competing Dust remain unknown.',
            'No empirical opponent frequencies, complete-game value or calibrated Gold score.'])


def main():
    result=build();OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    report='''# 第一敌回应：抽牌时序与卡牌进入手牌的时点

`first_opponent_natural_draw_count=1`声明根节点观察的是敌方当前物理手牌；己方结束后，敌方从同一有序牌库真实抽牌。默认0保留完整声明的回应菜单，不擅自补牌。首回应金币仍由输入提供，没有推测额外收入。

| 共同条件下的干预 | 最终己方HP保证 |
|---|---:|
| 己30HP、Dummy、敌Aaron6/5；不添加首抽 | 30 |
| 同局面，敌首抽Punishment且3G可支付 | 24 |
| 同首抽但敌只有2G | 30 |
| 两个Dummy、两次敌首抽/次抽各一张Punishment、各支付3G | 18 |
| 己3HP，Gem杀敌Dog→Dummy，敌Punishment尚在库，首抽后只有2G | 3 |
| 同一自己前缀，但错误地提前把未来Punishment放进手牌 | 0 |
| 敌1HP、空库疲劳1，在首次owner start死亡 | 30 |
| 敌满7手，首抽Punishment烧毁 | 30 |

出生时点反事实：敌Lesser Dog剩1HP，旁有Aaron6/5，敌现金2；己有当前费用0的TOKEN Gem与1G Dummy、己现金1和3/30HP。Gem杀Dog时，真实Punishment还在库，因此没有过去的−1COST；首抽后仍3G、不可支付，Dummy挡住Aaron，保证3HP。提前入手近似会让Punishment被减至2G，敌可杀Dummy再打脸，保证变成0。JSON同时保存强制相同合法己方前缀后的物理费用轨迹；各面板另对全部己方合法选择和敌方回应进行优化。

这不是单纯固定价值扣分。真实手牌结构、获得时点与可支付门槛共同决定回应是否存在；同ID副本必须保留不同索引，烧毁牌不能有手牌费用条目。八个面板的完整目标向量均与独立穷举一致，证明的是已声明窗口内的计算；并未校准天梯频率、构筑强度或服务器未验证顺序。旧的完整回应菜单只适用于其原声明范围。

```sh
python analysis/monster-value-heuristic/build_first_enemy_draw_comparison.py
python -m unittest discover -s analysis/monster-value-heuristic -p test_first_enemy_draw.py
```
'''
    (OUT/'comparison.md').write_text(report)
    print([(r['case'],r['result']['objectives'][0]['metrics']['own_player_hp']) for r in result['cases']])


if __name__=='__main__':main()