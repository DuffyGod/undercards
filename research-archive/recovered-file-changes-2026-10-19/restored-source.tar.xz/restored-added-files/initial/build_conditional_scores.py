"""Deliver same-task card scores, reference gaps, timing and numeric probes."""
from concurrent.futures import ProcessPoolExecutor,as_completed
import copy
import csv
import hashlib
import json
from pathlib import Path
import time

import build_damage_packet_comparison as packet
import build_dynamic_body_comparison as dynamic
import build_paid_standing_comparison as standing
import conditional_card_score as score
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/conditional-score-v01'


def scene3(enemy_hp=3):
    d=packet.fixture();d.update(enemy_player_hp=enemy_hp)
    for k in ('hand_ids','objectives','purpose_constraints'):d.pop(k)
    return d


def tasks_body():
    return {f'focal_{a}_{h}':dict(kind='joint',body_scope='focal',constraints=dict(
        min_own_body_attack=a,min_own_body_health=h)) for a,h in ((2,2),(2,3),(2,4),(4,3))}


def scenarios():
    cards=score_cards.load_cards();all3=[c['id'] for c in cards if c['card_type']=='monster' and
        c['pool_category']=='ordinary_non_token' and c['cost']==3]
    simple=scene3()
    flex=dict(scene3(30),next_max_plays='all_physical',max_plays='all_physical',own_deck_ids=[],
        opponent_deck_ids=[],next_own_gold_income=3,next_natural_draw_count=0,
        next_opponent_gold_income=0,next_opponent_natural_draw_count=0)
    high=standing.config('next_enemy_attack')['scene'];high['gold_before_play']=8
    control=dict(focal_4_3=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=4,min_own_body_health=3)),
        clear=dict(kind='joint',constraints=dict(max_enemy_living_count=0)),
        suppress=dict(kind='joint',constraints=dict(max_enemy_board_attack=3)))
    cases=[('all-native-3g',dict(scene=simple,candidate_ids=all3,reference_card_id=187,
        include_delay=True)),
        ('late-body-no-background',dict(scene=flex,candidate_ids=[187,22,53,56,377],tasks=tasks_body(),
        reference_card_id=187,include_delay=True)),
        ('same-dummy-background',dict(scene=flex,candidate_ids=[187,22,53,56,377],tasks=tasks_body(),
        background_hand=[dict(card_id=1,current_cost=1,base_cost=1)],reference_card_id=187,include_delay=True)),
        ('clear-versus-body',dict(scene=high,candidate_ids=[21,8,227],tasks=control,
        reference_card_id=21,include_delay=True))]
    for attack in (2,3):
        d=dynamic.scene(534,attack,3)
        for k in ('hand_ids','hand_base_costs','objectives','purpose_constraints'):d.pop(k)
        cases.append((f'5g-counter-attack-{attack}',dict(scene=d,candidate_ids=[534,15,14,509],
            tasks=tasks_body(),reference_card_id=509,include_delay=True)))
    for attack in (6,7,10):
        d=copy.deepcopy(high);d.update(own_player_hp=15,next_max_plays=1,
            enemy_bodies=[dict(card_id=15,attack=attack,health=8,max_health=8,current_card_cost=5,base_cost=5),
                dict(card_id=196,attack=1,health=1,max_health=1,current_card_cost=0,base_cost=0)])
        cases.append((f'toriel-window-target-{attack}-8',dict(scene=d,candidate_ids=[8,14,21],
            tasks=control,reference_card_id=14,include_delay=True)))
    for income in (0,1):
        d=dict(flex,gold_before_play=2,next_own_gold_income=income)
        cases.append((f'cash2-future-income{income}',dict(scene=d,candidate_ids=[187,22,53],
            tasks=tasks_body(),reference_card_id=187,include_delay=True)))
    d=scene3();d['own_player_hp']=27
    cases.append(('healing-cap27',dict(scene=d,candidate_ids=[9,22,53],include_delay=False)))
    # Real observed price increase. Printed/base cost stays3; no unpaid cash tax.
    cases.append(('candy-current-price4',dict(scene=scene3(),candidate_ids=[187],
        candidate_current_costs={'187':4},candidate_base_costs={'187':3},include_delay=True)))
    return cases


def one(item):
    name,config=item;t=time.monotonic();r=score.compare(config)
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/(name+'.input.json')).write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n')
    (OUT/(name+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
    return name,r,round(time.monotonic()-t,3)


def main():
    OUT.mkdir(parents=True,exist_ok=True);rows=[]
    with ProcessPoolExecutor(max_workers=3) as executor:
        fs=[executor.submit(one,item) for item in scenarios()]
        for f in as_completed(fs):
            name,r,seconds=f.result();rows.append((name,r))
            print(json.dumps(dict(case=name,candidates=len(r['rows']),queries=r['actual_search_queries'],seconds=seconds,
                hp_leaders=r['diagnostic_task_leaders']['hp']['best_supported_candidate_ids'],
                choice=r['selection']['best_supported_candidate_ids'])),flush=True)
    # Source-counterfactual uses the same Card IDs and all other native fields.
    cards=copy.deepcopy(score_cards.load_cards());target=next(c for c in cards if c['id']==377)
    before=dict(target);target['health']+=1
    config=dict(scene=scene3(),candidate_ids=[56,187,377],include_delay=True,reference_card_id=187)
    v=score.compare(config,cards);rows.append(('ranger-health-plus1',v))
    (OUT/'ranger-health-plus1.json').write_text(json.dumps(dict(v,counterfactual=dict(card_id=377,
        field='health',before=before['health'],after=target['health'],all_other_source_fields_preserved=True)),ensure_ascii=False,indent=2)+'\n')
    summaries=[]
    for name,r in sorted(rows):
        summaries.append(dict(case=name,artifact=name+'.json',candidate_count=len(r['rows']),
            known_hp=sum(x['scores']['hp']['known'] for x in r['rows']),
            exact_task_queries=sum(s['known'] for x in r['rows'] for s in x['scores'].values()),
            task_leaders=r['diagnostic_task_leaders'],selection=r['selection']))
    columns=['case','card_id','name','printed_cost','task','known','feasible','joint_guaranteed_player_hp',
        'hp_increment_over_removed_copy','same_slot_reference_hp_difference','same_slot_feasibility_change',
        'current_deployment_right_hp','current_deployment_right_feasibility','unknown']
    with (OUT/'scores.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns);w.writeheader()
        for name,r in sorted(rows):
            for card in r['rows']:
                for task,value in card['scores'].items():
                    absent=card['contribution_over_removed_copy'][task];ref=card['same_slot_reference_difference'][task]
                    right=card['current_deployment_right_value'].get(task,{})
                    w.writerow(dict(case=name,card_id=card['card_id'],name=card['name'],printed_cost=card['printed_cost'],
                        task=task,known=value['known'],feasible=value['feasible'],joint_guaranteed_player_hp=value['guaranteed_player_hp'],
                        hp_increment_over_removed_copy=absent.get('hp_difference'),same_slot_reference_hp_difference=ref.get('hp_difference'),
                        same_slot_feasibility_change=ref.get('feasibility_change'),current_deployment_right_hp=right.get('hp_difference'),
                        current_deployment_right_feasibility=right.get('feasibility_change'),unknown='; '.join(value.get('unknown',[]))))
    bindings={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
        ('build_conditional_scores.py','conditional_card_score.py','paid_board_tactics.py','board_tactics.py','alpha_beta_search.py')}
    (OUT/'index.json').write_text(json.dumps(dict(version=score.VERSION,cases=summaries,
        source_hashes=bindings,limits=['Conditional tasks and all unknown cards retained.',
            'No scene frequency, no averagingHP/ATK/Gold. Each column has a distinct joint strategy.']),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(cases=len(rows),candidate_context_rows=sum(len(r['rows']) for n,r in rows))))


if __name__=='__main__':main()