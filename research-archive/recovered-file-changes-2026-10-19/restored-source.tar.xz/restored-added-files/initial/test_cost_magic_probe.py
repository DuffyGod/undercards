"""Target-cost buckets, full payment and guard-preserving counterfactuals."""
import copy
from dataclasses import replace
import unittest
import cost_magic_probe as probe
import score_cards


class CostMagicTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def data(self,**changes):
        d=dict(hand_ids=[443],hand_costs=[10],hand_base_costs=[10],gold_before_play=10,
            own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
            own_deck_ids=[],opponent_deck_ids=[],opponent_hand_ids=[],opponent_hand_known=True,
            max_plays='all_physical',horizon='enemy_attack',node_limit=20000,
            enemy_bodies=[dict(card_id=270,attack=4,health=5,max_health=5,current_card_cost=3,base_cost=3,silenced=True)])
        d.update(changes);return d

    def goal(self):return dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=4,min_own_body_health=8))

    def test_one_complete_native_template_no_tail_dropping(self):
        matches=[c for c in self.cards if probe.parse(c)];self.assertEqual([c['id'] for c in matches],[443])
        self.assertIsNone(probe.parse(dict(matches[0],effect_readable=matches[0]['effect_readable']+' Draw a card.')))

    def test_native_damage5_kills_before_haste_and_preserves_body(self):
        result=probe.evaluate(self.data(),self.goal(),cards=self.cards)
        self.assertTrue(result['known']);self.assertTrue(result['feasible']);self.assertEqual(result['guaranteed_player_hp'],15)
        action=next(a for a in result['search']['principal_variation'] if a['kind']=='deploy')
        self.assertEqual(action['paid_gold'],10);self.assertEqual(action['calculated_damage'],5)
        self.assertTrue(all(a['kind']!='attack' for a in result['search']['principal_variation']))

    def test_bucket_equivalence_can_close_different_cost_facts(self):
        e=probe.CostMagicSearch(self.cards,self.data());u=e.root().enemy[0]
        amount,evidence=probe.dose(replace(u,current_card_cost=7,base_cost=8,printed_cost=6),('target_cost_damage',4,1,3))
        self.assertEqual(amount,6);self.assertEqual(set(evidence['damage_by_referent'].values()),{6})

    def test_disagreeing_or_missing_cost_stays_unknown(self):
        for facts in (dict(current_card_cost=2,base_cost=3),dict(current_card_cost=3)):
            d=self.data();d['enemy_bodies'][0].pop('base_cost');d['enemy_bodies'][0].update(facts)
            r=probe.evaluate(d,self.goal(),cards=self.cards);self.assertFalse(r['known']);self.assertIsNone(r['guaranteed_player_hp'])

    def test_target_cost3_to2_and_single_body_hp_threshold(self):
        cards=copy.deepcopy(self.cards);next(c for c in cards if c['id']==270)['cost']=2
        d=self.data();d['enemy_bodies'][0].update(current_card_cost=2,base_cost=2)
        native=probe.evaluate(d,self.goal(),cards=cards);self.assertTrue(native['known']);self.assertFalse(native['feasible'])
        outcomes=[]
        for hp in (11,12):
            variant=copy.deepcopy(cards);next(c for c in variant if c['id']==443)['health']=hp
            r=probe.evaluate(d,self.goal(),cards=variant);self.assertTrue(r['known']);outcomes.append(r['feasible'])
        self.assertEqual(outcomes,[False,True])

    def test_no_target_rejected_and_alpha_exhaustive_full_vector_agrees(self):
        empty=probe.evaluate(self.data(enemy_bodies=[]),dict(kind='hp'),cards=self.cards);self.assertFalse(empty['known'])
        a=probe.evaluate(self.data(),self.goal(),cards=self.cards)
        b=probe.evaluate(self.data(search_algorithm='exhaustive'),self.goal(),cards=self.cards)
        self.assertTrue(a['known'] and b['known']);self.assertEqual(tuple(a['search']['objective_vector']),tuple(b['search']['objective_vector']))


if __name__=='__main__':unittest.main()