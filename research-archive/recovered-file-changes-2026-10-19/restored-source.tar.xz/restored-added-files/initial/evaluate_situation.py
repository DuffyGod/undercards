"""Evaluate one declared current monster hand: quotes, coverage, action risk.

Input balances/boards/HP are observations supplied by the caller, not sampled
from synthetic deck priors. Future Dust hands remain unknown unless provided.
"""
from __future__ import annotations
import argparse
import copy
import json
import math
from pathlib import Path

import action_outcomes
import combat_increment as combat
import context_value as ledger
import deployment_timing as timing
import heuristic_contexts as contexts
import opportunity_fit as opportunities
import score_cards as base
import unified_value as unified

VERSION='current-situation-evaluation-0.1.0'
REQUIRED={'hand_ids','role','own_turn','gold_before_play','opponent_gold_before_response',
          'own_player_hp','enemy_player_hp','ally_bodies_before_play','enemy_bodies'}
OPTIONAL={'condition_state','response_weights','profile','dust_timing','context_id','useful_threshold'}


def make_state(data):
    if not isinstance(data,dict) or not REQUIRED<=set(data) or not set(data)<=REQUIRED|OPTIONAL:
        raise ValueError('Required current fields: '+', '.join(sorted(REQUIRED)))
    hand=data['hand_ids']
    if not isinstance(hand,list) or not 1<=len(hand)<=7 or any(type(cid) is not int for cid in hand):
        raise ValueError('A known hand needs one to seven monster card IDs; duplicate copies are allowed')
    if data['role'] not in contexts.ROLES or type(data['own_turn']) is not int or data['own_turn']<1:
        raise ValueError('Declare a supported role and positive own-turn index')
    p=unified.normalize_profile(data.get('profile'))
    phase=max((t for t in contexts.PHASES if t<=data['own_turn']),default=min(contexts.PHASES))
    state=copy.deepcopy(next(s for s in contexts.make_contexts()
                    if s['role']==data['role'] and s['own_turn']==phase and s['joint_resource_state']=='reserved'))
    for key in REQUIRED-{'hand_ids'}:
        state[key]=copy.deepcopy(data[key])
    if type(state['own_player_hp']) not in (int,float) or not math.isfinite(state['own_player_hp']) or state['own_player_hp']<=0:
        raise ValueError('Initial own player HP must be positive finite')
    if type(state['enemy_player_hp']) not in (int,float) or not math.isfinite(state['enemy_player_hp']) or state['enemy_player_hp']<=0:
        raise ValueError('Initial enemy player HP must be positive finite')
    if not all(isinstance(state[k],list) for k in ('ally_bodies_before_play','enemy_bodies')):
        raise ValueError('Supply current monster body lists')
    ally,enemy=len(state['ally_bodies_before_play']),len(state['enemy_bodies'])
    for unit in state['ally_bodies_before_play']+state['enemy_bodies']:
        if not isinstance(unit,dict) or not {'attack','health'}<=set(unit):
            raise ValueError('Observed bodies need attack and health')
        for key in ('attack','health'):
            if type(unit[key]) not in (int,float) or not math.isfinite(unit[key]) or unit[key]<0 or (key=='health' and unit[key]==0):
                raise ValueError('Observed bodies must be live with finite nonnegative attack')
    state.update(context_id=data.get('context_id','declared-current-situation'),weight=1.,
        gold_budget_source='declared_observed_balance',
        cumulative_base_gold_cap=contexts.cumulative_base_gold(state['own_turn'],p['second_player']),
        hand_size_before_play=len(hand),hand_size_after_play=len(hand)-1,
        ally_count_before_play=ally,ally_count_after_play=ally+1,
        ally_empty_slots_before_play=4-ally,ally_empty_slots_after_play=3-ally,
        enemy_count=enemy,enemy_empty_slots=4-enemy,other_monster_count=ally+enemy,
        second_player=p['second_player'],enemy_attack_limit=p['enemy_attack_limit'],
        condition_state=copy.deepcopy(data.get('condition_state',{})),
        death_event_hand_costs=[],actually_used_mask=[],
        draw_state_assumptions=copy.deepcopy(p['draw_state_assumptions']))
    weights=data.get('response_weights',combat.RESPONSE_WEIGHTS[state['role']])
    combat.validate_window(0,1,state['enemy_bodies'],{},state['opponent_gold_before_response'],state['role'],weights,
                           state['own_player_hp'],state['enemy_player_hp'])
    state['growth_response_weights']=copy.deepcopy(weights)
    window=state['resource_use_window']
    window.update(death_event_own_turn=state['own_turn'],first_own_turn=state['own_turn']+1,
                  last_own_turn=state['own_turn']+2,assumed_carry_gold=0)
    window['base_income_in_window']=sum(contexts.base_income(t,p['second_player']) for t in range(state['own_turn']+1,state['own_turn']+3))
    window['available_gold_assumption']=window['base_income_in_window']
    contexts.validate_context(state)
    if 'dust_timing' in data:
        state['dust_timing']=copy.deepcopy(data['dust_timing'])
    else:
        prepared=timing.dust_context(state,state,p)
        if prepared is None:
            # Current input has no future usage evidence: keep it unknown even
            # if a caller chooses legacy full-pool reproducibility parameters.
            prepared=timing.dust_context(state,state,unified.normalize_profile())
        for branch in prepared['branches']:
            if branch['event']=='ordinary_death':
                branch.pop('hand_at_event',None)
                branch.pop('payment_windows',None)
                branch.pop('initial_gold',None)
        state['dust_timing']=prepared
    state['assumptions']=[
        'Current hand, boards, player HP and balances are caller observations; not server-verified.',
        'Gold observations may include non-base income; no artificial cumulative-base cap is imposed on supplied balances.',
        'Current coverage chooses at most one affordable monster; combinations, other allied attacks and spells are not covered.',
        'Response weights/order and future draw priors are declared model scenarios, not measured opponent frequencies.',
        'Before own turn 3, earliest phase event priors are extrapolated design assumptions, not validated early-game risks.',
        'Future Dust hand/payment plan is unknown unless dust_timing is supplied; it is not an empty-hand zero assumption.']
    return state,p


def evaluate(data,reference=None,cards=None):
    cards=base.load_cards() if cards is None else cards
    by_id={c['id']:c for c in cards}
    state,profile=make_state(data)
    try:
        hand=[by_id[cid] for cid in data['hand_ids']]
    except KeyError as exc:
        raise ValueError('Unknown card ID: '+str(exc)) from exc
    if any(c['card_type']!='monster' or c['health']<=0 for c in hand):
        raise ValueError('This current entry point handles monster hands only')
    if reference is None:
        reference,_=base.make_reference(cards)
    coverage=opportunities.hand_coverage(hand,[state],reference,data.get('useful_threshold',0))
    window_results=[dict(hand_index=i,card_id=c['id'],name=c['name'],
                         **action_outcomes.evaluate(c,state,reference,state['growth_response_weights']))
                    for i,c in enumerate(hand)]
    return dict(version=VERSION,ledger_version=ledger.VERSION,combat_version=combat.VERSION,
                input=copy.deepcopy(data),declared_current_state=state,profile=profile,
                card_quotes=coverage['rows'][0]['actions'],hand_coverage=coverage,
                action_windows=window_results,scope=state['assumptions'])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    result=evaluate(json.loads(args.input.read_text(encoding='utf-8')))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(cards=len(result['card_quotes']),
        quoted=sum(row['pricing_supported'] for row in result['card_quotes']),
        no_effective_action_bounds=result['hand_coverage']['no_effective_action_weight_bounds'])))


if __name__=='__main__':
    main()