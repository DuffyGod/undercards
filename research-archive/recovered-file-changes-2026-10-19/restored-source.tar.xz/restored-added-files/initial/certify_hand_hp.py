"""Source-bound scalar HP optimum from a physical policy and healing ceiling.

A fixed legal enemy strategy (idle) supplies an upper bound for ANY own
policy. All physical own hand/library copies and live callbacks are checked.
A separately searched fixed own prefix supplies a guaranteed lower bound
against every implemented enemy reply. Equal bounds certify only HP, never
the complete lexicographic vector or all reachable mechanics.
"""
import copy
import hashlib
from pathlib import Path
import re
import finite_conditions
import paid_board_tactics as paid
import score_cards


def healing_ceiling(engine,root):
    unknown=[];rows=[];extensions=0;healing=0
    own_starts=int(engine.horizon!='enemy_attack')
    own_ends=1+own_starts
    needs_library=bool(engine.natural_draw)
    indexes=list(root.hand)
    # Strip only inventoried Need clauses to examine the strongest possible
    # Magic branch, even when its root condition is false or future-changing.
    def compile_unconditional(card):
        c=copy.deepcopy(card);text=c.get('effect_readable','')
        need=finite_conditions.parse_need(text)
        if need:
            if need['kind']=='unknown':raise paid.UnknownMechanic('Unknown Need cannot certify healing ceiling')
            for clause in finite_conditions.NEED_CLAUSES:text=text.replace(clause+' ','').replace(clause,'')
            c['effect_readable']=text
        return engine.spec(c,collect_unknown=False) if c['card_type']=='monster' else paid.spell_spec(c)
    specs={}
    for i in indexes:
        c=engine.hand[i][0];sp=compile_unconditional(c);specs[i]=sp
        if sp.get('magic') and sp['magic'][0]=='draw':needs_library=True
    if needs_library:
        if root.own_deck is None:raise paid.UnknownMechanic('Unknown drawn identities can contain additional healing')
        indexes+=list(root.own_deck)
        for i in root.own_deck:specs[i]=compile_unconditional(engine.hand[i][0])
    zero_magic={'toriel','self_atk_taunt','buff_paralyze','draw','damage_enemy','damage_all_enemy','damage_face',
        'damage_any','buff_ally_atk','buff_ally_hp','buff_any_hp','debuff_all_enemy_atk','buff_all_ally_atk',
        'buff_all_ally_stats','buff_ally_stats','debuff_enemy_stats','self_atk_per_ally','self_hp_per_enemy',
        'self_damage','silence_monster','silence_or_kill_enemy','paralyze_monster','paralyze_monster_if_already_damage'}
    for i in indexes:
        c=engine.hand[i][0];sp=specs[i]
        if sp['unknown']:raise paid.UnknownMechanic('Unclosed healing source '+str(c['id'])+': '+'; '.join(sp['unknown']))
        if re.search(r'\bTurbo\b|(?:After|When|Whenever).*draw|^In your hand|^While .*hand',c.get('effect_readable',''),re.I):
            raise paid.UnknownMechanic('Unclosed draw/held passive for healing ceiling')
        gain=0;ext=0
        if c['card_type']=='spell':
            if any(e['kind'] not in ('damage','kill','buff','gold','silence','silence_kill','buff_hand') for e in sp.get('spell',[])):
                raise paid.UnknownMechanic('Spell outside finite nonhealing registry')
        else:
            magic=sp.get('magic')
            if magic:
                if magic[0] in ('heal_any','heal_player'):gain+=magic[1]
                elif magic[0]=='extend_player_hp':gain+=magic[1];ext+=magic[1]
                elif magic[0] not in zero_magic:raise paid.UnknownMechanic('Magic can create additional uncounted sources: '+str(magic))
            if sp.get('delay'):gain+=sp['delay']['heal']
            if sp.get('start'):
                k,n=sp['start']
                if k=='heal_player':gain+=n*own_starts
                elif k=='extend_player_hp':gain+=n*own_starts;ext+=n*own_starts
                elif k!='self_atk':raise paid.UnknownMechanic('Uncounted owner start effect')
            if sp.get('end'):
                k,n=sp['end']
                if k=='idle_heal':gain+=n*own_ends
                elif k not in ('cash','both_cash','decline'):raise paid.UnknownMechanic('Uncounted owner end effect')
            if sp.get('dust') and sp['dust'][0] not in ('cash','damage_all_monsters','damage_all_enemy_monsters'):
                raise paid.UnknownMechanic('Dust can create additional uncounted healing sources')
        healing+=gain;extensions+=ext
        rows.append(dict(physical_index=i,card_id=c['id'],max_player_hp_gain=gain,max_hp_extension=ext))
    for u in root.own:
        gain=ext=0
        if u.start:
            k,n=u.start
            if k=='heal_player':gain+=n*own_starts
            elif k=='extend_player_hp':gain+=n*own_starts;ext+=n*own_starts
            elif k!='self_atk':raise paid.UnknownMechanic('Uncounted live owner start')
        if u.end:
            k,n=u.end
            if k=='idle_heal':gain+=n*own_ends
            elif k not in ('cash','both_cash','decline'):raise paid.UnknownMechanic('Uncounted live owner end')
        if u.dust and u.dust[0] not in ('cash','damage_all_monsters','damage_all_enemy_monsters'):
            raise paid.UnknownMechanic('Live Dust can create uncounted sources')
        healing+=gain;extensions+=ext
        rows.append(dict(live_unit=u.key,max_player_hp_gain=gain,max_hp_extension=ext))
    if root.queued_delays:raise paid.UnknownMechanic('Initial pending queue not counted by this certificate')
    # The chosen counterstrategy never voluntarily casts, plays or attacks.
    # Its existing owner callbacks cannot force healing onto the own hero in
    # this finite registry; refuse new/unknown incoming draw effects instead.
    if engine.horizon=='next_enemy_attack' and engine.second_enemy_draw:
        if root.enemy_deck is None:raise paid.UnknownMechanic('Unknown enemy draw can change the healing ceiling')
        for i in root.enemy_deck[:engine.second_enemy_draw]:
            text=engine.enemy_hand[i][0].get('effect_readable','')
            if re.search(r'\bTurbo\b|(?:After|When|Whenever).*draw|in (?:your )?hand',text,re.I):
                raise paid.UnknownMechanic('Enemy draw callback outside upper-bound proof')
    return dict(ceiling_complete=True,guaranteed_hp_upper=min(root.own_hp+healing,root.own_max_hp+extensions),
        physical_healing_sources=rows,root_player_hp=root.own_hp,max_possible_hp_gain=healing,
        counterstrategy='Enemy stops without optional plays/casts/attacks in each reply; drawing follows declared observations.',
        assumptions=['Each physical hand/library copy is counted once; a possible false Need is relaxed to its strongest Magic.',
            'No uncounted creation/held/draw callbacks; player healing from live owner callbacks is bounded by reached own turn count.',
            'Healing need not be payable or successfully targeted in this upper bound; this relaxation can only raise the ceiling.'])


def certify(data,prefix,cards=None):
    cards=score_cards.load_cards() if cards is None else cards
    e=paid.PaidSearch(cards,data);root=e.root();unknown=list(e.unknown)
    upper=None;lower=None;actions=[];state=root
    try:
        if unknown:raise paid.UnknownMechanic('; '.join(unknown))
        upper=healing_ceiling(e,root)
        for request in prefix:
            if request.get('kind')=='end_turn':
                actions.append(dict(kind='end_turn',phase=state.phase));state=e.boundary(state);continue
            matches=[(a,s) for a,s in e.deploys(state) if a.get('side','own')=='own' and
                all(a.get(k)==v for k,v in request.items())]
            if len(matches)!=1:raise paid.UnknownMechanic('Prefix must identify exactly one physical legal action')
            a,state=matches[0];actions.append(a)
        lower=e.solve(state,'guaranteed_hp')
        if not lower['search_complete']:unknown+=lower.get('unknown',[])
    except paid.UnknownMechanic as error:unknown.append(str(error))
    lo=lower['metrics']['own_player_hp'] if lower and lower['search_complete'] else None
    hi=upper['guaranteed_hp_upper'] if upper else None
    exact=not unknown and lo is not None and hi==lo
    if lo is not None and hi is not None and lo>hi:raise AssertionError('Feasible policy exceeds claimed upper ceiling')
    here=Path(__file__).resolve().parent
    return dict(hp_optimum_certified=exact,optimal_guaranteed_hp=lo if exact else None,
        guaranteed_hp_bounds=[lo,hi],full_future_vector_optimized=False,unknown=sorted(set(unknown)),
        input=data,prefix=actions,upper_certificate=upper,feasible_continuation=lower,
        source_hashes={f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in
            ('certify_hand_hp.py','paid_board_tactics.py','board_tactics.py','alpha_beta_search.py','queued_delay.py')},
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        limitations=['Only the scalar HP optimum when independently established bounds meet.',
            'The continuation must adapt to actual legal replies; the printed principal variation is one worst path, not every branch.',
            'No empirical probabilities, whole-pool champion or calibrated card Gold value.'])