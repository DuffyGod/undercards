"""Actual paid replies, independent packet proofs and role-sensitive choices."""
import copy
from dataclasses import replace
import hashlib
import json
from pathlib import Path

import board_tactics as board
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/damage-packet-v01'
INDEPENDENT=HERE/'research-runs/damage-packet-v01'
COHORT=(56,187,377)


def fixture(cid=56,enemy_hp=3):
    d=json.loads((INDEPENDENT/'independent-scenario.json').read_text())
    d.update(hand_ids=[cid],enemy_player_hp=enemy_hp,
        objectives=['guaranteed_hp','purpose'],purpose_constraints=dict(min_own_player_hp=1,
        min_own_body_attack=2,min_own_body_health=1))
    return d


def run(name,data,cards):
    r=paid.evaluate(data,cards);ex=paid.evaluate(dict(data,search_algorithm='exhaustive'),cards)
    assert r['complete_in_declared_scope']==ex['complete_in_declared_scope']
    if r['complete_in_declared_scope']:
        assert [o['objective_vector'] for o in r['objectives']]==[o['objective_vector'] for o in ex['objectives']]
    return dict(case=name,input=data,result=r,exhaustive_vector=[o.get('objective_vector') for o in ex['objectives']],
        complete=r['complete_in_declared_scope'])


def body_bound(data,cards):
    """Largest integral same-body HP bound, independent of player HP optimum.

    No body-health buffs in this declared cohort. Native startingHP is a valid
    physical upper bound; every positive tested threshold requires player1HP.
    """
    by={c['id']:c for c in cards};top=by[data['hand_ids'][0]]['health'];proofs=[];best=0
    for n in range(1,top+1):
        d=copy.deepcopy(data);d.update(objectives=['purpose'],purpose_constraints=dict(
            min_own_player_hp=1,min_own_body_attack=2,min_own_body_health=n))
        r=paid.evaluate(d,cards);assert r['complete_in_declared_scope'],r['unknown']
        yes=r['objectives'][0]['purpose_guaranteed'];proofs.append(dict(health=n,guaranteed=yes))
        if yes:best=n
    assert [x['guaranteed'] for x in proofs]==[n<=best for n in range(1,top+1)]
    return dict(bound=best,physical_upper_bound=top,threshold_proofs=proofs,
        scope='Independent purpose optimizations. Not the bodyHP of the HP-optimal path.')


def paid_packet_scene(cid,spells):
    c=next(x for x in score_cards.load_cards() if x['id']==cid)
    return dict(hand_ids=[],gold_before_play=0,max_plays=0,own_player_hp=30,own_player_max_hp=30,
        enemy_player_hp=30,enemy_player_max_hp=30,
        ally_bodies_before_play=[dict(card_id=cid,attack=c['attack'],health=c['health'],max_health=c['health'],ready=False)],
        enemy_bodies=[],opponent_hand_ids=spells,opponent_gold_before_response=4,horizon='enemy_attack',
        objectives=['purpose'],purpose_constraints=dict(min_own_player_hp=1,min_own_body_attack=2,min_own_body_health=2))


def forced_packet(data,cards):
    e=paid.PaidSearch(cards,data);s=e.boundary(e.root());steps=[]
    while s.enemy_hand:
        target=('own',0) if s.own[0].health>0 else ('own_player',None)
        options=list(e.spells(s,'enemy'))
        a,next_state=next((a,t) for a,t in options if a['targets']==[target])
        steps.append(dict(action=a,before_health=s.own[0].health,after_health=next_state.own[0].health,
            enemy_gold_before=s.enemy_gold,enemy_gold_after=next_state.enemy_gold,own_player_hp=next_state.own_hp))
        s=next_state
    return dict(steps=steps,actual_enemy_payment=4-s.enemy_gold,body_hp=s.own[0].health,
        no_attack_witness=True,scope='One feasible fully paid sequence; worst-reply search is reported separately.')


def build():
    cards=score_cards.load_cards();by={c['id']:c for c in cards};rows=[];summary=[]
    independent=json.loads((INDEPENDENT/'independent-probe-results.json').read_text())
    for enemy_hp in (2,3,4):
        for cid in COHORT:
            d=fixture(cid,enemy_hp);r=run(f'native-{cid}-enemyhp-{enemy_hp}',d,cards)
            assert r['complete'];rows.append(r)
            expected=12 if enemy_hp==2 or (enemy_hp==3 and cid==377) else 11
            actual=r['result']['objectives'][0]['metrics']['own_player_hp'];assert actual==expected
            if enemy_hp==3:
                bound=body_bound(d,cards);assert bound['bound']=={56:1,187:2,377:0}[cid]
                assert actual==next(x['guarantee'] for x in independent['rows'] if x['card_id']==cid and x['objective']=='hp')
                assert bound['bound']==next(x['guarantee'] for x in independent['rows'] if x['card_id']==cid and x['objective']=='body_hp')
                summary.append(dict(card_id=cid,name=by[cid]['name'],guaranteed_player_hp=actual,
                    guaranteed_same_body_hp=bound['bound'],body_bound=bound))
    for cid in COHORT:
        d=fixture(cid);d['opponent_gold_before_response']=1
        rows.append(run(f'enemy-cash1-{cid}',d,cards))
        d=fixture(cid);d['gold_before_play']=2
        rows.append(run(f'own-cash2-held-{cid}',d,cards))
    packets=[]
    for spells,label in (([351],'one8'),([598]*4,'four1')):
        for cid in COHORT:
            d=paid_packet_scene(cid,spells);r=run(f'paid-packet-{label}-{cid}',d,cards)
            assert r['complete'];r['forced_paid_witness']=forced_packet(d,cards);rows.append(r)
            packets.append(dict(card_id=cid,spell_ids=spells,actual_payment=r['forced_paid_witness']['actual_enemy_payment'],
                body_hp=r['forced_paid_witness']['body_hp'],body_at_least2_guaranteed=r['result']['objectives'][0]['purpose_guaranteed']))
    assert [p['body_hp'] for p in packets]==[2,0,2,1,2,0]
    # No arbitrary modifier ordering, source ownership or zero event is guessed.
    uncertain=[('cap-armor-order',dict(card_id=56,attack=2,health=5,max_health=5,armor=True),8),
        ('bowll-zero-counter',dict(card_id=840,attack=8,health=9,max_health=9),0)]
    for label,u,attack in uncertain:
        d=dict(hand_ids=[],gold_before_play=0,max_plays=0,own_player_hp=30,own_player_max_hp=30,
            ally_bodies_before_play=[dict(u,ready=True)],enemy_bodies=[dict(attack=attack,health=20)],
            horizon='enemy_attack',objectives=['guaranteed_hp'])
        r=run(label,d,cards);assert not r['complete'];rows.append(r)
    # Native printed-body intervention, not an ID exception or extra Gold price.
    uncapped=copy.deepcopy(cards);next(c for c in uncapped if c['id']==56)['effect_readable']=''
    d=paid_packet_scene(56,[351]);r=run('mettaton-cap-removed',d,uncapped);assert r['complete'];rows.append(r)
    assert r['result']['objectives'][0]['purpose_guaranteed'] is False
    OUT.mkdir(parents=True,exist_ok=True)
    record=dict(version='paid-damage-packet-comparison-0.1.0',paid_version=paid.VERSION,
        source_snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('board_tactics.py','paid_board_tactics.py','alpha_beta_search.py','build_damage_packet_comparison.py')},
        independent_probe_sha256=hashlib.sha256((INDEPENDENT/'independent_probe.py').read_bytes()).hexdigest(),
        independent_output_sha256=hashlib.sha256((INDEPENDENT/'independent-probe-results.json').read_bytes()).hexdigest(),
        cases=rows,role_summary=summary,paid_packet_examples=packets,
        unknown_cases=[r['case'] for r in rows if not r['complete']],
        limitations=['Conditional source interpretations, not server verification or whole-match rankings.',
            'Packet witnesses are chosen legal sequences; full evaluated purposes include every enemy target/order/stopping and real payment.',
            'PlayerHP and same-bodyHP are independently optimized, never concatenated.',
            'Gemstone/Gaster Blaster are explicitly physically held TOKENs, not ordinary construction copy claims.',
            'Mettaton+COST/Armor order and Bowll zero-event/friendly-spell grammar stay unknown if physical states differ.',
            'No new Gold fitting or meta probabilities.'])
    (OUT/'comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    lines=['# 按真实付费惩罚与目的比较站场牌','',
        '新paid0.20/board0.3接入Mettaton的单实例封顶3与Bowll的敌来源额外受伤2；处理普通战斗双方反击、Magic、自伤、Dust与物理咒术。Caps/Armor/COST/Dodge组合不挑有利顺序，物理HP或Dodge不同则unknown。','',
        '同3G、己15/30HP、敌3/30HP，敌已观察Aaron1ATK/5HP、两张实际持有Gemstone和2G；到第二敌回应，无后续收入/抽牌。允许持有不出、任意合法攻击/付款目标/顺序/停止。','',
        '| 候选 | 玩家HP最大保证 | 同一体HP最大保证（且玩家活） |', '|---|---:|---:|']
    for r in summary:lines.append(f"| {r['name']} | {r['guaranteed_player_hp']} | {r['guaranteed_same_body_hp']} |")
    lines+=['','两列是不同策略。Ranger的3攻能在下一己方攻击窗口终结，但为了杀其Dodge体，对手可以先用Aaron1伤消耗盾，再逐张付Gem1G；此路玩家损失少，却不能保身体。提高同体HP要求1→2，只Candy通过。敌玩家3HP→2或4时，HP差异分别变成全12或全11：优势来自真实终结门槛，非固定Dodge加分。','',
        '| 敌实际支付4G | Mettaton体HP | Candy体HP | Ranger体HP |', '|---|---:|---:|---:|',
        '| 一张Gaster Blaster，8伤 | 2 | 0 | 2 |', '| 四张Gemstone，1伤多次 | 1 | 2 | 0 |','',
        '这是可行付费示例；另有完整最坏回应目的检查。Ranger第三Gem已死亡，第四张改为合法玩家目标，不能继续指定死人。预算相同而身体排序反转，因此风险必须描述实例形态及对手真实持牌，不能按总伤或固定抗性奖励计价。','',
        '移除Mettaton cap源文后单8伤留体目的从true变false。Mettaton额外Armor面对8伤，两种顺序留下3HP或2HP，完整推荐保持unknown；Bowll与0攻反击的零事件解释也unknown，未把缺裁定填0。','',
        '完整JSON保留各目的向量、付款、合法路径、alpha-beta/穷举一致结果，并和不调用核心原语的独立小博弈求值对照。']
    (OUT/'comparison.md').write_text('\n'.join(lines)+'\n')
    return record


if __name__=='__main__':
    r=build();print(json.dumps(dict(cases=len(r['cases']),unknown=r['unknown_cases'],role_summary=[
        {k:v for k,v in x.items() if k!='body_bound'} for x in r['role_summary']]),ensure_ascii=False))