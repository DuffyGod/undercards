"""Change the deadline and actual reply payment; do not extrapolate a short score."""
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import alternative_goal_score as alt
import conditional_card_score as score


def main():
    bindings=score.source_bindings(ROOT/'alternative_goal_score.py');rows=[];queries=0
    for cid in (20,110,292,534,443,8):
        raw=json.loads((HERE/f'card{cid}.json').read_text())
        for horizon in ('next_own_attack','next_enemy_attack'):
            for reply in ('none','headshot-now6','headshot-later6'):
                data=copy.deepcopy(raw['input']);data.update(horizon=horizon,next_max_plays='all_physical',
                    next_own_gold_income=0,next_natural_draw_count=0)
                if horizon=='next_enemy_attack':
                    data.update(next_opponent_gold_income=1 if reply=='headshot-later6' else 0,
                        next_opponent_natural_draw_count=0)
                if reply!='none':
                    data.update(opponent_hand_ids=[100],opponent_hand_costs=[6],opponent_hand_base_costs=[6],
                        opponent_gold_before_response=6 if reply=='headshot-now6' else 5)
                results={}
                for name in ('hp','clear','clear_or_focal4_1'):
                    task=raw['tasks'][name]
                    results[name]=(alt.evaluate(data,task,focal_index=0) if task['kind']=='any'
                        else score.task_score(data,task,focal_index=0))
                    queries+=1
                label=f'card{cid}-{horizon}-{reply}';path=HERE/(label+'.json')
                path.write_text(json.dumps(dict(input=data,results=results,tasks=raw['tasks']),ensure_ascii=False,indent=2)+'\n')
                row=dict(card_id=cid,horizon=horizon,reply=reply,artifact=path.name,
                    scores={n:{k:v.get(k) for k in ('known','feasible','guaranteed_player_hp','unknown')} for n,v in results.items()})
                rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
    assert bindings==score.source_bindings(ROOT/'alternative_goal_score.py')
    (HERE/'horizon-transfer.json').write_text(json.dumps(dict(source_hashes=bindings,source_stable=True,
        builder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),actual_task_queries=queries,rows=rows,
        note='New deadlines are separately solved. No monotonicity across different deadlines or reply-income observations is assumed.'),ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()