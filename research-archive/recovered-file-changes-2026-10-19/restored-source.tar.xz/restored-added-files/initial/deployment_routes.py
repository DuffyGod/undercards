"""Observed-hand, at most two current plays, with one shared cash/board ledger.

This deliberately exposes restricted action ordering. It never sums card quotes
or uses a hidden reply to choose the second card. It is a survival axis only.
"""
import copy
import math

import action_outcomes
import combat_increment as combat
import spell_window

VERSION = 'shared-current-hand-routes-0.1.0'


def _window(card, ctx, reference, weights):
    return (spell_window.evaluate if card['card_type']=='spell' else action_outcomes.evaluate)(card,ctx,reference,weights)


def _current(action):
    if 'after_current' in action:
        return action['after_current']['state']
    return action['paths'][0]['after_current']['state']


def _next_context(ctx, raw, remaining_hand_count, cash):
    next_ctx=copy.deepcopy(ctx)
    allies=copy.deepcopy(raw.get('external_allies',ctx['ally_bodies_before_play']))
    actor=raw.get('actor')
    if actor and actor['health']>0:
        allies.append(copy.deepcopy(actor))
    allies=[x for x in allies if x['health']>0]
    enemies=[copy.deepcopy(x) for x in raw['enemies'] if x['health']>0]
    a,e=len(allies),len(enemies)
    next_ctx.update(gold_before_play=cash,own_player_hp=raw['own_player_hp'],
        enemy_player_hp=raw['enemy_player_hp'],opponent_gold_before_response=raw['enemy_gold'],
        ally_bodies_before_play=allies,enemy_bodies=enemies,
        hand_size_before_play=remaining_hand_count,hand_size_after_play=remaining_hand_count-1,
        ally_count_before_play=a,ally_count_after_play=a+1,
        ally_empty_slots_before_play=4-a,ally_empty_slots_after_play=3-a,
        enemy_count=e,enemy_empty_slots=4-e,other_monster_count=a+e)
    # Summoning a spell is a current history observation for a later Need.
    # Last-turn history never changes during this current route.
    return next_ctx


def _summary(actions, steps, cash):
    last=actions[-1]
    return dict(steps=steps,actual_paid_gold=sum(s['paid_gold'] for s in steps),
        gold_remaining=cash,death_probability=last['death_probability'],
        defeat_probability=last['defeat_probability'],outcome_known=last['outcome_known'],
        model_gold=None,action_id=' / '.join(str(s['hand_index'])+':'+s['action_id'] for s in steps))


def evaluate(hand,ctx,reference,weights=None,max_plays=2):
    if type(max_plays) is not int or not 1<=max_plays<=2:
        raise ValueError('Current route enumeration supports one or two plays')
    weights=ctx.get('growth_response_weights') if weights is None else weights
    routes=[];unknown=[]
    for i,card in enumerate(hand):
        first=_window(card,ctx,reference,weights)
        if not first['deployment_legal_now']:
            continue
        if not first['window_known']:
            unknown.append(dict(prefix=[],hand_index=i,reasons=first['window_unknown']))
        for action in first['actions']:
            if not action['outcome_known']:
                continue
            raw=_current(action)
            cash=(raw['own_gold'] if card['card_type']=='spell' else ctx['gold_before_play']-card['cost'])
            steps=[dict(hand_index=i,card_id=card['id'],action_id=action['action_id'],paid_gold=card['cost'])]
            routes.append(_summary([action],steps,cash))
            if max_plays==1 or len(hand)<2 or combat.terminal(raw):
                continue
            next_ctx=_next_context(ctx,raw,len(hand)-1,cash)
            for j,second_card in enumerate(hand):
                if i==j or second_card['cost']>cash:
                    continue
                if second_card['card_type']=='monster' and len(next_ctx['ally_bodies_before_play'])>=4:
                    continue
                second=_window(second_card,next_ctx,reference,weights)
                if not second['deployment_legal_now']:
                    continue
                if not second['window_known']:
                    unknown.append(dict(prefix=copy.deepcopy(steps),hand_index=j,reasons=second['window_unknown']))
                for second_action in second['actions']:
                    if not second_action['outcome_known']:
                        continue
                    final_raw=_current(second_action)
                    final_cash=(final_raw['own_gold'] if second_card['card_type']=='spell' else cash-second_card['cost'])
                    route=_summary([action,second_action],steps+[dict(hand_index=j,
                        card_id=second_card['id'],action_id=second_action['action_id'],paid_gold=second_card['cost'])],final_cash)
                    # A fresh later simulation carries board/HP but not earlier
                    # utility deltas. Consequently no summed Gold diagnostic.
                    routes.append(route)
    known=[r for r in routes if r['outcome_known']]
    best=min(known,key=lambda r:(r['death_probability'],-r['defeat_probability'],r['actual_paid_gold'],len(r['steps']),r['action_id'])) if known else None
    lowest=min((r['death_probability'] for r in known),default=None)
    return dict(version=VERSION,max_current_plays=max_plays,routes=routes,unknown_routes=unknown,
        best_known_survival_route=best,complete_within_restricted_order=not unknown,
        lowest_death_probability_bounds=([0. if unknown else lowest,lowest] if lowest is not None else [0.,1.]),
        scope=['Current observed hand only; first and second actions commit before the hidden response.',
            'One shared balance and board: each cost once, card copies consumed by hand index, no extra income or borrowed Gold.',
            'First card current attack occurs before the second play; deferred first-card attacks and proactive existing-allied attacks are unsearched.',
            'Final actor has one next-own attack; this is a restricted finite survival policy, not a full-game optimum.',
            'No addition of per-card Gold, no combo bonus, and no reuse of a first-card utility snapshot as a second reward.',
            'Unknown viable routes are retained; a best known rescue is evidence of feasibility, not proof of global optimality.'])