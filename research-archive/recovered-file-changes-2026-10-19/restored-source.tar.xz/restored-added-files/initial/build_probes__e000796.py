"""Compare real high-fee candidates under one cash budget and COST buckets."""
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import conditional_card_score as score
import cost_magic_probe as probe

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,obj):(HERE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

def main():
    native=score.score_cards.load_cards();by={c['id']:c for c in native};bindings=score.source_bindings(ROOT/'cost_magic_probe.py')
    def scene(cid,cost=3,attack=4,health=5,count=1):
        return dict(hand_ids=[cid],hand_costs=[by[cid]['cost']],hand_base_costs=[by[cid]['cost']],gold_before_play=10,
            own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
            own_deck_ids=[],opponent_deck_ids=[],opponent_hand_ids=[],opponent_hand_known=True,opponent_gold_before_response=0,
            max_plays='all_physical',horizon='enemy_attack',node_limit=20000,physical_slots=True,
            front_slot_map=[0,1,2,3],front_missing_policy='fizzle',switch_left_slots=[0,1],
            enemy_bodies=[dict(card_id=270,attack=attack,health=health,max_health=4 if health==2 else health,
                current_card_cost=cost,base_cost=cost,silenced=True,slot=j) for j in range(count)])
    tasks=dict(hp=dict(kind='hp'),clear=copy.deepcopy(score.DEFAULT_TASKS['clear']),
        body4_8=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=4,min_own_body_health=8)))
    source2=copy.deepcopy(native);next(c for c in source2 if c['id']==270)['cost']=2
    write('target-cost2.cards.json',dict(cards=source2,intervention='Only target identity printed cost3→2; current/base observations changed together to specify an unmodified2G target.'))
    rows=[];queries=0;vectors=[]
    configurations=[('single-cost3',[443,110,8],native,dict()),
        ('single-cost2',[443,110,8],source2,dict(cost=2)),
        ('big-attack20',[443,110,8],native,dict(attack=20,health=8)),
        ('wide-hp2',[443,419,249,110,8],native,dict(health=2,count=4))]
    for label,ids,cards,changes in configurations:
        for cid in ids:
            data=scene(cid,**changes);values={}
            for task_name,task in tasks.items():
                value=probe.evaluate(data,task,cards=cards);queries+=1;values[task_name]=value
                rows.append(dict(context=label,card_id=cid,name=by[cid]['name'],task=task_name,known=value['known'],
                    feasible=value['feasible'],hp=value['guaranteed_player_hp'],unknown=value['unknown'],artifact=f'{label}-card{cid}.json'))
                if (label,cid,task_name) in [('single-cost3',443,'body4_8'),('wide-hp2',419,'hp')]:
                    other=probe.evaluate(dict(data,search_algorithm='exhaustive'),task,cards=cards);queries+=1
                    match=value['known'] and other['known'] and tuple(value['search']['objective_vector'])==tuple(other['search']['objective_vector'])
                    assert match;vectors.append(dict(context=label,card_id=cid,task=task_name,alpha=value,exhaustive=other))
            write(f'{label}-card{cid}.json',dict(input=data,results=values,tasks=tasks,
                actual_card_source='target-cost2.cards.json' if cards is source2 else 'native-snapshot.json'))
    for hp in (11,12):
        cards=copy.deepcopy(source2);next(c for c in cards if c['id']==443)['health']=hp
        name=f'source-hp{hp}';write(name+'.cards.json',dict(cards=cards,intervention='Relative to target-cost2 source, only Spade Chain health changed.'))
        data=scene(443,cost=2);values={}
        for task_name in ('hp','body4_8'):
            value=probe.evaluate(data,tasks[task_name],cards=cards);queries+=1;values[task_name]=value
            rows.append(dict(context=name,card_id=443,name=by[443]['name'],task=task_name,known=value['known'],
                feasible=value['feasible'],hp=value['guaranteed_player_hp'],unknown=value['unknown'],artifact=name+'.json'))
        write(name+'.json',dict(input=data,results=values,actual_card_source=name+'.cards.json'))
    guards=[]
    for label,changes in [('cost-disagreement',dict(current_card_cost=2,base_cost=3)),('missing-base',{})]:
        data=scene(443)
        if label=='missing-base':data['enemy_bodies'][0].pop('base_cost')
        data['enemy_bodies'][0].update(changes)
        value=probe.evaluate(data,tasks['hp'],cards=native);queries+=1;assert not value['known']
        write(label+'.json',dict(input=data,result=value));guards.append(dict(label=label,unknown=value['unknown']))
    write('vector-checks.json',vectors)
    assert bindings==score.source_bindings(ROOT/'cost_magic_probe.py')
    src=HERE/'source';src.mkdir(exist_ok=True)
    for name,h in bindings.items():assert sha(ROOT/name)==h;(src/name).write_bytes((ROOT/name).read_bytes())
    (HERE/'native-snapshot.json').write_bytes(score.score_cards.DEFAULT_SNAPSHOT.read_bytes())
    write('index.json',dict(source_hashes=bindings,source_stable=True,builder_sha256=sha(Path(__file__)),rows=rows,
        guard_cases=guards,actual_queries=queries,full_vector_matches=len(vectors),prototype_only=True,
        observation_fix_required=True,node_limit_unchanged=20000,
        limits=['Single10G native family; other candidates use existing core mechanics at the same10G cash, without free use of their remaining cash.',
            'COST referent envelope=current/base/printed; agreement concerns damage buckets, not exact fee equality.',
            'No other monster target remains unknown; no guessed self/no-target rule.',
            'Alternative costs/HP are explicit hypothetical source changes; no live balancing or global Gold.']))
    print(json.dumps(dict(actual_queries=queries,rows=rows),ensure_ascii=False),flush=True)

if __name__=='__main__':main()