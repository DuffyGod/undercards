"""Actual API/CLI and full-vector alpha-beta/exhaustive equivalence."""
import copy
import gzip
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import evaluate_situation as api
import paid_board_tactics as paid
from benchmark import scene, by, cards, DECLARED

P = Path(__file__).parent
checks = []
for cid in (17, 163, 291, 526):
    data = scene(cid, 'small')
    if cid == 291: data['combat_event_rules'] = DECLARED
    data.update(hand_costs=[by[cid]['cost']], objectives=['guaranteed_hp'])
    a = paid.evaluate(dict(data, search_algorithm='alpha_beta'), cards)
    b = paid.evaluate(dict(data, search_algorithm='exhaustive'), cards)
    assert a['complete_in_declared_scope'] and b['complete_in_declared_scope']
    assert a['objectives'][0]['objective_vector'] == b['objectives'][0]['objective_vector']
    keys = ('hand_ids','gold_before_play','opponent_gold_before_response','own_player_hp',
            'enemy_player_hp','ally_bodies_before_play','enemy_bodies')
    obs = {k: copy.deepcopy(data[k]) for k in keys}
    params = {k: copy.deepcopy(v) for k, v in data.items() if k not in keys and k not in
              ('hand_costs','condition_known_state','own_player_max_hp','enemy_player_max_hp')}
    public = dict(obs, hand_costs=[by[cid]['cost']], condition_state=data['condition_known_state'],
                  role='midrange', own_turn=7, paid_board_scenario=params,
                  callback_state=dict(own_player_max_hp=30, enemy_player_max_hp=30))
    direct = paid.evaluate(data, cards)
    result = api.evaluate(public)
    assert result['paid_board_tactics'] == direct
    inp, out = P/f'api-card{cid}-input.json', P/f'api-card{cid}-output.json'
    inp.write_text(json.dumps(public, indent=2)+'\n')
    subprocess.run([sys.executable,'evaluate_situation.py','--input',str(inp),'--output',str(out)],
                   cwd=ROOT, check=True, capture_output=True, text=True)
    assert json.loads(out.read_text()) == json.loads(json.dumps(result))
    checks.append(dict(card_id=cid, alpha_ex_full_vector_equal=True, direct_public_equal=True,
                       actual_api_cli_equal=True, objective_vector=a['objectives'][0]['objective_vector']))

raw = json.loads(gzip.open(P/'pilot/card163-small-unresolved.json.gz', 'rt').read())
inp, out = P/'pressure-cli-input.json', P/'pressure-cli-output.json'
inp.write_text(json.dumps(dict(scenario=raw['scenario'], survival_floors=[1,11,15], focal_index=0), indent=2)+'\n')
subprocess.run([sys.executable,'survival_pressure.py','--input',str(inp),'--output',str(out)],
               cwd=ROOT, check=True, capture_output=True, text=True)
assert json.loads(out.read_text()) == raw['result']
report = dict(passed=True, cases=checks, actual_pressure_cli_full_json_equal=True,
              scope='Four complete objective-vector comparisons and actual interfaces; not an independent rules oracle.')
(P/'interface-verification.json').write_text(json.dumps(report, indent=2)+'\n')
print(report)