"""Versioned spell extraction through the configured API, never numeric grading.

Plan once; pilot once; expansion requires a saved main-agent pilot review.
Each attempt saves payload and raw response/error. No semantic retry loop.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

import deepseek_mechanism_family_triage as schema
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'research-runs/deepseek-spell-mechanisms-v01'
API=HERE.parents[1]/'tools/test_llm_api.py'
VERSION='spell-mechanism-extraction-0.1.0'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def read(p):return json.loads(p.read_text())


def prefix():
    rules=(HERE.parents[1]/'skills/undercards/references/rules.md').read_text()
    contract=schema.CONTRACT+'\n本轮只做原生法术机制提取。不能按传入六张怪物的评分拟合规则。卡牌目标元数据ALL不是全体AOE。费用是原生事实，不是价值标签。\n'
    contract+='运行边界：固定资料快照，非实时meta；来源未知裁定保留。当前模型能处理五张完整原生法术，不代表其他法术无效。先后顺序、剩余手牌与沉默后数值重置尤需留疑。\n'+rules
    return [dict(role='system',content=contract)]


def plan():
    if OUT.exists():raise ValueError('Versioned extraction run already exists')
    OUT.mkdir(parents=True)
    cards=score_cards.load_cards();by={c['id']:c for c in cards}
    native=[c['id'] for c in cards if c['card_type']=='spell' and c['pool_category']=='ordinary_non_token']
    tasks=[dict(id='pilot',ids=[77,182,84,79,96])]
    for n in range(0,len(native),10):
        ids=list(dict.fromkeys(native[n:n+10]+[79,96,182]))
        tasks.append(dict(id=f'batch{n//10:02d}',ids=ids))
    write(OUT/'cards.json',dict(cards=cards));write(OUT/'prefix.json',prefix())
    write(OUT/'plan.json',dict(version=VERSION,tasks=tasks,all_native_spell_ids=native,
        complete_fixed_prefix_sha256=sha(OUT/'prefix.json'),source_snapshot_sha256=sha(score_cards.DEFAULT_SNAPSHOT),
        runner_sha256=sha(Path(__file__)),api_helper_sha256=sha(API),max_concurrency=4,
        no_automatic_semantic_retries=True,raw_results_are_unverified_candidates=True))


def validate(raw,ids,by):
    errors=[]
    try:
        choice=raw['choices'][0]
        if choice['finish_reason']!='stop':errors.append('finish_reason='+str(choice['finish_reason']))
        doc=json.loads(choice['message']['content'])
        if set(doc)!={'annotations'}:errors.append('top fields')
        annotations=doc['annotations']
        if not isinstance(annotations,list) or [a.get('card_id') for a in annotations]!=ids:errors.append('ordered physical card records')
        for a in annotations:
            if set(a)!=schema.FIELDS:errors.append('row fields '+str(a.get('card_id')))
            card=by.get(a.get('card_id'))
            if not card or a.get('printed_effect')!=card['effect_readable']:errors.append('source text '+str(a.get('card_id')));continue
            for p in a.get('primitives',[]):
                if set(p)!=schema.PRIMITIVE_FIELDS or any(not isinstance(v,str) for v in p.values()):errors.append('primitive fields')
                if not p.get('evidence') or not any(p['evidence'] in card[k] for k in ('effect_readable','effect_raw')):errors.append('evidence '+str(card['id']))
            for k in ('required_state','zone_copy_accounting','unverified_rules','implementation_blockers'):
                if not isinstance(a.get(k),list) or any(not isinstance(v,str) for v in a[k]):errors.append(k)
            if not isinstance(a.get('no_target_boundary'),str) or not isinstance(a.get('generic_template'),str):errors.append('string fields')
            if not isinstance(a.get('native_probe'),dict) or set(a['native_probe'])!=schema.PROBE_FIELDS:errors.append('probe fields')
        return dict(structural_passed=not errors,errors=errors,data=doc)
    except (KeyError,TypeError,ValueError) as error:
        return dict(structural_passed=False,errors=errors+[str(error)],data=None)


def attempt(item):
    folder=OUT/item['id']
    if folder.exists():raise ValueError('Attempt already preserved; do not rerun blindly')
    folder.mkdir()
    by={c['id']:c for c in read(OUT/'cards.json')['cards']}
    ids=item['ids'];refs=sorted({r['id'] if isinstance(r,dict) else r for cid in ids for r in by[cid].get('card_references',[])})
    request=dict(task_id=item['id'],cards=[by[cid] for cid in ids],references=[by[cid] for cid in refs if cid in by],
        instruction='按固定合同输出每张context.cards的机制。仅输出annotations，顺序与cards相同。提案不是已执行验证；不输出数值评价或推荐排名。')
    payload=dict(model='deepseek/deepseek-flash',messages=read(OUT/'prefix.json')+[dict(role='user',content=json.dumps(request,ensure_ascii=False,sort_keys=True))],
        max_tokens=14000,stream=False,temperature=0,thinking=dict(type='disabled'),response_format=dict(type='json_object'))
    write(folder/'intent.json',dict(task=item,started_unix=time.time(),prefix_sha256=sha(OUT/'prefix.json')))
    write(folder/'payload.json',payload)
    module_spec=importlib.util.spec_from_file_location('spell_extract_api',API)
    api=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(api)
    if not os.environ.get('TENCENT_API_KEY'):raise RuntimeError('Configured API variable absent; no secret-file discovery')
    client=api.TencentClient(api_key=os.environ['TENCENT_API_KEY'],timeout=90,retries=0)
    started=time.monotonic()
    try:
        raw=client.complete(payload);write(folder/'raw-response.json',raw)
        check=validate(raw,ids,by);write(folder/'validation.json',check)
        result=dict(id=item['id'],http_response_received=True,structural_passed=check['structural_passed'],
            elapsed_seconds=round(time.monotonic()-started,3),usage=raw.get('usage'),errors=check['errors'])
    except Exception as error:
        result=dict(id=item['id'],http_response_received=False,structural_passed=False,
            elapsed_seconds=round(time.monotonic()-started,3),error=client.redact(error))
        write(folder/'failure.json',result)
    write(folder/'receipt.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=['plan','pilot','expand'])
    args=parser.parse_args()
    if args.action=='plan':plan();return
    doc=read(OUT/'plan.json')
    assert doc['runner_sha256']==sha(Path(__file__)) and doc['complete_fixed_prefix_sha256']==sha(OUT/'prefix.json')
    if args.action=='pilot':attempt(doc['tasks'][0]);return
    gate=read(OUT/'pilot-main-review.json')
    if not gate.get('expand') or gate.get('pilot_receipt_sha256')!=sha(OUT/'pilot/receipt.json'):raise ValueError('Source-bound main review required before expansion')
    with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(attempt,doc['tasks'][1:]))
    write(OUT/'expanded-index.json',dict(attempts=results,actual_requests=len(results),max_concurrency=4,
        observed_native_spell_ids=doc['all_native_spell_ids'],not_numerical_gold_or_adopted_mechanics=True))


if __name__=='__main__':main()