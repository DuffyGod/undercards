"""Natural draws, actual later payments and purpose-dependent deployment time."""
import copy
import hashlib
import json
from pathlib import Path

import build_damage_packet_comparison as original
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/damage-packet-v01'


def scenario(cid=187,background=False):
    d=original.fixture(cid)
    d.update(own_deck_ids=[196],opponent_deck_ids=[196,196],
        first_opponent_natural_draw_count=1,next_natural_draw_count=1,next_opponent_natural_draw_count=1,
        next_own_gold_income=6,next_opponent_gold_income=5,opponent_gold_before_response=10,
        max_plays='all_physical',next_max_plays='all_physical',hand_base_costs=[3])
    if background:d.update(hand_ids=[cid,1],hand_base_costs=[3,1])
    d.pop('purpose_constraints')
    d['objectives']=['guaranteed_hp','purpose']
    return d


def run(name,d,cards):
    goals={
        'body1':dict(min_own_player_hp=1,min_own_body_attack=2,min_own_body_health=1),
        'body2':dict(min_own_player_hp=1,min_own_body_attack=2,min_own_body_health=2),
        'hp11_body1':dict(min_own_player_hp=11,min_own_body_attack=2,min_own_body_health=1),
        'hp11_body2':dict(min_own_player_hp=11,min_own_body_attack=2,min_own_body_health=2),
        'defeat':dict(min_own_player_hp=1,max_enemy_player_hp=0)}
    hp=paid.evaluate(dict(d,objectives=['guaranteed_hp']),cards);assert hp['complete_in_declared_scope'],hp['unknown']
    results={}
    for label,g in goals.items():
        r=paid.evaluate(dict(d,objectives=['purpose'],purpose_constraints=g),cards)
        assert r['complete_in_declared_scope'],(name,label,r['unknown'])
        results[label]=r
    return dict(case=name,input=d,hp_result=hp,guaranteed_player_hp=hp['objectives'][0]['metrics']['own_player_hp'],
        goals=results,summary={k:r['objectives'][0]['purpose_guaranteed'] for k,r in results.items()})


def fixed_prefix(d,cards,wait):
    d=dict(d,objectives=['purpose'],purpose_constraints=dict(min_own_player_hp=1,min_own_body_attack=2,min_own_body_health=2))
    e=paid.PaidSearch(cards,d);root=e.root()
    if wait:action=dict(kind='end_turn',phase=0);child=e.boundary(root)
    else:action,child=next((a,c) for a,c in e.deploys(root) if a.get('card_id')==187)
    r=e.solve(child,'purpose');assert r['search_complete'],r.get('unknown')
    return dict(prefix=action,full_continuation=r,
        purpose_guaranteed=bool(r['objective_vector'][0]),
        scope='Fixed same legal current prefix, then optimal continuation against every enemy response.')


def main():
    cards=score_cards.load_cards();rows=[]
    configurations=[('mettaton-natural',scenario(56)),('candy-natural',scenario(187)),
        ('candy-no-future-play',dict(scenario(187),next_max_plays=0)),
        ('candy-with-real-dummy',scenario(187,True)),
        ('shyren-with-real-dummy',scenario(22,True)),
        ('candy-cash2-income0',dict(scenario(187),gold_before_play=2,next_own_gold_income=0)),
        ('candy-cash2-income1',dict(scenario(187),gold_before_play=2,next_own_gold_income=1))]
    for name,d in configurations:
        row=run(name,d,cards);rows.append(row)
        print(json.dumps(dict(case=name,hp=row['guaranteed_player_hp'],**row['summary'])),flush=True)
    by={r['case']:r for r in rows}
    assert by['mettaton-natural']['guaranteed_player_hp']==11
    assert by['mettaton-natural']['summary']['body1'] is True
    assert by['mettaton-natural']['summary']['hp11_body1'] is False
    assert by['candy-natural']['guaranteed_player_hp']==11
    assert by['candy-natural']['summary']['body2'] is True
    assert by['candy-natural']['summary']['hp11_body2'] is False
    assert by['candy-no-future-play']['summary']['body2'] is False
    assert by['candy-with-real-dummy']['summary']['hp11_body2'] is True
    assert by['candy-cash2-income0']['summary']['body2'] is False
    assert by['candy-cash2-income1']['summary']['body2'] is True
    prefixes=dict(now=fixed_prefix(scenario(187),cards,False),wait=fixed_prefix(scenario(187),cards,True))
    assert prefixes['now']['purpose_guaranteed'] is False and prefixes['wait']['purpose_guaranteed'] is True
    late=by['candy-cash2-income1']['goals']['body2']['objectives'][0]['payment_accounting']
    assert late['current_paid_gold']==0 and late['next_paid_gold']==3 and late['next_income_credited']==1
    dummy=by['candy-with-real-dummy']['goals']['hp11_body2']['objectives'][0]['payment_accounting']
    assert dummy['current_paid_gold']==1 and dummy['next_paid_gold']==3
    OUT.mkdir(parents=True,exist_ok=True)
    record=dict(version='paid-packet-observed-timing-0.1.0',cases=rows,candy_fixed_prefixes=prefixes,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('build_packet_timing.py','build_damage_packet_comparison.py','paid_board_tactics.py','board_tactics.py')},
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        limitations=['Natural draws use declared actual ordered identities, not a claim of hidden deck knowledge or meta frequency.',
            'First enemy cash10 and next income5, own next income6 are explicit; no earliest-turn claim or inferred baseline income.',
            'all_physical permits every actually held/drawn copy once; Tiny0G still needs actual draw and cannot attack on its fresh turn.',
            'Dummy is an extra physically held1G card. Its payment and card slot are not a free synergy coefficient.',
            'Two marginal guarantee maxima do not certify their conjunction; conjunction is separately searched.',
            'HP maximizing is a diagnostic goal, not a reason to prefer a nonwinning17HP path over an available immediate win.'])
    (OUT/'timing-comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    lines=['# 出场时机必须由共同手牌策略决定','',
        '每次到达双方开始均实际自然抽1：己库Tiny一张、敌库Tiny两张。敌初次可用10G、下次实际加5G，己下次加6G；手中的Gems/候选/Tiny都只用一次、照价支付。敌第一张Tiny在第二敌轮获得正常攻击，增加惩罚；未到达的开始不提前抽牌或加钱。','',
        '| 同手牌/改动 | 玩家HP最大保证 | 同体≥2ATK/2HP | HP≥11且同体≥2/2 |','|---|---:|---|---|']
    for r in rows:lines.append(f"| {r['case']} | {r['guaranteed_player_hp']} | {r['summary']['body2']} | {r['summary']['hp11_body2']} |")
    lines+=['','Candy的玩家HP最大保证11、同体2HP可行；但联合目的失败。固定现在部署使同体2HP失败，固定现在持有后真实付费使其成立。早出的2ATK能清掉敌新Tiny、减少第二次打脸；晚出避免第一次身体惩罚，却没有立即攻击去清Tiny。所以不能把两个单独最优值合起来。Mettaton也出现HP11与1HP活体分别可行、联合失败。','',
        '背景真持有Dummy1G后，当前付Dummy1、未来付Candy3，HP11且同体2/2变为可行；不以固定配合加分代替联合策略。Shyren加同一防守背景的HP也另优化，较高HP不自动等同已赢对手。','',
        '银行2G、下一收入0→1，仅这个数字跨越未来3G付款门槛：留2HP体false→true。前者不强迫当前无效部署、不扣未支出的3G；后者当前0支付、下一开始赚1后实际支付3一次。','',
        '这比给“卡手风险”一个固定扣分更具体：列出什么目的要早出/等待，什么背景牌与真实现金弥补缺口。输入与所有最坏回应、实际库/付款账本、固定当前前缀的完整续策均保存在JSON。']
    (OUT/'timing-comparison.md').write_text('\n'.join(lines)+'\n')


if __name__=='__main__':main()