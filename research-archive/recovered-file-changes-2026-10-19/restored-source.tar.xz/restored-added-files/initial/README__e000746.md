# 只证明所请求的数值，不为次级排序耗尽预算

独立入口[scalar_task_score.py](../../scalar_task_score.py)保留原动作、支付、手牌、规则和终点，只将保命目标从`(HP, 其余排序)`缩为`(HP)`，或联合用途从`(用途, HP, 其余排序)`缩为`(用途, HP)`。不是近似叶估值，没有删掉对手回应，也没有将未知分支记作0。旧生产和完整向量输出不改写。

通用理由：有限博弈树中，词典序取max/min的结果在前k坐标上的投影，等于先投影每个叶子再逐层max/min。对树深归纳即可；同值时可选不同路线，故后面的身体、现金等不再声称最优或共同保证。这是减少待证明结论，不是改变HP评价标准。

几何另由严格[position quotient证书](../position-quotient-v01/README.md)把关。明确区域和生成闭包不读位置时，可以对所有合法产品布局给相同分数；证书被撤回就拒绝该模式。没有把缺失槽补成一个方便位置。原physical输出仍未知，独立数值证书单列。

## 同预算资源挑战

沿用冻结v02的三个完整收入/自然抽牌输入，保留20k预算：敌4/4 Thrashing、两Gem与5G Long Sink、初始2G；己15HP、3G与候选。下一己收入3、第二敌收入4，三次自然抽各1，己库Tiny、敌库两Tiny。

| 候选 | 原完整向量physical | 完整向量位置商 | 只求HP的physical试跑 | 只求HP＋位置证书 |
| --- | --- | --- | --- | --- |
| Burgerpants | 预算未知 | 预算未知 | 预算未知 | **4HP，6,566状态** |
| Water Cooler | 预算未知 | 预算未知 | 预算未知 | 预算未知，19,998状态 |
| Candy Dish | 预算未知 | 预算未知 | 预算未知 | 预算未知，20,000状态 |

完整向量位置商的负结果引用原证据；六个初始标量试跑保留`pilot-index.json`。公共新入口再实际执行三例，结果如表；不把旧零收入分数填回本表，仍不能给三者确定排名。单独减少空间分支或单独减少目标坐标在Burger这里均不够，联合才闭合。

[independent_bounds.py](independent_bounds.py)不用主核，给出相等的4HP上下界。己方始终不出牌时，敌伤害最多为Thrashing两次4、第一张Tiny末轮1、两Gem各1，共11。Long首轮2G付不起，末轮才出时Haste只能打怪，不能直接打玩家。相应敌反策略对全部己方选择限制HP≤4：首轮两Gem打脸、Thrashing打脸并出Tiny；若己方晚出Burger，末轮付Long清Taunt，仍由Thrashing＋Tiny打脸5；若早出Burger，首轮就能付Long清掉它，后续更差。自己的抽到Tiny没有Taunt或Haste，不能强迫挡脸。证明依当前规则解释与有限时钟，不是整局强度校准。

## 验证与范围

- 8张原生候选×HP/保本体，共16个新查询，与冻结完整目标向量的前1/2坐标一致。涉及真实择时、治疗、动态身体、Toriel、Dodge、Switch，不是单一卡适配。
- 11项专项测试通过：包括alpha/穷举/原完整目标的小批对照、胜负路径HP反例、物理焦点归属、已知死亡0与不可行null、预算未知、空间拒证、实际延后支付与来源失效。
- 真实公共CLI完整JSON等于直接调用，见`cli.output.json`。本次验证20个查询=16个比较＋3个资源＋1个CLI，不含此前pilot和测试内部调用。
- `selective-regression.json`实际重跑11项，其余547项递归源码一致复用，当前合计558覆盖；不是558项刚重跑，原生产注册仍530。
- `validation.json`、修改前试跑、完整输入、来源快照与独立上下界保留。alpha的根值证明与全可达机制审计仍分别解释，标量入口没有扩大其审计范围。

```sh
python scalar_task_score.py research-runs/scalar-objective-v01/public-card30.input.json --output /tmp/burger-scalar.json
python research-runs/scalar-objective-v01/validate.py
python research-runs/scalar-objective-v01/independent_bounds.py
```

没有给原生产默认评分换公式。后续扩展应优先使用只证明请求坐标的入口，并在需要次级最优时明确另查；未知不回退到启发式点分。当前仍缺多数机制、真实频率和整局验证。