"""Native ten-fee damage and ambiguous target COST through the public API."""
import copy
import unittest
import evaluate_situation as api
import paid_board_tactics as paid
import test_cost_magic_probe as cost_tests


class TargetCostPublicTests(unittest.TestCase):
    def data(self):
        helper=cost_tests.CostMagicTests();helper.setUpClass();data=helper.data()
        data.update(objectives=['purpose'],purpose_constraints=dict(min_own_player_hp=1,min_own_body_attack=4,min_own_body_health=8))
        return data

    def entry(self,scene):
        obs={k:copy.deepcopy(scene.get(k,[] if 'bodies' in k else 0)) for k in ('hand_ids','gold_before_play',
            'opponent_gold_before_response','own_player_hp','enemy_player_hp','ally_bodies_before_play','enemy_bodies')}
        params={k:copy.deepcopy(v) for k,v in scene.items() if k not in obs and k not in
            ('own_player_max_hp','enemy_player_max_hp','hand_costs','opponent_hand_known')}
        return dict(obs,role='midrange',own_turn=10,hand_costs=scene['hand_costs'],paid_board_scenario=params,
            callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30))

    def test_native_target_cost_magic_reaches_public_full_json_and_real_payment(self):
        data=self.data();direct=paid.evaluate(data);public=api.evaluate(self.entry(data))['paid_board_tactics']
        self.assertTrue(public['complete_in_declared_scope'],public['unknown']);self.assertEqual(public,direct)
        result=public['objectives'][0];self.assertTrue(result['purpose_guaranteed'])
        self.assertEqual(result['metrics']['own_player_hp'],15)
        self.assertEqual(result['payment_accounting']['current_paid_gold'],10)

    def test_disagreeing_price_facts_clear_authoritative_recommendation(self):
        data=self.data();data['enemy_bodies'][0]['current_card_cost']=2
        result=api.evaluate(self.entry(data))['paid_board_tactics']
        self.assertFalse(result['complete_in_declared_scope']);self.assertFalse(result['recommendations'])
        self.assertTrue(any('referents produce different damage' in message for message in result['unknown']))


if __name__=='__main__':unittest.main()