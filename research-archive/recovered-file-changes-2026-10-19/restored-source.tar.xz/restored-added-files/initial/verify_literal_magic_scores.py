"""Bind independent arithmetic bounds to actual production scoring artifacts.

This checks seven complete short-window values, not a pooled scalar Gold or
server semantics. Raw independent reasoning lives outside the search modules.
"""
import hashlib
import json
from pathlib import Path

import conditional_card_score as score

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/literal-magic-v01'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    bindings=score.source_bindings(Path(__file__))
    comparison=json.loads((OUT/'comparison.json').read_text())
    assert comparison['source_hashes']==score.source_bindings(HERE/'build_literal_magic_scores.py')
    assert comparison['source_stable_during_run']
    for name,expected in comparison['artifact_hashes'].items():assert sha(OUT/name)==expected
    proof_path=HERE/'research-runs/literal-magic-v01/independent_arithmetic.json'
    proof=json.loads(proof_path.read_text())
    assert proof['script_sha256']==sha(proof_path.with_suffix('.py'))
    matched=[]
    for row in proof['rows']:
        record=json.loads((OUT/(row['scene']+'.json')).read_text())
        assert record['source_hashes']==score.source_bindings()
        scene=record['config']['scene']
        # Enforce the independent proof domain instead of applying its formula
        # to Armor/Dodge, healing, ready allies or a longer response window.
        assert scene['horizon']=='enemy_attack' and scene['own_player_hp']==15
        assert scene['gold_before_play']==3 and not scene['opponent_hand_ids']
        assert all(e['card_id']==270 and e['attack']==4 and 1<=e['health']<=2
                   and not e.get('armor') and not e.get('dodge') for e in scene['enemy_bodies'])
        allies=scene.get('ally_bodies_before_play',[])
        assert len(allies)==row['other_tem_count']
        assert all(a['card_id']==172 and not a.get('ready',False) for a in allies)
        candidate=next(c for c in record['rows'] if c['name']==row['card'])
        value=candidate['scores']['hp']
        assert value['known'] and value['guaranteed_player_hp']==row['guaranteed_hp']
        assert candidate['input']['hand_ids']==[candidate['card_id']]
        matched.append(dict(case=row['scene'],card_id=candidate['card_id'],name=row['card'],
            guaranteed_player_hp=value['guaranteed_player_hp'],upper_equals_lower=True))
    assert len(matched)==7
    api=json.loads((OUT/'api-verification.json').read_text())
    assert api['source_hashes']==comparison['source_hashes']
    assert len(api['checks'])==3 and all(c['api_direct_complete_json_equal'] and
        c['cli_direct_complete_json_equal'] for c in api['checks'])
    vectors=comparison['full_vector_checks']
    assert len(vectors)==16 and sum(v['known'] for v in vectors)==13
    assert all(v['full_vector_equal'] if v['known'] else v['unknown'] for v in vectors)
    assert bindings==score.source_bindings(Path(__file__))
    result=dict(source_hashes=bindings,source_stable_during_run=True,
        independent_proof_sha256=sha(proof_path),independent_values=matched,
        production_alpha_exhaustive_queries=32,closed_vectors=13,matching_unknowns=3,
        actual_api_direct_cli_complete_json_checks=3,
        statement='Arithmetic bounds and code agreement only; unverified interpretations and whole-pool optima remain unresolved.')
    (OUT/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(independent_values=len(matched),closed_vectors=13,unknowns=3,api_cli_checks=3)))


if __name__=='__main__':main()