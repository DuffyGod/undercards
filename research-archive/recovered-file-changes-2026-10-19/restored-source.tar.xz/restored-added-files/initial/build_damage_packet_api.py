"""New packet mechanics through the common user API and actual CLI."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import build_damage_packet_comparison as comparison
import evaluate_situation
import paid_board_tactics
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/damage-packet-v01'


def api_fixture(cid):
    scene=comparison.fixture(cid)
    root=('hand_ids','gold_before_play','own_player_hp','enemy_player_hp',
          'ally_bodies_before_play','enemy_bodies','opponent_gold_before_response')
    data={k:copy.deepcopy(scene[k]) for k in root}
    data.update(role='midrange',own_turn=5,condition_state=scene['condition_known_state'],
        response_weights={'enemy_face':1},opponent_hand_known=True,
        opponent_hand_ids=scene['opponent_hand_ids'],
        callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30))
    ignored=set(root)|{'own_player_max_hp','enemy_player_max_hp','condition_known_state'}
    data['paid_board_scenario']={k:copy.deepcopy(v) for k,v in scene.items() if k not in ignored}
    return data


def main():
    OUT.mkdir(parents=True,exist_ok=True);rows=[]
    for cid in comparison.COHORT:
        data=api_fixture(cid);result=evaluate_situation.evaluate(data)
        actual=result['paid_board_tactics'];direct=paid_board_tactics.evaluate(actual['input'])
        assert actual==direct
        assert actual['complete_in_declared_scope']
        assert result['hand_survival']['best_known_death_reducing_hand_index'] is None
        assert result['deployment_routes']['diagnostic_only']
        ip=OUT/f'card-{cid}.input.json';op=OUT/f'card-{cid}.result.json'
        ip.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        p=subprocess.run([sys.executable,str(HERE/'evaluate_situation.py'),'--input',str(ip),'--output',str(op)],cwd=HERE,capture_output=True,text=True)
        assert p.returncode==0,(p.stdout,p.stderr)
        assert json.loads(op.read_text())==json.loads(json.dumps(result))
        rows.append(dict(card_id=cid,guaranteed_player_hp=actual['objectives'][0]['metrics']['own_player_hp'],
            same_body_purpose_guaranteed=actual['objectives'][1]['purpose_guaranteed'],
            api_equals_standalone=True,cli_equals_api=True,legacy_recommendation_withdrawn=True,
            input_sha256=hashlib.sha256(ip.read_bytes()).hexdigest(),result_sha256=hashlib.sha256(op.read_bytes()).hexdigest()))
    record=dict(api_version=evaluate_situation.VERSION,paid_version=paid_board_tactics.VERSION,cases=rows,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('build_damage_packet_api.py','build_damage_packet_comparison.py','evaluate_situation.py','paid_board_tactics.py','board_tactics.py')},
        interpretation='Real CLI/input/source evidence, not server execution or empirical strength.')
    (OUT/'api-verification.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(rows,ensure_ascii=False))


if __name__=='__main__':main()