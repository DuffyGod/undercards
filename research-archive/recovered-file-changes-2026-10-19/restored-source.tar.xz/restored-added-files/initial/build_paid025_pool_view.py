"""Read frozen paid0.25 menus; render physical and certified scores separately."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'research-runs/pool-frontier-v03'
OUT=HERE/'experiments/pool-frontier-v03'
HTML=r'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Undercards · 按用途比较真实择时</title><style>
body{max-width:1200px;margin:32px auto;padding:0 20px;font:15px system-ui;color:#263548;background:#f6f8fa}p{line-height:1.7}section{background:white;padding:20px;margin:18px 0;border:1px solid #dae0e6;border-radius:8px}select{padding:8px;margin:5px 14px 5px 0}label{display:inline-block;margin-right:12px}table{border-collapse:collapse;width:100%}th,td{text-align:left;padding:9px;border-bottom:1px solid #e2e7eb}tr.unknown{color:#6a7781}tr.leader{background:#e8f6ed}tbody tr{cursor:pointer}pre{white-space:pre-wrap;overflow-wrap:anywhere;max-height:480px;overflow:auto}.scroll{overflow-x:auto}a{color:#0870a5;margin-right:14px}.muted{color:#5f6e7c}
</style><h1>按用途比较真实择时</h1>
<p>同费用、同观察和现金，允许现在出、留在手里或下次真实付款。Q是<strong>保证用途时，能共同保证的玩家HP</strong>。各列可以采用不同策略，不能把最优身体与最优HP拼成一个打法；可保证获胜时优先获胜。</p>
<p class="muted">paid0.25：565原生候选完整保留。物理搜索69张四用途闭合；启用位置无关证书后72张闭合，493张仍未知，无法认证任何全费用桶冠军。<a href="README.md">输入、方法与限制</a><a href="../../research-runs/pool-frontier-v03/scores.csv">完整CSV</a><a href="../targeted-hand-production-v01/README.md">真实手牌增益比较</a></p>
<section><label>费用<select id="scene"></select></label><label>用途<select id="task"></select></label><label><input id="known" type="checkbox" checked>只显示已闭合</label><label><input id="certificate" type="checkbox" checked>采用位置无关证书</label>
<p id="facts"></p><p id="summary"></p><div class="scroll"><table><thead><tr><th>卡牌</th><th>实际费用</th><th>Q（玩家HP）</th><th>用途HP代价</th><th>证明方式</th></tr></thead><tbody id="rows"></tbody></table></div><p id="count"></p></section>
<section><p id="links"></p><pre id="detail"></pre></section>
<section><p>基础输入：己15/30HP、敌30/30HP；敌4/4 Thrashing、两Gem与2G现金。自己仅持候选，现金等于原生费用。当前与下一己都可真实留牌付款，敌可将Gem留到第二次回应。外生收入0、自然抽0、双方空库与疲劳1；卡牌自身赚金和抽牌仍执行。这个窗口没有真实构筑频率。</p>
<p>位置证书仅用于Blockler B、Rock、Dad Slime：显式手牌、牌库与生成闭包都不读取位置时，对所有合法产品摆位给同一个条件分数。原物理搜索未知始终保留，可取消勾选查看；没有虚构生成物落点。此证明沿用原模型其余规则，不是服务器摆位裁定。</p>
<p>公开假设：四槽与front双射、空前方fizzle、Switch左区[0,1]、allies包括玩家；手牌目标为空时fizzle、双选仅选有合法目标分支。缺少规则裁定、隐藏信息、场景频率和完整对局验证。当前部署权未在本版本重查，不能从本表读成0；此前按用途的择时反事实见<a href="../pool-frontier-v02/README.md">paid0.24历史交付</a>。</p><p id="provenance" class="muted"></p></section>
<script type="application/json" id="data">__DATA__</script><script>
'use strict';
const DATA=JSON.parse(document.getElementById('data').textContent),el=id=>document.getElementById(id);
const taskName=t=>({hp:'保命',win:'保证获胜',clear:'保命并清场',focal_2_2:'保原体至少2攻2血'}[t]);
const cells=r=>el('certificate').checked?r.scores:r.physical_scores;
const q=c=>!c.known?'未知':c.guaranteed_player_hp===null?'不可保证':String(c.guaranteed_player_hp);
const purposeCost=(r,t)=>{const c=cells(r);return !c.hp.known||!c[t].known?'未知':c[t].guaranteed_player_hp===null?'不可行':String(c.hp.guaranteed_player_hp-c[t].guaranteed_player_hp);};
function link(file,label){if(!file)return;const a=document.createElement('a');a.href='../../research-runs/pool-frontier-v03/'+file;a.textContent=label;el('links').append(a);}
function detail(g,r,t){el('links').replaceChildren();link(r.artifact,'物理输入、真实支付与路径');if(r.quotient_artifact)link(r.quotient_artifact,'位置证书及原始未知');
 el('detail').textContent=JSON.stringify({card:DATA.sources[String(r.card_id)],cash:g.cost,task:DATA.tasks[t],score:cells(r)[t],
  purpose_hp_cost:purposeCost(r,t),method:el('certificate').checked?r.score_method:'physical',original_physical: r.physical_scores[t],
  current_deployment_right:'not_queried',source_model:DATA.source_model,source_hashes:DATA.source_hashes,
  same_policy_for_goal_and_hp:true,all_other_endpoint_metrics_componentwise_guaranteed:false},null,2);}
function render(){const g=DATA.groups.find(x=>x.key===el('scene').value),t=el('task').value,all=g.rows;
 const wins=all.filter(r=>cells(r).win.known&&cells(r).win.feasible),selected=wins.length?'win':t;
 const pool=wins.length?wins:all.filter(r=>cells(r)[t].known&&cells(r)[t].feasible);
 const best=pool.length?Math.max(...pool.map(r=>cells(r)[selected].guaranteed_player_hp)):-Infinity;
 const leaders=pool.filter(r=>cells(r)[selected].guaranteed_player_hp===best).map(r=>r.card_id);
 const blocked=all.filter(r=>!cells(r).win.known||(!wins.length&&!cells(r)[t].known));
 el('facts').textContent='共同现金'+g.cost+'G；原生费用与实际费用相同，截止第二次敌方攻击。';
 el('summary').textContent=(wins.length?'保证获胜优先：':'本用途已闭合候选领先：')+(pool.filter(r=>leaders.includes(r.card_id)).map(r=>r.name).join('、')||'无')+'。'+blocked.length+'张未知阻断全桶认证。';
 const shown=all.filter(r=>!el('known').checked||cells(r)[t].known).sort((a,b)=>Number(cells(b)[t].known)-Number(cells(a)[t].known)||Number(cells(b)[t].feasible)-Number(cells(a)[t].feasible)||(cells(b)[t].guaranteed_player_hp??-Infinity)-(cells(a)[t].guaranteed_player_hp??-Infinity)||a.card_id-b.card_id);
 el('rows').replaceChildren();for(const r of shown){const tr=document.createElement('tr');if(!cells(r)[t].known)tr.className='unknown';if(leaders.includes(r.card_id))tr.classList.add('leader');
  const method=el('certificate').checked&&r.quotient_artifact?'位置证书':'物理搜索';
  for(const value of [r.name+' #'+r.card_id,String(r.printed_cost),q(cells(r)[t]),purposeCost(r,t),method]){const td=document.createElement('td');td.textContent=value;tr.append(td);}
  tr.addEventListener('click',()=>detail(g,r,t));el('rows').append(tr);}
 el('count').textContent='本用途闭合'+all.filter(r=>cells(r)[t].known).length+'/'+all.length+'，显示'+shown.length+'。';
 if(shown.length)detail(g,shown[0],t);else{el('links').replaceChildren();el('detail').textContent='没有闭合结果，可展开未知查看来源。';}}
for(const g of DATA.groups){const o=document.createElement('option');o.value=g.key;o.textContent=g.cost+'G';el('scene').append(o);}
for(const t of Object.keys(DATA.tasks)){const o=document.createElement('option');o.value=t;o.textContent=taskName(t);el('task').append(o);}
el('scene').value='native-5';el('task').value='focal_2_2';for(const id of ['scene','task','known','certificate'])el(id).addEventListener('change',render);render();
el('provenance').textContent='读取冻结收据SHA256 '+DATA.frozen_receipt_sha256+'；本页面不运行估值模型。';
</script></html>'''

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    receipt=json.loads((SOURCE/'frozen-receipt.json').read_text())
    for name,h in receipt['artifact_sha256'].items():assert sha(SOURCE/name)==h,name
    raw=json.loads((SOURCE/'frontiers.json').read_text());inventory=json.loads((SOURCE/'inventory.json').read_text())
    def compact(cell):
        search=cell.get('search') or {}
        return {**{k:cell.get(k) for k in ('known','feasible','guaranteed_player_hp','unknown')},
            'selected_path_ledgers':{k:search.get(k) for k in ('payment_accounting','draw_accounting','opponent_draw_accounting','hand_keyword_accounting')},
            'endpoint_metrics_are_not_componentwise_guarantees':True}
    groups=[]
    for g in raw['groups']:
        rows=[]
        for r in g['rows']:
            rows.append({**{k:v for k,v in r.items() if k not in ('scores','physical_scores')},
                'scores':{t:compact(c) for t,c in r['scores'].items()},'physical_scores':{t:compact(c) for t,c in r['physical_scores'].items()}})
        groups.append(dict(key=g['key'],cost=g['cost'],rows=rows))
    data=dict(groups=groups,tasks=raw['tasks'],totals=raw['totals'],source_model=raw['source_model'],source_hashes=raw['source_hashes'],
        sources={str(r['card_id']):r['source'] for r in inventory['rows']},frozen_receipt_sha256=sha(SOURCE/'frozen-receipt.json'))
    encoded=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<',r'\u003c').replace('>',r'\u003e').replace('&',r'\u0026');assert json.loads(encoded)==data
    OUT.mkdir(exist_ok=True);(OUT/'score-explorer.html').write_text(HTML.replace('__DATA__',encoded))
    (OUT/'view-provenance.json').write_text(json.dumps(dict(builder_sha256=sha(Path(__file__)),
        html_sha256=sha(OUT/'score-explorer.html'),frozen_receipt_sha256=data['frozen_receipt_sha256'],
        frontiers_sha256=sha(SOURCE/'frontiers.json'),totals=raw['totals'],model_search_calls=0),indent=2)+'\n')
    print(json.dumps(raw['totals']))

if __name__=='__main__':main()