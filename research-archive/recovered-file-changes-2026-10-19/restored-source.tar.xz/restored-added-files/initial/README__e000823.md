# paid0.27跨费双轮原始证据

入口见[交付说明](../../experiments/pool-frontier-v04/README.md)。index.json是本轮78张实际物理执行；frontiers.json保存565候选及原物理未知，另三张quotient-card*.json保存位置证书。312物理目标调用＋24位置商内部调用，76/565四用途闭合，489未知。源与产物由frozen-receipt.json固定，不重写旧v03。