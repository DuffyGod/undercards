"""Execute frozen old observation logic and quantify current-status effects."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import conditional_card_score as score
import paid_board_tactics as paid

HERE=Path(__file__).resolve().parent
OUT=HERE/'research-runs/observed-status-fix-v01'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def main():
    OUT.mkdir(exist_ok=True);bindings=score.source_bindings(Path(__file__));cards=score.score_cards.load_cards();by={c['id']:c for c in cards}
    scene=dict(hand_ids=[],gold_before_play=0,max_plays=0,own_player_hp=1,own_player_max_hp=30,
        enemy_player_hp=4,enemy_player_max_hp=30,opponent_hand_ids=[],opponent_hand_known=True,horizon='enemy_attack',
        ally_bodies_before_play=[dict(card_id=270,attack=4,health=4,max_health=4,ready=True,current_card_cost=3,base_cost=3)],
        enemy_bodies=[dict(card_id=14,attack=4,health=5,max_health=5,silenced=True,taunt=True,current_card_cost=5,base_cost=5)],
        purpose_constraints=dict(min_own_player_hp=1,max_enemy_player_hp=0))
    write('lethal-counterexample.input.json',scene)
    old=HERE/'research-runs/presence-magic-production-v01/before-cost-and-observation'
    frozen=json.loads((old/'frozen-receipt.json').read_text())
    for name,h in frozen['artifact_sha256'].items():assert sha(old/name)==h,name
    bootstrap=r'''
import hashlib,json,sys
from pathlib import Path
folder=Path(sys.argv[1]).resolve();sys.path.insert(0,str(folder))
import paid_board_tactics as paid
scene=json.loads(Path(sys.argv[2]).read_text());cards=json.loads(Path(sys.argv[3]).read_text())['cards']
engine=paid.PaidSearch(cards,scene);result=engine.solve(engine.root(),'purpose')
loaded={}
for name,module in list(sys.modules.items()):
 path=getattr(module,'__file__',None)
 if path and Path(path).resolve().parent==folder:
  p=Path(path);loaded[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
Path(sys.argv[4]).write_text(json.dumps(dict(version=paid.VERSION,result=result,loaded_frozen_sources=loaded),indent=2)+'\n')
'''
    cmd=[sys.executable,'-B','-c',bootstrap,str(old/'source'),str(OUT/'lethal-counterexample.input.json'),
        str(score.score_cards.DEFAULT_SNAPSHOT),str(OUT/'old-paid026-result.json')]
    run=subprocess.run(cmd,capture_output=True,text=True,cwd=OUT)
    (OUT/'old.stdout.log').write_text(run.stdout);(OUT/'old.stderr.log').write_text(run.stderr)
    assert run.returncode==0,run.stderr
    historical=json.loads((OUT/'old-paid026-result.json').read_text())
    assert historical['version'].endswith('0.26.0') and historical['result']['search_complete']
    assert historical['result']['purpose_guaranteed']
    for name,h in historical['loaded_frozen_sources'].items():assert frozen['artifact_sha256']['source/'+name]==h
    current=paid.PaidSearch(cards,scene);result=current.solve(current.root(),'purpose')
    assert result['search_complete'] and not result['purpose_guaranteed']
    write('current-lethal-result.json',result)
    rows=[]
    for label,status in [('plain',{}),('dodge1',dict(dodge=1)),('armor',dict(armor=True)),('taunt',dict(taunt=True)),('transparency',dict(transparency=True))]:
        for cid in (443,110,8):
            data=dict(hand_ids=[cid],hand_costs=[by[cid]['cost']],hand_base_costs=[by[cid]['cost']],gold_before_play=10,
                own_player_hp=15,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
                opponent_hand_ids=[],opponent_hand_known=True,own_deck_ids=[],opponent_deck_ids=[],
                max_plays='all_physical',horizon='enemy_attack',node_limit=20000,
                enemy_bodies=[dict(card_id=270,attack=4,health=5,max_health=5,silenced=True,current_card_cost=3,base_cost=3,**status)])
            values={}
            for task_name,task in [('hp',dict(kind='hp')),('body4_8',dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=4,min_own_body_health=8)))]:
                value=score.task_score(data,task,cards=cards,focal_index=0);values[task_name]=value
                rows.append(dict(status=label,card_id=cid,task=task_name,known=value['known'],feasible=value['feasible'],
                    hp=value['guaranteed_player_hp'],unknown=value['unknown']))
            write(f'{label}-card{cid}.json',dict(input=data,results=values))
    assert bindings==score.source_bindings(Path(__file__))
    write('verification.json',dict(passed=True,source_hashes=bindings,source_stable=True,
        old_module_version=historical['version'],current_module_version=paid.VERSION,
        old_guaranteed_win=True,current_guaranteed_win=False,
        actual_frozen_source_execution=True,frozen_manifest_sha256=sha(old/'frozen-receipt.json'),
        historical_loaded_sources=historical['loaded_frozen_sources'],current_status_matrix=rows,actual_current_matrix_queries=30,
        input_sha256=sha(OUT/'lethal-counterexample.input.json'),cards_snapshot_sha256=sha(score.score_cards.DEFAULT_SNAPSHOT),
        explanation='Already-Silenced describes removed printed abilities, not a fresh instruction to erase explicit current status observations. New Silence events still remove them.',
        limits=['Known card identity supplies only printed fee; current/base fee and current statuses still require their own facts.',
            'The status matrix compares explicit observations, not an executed historical version that lacked target-COST Magic.']))
    print(json.dumps(dict(old_win=True,current_win=False,status_queries=len(rows))))

if __name__=='__main__':main()