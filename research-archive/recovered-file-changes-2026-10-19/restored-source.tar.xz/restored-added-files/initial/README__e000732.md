# 各费用的用途菜单：固定paid0.23快照

[交互比较](score-explorer.html)。这是paid0.23 / board0.5 / scorer0.3的版本固定结果；[paid0.24新增原生9G](../nine-cost-v01/README.md)与[补齐观察的5/8G联合用途](../frontier-observations-v01/README.md)另列，不能把这里9G全未知解读为当前程序仍全未知。

全671普通非TOKEN怪物都保留来源与编译清单。3–10G八桶共565原生候选，其中68个编译支持候选实际执行四用途查询；另7个9/10G共同现金的低费替代。60个原生候选在此固定输入闭合、505个未知（497编译未知、8可达机制/观察未知）。编译成功不等于评分闭合。

共同压力输入：己15/max30、敌30，单4攻4血Thrashing、两张可付的Gem/2G；当前一手为候选、现金等于本桶费用。无自然抽、无下一己出牌，截止下一己攻击结束；当前整数上限1恰覆盖这一张物理持牌。明确物理四槽和空前方fizzle假设，空库却缺疲劳事实的Draw仍unknown。

| 原生费用 | 此输入闭合/总数 | 已支持保命领先 | 其HP | 已支持保自身2/2领先 | 联合HP |
|---:|---:|---|---:|---|---:|
| 3 | 20/106 | Vegetoid、Shyren、Burgerpants、Water、Totemic Guard | 13 | 无可保证者 | — |
| 4 | 15/131 | Parsnik、Diamond Receptionist、Dog Food、Cracked Geode | 13 | Parsnik | 13 |
| 5 | 9/95 | Long Sink | 15 | Carbed | 9 |
| 6 | 10/97 | Innkeeper | 14 | Big Hat Charles | 9 |
| 7 | 3/54 | Tsunderplane、Coffee Man | 13 | 无可保证者 | — |
| 8 | 2/27 | Baron | 13 | Toriel | 12 |
| 9 | 0/32 | 当时无闭合 | — | 当时无闭合 | — |
| 10 | 1/23 | Mettaton NEO | 9 | 无可保证者 | — |

未知始终阻断全桶冠军。共同现金替代组可以真实支付更低费用，但不把这些卡冒充原生9G卡。不同费用桶现金不同，不能把表中HP直接排列成跨费用强度。

程序又实际追加75个获胜查询，全部已知候选在本窗口都没有保证获胜；推荐函数仍保留获胜优先规则。35个代表卡/目标完整向量与穷举一致。视图100次选择切换、3195个评分单元核对；DOM替身不当浏览器布局验证。

“非支配菜单”仅表示在已经查询的各用途上没有另一已知候选全部不差且至少一项更好；每项可有不同打法，不能拼成共同策略。永久支配、全卡强度、真实频率或Gold均未识别。5G/8G新探针专门加入“清场且保焦点2/2”合取，说明独立菜单确实有不能拼的情况。

首轮非法`full_heal_transfer=actual_restored_hp`导致所有输入被schema拒绝，完整84文件冻结于`research-runs/pool-frontier-v01/attempts/invalid-full-heal-param/`。修正为`actual_restored`并增加pilot失败即停止后，实际300查询28.074s；后续只追加获胜与代表穷举，未重复旧主核回归。当前数据绑定于`research-runs/nine-cost-v01/before`的paid0.23来源，完整输入/路径在[frontiers.json](../../research-runs/pool-frontier-v01/frontiers.json)所引用文件，源码运行期不变。