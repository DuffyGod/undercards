"""Elementary strategy bounds; no search, combat, payment or parser imports."""
import hashlib
from itertools import permutations
import json
import math
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SNAPSHOT=ROOT.parents[1]/'skills/undercards/references/snapshot.json'
CARDS={c['id']:c for c in json.loads(SNAPSHOT.read_text())['cards']}


def main():
    # Native facts, not values copied from the implementation's compiled specs.
    for cid,cost,atk,hp in ((419,9,6,9),(249,9,9,8),(270,3,4,4),(8,8,6,4),
            (21,7,6,4),(556,8,6,5),(44,8,6,8),(509,5,4,6),(534,5,2,5)):
        c=CARDS[cid];assert (c['cost'],c['attack'],c['health'])==(cost,atk,hp),(cid,c)
    assert CARDS[249]['effect_readable']=='Dodge (98). Turn end: Lose 97 Dodge.'
    assert CARDS[509]['effect_readable']=="Haste. Turn end: If this didn't attack this turn, heal 3 HP to you."
    assert CARDS[44]['effect_readable']=='Taunt. Magic: Draw up to 2 cards.'
    checks=[]
    def match(folder,scene,cid,task,hp=None,feasible=True,argument=''):
        record=json.loads((ROOT/'experiments'/folder/(scene+'.json')).read_text())
        row=next(r for r in record['rows'] if r['card_id']==cid);value=row['scores'][task]
        assert value['known'] and value['feasible']==feasible,(scene,cid,task,value)
        assert value['guaranteed_player_hp']==hp,(scene,cid,task,hp,value['guaranteed_player_hp'])
        checks.append(dict(case=scene,card_id=cid,task=task,feasible=feasible,hp=hp,
            equal_upper_lower=True,argument=argument))
    def hero_bound(damage):return max(0,15-damage)
    # All four ordinary4ATK enemies may attack the hero or must hit Taunt.
    # A Taunt kills every attacking foe on the simultaneous counterhit, so
    # exactly ceil(native HP/4) attacks can be absorbed. No callbacks/spells.
    spade_no_kill=hero_bound(4*(4-math.ceil(CARDS[419]['health']/4)))
    baron=hero_bound(4*(4-math.ceil(CARDS[556]['health']/4)))
    toriel=hero_bound(4*3+1);plane=hero_bound(4*3)
    for scene,hp,threshold in (('four-hp2',2,2),('four-hp3',3,2),('four-hp3-threshold3',3,3)):
        spade=15 if hp<=threshold else spade_no_kill
        for cid,expected in ((419,spade),(8,toriel),(21,plane),(556,baron)):
            match('nine-cost-v01',scene,cid,'hp',expected,
                argument='Legal best own placement/haste exchange and all-face-or-Taunt enemy strategy close both bounds; no hero heals or other actions.')
        match('nine-cost-v01',scene,249,'hp',0,False,
            'Fresh non-Taunt Robot has no current attack; four4ATK foes can deal16 face, even if Robot is not played.')
    match('nine-cost-v01','right-full-four-hp2',419,'hp',spade_no_kill,
        argument='No right slot at deployment, no threshold kill. Tiny has no Taunt; enemy attacks Spade three times, then hero once.')
    match('nine-cost-v01','right-free-four-hp2',419,'hp',15,
        argument='Moving one Tiny exposes a right deployment slot; preselected2HP enemies all die before any response.')
    packet_bounds=[]
    for decay in (97,96):
        dodges=max(0,98-decay)
        worst=max(sum(order[dodges:]) for order in set(permutations((4,1,1))))
        minimum_body_hp=CARDS[249]['health']-worst
        packet_bounds.append(dict(decay=decay,dodge_after_owner_end=dodges,worst_body_damage=worst,minimum_body_hp=minimum_body_hp))
        scene='robot-punishment-native' if decay==97 else 'robot-punishment-decay96'
        match('nine-cost-v01',scene,249,'hp',hero_bound(6),
            argument='One ordinary4ATK and two actual1DMG Gems can all hit hero for6; Robot has no Taunt/heal.')
        feasible=minimum_body_hp>=4
        match('nine-cost-v01',scene,249,'body_2_4',9 if feasible else None,feasible,
            'Dodge consumes positive instances; enemy may spend cheap Gems before the4ATK hit. All-body focus gives the exact worst remaining HP; any split cannot reduce it further.')
    assert [x['minimum_body_hp'] for x in packet_bounds]==[3,4]
    # Same one-response-plus-own-attack8G window: only enemy ATK changes4->8.
    # Forced zero draw is legal for Gyftrot; positive fatigue draws cannot
    # improve any candidate stat, Taunt protection or clear ability here.
    for attack in (4,8):
        scene='fatigue1-8g-enemy'+str(attack)
        for cid,hp in ((44,13),(8,12),(556,13)):
            match('frontier-observations-v01',scene,cid,'hp',hp,
                argument='Two Gems always give the face upper bound2; Toriel additionally allows the reduced1ATK hit. Deploy/draw0 meets each bound.')
        for cid in (44,8,556):
            feasible=cid==8 or (cid==44 and attack==4)
            hp=(12 if cid==8 else 13) if feasible else None
            match('frontier-observations-v01',scene,cid,'clear_and_body_2_2',hp,feasible,
                'Gyftrot8HP survives at most4+2 damage at attack4, then conditionally clears if needed; attack8 kills it. Toriel starts A+3HP, reduces A to1, and loses at most3 bodyHP while killing4HP target. Baron5HP can be killed by4+1 damage. Holding has no focal body.')
    for cid,hp in ((199,9),(243,9),(509,15),(534,9)):
        match('frontier-observations-v01','fatigue1-5g',cid,'hp',hp,
            argument=('Long Sink: current kill leaves2HP. Enemy spends both Gems on it ->15; any face Gem allows next idle heal and cannot lower below15. If Sink waits, enemy face6 offsets two idle heals and caps15.' if cid==509 else
                'Holding attains9 against all-face6. Draw-only fresh non-Taunt Magic cannot prevent face6 and incurs fatigue; Carbed cannot kill4HP before the reply from healthy2ATK.'))
        match('frontier-observations-v01','fatigue1-5g',cid,'clear_and_body_2_2',None,False,
            'One enemy policy defeats the conjunction: Sink is killed by two Gems after its haste exchange, or by4+2 when it waits; Bench/Manticore cannot clear without falling below2HP; Carbed must hit twice and dies to the second counterhit if the enemy ignores it. Holding lacks a focal body.')
    output=dict(script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        snapshot_sha256=hashlib.sha256(SNAPSHOT.read_bytes()).hexdigest(),no_production_module_imports=True,
        checks=checks,dodge_packet_bounds=packet_bounds,
        limits=['Bounds assume the declared finite windows and ordinary4ATK foes, shared simultaneous exchange, positive damage packet Dodge semantics and explicit slot partition.',
            'Equal strategy bounds under these interpretations do not verify server rules or real scene frequencies.'])
    (HERE/'independent-bounds.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(independent_values=len(checks),all_match=True,dodge_worst_hp=[x['minimum_body_hp'] for x in packet_bounds])))


if __name__=='__main__':main()