"""Cross-card impact: exact same inputs, actual frozen old executions."""
import gzip
import json
from pathlib import Path
P=Path(__file__).parent
old_root=P.parent/'generated-hand-v01'
main=json.loads((P/'main/index.json').read_text())
def load(path):return json.loads(gzip.open(path,'rt').read())
def value(result):
    m=result['maximum_survival']
    return dict(maximum=(m['known'],m['feasible'],m['guaranteed_player_hp']),
        rows=[(r['requested_own_hp_floor'],r['known'],r['feasible'],r['guaranteed_own_hp'],r['guaranteed_enemy_hp_at_most']) for r in result['rows']],
        frontier=result['frontier'])
checks=[]
for row in main['rows']:
    if row['variant']!='unresolved' or row['card_id'] in (17,163,291,526):continue
    current=load(P/'main'/row['artifact'])
    oldpath=old_root/'main'/f"card{row['card_id']}-{row['situation']}.json.gz"
    old=load(oldpath)
    assert old['scenario']==current['scenario']
    assert old['result']['cards_sha256']==current['result']['cards_sha256']
    assert value(old['result'])==value(current['result']),row
    checks.append(dict(card_id=row['card_id'],scene=row['situation'],same_input=True,
        same_card_source=True,same_quoted_values=True,
        old_artifact=str(oldpath),new_artifact=str(P/'main'/row['artifact'])))
assert len(checks)==220
result=dict(passed=True,old_paid_version='0.31',new_paid_version='0.32',
    matched_curves=len(checks),matched_old_native_cards=len({r['card_id'] for r in checks}),
    checks=checks,scope='All220 prior supported curves in the four measured cost groups actually rerun under new sources; '
    'full maximum/known/feasible/floor/joint/frontier values unchanged. No rerun claim for other cost groups.')
(P/'cross-version-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:v for k,v in result.items() if k!='checks'})