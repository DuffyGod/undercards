"""Independent arithmetic bounds for an actual retained-card capacity loss.

No battle/payment/search/scoring imports. Enemy always-face is a legal upper
strategy; legal retain/pay/heal or pay0-tiny policies attain the lower bounds.
"""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
RESEARCH=HERE.parents[1]
SNAPSHOT=RESEARCH.parents[1]/'skills/undercards/references/snapshot.json'


def main():
    cards={c['id']:c for c in json.loads(SNAPSHOT.read_text())['cards']}
    background=[14,15,49,509,534,21]
    assert all(cards[i]['cost']>3 for i in background)
    assert (cards[8]['cost'],cards[196]['cost'],cards[196]['attack'],cards[196]['health'])==(8,0,1,1)
    assert cards[196]['effect_readable']==''
    assert cards[22]['cost']==3 and cards[22]['effect_readable']=='Magic: Heal 4 HP.'
    assert (cards[270]['attack'],cards[270]['health'],cards[270]['effect_readable'])==(4,4,'')
    scenarios=[]
    for held_background in (5,6):
        for focal in (None,8,196):
            for draw in (22,196):
                # Gold0 at root; only focal Tiny0 can create a hand space.
                held=held_background+int(focal is not None)
                frees=int(focal==196)
                burned=held-frees>=7
                keeps_heal=draw==22 and not burned
                hp=10-4-4+(4 if keeps_heal else 0)
                scenarios.append(dict(background_copies=held_background,focal_card_id=focal,next_card_id=draw,
                    capacity=7,policy_current_paid_gold=0,next_paid_gold=3 if keeps_heal else 0,
                    next_card_burned=burned,lower_bound=hp,upper_bound=hp,
                    lower_policy=('Deploy Tiny0 now to free the slot; ' if frees else 'Hold; ')+
                        ('retain Shyren at next owner draw, pay3 and heal own hero4.' if keeps_heal else 'No payable healing is retained.'),
                    upper_enemy_strategy='4ATK/4HP enemy hits own hero in each response. Tiny1 cannot kill it within the window.',
                    scope='No extra draw/income or other actions; background and Toriel remain unaffordable at Gold0/3.'))
    result=dict(production_modules_imported=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        snapshot_sha256=hashlib.sha256(SNAPSHOT.read_bytes()).hexdigest(),scenarios=scenarios,
        physical_facts=dict(hand_cap=7,initial_player_hp=10,maximum_player_hp=30,current_gold=0,next_income=3,
            natural_draws=1,enemy_attacks=[4,4],enemy_hp=30,enemy_body_hp=4,background_ids=background),
        limits=['Capacity7 and owner draw-before-next-play are declared model facts; not a server execution trace.',
            'No construction probability is inferred from this particular known draw.',
            'This certifies a conditional capacity cost, not all hand-clog opportunity costs.'])
    (HERE/'hand-capacity-bounds.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(cases=len(scenarios),independent_bounds_equal=True)))


if __name__=='__main__':main()