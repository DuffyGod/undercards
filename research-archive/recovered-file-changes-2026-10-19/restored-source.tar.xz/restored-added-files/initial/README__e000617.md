# 真实惩罚、出场时机与手牌结构

本轮 paid0.20.0 / board0.3.0 / API0.22.0。评价输出是声明场景和目的下的可执行保证，不是已校准的 Gold 或天梯胜率。当前已有程序能逐卡比较、选择持有或部署、处理双方实际付款和自然抽牌，并独立查询玩家存活与同一个身体的攻击/耐久合取目的。

## 本轮改进与反事实

新增两种按完整来源文本识别的参数机制：单次受伤上限（Mettaton）和敌方来源额外受伤（Bowll）。双方战斗反击、Magic、自伤、Dust、实际咒术共同使用来源伤害结算；沉默删除能力。没有卡名特判或新 Gold 权重。所有 admissible 顺序须遵守最终单次上限；若 Armor、COST、Dodge、上限或额外受伤的不同合理顺序产生不同 HP/Dodge 物理状态，保持 unknown。

同实际4G惩罚，一张8伤法术使 Mettaton/Candy Dish/Ranger Rudinn 留2/0/2HP；四张1伤法术使它们留1/2/0HP。总伤相同不能给相同风险。敌玩家3→2或4HP又会移除 Ranger 在最初三卡比较中的保命优势：真实终结门槛决定窗口长度。来源封顶移除、敌预算变化、相同副本实际花费、不同目的和完整最坏回应见[机制比较](comparison.md)。另有不导入核心规则或搜索的[独立小博弈](../../research-runs/damage-packet-v01/independent-review.md)。

## 完整候选筛选

[全106张普通3G卡](pool-comparison.md)在共同15HP/3G、敌3HP及Aaron1/5、敌手持两张1G Gemstone的双回应窗口逐卡计算。13张闭合、93张明确未知。已支持子集的玩家HP最佳15是 Ice Cap/Shyren；能保证留同一≥2ATK/2HP身体的是 Napstablook/Candy Dish。未知者仍阻断全桶冠军，不能把最初三张中的领先者写成3G最佳。

[跨卡反事实](pool-challenge.md)把敌3HP提高到5：Ice Cap玩家保证15→12，Napstablook身体2→1，Candy仍2；Shyren玩家15不变。己27/max30时 Shyren实际治疗3，保证26；Ice Cap立即终结保27。输出对临界数字敏感，但并不要求全局状态单调。所有这些新根的完整向量与穷举一致；独立 Napstablook 固定策略上下界另保留。

原404张4–8G面板也全部实际重算，短窗49闭合/355未知，长窗50/354。新增 Bowll 闭合，但该旧压力场景玩家HP为0、旧联合目的失败；支持一种能力并不自动提高推荐。

## 等待、联合目的与真实背景

[自然抽牌与后续付款](timing-comparison.md)显式输入双方实际库序、开始抽牌和收入。Candy 的玩家11HP保证与2HP身体分别可行，联合却失败：早出可清敌方第一张新 Tiny、少挨下一次攻击；晚出避开第一轮身体惩罚，却没有即时攻击。不能拼接独立最大值。当前2G、未来收入0→1使等待后付款3G成为可能，留2HP身体 false→true；没有在持有时扣未花费的钱。

真的持有并付 Dummy1G，再未来付 Candy3G，可满足原失败的联合目的。[相同背景的贡献比较](hand-structure.md)改用敌玩家30HP，研究防守与发展；Dummy单持已经保证13HP：

| 同一 Dummy 背景 | 玩家HP最大保证 | 相对 Dummy 单持增量 | 另行搜索的联合目的 |
|---|---:|---:|---|
| Candy Dish | 13 | 0 | 玩家≥13且同体≥2ATK/4HP：可行 |
| Shyren | 17 | +4 | 玩家≥13且同体≥2ATK/4HP：不可行 |
| Napstablook | 13 | 0 | 玩家≥13且同体≥4ATK/3HP：可行 |

Candy/Napstablook 增加的是可用身体，不能把背景保住的13HP全算给它。Dummy占实际手牌槽、当前付款与行动；不是免费配合。移除候选的反事实使身体目的失败，但玩家保证仍13。[无背景的贡献](incremental-comparison.md)同样扣掉全持有基线：11HP通常不是候选贡献11HP。

实际对局优先获胜。纯HP与特定身体目的用于拆解用途，不应为更高HP或指定厚身体而放弃现成获胜。每列是独立策略；只有专门的联合查询或明示的共同策略证明才能合并。

## 可运行入口

在 `analysis/monster-value-heuristic` 下执行：

```bash
# 相同目的：Candy单持失败；加入真实Dummy与付款后成功
python evaluate_situation.py --input experiments/damage-packet-v01/timing-alone.input.json --output /tmp/candy-alone.json
python evaluate_situation.py --input experiments/damage-packet-v01/timing-dummy.input.json --output /tmp/candy-dummy.json
# 完整3G池同场景比较；改场景应保留同预算/背景/目的
python build_packet_pool.py
python build_packet_hand_structure.py
```

入口结果的 `paid_board_tactics.objectives` 包含目的真假、完整向量、最坏路径与实际付款账本。旧启发式路线只是诊断，不恢复确定推荐。两个等待输入的真实 CLI、公共 API 与独立调用一致，见[timing-api-verification.json](timing-api-verification.json)。

## 证据与仍未识别的部分

核心395项回归127.675s通过，模型及测试依赖在运行期间不变。此前失败395项保留，原因是测试未给所需base cost而先遇到合法unknown；补充真实费用观测后检查顺序歧义，没有削弱校验。此后仅增加独立研究脚本和审计登记，不重复已通过的模型测试。新增报告均核验实际来源绑定；两次算法一致仍共享规则原语，不能证明服务器裁定。完整记录在[统一验证](../current-integration-verification.json)、[本轮失败与修正](../../research-runs/damage-packet-v01/validation-history.json)。旧33报告与源码已冻结，重算命令/原始证据保留。

封顶与 Armor/COST 顺序、敌来源额外受伤的零伤事件、friendly spell 文法作用域不明确时继续拒绝确定推荐。93张3G及多数全池机制未闭合；公开候选画像不是完整模拟支持。长期持有频率、隐敌手与成熟卡组分布、SOUL/神器和服务器裁定仍未识别，没有编造局面概率或实战可靠率。当前条件结果可用于指定场景决策与反例，不能据此认证全池最佳或整个Goal完成。

下一可执行机制缺口是 Carbed/Trashy 的动态有效ATK：须区分永久属性、真实回合归属、当前攻击窗口，并覆盖伤害、减攻、沉默与目的阈值消费者。独立19项检查已给出健康/受损/治疗/攻防切换反例，见[机制审查](../../research-runs/damage-packet-v01/dynamic-body-review.md)；主程序目前诚实 unknown，尚未接入。