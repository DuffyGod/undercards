"""Real paid helpers, same-background comparisons and single-number probes."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import conditional_card_score as score
import targeted_hand_magic as hand

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,value):(HERE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def scene(ids,cash,attack=6,health=5):
    return dict(hand_ids=ids,gold_before_play=cash,own_player_hp=15,own_player_max_hp=30,
        enemy_player_hp=30,enemy_player_max_hp=30,opponent_hand_ids=[],opponent_hand_known=True,
        own_deck_ids=[],opponent_deck_ids=[],max_plays='all_physical',horizon='enemy_attack',
        enemy_bodies=[dict(card_id=15 if (attack,health)==(6,5) else 270,attack=attack,health=health,max_health=health,ready=True,slot=1)],
        physical_slots=True,front_slot_map=[0,1,2,3],front_missing_policy='fizzle',
        targeted_hand_empty='fizzle',targeted_hand_choice='eligible_targets',node_limit=20000)

def main():
    cards=score.score_cards.load_cards();by={c['id']:c for c in cards};bindings=score.source_bindings(ROOT/'targeted_hand_magic.py')
    cases=[('endo-dog',scene([33,43],10),1,6),('bone-dog',scene([253,43],10),1,6),
        ('sugar-dog',scene([406,43],10),1,6),('sugar-short-cash',scene([406,43],9),1,6),
        ('sugar-enemy-attack7',scene([406,43],10,7),1,6),
        ('town-long-cash8',scene([436,509],8,4,4),1,5),('town-long-cash7',scene([436,509],7,4,4),1,5),
        ('dog-alone-cash10',scene([43],10),0,6),('dog-alone-cash9',scene([43],9),0,6),
        ('dog-alone-enemy7',scene([43],10,7),0,6),('long-alone-cash8',scene([509],8,4,4),0,5),
        ('long-alone-cash7',scene([509],7,4,4),0,5)]
    rows=[];queries=0;vectors=[]
    for label,data,index,threshold in cases:
        tasks=dict(hp=dict(kind='hp'),buddy=dict(kind='joint',body_scope='focal',
            constraints=dict(min_own_body_attack=threshold,min_own_body_health=1)))
        results={}
        for name,task in tasks.items():
            start=time.monotonic();value=hand.evaluate(data,task,cards=cards,focal_index=index);queries+=1
            results[name]=value
            rows.append(dict(label=label,task=name,known=value['known'],feasible=value['feasible'],hp=value['guaranteed_player_hp'],
                states=value['search'].get('visited_states'),seconds=time.monotonic()-start,artifact=label+'.json'))
            if (label,name) in [('endo-dog','hp'),('bone-dog','hp'),('sugar-dog','buddy'),('town-long-cash8','buddy')]:
                exhaustive=hand.evaluate(dict(data,search_algorithm='exhaustive'),task,cards=cards,focal_index=index);queries+=1
                assert value['known'] and exhaustive['known']
                assert tuple(value['search']['objective_vector'])==tuple(exhaustive['search']['objective_vector'])
                vectors.append(dict(label=label,task=name,alpha_beta=value,exhaustive=exhaustive))
        write(label+'.json',dict(input=data,focal_index=index,tasks=tasks,results=results,
            focal_is='Buddy physical copy, not the helper; these are real whole-hand and buddy-purpose scores.'))
    write('complete-vector-checks.json',vectors)
    pool=[];parent=ROOT/'research-runs/pool-frontier-v02'
    for cid in (33,253,406,436):
        cost=by[cid]['cost'];reference=next(parent.glob(f'native{cost}-card*.json'));old=json.loads(reference.read_text())
        data=copy.deepcopy(old['input']);data.update(hand_ids=[cid],hand_costs=[cost],hand_base_costs=[cost],
            targeted_hand_empty='fizzle',targeted_hand_choice='eligible_targets')
        prior=score.task_score(data,dict(kind='hp'),cards=cards,focal_index=0);queries+=1
        assert not prior['known'],'This is meant to extend prior unknown coverage'
        results={}
        for name,task in old['tasks'].items():
            value=hand.evaluate(data,task,cards=cards,focal_index=0);queries+=1;results[name]=value
        artifact=f'pool-card{cid}.json';write(artifact,dict(input=data,tasks=old['tasks'],focal_index=0,
            original_core_hp=prior,results=results,scene_reference=str(reference.relative_to(ROOT)),
            scene_reference_sha256=sha(reference)))
        pool.append(dict(card_id=cid,name=by[cid]['name'],cost=cost,artifact=artifact,
            all_four_known=all(v['known'] for v in results.values()),
            scores={name:dict(known=v['known'],feasible=v['feasible'],hp=v['guaranteed_player_hp']) for name,v in results.items()}))
    payload=dict(scene=cases[0][1],task=dict(kind='hp'),focal_index=1);write('cli.input.json',payload)
    cmd=[sys.executable,str(ROOT/'targeted_hand_magic.py'),str(HERE/'cli.input.json'),'--output',str(HERE/'cli.output.json')]
    run=subprocess.run(cmd,capture_output=True,text=True,cwd=ROOT);queries+=1
    (HERE/'cli.stdout.log').write_text(run.stdout);(HERE/'cli.stderr.log').write_text(run.stderr)
    assert run.returncode==0
    assert json.loads((HERE/'cli.output.json').read_text())==json.loads((HERE/'endo-dog.json').read_text())['results']['hp']
    assert bindings==score.source_bindings(ROOT/'targeted_hand_magic.py')
    src=HERE/'source';src.mkdir(exist_ok=True)
    for name,h in bindings.items():assert sha(ROOT/name)==h;(src/name).write_bytes((ROOT/name).read_bytes())
    (HERE/'native-snapshot.json').write_bytes(score.score_cards.DEFAULT_SNAPSHOT.read_bytes())
    write('index.json',dict(source_hashes=bindings,source_stable=True,builder_sha256=sha(Path(__file__)),
        rows=rows,pool_extension=pool,complete_vector_matches=len(vectors),actual_queries=queries,
        actual_cli_full_json_equal=True,production_core_changed=False,
        hypotheses=['No eligible held target fizzles; explicit and unverified server convention.',
            'Two-option Endogeny selects only a branch with a matching held target; explicit and unverified server convention.'],
        limits=['New helper draws still guarded by production draw callback registry.',
            'Charge vs Haste target classification unknown; no geometry quotient for the extended keyword state.',
            'No inferred card frequencies, Gold or whole-pool champion.']))
    print(json.dumps(dict(rows=rows,pool=pool,queries=queries),ensure_ascii=False),flush=True)

if __name__=='__main__':main()