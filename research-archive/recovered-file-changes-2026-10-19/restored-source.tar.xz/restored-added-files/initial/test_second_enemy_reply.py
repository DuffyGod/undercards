"""Actual timing, persistent physical copies, and paid second responses."""
from dataclasses import replace
import unittest
import paid_board_tactics as paid
import score_cards


class SecondReplyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cards=score_cards.load_cards()

    def scene(self,**changes):
        return dict(dict(hand_ids=[],gold_before_play=0,own_player_hp=30,
            own_player_max_hp=30,max_plays=0,next_max_plays=0,next_own_gold_income=0,
            horizon='next_enemy_attack',next_opponent_gold_income=0,
            next_opponent_natural_draw_count=0,current_turn_gold_spent_on_spells=0,
            enemy_bodies=[dict(card_id=15,attack=6,health=5)],objectives=['guaranteed_hp']),**changes)

    def solved(self,**changes):
        result=paid.evaluate(self.scene(**changes),self.cards)
        self.assertTrue(result['complete_in_declared_scope'],result['unknown'])
        return result['objectives'][0]

    def test_second_owner_start_refreshes_and_repeats_callbacks(self):
        r=self.solved(own_player_hp=10,enemy_bodies=[dict(card_id=2,attack=2,health=3,ready=False)])
        self.assertEqual(r['metrics']['own_player_hp'],6)
        r=self.solved(own_player_hp=15,enemy_bodies=[dict(card_id=307,attack=4,health=5)])
        self.assertEqual(r['metrics']['own_player_hp'],4)

    def test_paralyze_timing_reverses_preferred_deployment(self):
        now=self.solved(hand_ids=[990],gold_before_play=1,max_plays=1)
        late=self.solved(hand_ids=[990],gold_before_play=1,next_max_plays=1)
        self.assertEqual((now['metrics']['own_player_hp'],late['metrics']['own_player_hp']),(23,24))
        self.assertEqual(now['endpoint_boards']['enemy'][0]['paralyze_owner_starts_remaining'],0)
        self.assertEqual(late['endpoint_boards']['enemy'][0]['paralyze_owner_starts_remaining'],1)
        phases=[];phase=0
        for a in late['principal_variation']:
            if a['kind']=='end_turn':phase=a['phase']+1
            if a['kind']=='deploy':phases.append(phase)
        self.assertEqual(phases,[2])

    def test_fresh_heal_vs_taunt_order_reverses_after_reply(self):
        shy=self.solved(hand_ids=[22],gold_before_play=3,next_max_plays=1,own_player_hp=10)
        dummy=self.solved(hand_ids=[1],gold_before_play=3,next_max_plays=1,own_player_hp=10)
        self.assertEqual((shy['metrics']['own_player_hp'],dummy['metrics']['own_player_hp']),(2,4))
        punished=self.solved(hand_ids=[1],gold_before_play=3,next_max_plays=1,own_player_hp=10,
            opponent_hand_ids=[96],opponent_gold_before_response=3)
        self.assertEqual(punished['metrics']['own_player_hp'],0)

    def test_one_spell_copy_is_not_rebuilt_for_second_turn(self):
        r=self.solved(hand_ids=[1,1],gold_before_play=2,max_plays=1,next_max_plays=1,
            opponent_hand_ids=[96],opponent_gold_before_response=3)
        self.assertEqual(r['metrics']['own_player_hp'],24)
        casts=[a for a in r['principal_variation'] if a['kind']=='cast_spell' and a['side']=='enemy']
        self.assertEqual(len(casts),1)
        self.assertEqual(r['payment_accounting']['enemy_first_paid_gold']+r['payment_accounting']['enemy_second_paid_gold'],3)
        two=self.solved(hand_ids=[1,1],gold_before_play=2,max_plays=1,next_max_plays=1,
            opponent_hand_ids=[96,96],opponent_gold_before_response=3,next_opponent_gold_income=3)
        self.assertEqual(two['metrics']['own_player_hp'],18)

    def test_second_response_cash_threshold_and_retention(self):
        for before,income,hp in ((0,2,30),(0,3,24),(2,1,24)):
            r=self.solved(hand_ids=[1,1],gold_before_play=2,max_plays=1,next_max_plays=1,
                opponent_hand_ids=[96],opponent_gold_before_response=before,next_opponent_gold_income=income)
            self.assertEqual(r['metrics']['own_player_hp'],hp)
            self.assertEqual(r['payment_accounting']['second_enemy_income_credited'],income)

    def test_drawn_enemy_spell_is_a_new_physical_index(self):
        r=self.solved(enemy_bodies=[],own_player_hp=20,opponent_hand_ids=[598],opponent_gold_before_response=1,
            next_opponent_gold_income=1,next_opponent_natural_draw_count=1,opponent_deck_ids=[598])
        self.assertEqual(r['metrics']['own_player_hp'],18)
        casts=[a for a in r['principal_variation'] if a['kind']=='cast_spell']
        self.assertEqual({a['hand_index'] for a in casts},{0,1})
        self.assertEqual(r['opponent_draw_accounting']['remaining_known_deck'],0)

    def test_enemy_full_hand_burn_and_empty_library_fatigue_are_physical(self):
        e=paid.PaidSearch(self.cards,self.scene(enemy_bodies=[],opponent_hand_ids=[196]*7,
            next_opponent_natural_draw_count=1,opponent_deck_ids=[96]))
        s=e.boundary(e.boundary(e.boundary(e.root())))
        self.assertEqual((s.enemy_cards_burned,len(s.enemy_hand),s.enemy_deck),(1,7,()))
        self.assertTrue(all(a.get('card_id')!=96 for a,s in e.deploys(s)))
        r=self.solved(enemy_bodies=[],enemy_player_hp=1,next_opponent_natural_draw_count=1,
            opponent_deck_ids=[],opponent_fatigue_next=1,next_opponent_gold_income=3)
        self.assertTrue(r['metrics']['enemy_player_defeated'])
        self.assertEqual(r['payment_accounting']['second_enemy_income_credited'],3)

    def test_enemy_draw_unknown_identity_and_fatigue_are_not_defaults(self):
        for extra,needle in (({},'opponent_deck_ids'),({'opponent_deck_ids':[]},'opponent_fatigue_next')):
            r=paid.evaluate(self.scene(next_opponent_natural_draw_count=1,**extra),self.cards)
            self.assertFalse(r['complete_in_declared_scope'])
            self.assertTrue(any(needle in s for s in r['unknown']))

    def test_second_income_makes_unknown_enemy_monster_reachable(self):
        r=paid.evaluate(self.scene(enemy_bodies=[],opponent_hand_ids=[14],next_opponent_gold_income=5),self.cards)
        self.assertFalse(r['complete_in_declared_scope'])
        self.assertTrue(any('Reachable enemy card 14 in phase 3' in s for s in r['unknown']))

    def test_paid_enemy_body_is_fresh_then_refreshes_and_printed_cost_stays_separate(self):
        e=paid.PaidSearch(self.cards,self.scene(enemy_bodies=[],own_player_hp=20,
            opponent_hand_ids=[2],opponent_hand_costs=[1],opponent_gold_before_response=1))
        first=e.boundary(e.root());action,s=next(e.deploys(first))
        self.assertEqual((s.enemy[0].cost,s.enemy[0].printed_cost,s.enemy[0].base_cost),(1,2,None))
        self.assertEqual(list(e.attacks(s)),[])
        third=e.boundary(e.boundary(s))
        self.assertEqual(len(list(e.attacks(third))),1)
        dead=e.deaths(third,replace(third,enemy=(replace(third.enemy[0],health=0),)))
        self.assertEqual(paid.board.metrics(dead)['enemy_killed_printed_cost'],2)
        r=e.solve(e.root(),'guaranteed_hp')
        self.assertEqual(r['metrics']['own_player_hp'],18)
        self.assertEqual(r['payment_accounting']['enemy_first_paid_gold'],1)

    def test_enemy_magic_summon_does_not_double_play_or_double_pay(self):
        r=self.solved(enemy_bodies=[],own_player_hp=20,opponent_hand_ids=[563],
            opponent_hand_costs=[0],opponent_gold_before_response=0)
        self.assertEqual(r['metrics']['own_player_hp'],18)
        self.assertEqual(r['metrics']['enemy_living_count'],2)
        self.assertEqual(r['payment_accounting']['enemy_first_paid_gold'],0)
        mother=next(u for u in r['endpoint_boards']['enemy'] if u['card_id']==563)
        self.assertIsNone(mother['base_cost'])
        e=paid.PaidSearch(self.cards,self.scene(enemy_bodies=[],opponent_hand_ids=[563],
            opponent_hand_costs=[0],opponent_hand_base_costs=[4]))
        body=next(s for a,s in e.deploys(e.boundary(e.root())))
        self.assertEqual(body.enemy[0].base_cost,4)

    def test_enemy_need_uses_its_actual_spell_spend_not_own_or_body_payment(self):
        for cost,attack in ((0,3),(1,5)):
            e=paid.PaidSearch(self.cards,self.scene(enemy_bodies=[],opponent_hand_ids=[598,438],
                opponent_hand_costs=[cost,4],opponent_gold_before_response=cost,
                next_opponent_gold_income=4,condition_known_state={'last_turn_gold_spent_on_spells':1}))
            first=e.boundary(e.root());cast=next(s for a,s in e.deploys(first) if a['kind']=='cast_spell')
            third=e.boundary(e.boundary(cast))
            body=next(s for a,s in e.deploys(third) if a['kind']=='deploy')
            self.assertEqual(body.enemy[-1].attack,attack)
        e=paid.PaidSearch(self.cards,self.scene(enemy_bodies=[],opponent_hand_ids=[196,438],
            opponent_hand_costs=[1,4],opponent_gold_before_response=1,next_opponent_gold_income=4))
        body=next(s for a,s in e.deploys(e.boundary(e.root())) if a['kind']=='deploy')
        third=e.boundary(e.boundary(body));played=next(s for a,s in e.deploys(third))
        self.assertEqual(played.enemy[-1].attack,3)

    def test_second_start_assumptions_are_mandatory(self):
        for key in ('next_opponent_gold_income','next_opponent_natural_draw_count'):
            data=self.scene();del data[key]
            with self.assertRaisesRegex(ValueError,'explicit'):paid.PaidSearch(self.cards,data)


if __name__=='__main__':unittest.main()