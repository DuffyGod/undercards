"""Actual common API and CLI observation policies; diagnostic values withdrawn."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import current_draw_policy
import evaluate_situation
import test_current_draw_policy as probes

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/current-draw-challenge-v01'


def fixture(cash=8):
    source=probes.fixture(cash);scene=copy.deepcopy(source['panels'][0])
    root=('hand_ids','gold_before_play','own_player_hp','enemy_player_hp',
          'ally_bodies_before_play','enemy_bodies','opponent_gold_before_response')
    data={k:scene[k] for k in root}
    data.update(role='midrange',own_turn=5,hand_costs=[5,0],condition_state={},
        response_weights={'enemy_face':1},opponent_hand_known=True,opponent_hand_ids=[],
        callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30,own_fatigue_next=1))
    ignored=set(root)|{'own_deck_ids','own_player_max_hp','enemy_player_max_hp','own_fatigue_next',
                       'opponent_hand_ids','objectives','node_limit'}
    data['current_draw_scenario']={k:v for k,v in scene.items() if k not in ignored}
    data['current_draw_scenario'].update(own_deck_orders=[p['own_deck_ids'] for p in source['panels']],
        objective='guaranteed_hp',node_limit=20000)
    return data


def main():
    OUT.mkdir(parents=True,exist_ok=True);rows=[]
    for cash in (8,7):
        data=fixture(cash);result=evaluate_situation.evaluate(data)
        current=result['current_draw_policy']
        assert current==current_draw_policy.evaluate(current['input'])
        assert current['complete_in_declared_scope'] and current['metrics']['own_player_hp']==(5 if cash==8 else 1)
        assert result['hand_survival']['best_known_death_reducing_hand_index'] is None
        assert result['deployment_routes']['best_known_survival_route'] is None
        input_path=OUT/f'cash-{cash}.input.json';result_path=OUT/f'cash-{cash}.result.json'
        input_path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        process=subprocess.run([sys.executable,str(HERE/'evaluate_situation.py'),'--input',str(input_path),
            '--output',str(result_path)],cwd=HERE,capture_output=True,text=True)
        assert process.returncode==0,(process.stdout,process.stderr)
        assert json.loads(result_path.read_text())==json.loads(json.dumps(result))
        rows.append(dict(cash=cash,guaranteed_hp=current['metrics']['own_player_hp'],
            api_matches_standalone=True,cli_matches_api=True,cli_summary=json.loads(process.stdout),
            input_sha256=hashlib.sha256(input_path.read_bytes()).hexdigest(),
            result_sha256=hashlib.sha256(result_path.read_bytes()).hexdigest()))
    (OUT/'api-verification.json').write_text(json.dumps(dict(api_version=evaluate_situation.VERSION,
        cases=rows,source_hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in
            ('build_current_draw_api.py','test_current_draw_policy.py','current_draw_policy.py',
             'evaluate_situation.py','paid_board_tactics.py','board_tactics.py')}),ensure_ascii=False,indent=2)+'\n')
    print('Current Draw API=standalone=CLI; cash8/7 guarantee5/1, old recommendations withdrawn')


if __name__=='__main__':main()