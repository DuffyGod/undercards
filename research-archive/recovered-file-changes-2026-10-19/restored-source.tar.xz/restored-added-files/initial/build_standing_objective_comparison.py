"""Falsify survival-only standing rankings using common observable contexts."""
import copy
import hashlib
import json
from pathlib import Path
import paid_board_tactics as paid
import score_cards
from certify_hand_hp import cards_digest

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/standing-objectives-v01'
CANDIDATES=[438,583,217,13,20,14,15,509,650,101,108,250,21,227,8]
PURPOSES=dict(survive_and_clear=dict(min_own_player_hp=1,max_enemy_living_count=0),
    survive_and_retain_pressure=dict(min_own_player_hp=1,min_own_board_attack=4,min_own_board_health=3))


def contexts():
    base=dict(own_player_hp=7,own_player_max_hp=30,enemy_player_hp=30,enemy_player_max_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[dict(card_id=15,attack=6,health=5,current_cost=5,base_cost=5),
            dict(card_id=196,attack=1,health=1,current_cost=0,base_cost=0)],
        opponent_hand_ids=[96],opponent_gold_before_response=3,horizon='next_enemy_attack',
        max_plays=1,next_max_plays=0,next_own_gold_income=0,next_natural_draw_count=0,
        next_opponent_gold_income=3,next_opponent_natural_draw_count=0,
        current_turn_gold_spent_on_spells=0,condition_known_state={'last_turn_gold_spent_on_spells':0},
        own_deck_ids=[],own_dustpile_monsters=[],opponent_deck_ids=[],node_limit=20000)
    comfortable=dict(copy.deepcopy(base),own_player_hp=26)
    supported=dict(copy.deepcopy(comfortable),ally_bodies_before_play=[dict(card_id=9,
        attack=3,health=1,current_cost=3,base_cost=3,ready=True)])
    return dict(emergency_empty_board=base,comfortable_empty_board=comfortable,comfortable_ready_ally=supported)


def value(output,mode):
    if not output['complete_in_declared_scope']:return None
    r=output['objectives'][0]
    return r['metrics']['own_player_hp'] if mode=='guaranteed_hp' else r['purpose_guaranteed']


def build():
    cards=score_cards.load_cards();by={c['id']:c for c in cards};rows=[];holds={};checks=[]
    scenes=contexts()
    def solve(scene,mode,constraints=None):
        data=dict(scene,objectives=[mode])
        if constraints:data['purpose_constraints']=constraints
        return paid.evaluate(data,cards)
    for name,scene in scenes.items():
        for fee in sorted({by[c]['cost'] for c in CANDIDATES}):
            control=dict(scene,hand_ids=[],gold_before_play=fee)
            holds[(name,fee)]=dict(hp=solve(control,'guaranteed_hp'),
                purposes={goal:solve(control,'purpose',conditions) for goal,conditions in PURPOSES.items()})
        for cid in CANDIDATES:
            card=by[cid];data=dict(scene,hand_ids=[cid],hand_base_costs=[card['cost']],gold_before_play=card['cost'])
            hp=solve(data,'guaranteed_hp')
            purposes={goal:solve(data,'purpose',conditions) for goal,conditions in PURPOSES.items()}
            baseline=holds[(name,card['cost'])]
            a,b=value(hp,'guaranteed_hp'),value(baseline['hp'],'guaranteed_hp')
            goal_values={goal:value(output,'purpose') for goal,output in purposes.items()}
            baseline_values={goal:value(output,'purpose') for goal,output in baseline['purposes'].items()}
            rows.append(dict(context=name,card_id=cid,name=card['name'],printed_cost=card['cost'],input=data,
                guaranteed_hp=a,hold_guaranteed_hp=b,hp_increment_over_hold=a-b if a is not None and b is not None else None,
                goals=goal_values,hold_goals=baseline_values,
                newly_guaranteed_goals=[goal for goal in PURPOSES if goal_values[goal] is True and baseline_values[goal] is False],
                hp_search=hp,purpose_searches=purposes))
            # Independent full-vector checks for ordinary body, threshold resistance,
            # Haste and attack-setting across all three contexts, not every mirrored call.
            if cid in (15,14,21,8):
                for mode,constraints,reference in [('guaranteed_hp',None,hp),
                    ('purpose',PURPOSES['survive_and_retain_pressure'],purposes['survive_and_retain_pressure'])]:
                    if not reference['complete_in_declared_scope']:continue
                    exhaustive=solve(dict(data,search_algorithm='exhaustive'),mode,constraints)
                    if not exhaustive['complete_in_declared_scope'] or exhaustive['objectives'][0]['objective_vector']!=reference['objectives'][0]['objective_vector']:
                        raise AssertionError(('Independent vector mismatch',name,cid,mode))
                    checks.append(dict(context=name,card_id=cid,objective=mode,full_vector_equal=True))
    comparisons=[]
    for name in scenes:
        current=[r for r in rows if r['context']==name]
        known=[r for r in current if r['guaranteed_hp'] is not None]
        best=max((r['guaranteed_hp'] for r in known),default=None)
        comparisons.append(dict(context=name,selected_subset_hp_best=best,
            hp_best_ids=[r['card_id'] for r in known if r['guaranteed_hp']==best],
            purpose_feasible_ids={goal:[r['card_id'] for r in current if r['goals'][goal] is True] for goal in PURPOSES},
            purpose_newly_feasible_ids={goal:[r['card_id'] for r in current if goal in r['newly_guaranteed_goals']] for goal in PURPOSES}))
    return dict(version='standing-observable-objective-comparison-0.1.0',candidate_ids=CANDIDATES,
        hypothesis='An emergency empty-board survival ranking need not select monsters that retain pressure in a comfortable or already-developed position.',
        purposes=PURPOSES,contexts=scenes,cases=rows,comparisons=comparisons,
        hold_controls=[dict(context=name,printed_cost_budget=fee,results=result) for (name,fee),result in holds.items()],
        independent_search_checks=checks,cards_canonical_sha256=cards_digest(cards),
        source_hashes={f:hashlib.sha256((HERE/f).read_bytes()).hexdigest() for f in
            ('build_standing_objective_comparison.py','paid_board_tactics.py','board_tactics.py','alpha_beta_search.py')},
        limitations=['Selected 15 contrasting native candidates, not whole-bucket champions or a representative empirical sample.',
            'Each purpose searches its whole conjunction against all implemented replies; endpoint columns are not combined into a guarantee.',
            'HP and total own board ATK/HP are explicit state objectives, not future damage, win rate or Gold prices.',
            'Current own play is optional. Hold controls use the same budget, existing bodies and response window; a goal already true without the card is not added value.',
            'A ready Ice Cap is an observed existing unit; no free unobserved prior attack or activation is inferred.',
            'Unknown mechanics remain unknown. Opponent hand is known and naturally drawn cards are disabled in this diagnostic.',
            'No frequency weights; these are causal interventions, not claims about typical actual games.'])


def main():
    result=build();OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    lines=['# 站场评价：紧急保命、正常生命与已有友军','','检验同一组原牌在不同实际目的下的选择。三组共同状态仅改变己方7→26HP，以及是否已有ready Ice Cap3/1；敌Aaron6/5＋Tiny1/1、已知Punishment3G，包含第二敌回应。每次一个候选、一笔等于其印刷费用的现金、当前最多一次Play，未来只攻击，没有新增收入、抽牌或Play。敌第二次显式收入3G。','','保留压力目的要求同一策略在所有回复下同时满足己方HP≥1、己场总ATK≥4、总HP≥3；清场另独立检验HP≥1和敌存活怪物0。每个费用另搜相同状态的空手持有基线。已有友军不是新牌收益。','','| 状态 | 已选子集HP最佳及卡ID | 保命且清场 | 保命且留4ATK/3HP |','|---|---|---|---|']
    for c in result['comparisons']:
        lines.append('| '+c['context']+' | '+str(c['selected_subset_hp_best'])+': '+str(c['hp_best_ids'])+' | '+str(c['purpose_feasible_ids']['survive_and_clear'])+' | '+str(c['purpose_feasible_ids']['survive_and_retain_pressure'])+' |')
    lines+=['','| 原牌 | 7HP空场：HP / 留压力 | 26HP空场：HP / 留压力 | 26HP已有友军：HP / 留压力 |','|---|---|---|---|']
    for cid in CANDIDATES:
        cells=[]
        for name in result['contexts']:
            row=next(r for r in result['cases'] if r['context']==name and r['card_id']==cid)
            cells.append(str(row['guaranteed_hp'])+' / '+str(row['goals']['survive_and_retain_pressure']))
        row=next(r for r in result['cases'] if r['card_id']==cid)
        lines.append('| '+row['name']+' #'+str(cid)+' | '+' | '.join(cells)+' |')
    lines+=['','JSON保存每个目的的独立搜索、目标/付款/反击最坏路径、同费用空手基线及未知原因。上述15张是机制不同的诊断集合，不能当完整费用桶最优。阈值是公开指定的场面需求，不是调成期望排名的奖励；未将这些不同状态平均成Gold或虚构天梯权重。','','```sh','python analysis/monster-value-heuristic/build_standing_objective_comparison.py','```','']
    (OUT/'comparison.md').write_text('\n'.join(lines))
    print(result['comparisons'])


if __name__=='__main__':main()