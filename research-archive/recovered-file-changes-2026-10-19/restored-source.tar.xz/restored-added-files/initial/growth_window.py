"""Root-body quotes corrected by a shared modifier/keyword response window.

Pref is a permanent grown ordinary body. Pmid has removable self modifiers;
P1 has the same modifiers plus keywords. F(grown)+U(P1)-U(Pref) preserves
ordinary-body pricing without adding the ordinary attack a second time.
Synthetic response rates and fresh modifier removal are declared assumptions,
not measured win rates or verified general server silence semantics.
"""
from __future__ import annotations

import copy
import json
import math

import combat_increment as combat
import score_cards as prices

VERSION = 'normalized-growth-window-0.1.0'


def _reply(state, event):
    actor = state['actor']
    # A dead body is absorbing; unavailable/zero-weight silence is never used.
    if (event == 'silence' and not combat.terminal(state)
            and actor['health'] > 0 and state['enemy_gold'] >= 3):
        modifier = actor.get('modifier', {'attack': 0, 'health': 0})
        if modifier['health'] and actor['health'] != actor['max_hp']:
            raise ValueError('Injured HP modifier silence reset is unverified')
        combat.reply(state, event)
        actor['attack'] -= modifier['attack']
        actor['health'] -= modifier['health']
        actor['max_hp'] -= modifier['health']
        actor['modifier'] = {'attack': 0, 'health': 0}
        state['log'].append({'event': 'synthetic_fresh_modifier_reset', 'removed': modifier})
    else:
        combat.reply(state, event)


def _plan(initial, haste, weights, reference, role):
    plans = ['delay'] + combat.legal_own_targets(initial) if haste else ['delay']
    known, unknown = [], []
    for plan in plans:
        outcomes, errors = {}, []
        for event, weight in weights.items():
            if not weight:
                continue
            state = copy.deepcopy(initial)
            if plan != 'delay':
                combat.trade(state, plan)
            try:
                _reply(state, event)
                state = combat.later_attack(state, reference, role)
                assert state['own_attacks'] <= (1 if plan == 'delay' else 2)
                outcomes[event] = {
                    'utility': combat.utility(state, reference, role),
                    'components': combat.utility_components(state, reference, role),
                    'state': state, 'terminal': combat.terminal(state)}
            except ValueError as exc:
                errors.append({'event': event, 'weight': weight, 'reason': str(exc)})
        if errors:
            unknown.append({'plan': plan, 'errors': errors})
        else:
            known.append({'plan': plan, 'outcomes': outcomes,
                          'expected': sum(weights[e] * o['utility'] for e, o in outcomes.items())})
    best = max(known, key=lambda p: p['expected']) if known else None
    terminal = any(o['terminal'] for p in known for o in p['outcomes'].values())
    return {'best_known': best, 'unknown_routes': unknown,
            'terminal_candidate_present': terminal, 'known_plan_count': len(known)}


def evaluate(attack, health, delta_attack, delta_health, enemy_bodies, statuses,
             enemy_gold, reference, role, weights=None, own_player_hp=30, enemy_player_hp=30):
    weights = combat.validate_window(attack, health, enemy_bodies, statuses, enemy_gold,
                                     role, weights, own_player_hp, enemy_player_hp)
    if health <= 0 or any(type(x) not in (int, float) or not math.isfinite(x) or x < 0
                          for x in (delta_attack, delta_health)):
        raise ValueError('Growth window requires a fresh live body and positive self modifiers')
    if len(enemy_bodies) > 4 or any(t['health'] <= 0 for t in enemy_bodies):
        raise ValueError('Growth window requires live enemies within four slots')
    grown_attack, grown_health = attack + delta_attack, health + delta_health
    # Three routes share grown initial stats, resources, response weights and
    # all post-response action rules. Only actual modifiers/keywords differ.
    pref = combat.state(grown_attack, grown_health, enemy_bodies, {}, enemy_gold,
                         own_player_hp, enemy_player_hp)
    pref['actor'].update(base_attack=grown_attack, base_max_hp=grown_health, max_hp=grown_health,
                         modifier={'attack': 0, 'health': 0})
    mid = copy.deepcopy(pref)
    mid['actor'].update(base_attack=attack, base_max_hp=health,
                        modifier={'attack': delta_attack, 'health': delta_health})
    special = copy.deepcopy(mid)
    special['actor'].update(dodge=statuses.get('dodge', 0), armor=statuses.get('armor', False),
                            taunt=statuses.get('taunt', False))
    routes = {
        'permanent_grown': _plan(pref, False, weights, reference, role),
        'actual_growth': _plan(mid, False, weights, reference, role),
        'growth_keywords': _plan(special, statuses.get('haste', False), weights, reference, role)}
    unknown = [{'route': name, **error} for name, result in routes.items()
               for error in result['unknown_routes']]
    terminal = any(r['terminal_candidate_present'] for r in routes.values())
    supported = not unknown and not terminal
    values = {name: r['best_known']['expected'] if r['best_known'] else None
              for name, r in routes.items()}
    p = prices.role_parameters(role)
    printed_body = prices.body_value(attack, health, reference, p)
    grown_body = prices.body_value(grown_attack, grown_health, reference, p)
    modifier_delta = values['actual_growth'] - values['permanent_grown'] if supported else None
    keyword_delta = values['growth_keywords'] - values['actual_growth'] if supported else None
    return {
        'version': VERSION, 'pricing_supported': supported,
        'printed_body_model_gold': printed_body, 'grown_body_model_gold': grown_body,
        'joint_growth_body_model_gold': grown_body - printed_body,
        'modifier_window_adjust_model_gold': modifier_delta,
        'keyword_window_adjust_model_gold': keyword_delta,
        'gross_model_gold': grown_body + modifier_delta + keyword_delta if supported else None,
        'routes': routes, 'response_weights': weights, 'unknown_routes': unknown,
        'terminal_requires_separate_outcome_evaluation': terminal,
        'bound_modifier': {'attack': delta_attack, 'health': delta_health},
        'assumptions': [
            'F is a root ordinary-body price including ordinary lifetime, not this window payoff.',
            'Only fresh positive non-base self modifiers; silence removes them under a declared model assumption.',
            'Injured HP modifier reset is unverified and blocks all-route pricing when reachable.',
            'Role response probabilities and HP/cash utilities are normative, not empirical.',
            'One existing enemy response and one later own attack; other allies do not actively defend.',
            'Opponent silence/chip costs are utility differences, not cash received by our player.',
            'Any known positive-weight terminal route prevents resource-Gold pricing.']}


def evaluate_cached(card, ctx, delta_attack, delta_health, statuses, reference, weights=None):
    if any(t.get('taunt') for t in ctx.get('ally_bodies_before_play', [])):
        raise ValueError('Other allied Taunt defenders are outside the growth response window')
    args = (card['attack'], card['health'], delta_attack, delta_health, ctx['enemy_bodies'],
            statuses, ctx['opponent_gold_before_response'], reference, ctx['role'], weights,
            ctx.get('own_player_hp', 30), ctx.get('enemy_player_hp', 30))
    cache = getattr(reference, 'growth_window_cache', None)
    if cache is None:
        return evaluate(*args)
    key = json.dumps([VERSION, args[:7], args[8:], prices.role_parameters(ctx['role']),
                      combat.RESPONSE_WEIGHTS[ctx['role']], combat.HP_WEIGHTS[ctx['role']],
                      combat.CASH_WEIGHT], sort_keys=True)
    if key not in cache:
        result = evaluate(*args)
        if len(cache) >= 4096:
            return result
        cache[key] = result
    return copy.deepcopy(cache[key])