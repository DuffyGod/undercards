"""Validate reviewed whole-2G-bucket target proofs against executable witnesses.

These four fixed scenes require every condition in the reviewed source proof.
Unknown irrelevant state transitions are retained; no full-card simulation or
matchup frequency is inferred from a goal certificate.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import certify_low_fee_rescue as low
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
PROOF=HERE/'experiments/fee-purpose-v02/two-cost-source-review.json'
PANELS={k:v for k,v in low.PANELS.items() if 'silence' not in k}


def certify(panel='two_attacks',cards=None):
    if panel not in PANELS: raise ValueError('Unsupported reviewed panel')
    cards=score_cards.load_cards() if cards is None else cards
    proof=json.loads(PROOF.read_text())
    by={c['id']:c for c in cards}
    if proof['snapshot_sha256']!=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest():
        raise ValueError('Reviewed source snapshot changed')
    candidates={c['id'] for c in cards if c['card_type']=='monster'
        and c['pool_category']=='ordinary_non_token' and c['cost']==2}
    if {r['card_id'] for r in proof['rows']}!=candidates:
        raise ValueError('Complete 2G candidate inventory changed')
    for row in proof['rows']:
        c=by[row['card_id']]
        fields={'name':'name','printed_cost':'cost','attack':'attack','health':'health',
                'effect_readable':'effect_readable','target':'target'}
        if any(row[a]!=c[b] for a,b in fields.items()):
            raise ValueError('Reviewed card changed: '+str(c['id']))
        for ref in row['references']:
            if any(ref[k]!=by[ref['card_id']][k] for k in ('name','cost','attack','health','effect_readable')):
                raise ValueError('Referenced product changed: '+str(ref['card_id']))
    second,spell=PANELS[panel]
    data=dict(hand_ids=[],gold_before_play=2,own_player_hp=3,own_player_max_hp=30,
        enemy_player_hp=30,enemy_player_max_hp=30,max_plays=1,horizon='enemy_attack',
        ally_bodies_before_play=[],enemy_bodies=[dict(card_id=15,attack=6,health=5)],
        opponent_hand_ids=[] if spell is None else [spell],
        opponent_gold_before_response=0 if spell is None else 3,
        own_deck_ids=[],own_fatigue_next=1,next_natural_draw_count=0,
        objectives=['survive','purpose'],purpose_constraints={'min_own_player_hp':1,'max_enemy_living_count':0})
    if second: data['enemy_bodies'].append(dict(card_id=2,attack=2,health=3))
    rows=[]
    for row in proof['rows']:
        bounds=row['guaranteed_endpoint_hp_bounds'][panel]
        current=dict(row,panel_bounds=bounds)
        result=paid.evaluate(dict(data,hand_ids=[row['card_id']]),cards)
        if result['complete_in_declared_scope']:
            hp=result['objectives'][0]['metrics']['own_player_hp']
            if not bounds[0]<=hp<=bounds[1]: raise AssertionError('Runtime/source survival disagreement')
            if result['objectives'][1]['purpose_guaranteed']:
                raise AssertionError('Runtime/source joint-goal disagreement')
        current['runtime']=result
        current['full_state_simulated']=result['complete_in_declared_scope']
        rows.append(current)
    lower=max(r['panel_bounds'][0] for r in rows)
    upper=max(r['panel_bounds'][1] for r in rows)
    return dict(version='complete-2G-target-certificate-0.1.0',panel=panel,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('certify_two_fee_rescue.py','paid_board_tactics.py','board_tactics.py')},
        reviewed_proof_sha256=hashlib.sha256(PROOF.read_bytes()).hexdigest(),
        snapshot_sha256=proof['snapshot_sha256'],reviewed_conditions=proof['conditions'],
        common_runtime_input=data,all_candidate_ids=sorted(candidates),cards=rows,
        optimal_guaranteed_hp_bounds=[lower,upper],optimum_certified=lower==upper,
        known_optimal_card_ids=[r['card_id'] for r in rows if r['panel_bounds']==[lower,lower]] if lower==upper else [],
        certified_survival_card_ids=[r['card_id'] for r in rows if r['panel_bounds'][0]>0],
        any_candidate_can_guarantee_survival_and_clear=False,
        limitations=['All reviewed historical/source conditions are required, not just the executable scene.',
            'Source survival proofs certify this goal only; unimplemented full-state transitions stay unknown.',
            'No weights or matchup probabilities assigned to these fixed scenes. No higher-cost or universal card-price optimum.'])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--panel',choices=list(PANELS),default='two_attacks')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    r=certify(a.panel)
    a.output.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:r[k] for k in ('panel','optimal_guaranteed_hp_bounds','certified_survival_card_ids')},ensure_ascii=False))


if __name__=='__main__':main()