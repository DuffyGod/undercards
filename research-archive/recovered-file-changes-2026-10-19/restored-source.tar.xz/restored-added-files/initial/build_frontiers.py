"""Preserve physical unknowns; add separately certified geometry-only scores."""
import copy
import csv
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import conditional_card_score as score
import position_quotient_score as quotient

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,obj):(HERE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

def main():
    measured=json.loads((HERE/'index.resumed.json').read_text());inventory=json.loads((HERE/'inventory.json').read_text())['rows']
    assert not measured['unmeasured_compile_supported']
    bindings=score.source_bindings(ROOT/'position_quotient_score.py');cards=score.score_cards.load_cards()
    certificate_rows=[];overlays={}
    for cid,cost in ((469,5),(108,6),(235,7)):
        path=HERE/f'native{cost}-card{cid}.json';raw=json.loads(path.read_text());outcomes={}
        for name,task in raw['tasks'].items():
            value=quotient.evaluate(raw['input'],task,cards=cards,focal_index=0)
            expected={k:v for k,v in raw['results'][name].items() if k!='query_seconds'}
            assert value['physical_score']==expected and not expected['known']
            assert value['known'];outcomes[name]=value;certificate_rows.append(dict(card_id=cid,task=name,known=True,hp=value['quotient_score']['guaranteed_player_hp']))
        artifact=f'quotient-card{cid}.json';write(artifact,dict(input=raw['input'],results=outcomes,physical_artifact=path.name))
        overlays[cid]=(artifact,outcomes)
    by={r['card_id']:r for r in measured['rows']};groups=[];flat=[]
    for cost in range(3,11):
        rows=[]
        for item in inventory:
            if item['cost']!=cost:continue
            cid=item['card_id'];raw=None;physical={}
            if cid in by:
                artifact=by[cid]['artifact'];raw=json.loads((HERE/artifact).read_text());physical=raw['results']
            else:
                artifact=None
                physical={name:dict(known=False,status='compiler_unknown',feasible=None,guaranteed_player_hp=None,
                    unknown=item['physical_spec']['unknown'],search=None) for name in measured['tasks']}
            chosen=copy.deepcopy(physical);method='physical';proof=None
            if cid in overlays:
                proof,outcomes=overlays[cid];chosen={name:v['quotient_score'] for name,v in outcomes.items()};method='certified_position_quotient'
            row=dict(card_id=cid,name=item['name'],printed_cost=cost,artifact=artifact,
                score_method=method,quotient_artifact=proof,physical_scores=physical,scores=chosen)
            rows.append(row)
            for task,cell in chosen.items():
                p=physical[task]
                flat.append(dict(cost=cost,card_id=cid,name=item['name'],task=task,method=method,known=cell['known'],
                    feasible=cell['feasible'],hp=cell['guaranteed_player_hp'],physical_known=p['known'],physical_hp=p['guaranteed_player_hp'],
                    artifact=proof or artifact,original_physical_artifact=artifact))
        groups.append(dict(key='native-'+str(cost),cost=cost,native_candidates=len(rows),
            measured=sum(r['card_id'] in by for r in rows),known_all_tasks=sum(all(v['known'] for v in r['scores'].values()) for r in rows),
            physical_known_all_tasks=sum(all(v['known'] for v in r['physical_scores'].values()) for r in rows),rows=rows,
            selections_by_task={name:score.ranking(rows,name) for name in measured['tasks']}))
    assert bindings==score.source_bindings(ROOT/'position_quotient_score.py')
    totals=dict(native_candidates=len(inventory),compile_supported=len(by),physical_known=sum(g['physical_known_all_tasks'] for g in groups),
        known_with_certificates=sum(g['known_all_tasks'] for g in groups),compiler_unknown=len(measured['compiler_unknown_ids']),
        remaining_runtime_unknown=sum(any(not v['known'] for v in r['scores'].values()) and r['card_id'] in by for g in groups for r in g['rows']))
    write('frontiers.json',dict(groups=groups,tasks=measured['tasks'],totals=totals,source_hashes=bindings,
        source_stable=True,source_model='paid0.25',source_index_sha256=sha(HERE/'index.resumed.json'),
        quotient_task_queries=12,quotient_actual_core_calls=24,physical_original_results_preserved=True,
        certificate_rows=certificate_rows,whole_bucket_champions_certified=0,
        assumptions=['Physical four slots and explicit front mapping/fizzle; Switch left slots0,1.',
            'Targeted hand no-target fizzle and eligible-only branch choice explicit, no server trace.',
            'No exogenous income/natural draws; real optional card effects, holding, future cash and two enemy replies retained.',
            'No context frequencies, deck distributions, Gold prices or real-match validation.']))
    with (HERE/'scores.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
    print(json.dumps(totals),flush=True)

if __name__=='__main__':main()