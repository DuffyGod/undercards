"""One-card answer cost does not determine resistance to an actual hand."""
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import alternative_goal_score as alt
import conditional_card_score as score


def main():
    bindings=score.source_bindings(ROOT/'alternative_goal_score.py');rows=[];vectors=[]
    for cid in (20,110,292,534,443,8):
        raw=json.loads((HERE/f'card{cid}.json').read_text())
        for cash,ids in [(1,[79,598]),(2,[79,598]),(2,[598,79])]:
            data=copy.deepcopy(raw['input'])
            data['enemy_bodies'][0].update(card_id=14,current_card_cost=5,base_cost=5)
            data.update(opponent_hand_ids=ids,opponent_hand_costs=[1,1],opponent_hand_base_costs=[1,1],
                opponent_gold_before_response=cash)
            values={}
            for name in ('hp','clear_or_focal4_1'):
                task=raw['tasks'][name]
                values[name]=(alt.evaluate(data,task,focal_index=0) if task['kind']=='any'
                    else score.task_score(data,task,focal_index=0))
            label=f'combo-card{cid}-cash{cash}-'+('-'.join(map(str,ids)))
            (HERE/(label+'.json')).write_text(json.dumps(dict(input=data,tasks=raw['tasks'],results=values),ensure_ascii=False,indent=2)+'\n')
            if cid==110 and cash==2 and ids[0]==79:
                ex=alt.evaluate(dict(data,search_algorithm='exhaustive'),raw['tasks']['clear_or_focal4_1'],focal_index=0)
                assert ex['known'] and tuple(ex['search']['objective_vector'])==tuple(values['clear_or_focal4_1']['search']['objective_vector'])
                vectors.append(dict(alpha=values['clear_or_focal4_1'],exhaustive=ex))
            row=dict(card_id=cid,enemy_cash=cash,hand_ids=ids,artifact=label+'.json',
                scores={n:{k:v.get(k) for k in ('known','feasible','guaranteed_player_hp','unknown')} for n,v in values.items()})
            rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
    assert bindings==score.source_bindings(ROOT/'alternative_goal_score.py')
    for cid in (20,110,292,534,443,8):
        variants=[r for r in rows if r['card_id']==cid and r['enemy_cash']==2]
        assert variants[0]['scores']==variants[1]['scores']
    (HERE/'combo-answers.json').write_text(json.dumps(dict(source_hashes=bindings,source_stable=True,
        builder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),actual_task_queries=37,
        full_vector_matches=1,rows=rows,physical_hand_permutation_invariant_scores=True,
        limits=['Actual two-copy hand, real shared cash. Enemy chooses the order, not the order of listed hand IDs.',
            'Gemstone is generated/token; this is a held in-game menu, not an illegal starting cross-SOUL deck.']),ensure_ascii=False,indent=2)+'\n')
    (HERE/'combo-vector-checks.json').write_text(json.dumps(vectors,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()