"""High-fee strategy bounds, independent of battle/search implementation."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    cards={c['id']:c for c in json.loads((HERE/'native-snapshot.json').read_text())['cards']}
    assert (cards[443]['cost'],cards[443]['attack'],cards[443]['health'])==(10,4,9)
    assert cards[443]['effect_readable']=='Haste. Magic: Deal 4 DMG to a monster. Deal 1 extra DMG for every 3 GOLD it costs.'
    assert (cards[110]['cost'],cards[110]['attack'],cards[110]['health'])==(10,13,1)
    assert cards[110]['effect_readable']=='Dust: Deal its ATK as DMG to all enemy monsters.'
    assert (cards[8]['cost'],cards[8]['attack'],cards[8]['health'])==(8,6,4)
    expected={
        ('single-cost3',443):(15,15,15),('single-cost3',110):(11,None,None),('single-cost3',8):(14,None,None),
        ('single-cost2',443):(15,15,None),('single-cost2',110):(11,None,None),('single-cost2',8):(14,None,None),
        ('big-attack20',443):(15,15,None),('big-attack20',110):(0,None,None),('big-attack20',8):(14,None,14),
        ('wide-hp2',443):(7,None,None),('wide-hp2',419):(15,15,15),('wide-hp2',249):(0,None,None),
        ('wide-hp2',110):(0,None,None),('wide-hp2',8):(2,None,None),
    }
    checks=[]
    for (label,cid),values in expected.items():
        path=HERE/f'{label}-card{cid}.json';r=json.loads(path.read_text())['results']
        for task,value in zip(('hp','clear','body4_8'),values):
            assert r[task]['known'] and r[task]['guaranteed_player_hp']==value,(label,cid,task)
            assert r[task]['feasible']==(value is not None and (task!='hp' or value>0))
            checks.append(dict(context=label,card_id=cid,task=task,independent_hp=value,artifact_sha256=sha(path)))
    for hp,body in ((11,None),(12,15)):
        path=HERE/f'source-hp{hp}.json';r=json.loads(path.read_text())['results']
        assert r['hp']['guaranteed_player_hp']==15 and r['body4_8']['guaranteed_player_hp']==body
        checks.extend([dict(context='source-hp'+str(hp),task='hp',independent_hp=15),
            dict(context='source-hp'+str(hp),task='body4_8',independent_hp=body)])
    assert 4+3//3==5 and 4+2//3==4 and 11-4<8<=12-4
    report=dict(imports_production_model=False,builder_sha256=sha(Path(__file__)),source_snapshot_sha256=sha(HERE/'native-snapshot.json'),
        matching_context_cells=len(checks),checks=checks,
        strategy_bounds=[
            'At target5HP/COST3, Chain Magic5 clears it without retaliation, so hero15 and source4/9. At COST2, Magic4 leaves1; Haste4 clears it but takes4, leaving source5HP. Not attacking lets the enemy hit that source to5HP instead, denying8HP in either plan; pure HP still15 by preempting.',
            'Source HP11 versus12 in the COST2 world: a required4-damage trade leaves7 versus8. Only12 can guarantee body4/8 and hero15. Other candidate metadata is identical.',
            'NEO has no Haste or Taunt. Against a single4ATK enemy, face4 forces11 and leaves that enemy alive, despite a possible voluntary body trade/Dust reply. Against20ATK, face kills the15HP hero before NEO attacks. Never electing to trigger its Dust is legal enemy strategy.',
            'Toriel reduces a single enemy to1. Against4ATK it gains3HP to7, cannot meet8HP; face1 forces14. Against20ATK it gains19 to23HP, guarantees6/22 or more after a body hit, while face1 still bounds hero14. Enemy8HP cannot be cleared before the one-response deadline.',
            'Wide four4ATK/2HP: Chain Magic kills one, fresh Haste kills one while taking4, leaving two face attacks8 and hero7. It cannot force the other two to die or preserve8 sourceHP. Spade King right kills all2HP and keeps6/9, hero15. Robot/NEO can be ignored for16 face damage, hero0. Toriel reduces only one attack:1+4+4+4=13, hero2.'
        ],
        assumptions=['All candidates share10G cash; actual costs9/8 leave unused money without a nonexistent extra hand card.',
            'Existing selected-Magic convention excludes source/Transparency. Empty-other-target scenes are unknown, not guessed fizzle.',
            'Explicit current/base/printed COST domain and the corrected already-Silenced observation metadata.',
            'These finite one-response contexts only; no card frequencies, global Gold or real-match ranking.'])
    (HERE/'independent-bounds.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(matching_context_cells=len(checks))))

if __name__=='__main__':main()