"""Actual public CLI exercises of dynamic deployment and honest unknown."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import build_dynamic_body_comparison as comparison
import evaluate_situation as api
import paid_board_tactics as paid

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/dynamic-body-v01'


def main():
    rows=[]
    for cid in (534,632):
        scene=comparison.scene(cid,3,3)
        root=('hand_ids','gold_before_play','own_player_hp','enemy_player_hp',
            'enemy_bodies','opponent_gold_before_response')
        data={k:copy.deepcopy(scene[k]) for k in root}
        data.update(ally_bodies_before_play=[],role='midrange',own_turn=5,condition_state={},
            response_weights={'enemy_face':1},callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30))
        ignored=set(root)|{'own_player_max_hp','enemy_player_max_hp'}
        data['paid_board_scenario']={k:copy.deepcopy(v) for k,v in scene.items() if k not in ignored}
        result=api.evaluate(data);scene['hand_costs']=[5 if cid==534 else 4]
        assert result['paid_board_tactics']==paid.evaluate(scene)
        assert result['paid_board_tactics']['complete_in_declared_scope']
        ip=OUT/f'card-{cid}.input.json';op=OUT/f'card-{cid}.result.json'
        ip.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        p=subprocess.run([sys.executable,str(HERE/'evaluate_situation.py'),'--input',str(ip),
            '--output',str(op)],cwd=HERE,capture_output=True,text=True)
        assert p.returncode==0,(p.stdout,p.stderr)
        assert json.loads(op.read_text())==json.loads(json.dumps(result))
        rows.append(dict(card_id=cid,api_equals_paid=True,cli_equals_api=True,
            input_sha256=hashlib.sha256(ip.read_bytes()).hexdigest(),output_sha256=hashlib.sha256(op.read_bytes()).hexdigest()))
    (OUT/'api-verification.json').write_text(json.dumps(dict(cases=rows,
        api_version=api.VERSION,paid_version=paid.VERSION,
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
            ('build_dynamic_body_api.py','build_dynamic_body_comparison.py','evaluate_situation.py',
             'board_tactics.py','paid_board_tactics.py')},
        limits=['Declared hand/deck/incomes and actual current/future payment.',
            'CLI agreement checks integration, not server rules or real-match strength.']),indent=2)+'\n')
    print(json.dumps(rows))


if __name__=='__main__':main()