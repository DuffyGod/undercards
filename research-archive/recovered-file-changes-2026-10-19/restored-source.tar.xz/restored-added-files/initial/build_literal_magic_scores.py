"""Use the production scoring/paid/API hooks for literal Magic comparisons."""
import copy
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import conditional_card_score as score
import paid_board_tactics as paid
import evaluate_situation as api

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/literal-magic-v01'
SOURCE=HERE/'research-runs/literal-magic-v01'


def source_configs():
    index=json.loads((SOURCE/'index.json').read_text());groups={}
    for row in index['rows']:
        record=json.loads((SOURCE/row['artifact']).read_text());data=record['input']
        group=groups.setdefault(row['scene'],dict(data=copy.deepcopy(data),ids=[]))
        group['ids'].append(row['card_id'])
    for name,g in groups.items():
        scene=g['data'];ids=scene.pop('hand_ids');costs=scene.pop('hand_costs',None);bases=scene.pop('hand_base_costs',None)
        background=[]
        if len(ids)>1:
            assert len(g['ids'])==1 and ids[-1]==g['ids'][0]
            background=[dict(card_id=cid,current_cost=costs[i],base_cost=bases[i]) for i,cid in enumerate(ids[:-1])]
        tasks=dict(clear=dict(kind='joint',constraints=dict(max_enemy_living_count=0)),
            body1_1=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=1,min_own_body_health=1)),
            body2_2=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=2,min_own_body_health=2)))
        yield name,dict(scene=scene,candidate_ids=g['ids'],background_hand=background,tasks=tasks,include_delay=True)


def main():
    OUT.mkdir(exist_ok=True);bindings=score.source_bindings(Path(__file__));cases=[];records={};vectors=[]
    cards=None
    for name,cfg in source_configs():
        r=score.compare(cfg);records[name]=r
        for suffix,value in [('.input.json',cfg),('.json',r)]:
            (OUT/(name+suffix)).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
        cases.append(dict(case=name,artifact=name+'.json',candidate_count=len(r['rows']),
            known_hp=sum(c['scores']['hp']['known'] for c in r['rows']),selection=r['selection'],leaders=r['diagnostic_task_leaders']))
        for card in r['rows']:
            chosen=card['scores']['hp'];data=dict(card['input'],search_algorithm='exhaustive')
            x=score.task_score(data,r['tasks']['hp'],focal_index=len(cfg['background_hand']))
            assert chosen['known']==x['known']
            if chosen['known']:
                assert chosen['search']['objective_vector']==list(x['search']['objective_vector'])
            else:assert chosen['unknown']==x['unknown']
            vectors.append(dict(case=name,card_id=card['card_id'],known=chosen['known'],
                hp=chosen['guaranteed_player_hp'],full_vector_equal=chosen['known'],unknown=chosen.get('unknown',[])))
        print(json.dumps(dict(case=name,candidates=len(r['rows']),known=sum(c['scores']['hp']['known'] for c in r['rows']),
            hp=[(c['card_id'],c['scores']['hp']['guaranteed_player_hp']) for c in r['rows']])),flush=True)
    rows=[]
    for name,r in records.items():
        for card in r['rows']:
            for task,v in card['scores'].items():
                rows.append(dict(case=name,card_id=card['card_id'],name=card['name'],task=task,known=v['known'],
                    feasible=v['feasible'],joint_hp=v['guaranteed_player_hp'],unknown='; '.join(v.get('unknown',[]))))
    with (OUT/'scores.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    # Real public entry and actual CLI, preserving their older paid objective
    # semantics. Scalar guaranteed_hp is identical across all three routes.
    checks=[]
    for name in ('single-hp1-no-tem','two-hp1-endpoints','allergic-two-tem-armor-unknown'):
        card=records[name]['rows'][0]
        if name=='two-hp1-endpoints':card=next(c for c in records[name]['rows'] if c['card_id']==244)
        data=dict(card['input'],objectives=['guaranteed_hp'])
        observations={k:copy.deepcopy(data.get(k,[] if k.endswith('bodies') or k=='ally_bodies_before_play' else None))
            for k in ('hand_ids','gold_before_play','opponent_gold_before_response','own_player_hp','enemy_player_hp',
                'ally_bodies_before_play','enemy_bodies')}
        observations['opponent_gold_before_response']=data.get('opponent_gold_before_response',0)
        observations['ally_bodies_before_play']=data.get('ally_bodies_before_play',[])
        params={k:copy.deepcopy(v) for k,v in data.items() if k not in observations and k not in ('own_player_max_hp','enemy_player_max_hp')}
        # Candidate current costs are copied by the root API, so hand_costs is
        # an input observation and cannot override it through paid params.
        params.pop('hand_costs',None)
        public=dict(observations,role='midrange',own_turn=3,hand_costs=data.get('hand_costs'),
            callback_state=dict(own_player_max_hp=30,enemy_player_max_hp=30),paid_board_scenario=params)
        if public['hand_costs'] is None:public.pop('hand_costs')
        via_api=api.evaluate(public)['paid_board_tactics'];direct=paid.evaluate(data)
        assert via_api==direct
        inp=OUT/(name+'.paid-input.json');output=OUT/(name+'.paid-cli.json')
        inp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        done=subprocess.run([sys.executable,str(HERE/'paid_board_tactics.py'),'--input',str(inp),'--output',str(output)],
            cwd=HERE,capture_output=True,text=True,check=True)
        assert json.loads(output.read_text())==json.loads(json.dumps(direct))
        checks.append(dict(case=name,complete=direct['complete_in_declared_scope'],api_direct_complete_json_equal=True,
            cli_direct_complete_json_equal=True,unknown=direct['unknown']))
    assert bindings==score.source_bindings(Path(__file__))
    (OUT/'index.json').write_text(json.dumps(dict(version=score.VERSION,source_hashes=bindings,cases=cases,
        candidate_context_rows=sum(c['candidate_count'] for c in cases)),ensure_ascii=False,indent=2)+'\n')
    comparison=dict(version=score.VERSION,source_hashes=bindings,source_stable_during_run=True,
        production_core=True,cases=cases,full_vector_checks=vectors,
        artifact_hashes={name+'.json':hashlib.sha256((OUT/(name+'.json')).read_bytes()).hexdigest() for name in records},
        limits=['Known per-goal HP does not certify unavailable packet/target ordering interpretations.',
            'Modifiers, source instance type, actual hand payment and explicit geometry are retained.'])
    (OUT/'comparison.json').write_text(json.dumps(comparison,ensure_ascii=False,indent=2)+'\n')
    (OUT/'api-verification.json').write_text(json.dumps(dict(source_hashes=bindings,checks=checks,
        input_output_scope='Actual paid public API, direct engine and CLI; unknown preserved.'),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(cases=len(cases),candidate_context_rows=len(vectors),api_cli_checks=len(checks))))


if __name__=='__main__':main()