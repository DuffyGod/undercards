"""Small complete reply enumeration, with no imports from the game engine.

One observed enemy and one paid threat; no income/draw/second turn. This
enumerates face, combat, optional silence-kill and ordering independently.
The saved full engine's search, PV and objective are not read as premises.
"""
from dataclasses import dataclass, replace
from functools import lru_cache
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()


@dataclass(frozen=True)
class State:
    hero: int
    own_attack: int
    own_hp: int
    dust: bool
    enemy_attack: int
    enemy_hp: int
    armor: bool
    dodge: int
    ready: bool
    headshot: bool


def packet(s, damage):
    if s.enemy_hp <= 0: return s
    if s.dodge: return replace(s, dodge=s.dodge-1)
    return replace(s, enemy_hp=max(0, s.enemy_hp-max(0, damage-int(s.armor))))


@lru_cache(None)
def endpoints(s):
    if s.hero <= 0: return (s,)
    out = {s}  # enemy may finish its turn without using cards or attacking
    if s.enemy_hp > 0 and s.ready:
        out.update(endpoints(replace(s, hero=max(0, s.hero-s.enemy_attack), ready=False)))
        if s.own_hp > 0:
            child = packet(replace(s, own_hp=max(0, s.own_hp-s.enemy_attack), ready=False), s.own_attack)
            if child.own_hp == 0 and s.dust:
                child = packet(replace(child, dust=False), s.own_attack)
            out.update(endpoints(child))
    if s.headshot:
        if s.own_hp > 0:
            out.update(endpoints(replace(s, own_hp=0, dust=False, headshot=False)))
        if s.enemy_hp > 0:
            out.update(endpoints(replace(s, enemy_hp=0, armor=False, dodge=0, headshot=False)))
    return tuple(out)


def solve(raw, card):
    scene = raw['input']; enemy = scene['enemy_bodies'][0]; cid = card['id']
    assert cid in (110,270,443,8)
    headshot = bool(scene['opponent_hand_ids']) and scene['opponent_gold_before_response'] >= 6
    if scene['opponent_hand_ids']: assert scene['opponent_hand_ids']==[100]
    held = State(scene['own_player_hp'],0,0,False,enemy['attack'],enemy['health'],
        enemy.get('armor',False),enemy.get('dodge',0),True,headshot)
    deployed = replace(held,own_attack=card['attack'],own_hp=card['health'],
        dust=cid==110 and not scene.get('hand_silenced',[False])[0])
    actions = [held]
    if cid==443:
        assert enemy['current_card_cost']==enemy['base_cost']==3
        deployed=packet(deployed,5)
        actions.append(deployed)  # retain unused fresh Haste
        if deployed.enemy_hp>0:
            traded=packet(replace(deployed,own_hp=max(0,deployed.own_hp-enemy['attack'])),4)
            actions.append(traded)
    elif cid==8:
        deployed=replace(deployed,enemy_attack=1,own_hp=card['health']+max(0,enemy['attack']-1))
        actions.append(deployed)
    else:
        actions.append(deployed)
    def goal(state, name):
        alive=state.hero>0
        clear=state.enemy_hp<=0
        body=state.own_hp>=1 and state.own_attack>=4
        return alive and {'clear':clear,'focal4_1':body,'clear_or_focal4_1':clear or body}[name]
    result={}
    for name in ('hp','clear','focal4_1','clear_or_focal4_1'):
        if name=='hp':
            hp=max(min(s.hero for s in endpoints(a)) for a in actions)
            result[name]=dict(hp=hp,feasible=hp>0)
        else:
            success,hp=max(min((int(goal(s,name)),s.hero) for s in endpoints(a)) for a in actions)
            result[name]=dict(hp=hp if success else None,feasible=bool(success))
    return result


def main():
    source={c['id']:c for c in json.loads((HERE/'native-snapshot.json').read_text())['cards']}
    assert (source[110]['attack'],source[110]['health'],source[110]['effect_readable']) == \
        (13,1,'Dust: Deal its ATK as DMG to all enemy monsters.')
    assert source[270]['effect_readable']==''
    assert source[100]['cost']==6 and source[100]['effect_readable']=='Silence and kill a monster.'
    assert source[443]['effect_readable']=='Haste. Magic: Deal 4 DMG to a monster. Deal 1 extra DMG for every 3 GOLD it costs.'
    assert source[8]['effect_readable']=="Magic: Set an enemy monster's ATK to 1 and gain HP equal to the amount of ATK decreased."
    index=json.loads((HERE/'index.json').read_text());checks=[]
    for row in index['rows']:
        if row['context'].startswith('card') and row['card_id'] not in (110,270,443,8): continue
        path=HERE/row['artifact'];raw=json.loads(path.read_text());expected=solve(raw,source[row['card_id']])
        for name,bound in expected.items():
            actual=row['scores'][name]
            assert actual['known'] and actual['guaranteed_player_hp']==bound['hp'] and actual['feasible']==bound['feasible'], (row['context'],name,bound,actual)
            checks.append(dict(context=row['context'],task=name,**bound,raw_sha256=sha(path)))
    report=dict(passed=True,imports_production_model=False,matching_cells=len(checks),checks=checks,
        reply_states=endpoints.cache_info().currsize,builder_sha256=sha(Path(__file__)),
        source_snapshot_sha256=sha(HERE/'native-snapshot.json'),
        packet_thresholds=dict(unprotected=13+13,armor=12+12,one_dodge=0+13),
        scope='Exact one-enemy simplified independent reply enumeration for NEO, Thrashing, Toriel and Chain and eleven controlled counterfactuals. Not independent validation of all78 compiled candidates.')
    (HERE/'independent-bounds.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(passed=True,cells=len(checks),states=endpoints.cache_info().currsize)))


if __name__=='__main__': main()