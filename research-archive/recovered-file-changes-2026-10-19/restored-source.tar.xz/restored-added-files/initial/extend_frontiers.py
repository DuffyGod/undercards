"""Add actual win queries and conditional menu frontiers to the paid probes.

Existing four-task searches are reused only under their exact source binding.
The inventory's unsupported cards remain explicit unknown candidates.
"""
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import conditional_card_score as score
import score_cards


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def compact(value):
    return {key:value.get(key) for key in ('known','feasible','guaranteed_player_hp','unknown')}


def menu_cell(value):
    return (bool(value['feasible']),value['guaranteed_player_hp'] if value['feasible'] else -1)


def main():
    original=json.loads((HERE/'index.json').read_text())
    bindings=score.source_bindings()
    assert original['source_bindings']==bindings and original['source_stable_during_run']
    assert original['builder_sha256']==sha(HERE/'run_frontier.py')
    inventory=json.loads((HERE/'inventory.json').read_text())
    cards=score_cards.load_cards();by={c['id']:c for c in cards}
    win=copy.deepcopy(score.RESERVED['win']);rows=[];vectors=[]
    for item in original['rows']:
        path=HERE/item['artifact'];record=json.loads(path.read_text())
        assert not item.get('input_or_adapter_failure')
        data=record['input'];value=score.task_score(data,win,cards=cards,focal_index=0)
        assert 'search' in value
        record['tasks']['win']=win;record['results']['win']=value
        record['additional_win_query_source_hashes']=bindings
        path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
        row=dict(card_id=item['card_id'],name=item['name'],printed_cost=item['printed_cost'],
            budget=item['budget'],bucket=item['bucket'],artifact=item['artifact'],
            scores={t:compact(v) for t,v in record['results'].items()},
            compiler_supported=True,input_or_adapter_failure=False)
        rows.append(row)
        # One representative per nonempty 3..8 and10G bucket, five complete
        # vectors each, without raising a search budget for agreement.
        if item['bucket']=='native' and item['card_id'] in (22,11,534,302,21,8,110):
            for name,task in record['tasks'].items():
                a=record['results'][name]
                x=score.task_score(dict(data,search_algorithm='exhaustive'),task,cards=cards,focal_index=0)
                assert a['known']==x['known']
                equal=tuple(a['search']['objective_vector'])==tuple(x['search']['objective_vector']) if a['known'] else None
                assert equal is True if a['known'] else a['unknown']==x['unknown']
                vectors.append(dict(card_id=item['card_id'],budget=item['budget'],task=name,
                    known=a['known'],complete_vector_equal=equal,matching_unknown=None if a['known'] else True))
    tasks={**original['tasks'],'win':win}
    unknown=dict(known=False,feasible=None,guaranteed_player_hp=None,unknown=['Complete source is not implemented'])
    groups=[]
    for budget in range(3,11):
        native=[copy.deepcopy(row) for row in rows if row['bucket']=='native' and row['budget']==budget]
        for item in inventory['rows']:
            if item['cost']==budget and not item['physical_compile_supported']:
                native.append(dict(card_id=item['card_id'],name=item['name'],printed_cost=budget,budget=budget,bucket='native',
                    compiler_supported=False,artifact=None,scores={name:copy.deepcopy(unknown) for name in tasks}))
        supported=[r for r in native if all(c['known'] for c in r['scores'].values())]
        # Dominance of the separate task menus does not combine their optimal
        # policies into one multi-purpose policy, nor value unspent cash.
        frontier=[];dominators={}
        for row in supported:
            dominates=[]
            for other in supported:
                if other['card_id']==row['card_id']:continue
                comparisons=[(menu_cell(other['scores'][t]),menu_cell(row['scores'][t])) for t in tasks]
                if all(a>=b for a,b in comparisons) and any(a>b for a,b in comparisons):dominates.append(other['card_id'])
            dominators[str(row['card_id'])]=dominates
            if not dominates:frontier.append(row['card_id'])
        rankings={task:score.ranking(native,task) for task in tasks}
        groups.append(dict(label='native',budget=budget,native_candidates=len(native),rows=native,
            known_all_tasks=len(supported),menu_frontier_ids=frontier,menu_dominators=dominators,selections_by_task=rankings,
            menu_frontier_is_single_shared_policy=False))
    for budget in (9,10):
        alternatives=[r for r in rows if r['bucket']=='shared-budget' and r['budget']==budget]
        groups.append(dict(label='shared-budget',budget=budget,native_candidates=None,rows=alternatives,
            selections_by_task={task:score.ranking(alternatives,task) for task in tasks},
            native_bucket_champion=False))
    assert bindings==score.source_bindings()
    result=dict(version='same-budget-task-menu-frontiers-0.1.0',source_hashes=bindings,
        builder_sha256=sha(Path(__file__)),input_builder_sha256=original['builder_sha256'],
        source_snapshot_sha256=sha(HERE/'source-snapshot.json'),tasks=tasks,groups=groups,
        additional_actual_win_queries=len(rows),representative_complete_vector_checks=vectors,
        source_stable_during_run=True,
        artifact_sha256={r['artifact']:sha(HERE/r['artifact']) for r in rows},
        limits=['Diagnostic declared one-candidate hand and fixed pressure window; no observed scene probabilities.',
            'Each menu component uses its own policy; dominance does not assert one policy achieves them all.',
            'Unimplemented native cards and reachable unknown mechanisms block whole-bucket certification.',
            'Empty declared libraries without fatigue observations leave reachable draw sources unknown.',
            'Shared-budget alternatives are lower native costs, not native9G champions.'])
    (HERE/'frontiers.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(win_queries=len(rows),vector_checks=len(vectors),groups=len(groups),
        known_native=sum(g.get('known_all_tasks',0) for g in groups))))


if __name__=='__main__':main()