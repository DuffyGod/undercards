# 回合末治疗、真实摆位与卡手机会成本

2026-10-15。模型：paid0.22 / board0.5 / API0.24 / conditional score0.2。直接打开[交互比较](score-explorer.html)、[CSV](scores.csv)；23个声明输入、215个候选与条件组合，其中保留2个未闭合的观察诊断输入。另有[可观察场景的构筑切换门槛](context-switches.json)及2个完整输入窗口，不混入主表计数。

## 同费用的用途差异与时机

共同场景：己15/30HP、现金3G；敌Aaron观察1攻5血、敌玩家3或30HP、实际持有0至2张Gemstone并能付款；无抽牌，窗口到第二敌回应。候选真实付3G，双方可以停止或按任意顺序行动。这里的HP是相同策略内的最坏保证。

| 敌持Gem数 | Water保命HP | Water保证获胜时HP（敌3HP） | Shyren保命HP | Candy保命HP |
|---:|---:|---:|---:|---:|
| 0 | 17 | 16 | 17 | 13 |
| 1 | 16 | 15 | 16 | 12 |
| 2 | 15 | 无法保证 | 15 | 11 |

0Gem时Water比Ice Cap的获胜HP15更高，成为本候选集获胜优先选择；2Gem时改选Ice Cap，不能把Water的15保命HP冒充获胜保证。原生Water3攻3血、回合末治2；它只在活着的拥有者回合末触发，获胜后不会再补第二次治疗。

敌30HP、1Gem时，Water连自身≥2攻2血也无法保证。对手可以保留Gem，在最后敌回合用Aaron1+Gem1把它打至1HP，此后没有己方回合末治疗。Shyren原生2/4，允许真实晚出后能保2/2，联合玩家HP16；禁止晚出则不能保证。敌30HP、2Gem时，Water当前可出保15，禁止现在但允许晚出保13，当前部署权价值2；Shy与Candy相同干预分别保持15与11。

`allies`含玩家是明确公开的源文解释。主表另给`allies_include_player=false`和`unknown`的反事实：不含玩家时Water保命11，Shy15；不能确定范围且会改变HP时返回未知。治疗需要每个被治疗活体的实际最大HP，死者不复活。Water治满Carbed会撤销受伤加攻5→2，增加体血不保证后续反杀更好。

独立[标准库枚举](../../research-runs/periodic-heal-v01/review.md)的114个输入/用途/时机/范围干预均与主程序匹配，最初关于Water获胜、稳定留体的错误预测保存在其`hypotheses.json`。

## 摆位改变排名

同3G、己15HP、敌两只原生4攻4血Thrashing Machine、敌无手牌，到首个敌回应结束；明确四个固定物理格、正前方映射和空正前方fizzle解释。背景体已在场，费用不重复算给候选。

| 背景 | Glad Dummy | Janitor | Fuku Fire | Water Cooler |
|---|---:|---:|---:|---:|
| Dummy0攻4血/Taunt | 11 | 15 | 11 | 13 |
| Tiny1攻1血/无Taunt | 11 | 7 | 7 | 9 |

Janitor放在Dummy右侧，将它增至5血，两次4伤都被Taunt挡住；改成Tiny时，Glad赋予Taunt反而更有用。把Dummy放到最右格，Janitor不能再位于其右侧加HP，保证15→11。Fuku面对4攻3血敌时可击杀，保11；目标改4血则保7。同4G真实手持Dummy/Tiny并实际支付组合的反转也由独立实现核验，未用免费背景代替手牌配合。

格子不会因死亡或空隙压缩；双方部署枚举真正空格。自动空间效果遵照非选择目标的卡文处理Transparency，源解释公开。Summon/Dust产生的新体缺少落点规则时保留未知。详见[独立27值与54次完整向量比较](../../research-runs/spatial-magic-v01/README.md)。

## 卡手损失来自错失下一张牌

六张真实高费背景牌均在当前0G与下回合3G内无法支付；己玩家10HP，敌单体4/4，无敌手，下一自然牌明确是Shyren，窗口到第二敌回应。允许所有物理出牌，不强迫坏出场。

| 第7个槽位 | 最坏玩家HP | 相对移除该副本 | 真实下一抽 | 下回合实际支付 |
|---|---:|---:|---|---:|
| Toriel8G | 2 | −4 | 手牌满7，Shyren烧毁 | 0 |
| Tiny0G | 6 | 0 | 当前打出腾格，保留Shyren | 3 |
| 移除基线 | 6 | — | 保留Shyren | 3 |

少一张背景牌、初始只有6手时，Toriel也保6，损失消失；下一抽换成不能有效保护玩家的Tiny时，Toriel的移除差也变0。没有给高费牌或持有一张牌固定罚4HP。这是当前窗口的实际容量机会成本，不是完整构筑卡手成本。独立[上下界程序](../../research-runs/periodic-spatial-v01/hand_capacity_bounds.py)无核心导入：敌两轮各打脸4提供上界，合法保留/支付Shy治疗4提供同值下界。

## 携带条件可以给门槛，但不能猜频率

另两个共同8G、己15HP、敌30HP、敌Punishment真实可付的窗口，只将敌Aaron由6攻8血改成2攻2血（最大血8，明确改动/受伤观察），另有Tiny1/1。Toriel/Plane在高血威胁窗口保12/3；低血窗口保12/15。两张牌在各自窗口的保证获胜可行性相同，才比较条件HP。若高血窗口频率是p，则Toriel相对差为`9p−3(1−p)`，p>1/4才占优。

Toriel对Tiny，在上述高血控制窗口差+11，在满手错失治疗窗口差−4，形式门槛为p>4/15。这回答的是声明条件组合中的HP用途，不是整卡Gold、真实胜率或全局携带率；p没有被估计。构筑选择跨窗口固定，打法只在窗口真正被观察后适应；隐藏状态不能先知。真实放入卡组还会改变窗口频率，此处把窗口当外生的假设必须保留。

最初尝试用敌3HP的Plane即时击杀作混合窗口，被完整效果顺序守卫拒绝：先脸伤结束游戏与先打体后脸伤的最终敌场不同。程序没有把这个未闭合窗口的值填进门槛；原失败日志保留。2个最终窗口的12个目标完整向量另与穷举一致。

## 覆盖、失败与复算

普通3G原106张没有按支持情况删卡。相同旧无位置输入现在15完整/91未知；有明确位置与空前方解释时18/88。Scarf另在原生目标与完整COST观察下可用：移除Jerry Taunt使已站Ice Cap当前获胜、保15，其他候选无法保证获胜；面对受伤Carbed，可保证压敌攻≤2。敌Trashy当前观察攻击必须按实际拥有者时钟解释，不能把其临时有效值当永久base。

两条早期诊断保留未知：Jerry误记7HP并缺Ice当前/基价费用；敌Trashy观察2攻被误当原生，实际上根为它的敌方回合，原生有效值应4。后续独立原生观察案例补齐事实，不削弱modified-stat/COST守卫、不按卡名硬编码分数。首轮Silence测试还把Candy最大血误写4，源证实原生6后修正；失败保留。

464项统一测试实际通过，269.2s，源码运行期间未变；不是只读旧日志。新评分验证见[verification.json](verification.json)：114治疗独立值、19治疗完整向量、27空间独立值/54次算法查询、6容量上下界和3实际CLI完整JSON。旧48报告另按依赖真实刷新，旧源/82报告保存在本轮before目录；这部分是来源维护，不当作新的实战标注。

在仓库根目录运行：

```sh
python analysis/monster-value-heuristic/build_periodic_spatial_scores.py
python analysis/monster-value-heuristic/build_silence_observation_probes.py
python analysis/monster-value-heuristic/context_switch_thresholds.py
python analysis/monster-value-heuristic/build_conditional_score_view.py --directory analysis/monster-value-heuristic/experiments/periodic-spatial-v01 --default-case hand-6-draw-clog
python analysis/monster-value-heuristic/verify_periodic_spatial_scores.py
```

直接评分仍使用`conditional_card_score.py --input …input.json --output …json`。空间输入增加`physical_slots=true`、各体`slot`、完整`front_slot_map`，空正前方规则显式声明。卡文规则解释、未知机制、真实场景分布、完整隐藏信息和整个建模Goal仍未完成；以上数值只在相应窗口/目的内使用。