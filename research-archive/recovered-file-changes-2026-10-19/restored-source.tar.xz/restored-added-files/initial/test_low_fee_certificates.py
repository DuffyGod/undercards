import copy
import unittest
import certify_low_fee_rescue as certificate
import score_cards


class LowFeeCertificateTests(unittest.TestCase):
    def test_full_bucket_optimum_keeps_unknown_possible_tie(self):
        result=certificate.certify()
        one=result['buckets'][1]
        self.assertEqual(len(one['all_candidate_ids']),28)
        self.assertEqual(one['optimal_guaranteed_hp_bounds'],[3,3])
        self.assertEqual(one['known_optimal_card_ids'],[1,990])
        self.assertEqual(one['unresolved_possible_ties_or_winners'],[226])
        self.assertEqual(result['certified_minimum_monster_payment_for_survival'],1)

    def test_paid_damage_changes_complete_pool_recommendation(self):
        result=certificate.certify('one_attack_paid_damage')
        one=result['buckets'][1]
        self.assertEqual(one['known_optimal_card_ids'],[990])
        self.assertEqual(one['optimal_guaranteed_hp_bounds'],[3,3])
        self.assertFalse(one['unresolved_possible_ties_or_winners'])

    def test_second_attacker_changes_guarantee_and_removes_microwave_tie(self):
        result=certificate.certify('two_attacks')
        one=result['buckets'][1]
        self.assertEqual(one['optimal_guaranteed_hp_bounds'],[1,1])
        self.assertEqual(one['known_optimal_card_ids'],[1,990])
        micro=next(r for r in result['cards'] if r['card_id']==226)
        self.assertEqual(micro['guaranteed_endpoint_hp_bounds'],[0,0])

    def test_unknown_silence_rule_prevents_life_certificate(self):
        result=certificate.certify('one_attack_paid_silence')
        one=result['buckets'][1]
        self.assertEqual(one['optimal_guaranteed_hp_bounds'],[0,3])
        self.assertFalse(one['optimum_certified'])
        self.assertFalse(one['known_optimal_card_ids'])

    def test_missing_cost_history_does_not_force_noelle_unpayable(self):
        with self.assertRaises(ValueError):certificate.certify(two_plus_spells_cast=0)

    def test_numeric_source_change_invalidates_previously_reviewed_lemma(self):
        cards=copy.deepcopy(score_cards.load_cards())
        next(c for c in cards if c['id']==115)['attack']=5
        with self.assertRaises(ValueError):certificate.certify(cards=cards)

    def test_referenced_product_change_also_invalidates_proof(self):
        cards=copy.deepcopy(score_cards.load_cards())
        next(c for c in cards if c['id']==553)['effect_readable']='Taunt.'
        with self.assertRaises(ValueError):certificate.certify(cards=cards)


if __name__=='__main__':unittest.main()