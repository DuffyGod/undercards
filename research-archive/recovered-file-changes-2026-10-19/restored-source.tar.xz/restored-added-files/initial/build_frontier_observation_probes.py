"""Close fatigue observations, then test one-parameter 8G body/control flips."""
import copy
import hashlib
import json
from pathlib import Path

import conditional_card_score as score
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/frontier-observations-v01'
PRIOR=HERE/'research-runs/pool-frontier-v01'
TASKS=dict(clear=dict(kind='joint',constraints=dict(max_enemy_living_count=0)),
    body_2_2=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=2,min_own_body_health=2)),
    clear_and_body_2_2=dict(kind='joint',body_scope='focal',constraints=dict(min_own_body_attack=2,min_own_body_health=2,max_enemy_living_count=0)))


def main():
    OUT.mkdir(exist_ok=True);bindings=score.source_bindings(Path(__file__));cases=[];cross=[]
    fixtures=[('fatigue1-5g',5,[199,243,509,534],4),
        ('fatigue1-8g-enemy4',8,[44,8,556],4),('fatigue1-8g-enemy8',8,[44,8,556],8)]
    for name,cost,ids,attack in fixtures:
        reference=243 if cost==5 else 44
        raw=json.loads((PRIOR/f'native-cash{cost}-card{reference}.json').read_text())
        data=copy.deepcopy(raw['input'])
        for field in ('hand_ids','hand_costs','hand_base_costs'):data.pop(field,None)
        data.update(own_fatigue_next=1,opponent_fatigue_next=1,max_plays='all_physical')
        data['enemy_bodies'][0]['attack']=attack
        cfg=dict(scene=data,candidate_ids=ids,tasks=TASKS,include_delay=False)
        result=score.compare(cfg)
        assert all(c['scores']['hp']['known'] for c in result['rows'])
        for suffix,obj in [('.input.json',cfg),('.json',result)]:
            (OUT/(name+suffix)).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
        for row in result['rows']:
            # The joint query directly tests simultaneous control and the
            # physical candidate body, rather than joining two purpose optima.
            task='clear_and_body_2_2';a=row['scores'][task]
            ex=score.task_score(dict(row['input'],search_algorithm='exhaustive'),TASKS[task],focal_index=0)
            assert a['known'] and ex['known']
            assert tuple(a['search']['objective_vector'])==tuple(ex['search']['objective_vector'])
            cross.append(dict(case=name,card_id=row['card_id'],task=task,full_vector_equal=True))
        cases.append(dict(case=name,artifact=name+'.json',candidate_count=len(ids),known_hp=len(ids),
            selection=result['selection'],leaders=result['diagnostic_task_leaders']))
        print(json.dumps(dict(case=name,hp=[(c['card_id'],c['scores']['hp']['guaranteed_player_hp']) for c in result['rows']],
            joint=[(c['card_id'],c['scores']['clear_and_body_2_2']['guaranteed_player_hp']) for c in result['rows']])),flush=True)
    assert bindings==score.source_bindings(Path(__file__))
    index=dict(version=score.VERSION,source_hashes=bindings,source_stable_during_run=True,cases=cases,
        candidate_context_rows=sum(c['candidate_count'] for c in cases),full_vector_checks=cross,
        artifact_hashes={c['artifact']:hashlib.sha256((OUT/c['artifact']).read_bytes()).hexdigest() for c in cases},
        fatigue_observation='Both empty libraries and known next fatigue1 are declared state, not a guessed default',
        comparison_scope='Only within each identical observation; scene frequencies and complete carry prices unestimated')
    (OUT/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()