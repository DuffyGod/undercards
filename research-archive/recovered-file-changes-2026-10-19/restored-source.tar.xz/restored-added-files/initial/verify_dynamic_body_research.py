"""Compare core direct events with a separately written literal arithmetic model."""
from dataclasses import replace
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import board_tactics as b
import paid_board_tactics as p
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/dynamic-body-v01'
PROBE=HERE/'research-runs/damage-packet-v01/check_dynamic_body.py'


def main():
    spec=importlib.util.spec_from_file_location('independent_dynamic_arithmetic',PROBE)
    independent=importlib.util.module_from_spec(spec);sys.modules[spec.name]=independent
    spec.loader.exec_module(independent)
    isolated=independent.run();assert isolated['passed']==19
    cards=score_cards.load_cards();rows=[]
    def check(name,actual,expected):
        assert actual==expected,(name,actual,expected)
        rows.append(dict(case=name,core=actual,independent=expected,equal=True))
    def engine(cid,attack,health,maximum,enemy_attack=0,enemy_health=1):
        e=p.PaidSearch(cards,dict(hand_ids=[],gold_before_play=0,
            ally_bodies_before_play=[dict(card_id=cid,attack=attack,health=health,max_health=maximum,ready=True)],
            enemy_bodies=[dict(attack=enemy_attack,health=enemy_health,max_health=enemy_health)],
            opponent_hand_ids=[],opponent_hand_known=True,own_player_hp=15,enemy_player_hp=30))
        return e,e.root()
    def hit(e,s,target):return next(c for a,c in e.attacks(s) if a['target']==target)
    car=independent.Body(2,5,5,armor=True,damaged_bonus=3)
    trash=independent.Body(2,5,5,opposing_turn_bonus=2,attacking_immunity=True)
    for damage,hp in ((1,2),(2,2),(3,2),(3,3)):
        e,s=engine(534,2,5,5,damage,hp);c=hit(e,s,'enemy:0')
        a,v=independent.combat(car,independent.Body(damage,hp,hp))
        check(f'carbed-vs-{damage}/{hp}',(c.own[0].health,c.enemy[0].health,b.effective_attack(c.own[0],c,'own')),
            (a.hp,v.hp,independent.atk(a,True)))
    e,s=engine(534,5,4,5,3,5);c=hit(e,s,'enemy:0')
    a,v=independent.combat(replace(car,hp=4),independent.Body(3,5,5))
    check('damaged-before',(c.own[0].health,c.enemy[0].health),(a.hp,v.hp))
    e,s=engine(534,2,5,5)
    a=e.hurt_unit(s.own[0],2,source=None,source_is_enemy=True);v=independent.packet(car,2)
    check('spell-activates',(a.health,b.effective_attack(a,s,'own')),(v.hp,independent.atk(v,True)))
    healed,_=e.fully_heal_unit(a)
    check('full-heal-removes-bonus',b.effective_attack(healed,s,'own'),independent.atk(replace(v,hp=5),True))
    check('hp-growth-preserves-injury',b.effective_attack(replace(a,health=6,max_health=7),s,'own'),
        independent.atk(replace(v,hp=6,maximum=7),True))
    buffed=replace(a,attack=4);restored,_=e.fully_heal_unit(buffed)
    check('permanent-buff-and-heal',(b.effective_attack(buffed,s,'own'),b.effective_attack(restored,s,'own')),
        (independent.atk(replace(v,attack_base=4),True),independent.atk(replace(v,attack_base=4,hp=5),True)))
    for damage in (5,6,20):
        e,s=engine(632,2,5,5,damage,2);c=hit(e,s,'enemy:0')
        a,v=independent.combat(trash,independent.Body(damage,2,2))
        check(f'trashy-attacking-{damage}',(c.own[0].health,c.enemy[0].health),(a.hp,v.hp))
    e,s=engine(632,2,5,5,3,5);c=hit(e,e.boundary(s),'own:0')
    a,v=independent.combat(independent.Body(3,5,5),trash)
    check('trashy-defending',(c.enemy[0].health,c.own[0].health),(a.hp,v.hp))
    check('trashy-turn-owner',(b.effective_attack(s.own[0],s,'own'),b.effective_attack(c.own[0],c,'own')),
        (independent.atk(trash,True),independent.atk(trash,False)))
    check('spell-outside-attacks',e.hurt_unit(s.own[0],5,source=None,source_is_enemy=True).health,
        independent.packet(trash,5).hp)
    report=json.loads((OUT/'comparison.json').read_text())
    for main,local in zip(report['fixed_prefixes'][:4],isolated['same_cost_comparison']):
        check(f"same4G-ready-{local['card_id']}",(main['own_hp'],main['enemy_hp'],30-main['enemy_player_hp']),
            (local['own_hp_after_attack'],local['enemy_hp_after_attack'],local['face_damage_before_attack']))
    assert len(rows)==19
    source_names=('verify_dynamic_body_research.py','board_tactics.py','paid_board_tactics.py',
        'research-runs/damage-packet-v01/check_dynamic_body.py')
    out=dict(cases=rows,independent_original_checks=isolated['passed'],
        source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in source_names},
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        comparison_sha256=hashlib.sha256((OUT/'comparison.json').read_bytes()).hexdigest(),
        limitations=['Independent arithmetic module does not import game, damage, phase or search primitives.',
            'The two implementations share explicit before-exchange sampling and retaliation-immunity interpretations, not a server trace.',
            'These19 compare local physical events and selected actual prefixes, not full strategy vectors or real matchup frequency.'])
    (OUT/'independent-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(matches=len(rows),independent_checks=isolated['passed'])))


if __name__=='__main__':main()