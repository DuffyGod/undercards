"""A useful threat floor and the actual affordable punishment are separate axes."""
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import alternative_goal_score as alt
import conditional_card_score as score


def main():
    bindings=score.source_bindings(ROOT/'alternative_goal_score.py');rows=[]
    for cid in (20,110,292,534,443,8):
        raw=json.loads((HERE/f'card{cid}.json').read_text())
        for reply,n in [('none',0),('gem1',1),('gem3',3),('gem4',4),('headshot6',1)]:
            data=copy.deepcopy(raw['input'])
            data.update(opponent_hand_ids=([100] if reply=='headshot6' else [598]*n),
                opponent_hand_costs=([6] if reply=='headshot6' else [1]*n),
                opponent_hand_base_costs=([6] if reply=='headshot6' else [1]*n),
                opponent_gold_before_response=6 if reply=='headshot6' else n)
            results={};tasks={}
            for attack,hp in ((4,1),(4,2),(8,1)):
                name=f'body{attack}_{hp}'
                task=dict(kind='any',clauses=[dict(constraints=dict(max_enemy_living_count=0)),
                    dict(body_scope='focal',constraints=dict(min_own_body_attack=attack,min_own_body_health=hp))])
                tasks[name]=task;results[name]=alt.evaluate(data,task,focal_index=0)
                row=dict(card_id=cid,name=raw['card']['name'],reply=reply,body_attack=attack,body_health=hp,
                    known=results[name]['known'],feasible=results[name]['feasible'],hp=results[name]['guaranteed_player_hp'],
                    unknown=results[name]['unknown'],artifact=f'frontier-card{cid}-{reply}.json',task=name)
                rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
            (HERE/f'frontier-card{cid}-{reply}.json').write_text(json.dumps(dict(input=data,tasks=tasks,results=results),ensure_ascii=False,indent=2)+'\n')
    assert bindings==score.source_bindings(ROOT/'alternative_goal_score.py')
    (HERE/'resistance-frontier.json').write_text(json.dumps(dict(source_hashes=bindings,source_stable=True,
        builder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),actual_task_queries=len(rows),rows=rows,
        assumptions=['Same10G cash, single4/5 enemy, one reply; no probabilities assigned to reply menus.',
            'Threat floors are different requested purposes, not universal prices or a count to sum.']),ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()