import copy
import unittest

import combat_increment as combat
import finite_timing_window as window
import score_cards as base


class AbsoluteTimingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cards = base.load_cards()
        cls.cards = {c['id']: c for c in cards}
        cls.reference, _ = base.make_reference(cards)
        cls.scale = .7624636451121338

    def scene(self, **changes):
        s = dict(own_turn=4, horizon_tick=11, gold_before_play=12,
                 enemy_bodies=[], responses={'none': 1}, own_player_hp=30,
                 enemy_player_hp=60, initial_hand_size=1)
        s.update(changes)
        return s

    def evaluate(self, card=15, **changes):
        c = self.cards[card] if isinstance(card, int) else card
        return window.evaluate(c, self.reference, self.scale, self.scene(**changes), include_policy=True)

    def test_late_ordinary_body_has_no_attack_past_the_endpoint(self):
        r = self.evaluate(own_turn=6, horizon_tick=11, force_root_deployment=True)
        p = base.role_parameters('midrange')
        body = base.body_value(6, 5, self.reference, p)
        self.assertAlmostEqual(r['absolute_endpoint_option_model_gold'], self.scale * body - 5)
        self.assertEqual(r['actual']['selected_policy_components']['enemy_player_hp'], 0)
        early = self.evaluate(force_root_deployment=True)
        self.assertAlmostEqual(early['absolute_endpoint_option_model_gold'] - r['absolute_endpoint_option_model_gold'], self.scale * .25 * 12)

    def test_late_haste_cannot_face_attack_on_empty_deployment_board(self):
        r = self.evaluate(115, own_turn=6, horizon_tick=11, force_root_deployment=True)
        self.assertEqual(r['actual']['selected_policy_components']['enemy_player_hp'], 0)
        self.assertEqual(r['actual']['root_action_id'], 'deploy:delay')

    def test_growth_is_applied_before_later_attacks_and_only_one_final_body(self):
        r = self.evaluate(307, force_root_deployment=True)
        # Tick7 deployment 4 ATK; ticks9,11 attack at 5,6 ATK.
        p = base.role_parameters('midrange')
        expected = self.scale * (base.body_value(6, 5, self.reference, p) + .25 * 11) - 4
        self.assertAlmostEqual(r['absolute_endpoint_option_model_gold'], expected)
        self.assertAlmostEqual(r['actual']['selected_policy_components']['enemy_player_hp'], self.scale * .25 * 11)

    def test_same_absolute_endpoint_counts_first_and_second_player_differently(self):
        first = self.evaluate(307, own_turn=2, horizon_tick=9, force_root_deployment=True)
        second = self.evaluate(307, own_turn=2, horizon_tick=9, second_player=True, force_root_deployment=True)
        self.assertGreater(first['absolute_endpoint_option_model_gold'], second['absolute_endpoint_option_model_gold'])
        self.assertAlmostEqual(first['actual']['selected_policy_components']['enemy_player_hp'], self.scale * .25 * 18)
        self.assertAlmostEqual(second['actual']['selected_policy_components']['enemy_player_hp'], self.scale * .25 * 11)

    def test_death_does_not_erase_previously_realized_growth_damage(self):
        v = window.Window(self.cards[307], self.reference, self.scale,
            self.scene(own_turn=2, horizon_tick=9, enemy_bodies=[{'attack':7, 'health':100}],
                responses={'none':1}, responses_by_tick={'8':{'enemy_contact':1}}))
        s = v.deploy_options(v.root())[0]['child_state']
        while s['phase'] != 'leaf':
            d = v.expand(s)
            choices = d['branches']
            if d['kind'] == 'max':
                s = next(b['child_state'] for b in choices if b['action_id'] == 'attack:face')
            else:
                s = choices[0]['child_state']
        self.assertLessEqual(s['actor']['health'], 0)
        self.assertEqual(s['growth_count'], 2)
        self.assertEqual(s['enemy_hp_delta'], -11)  # 5+6 retained after tick8 death
        self.assertEqual(window._parts(s, self.reference, 'midrange', self.scale)['remaining_actor_body'], 0)

    def test_callback_cash_and_actual_payment_are_each_applied_once(self):
        r = self.evaluate(404, force_root_deployment=True)
        # Three turn ends earn3; source paid3; absent keeps original cash.
        cash = r['actual']['selected_policy_components']['retained_own_cash'] - r['absent']['selected_policy_components']['retained_own_cash']
        self.assertEqual(cash, 0)

    def test_no_attack_heal_can_be_a_better_later_action(self):
        r = self.evaluate(509, role='aggro', own_player_hp=10, own_player_max_hp=30, horizon_tick=9, force_root_deployment=True)
        later = [p for p in r['actual']['policy'] if p['kind']=='max' and p['tick']==9]
        self.assertTrue(later)
        self.assertTrue(any(p['selected_action_id']=='no_attack' for p in later))
        self.assertAlmostEqual(r['actual']['selected_policy_components']['own_player_hp'], self.scale * .4 * 6)

    def test_unused_full_hand_loses_one_draw_without_paying_or_resetting_reference(self):
        c = dict(self.cards[15], cost=100)
        r = self.evaluate(c, initial_hand_size=7, natural_draw_count=1)
        self.assertAlmostEqual(r['absolute_endpoint_option_model_gold'], -.6)
        self.assertEqual(r['actual']['root_action_id'], 'hold')
        self.assertEqual(r['actual']['selected_policy_components']['retained_own_cash'], r['absent']['selected_policy_components']['retained_own_cash'])

    def test_magic_draw_consumes_actual_library_and_unknown_fatigue_stays_unknown(self):
        v = window.Window(self.cards[243], self.reference, self.scale,
            self.scene(own_deck_available=1, natural_draw_count=1))
        s = v.deploy_options(v.root())[0]['child_state']
        self.assertEqual(s['own_deck_available'], 0)
        r = self.evaluate(243, own_deck_available=1, natural_draw_count=1)
        self.assertFalse(r['pricing_supported'])
        self.assertTrue(any('fatigue' in str(u['reasons']) for u in r['actual']['unknown']))
        closed = self.evaluate(243, own_deck_available=1, natural_draw_count=1, own_fatigue_next=1)
        self.assertTrue(closed['pricing_supported'])

    def test_last_turn_spell_spend_does_not_persist_through_waiting(self):
        v = window.Window(self.cards[438], self.reference, self.scale,
            self.scene(condition_state={'last_turn_gold_spent_on_spells':1}))
        now = v.deploy_options(v.root())[0]['child_state']
        self.assertEqual(now['actor']['attack'], 5)
        later = v.root(); later.update(turn=5, tick=9)
        then = v.deploy_options(later)[0]['child_state']
        self.assertEqual(then['actor']['attack'], 3)

    def test_opponent_min_uses_choices_and_cannot_improve_same_world_payoff(self):
        avg = self.evaluate(404, enemy_bodies=[{'attack':2,'health':8}], responses={'enemy_face':1})
        minimum = self.evaluate(404, enemy_bodies=[{'attack':2,'health':8}], response_mode='min', responses={'none':0,'enemy_face':0,'enemy_contact':0})
        self.assertLessEqual(minimum['actual_value_model_gold'], avg['actual_value_model_gold'])
        self.assertEqual(minimum['actual']['root_action_id'], 'hold')

    def test_unverified_random_fizzle_does_not_get_silently_assumed(self):
        r = self.evaluate(197)
        self.assertFalse(r['pricing_supported'])
        explicit = self.evaluate(197, random_no_target_policy='fizzle_assumed')
        self.assertTrue(explicit['pricing_supported'])


if __name__ == '__main__':
    unittest.main()