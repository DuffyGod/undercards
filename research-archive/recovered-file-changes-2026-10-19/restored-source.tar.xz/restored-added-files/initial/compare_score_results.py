"""Compare matched pool runs and execute low-cost numeric counterfactuals.

No API calls. Reuses saved pool runs; new results never overwrite frozen stage
evidence. Body-only quotes for partial cards are explicitly separate proxies.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import combat_increment as combat
import context_value as ledger
import score_cards as base
import unified_value as unified

HERE=Path(__file__).resolve().parent


def read(path): return json.loads(path.read_text(encoding='utf-8'))
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data): path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def value(row): return row['value_margin_model_gold']
def brief(row):
    return {k:row[k] for k in ('card_id','name','support_status','value_margin_model_gold',
                              'value_quote_model_gold','supported_terms_margin','task_margins','unsupported')}
def fmt(number): return '—' if number is None else f'{number:.4f}'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',type=Path,default=HERE/'experiments/growth-window-v01')
    args=parser.parse_args(); directory=args.directory
    before=read(directory/'baseline-pool.json'); after=read(directory/'current-pool.json')
    old={r['card_id']:r for r in before['scores']}; new={r['card_id']:r for r in after['scores']}
    if set(old)!=set(new) or len(old)!=404 or len(before['scores'])!=len(old) or len(after['scores'])!=len(new):
        raise ValueError('Expected the same 404 unique card IDs in both runs')
    for key,prior in before['profile'].items():
        if after['profile'].get(key)!=prior:
            raise ValueError('Existing common profile changed: '+key)
    if any(r['context_count']!=72 or abs(r['weight_sum']-1)>1e-9 for r in list(old.values())+list(new.values())):
        raise ValueError('Pool run does not preserve the same 72-state total weight')
    cards={c['id']:c for c in base.load_cards()}; reference,_=base.make_reference(list(cards.values()))
    rows=[]; changes=[]
    for cid in sorted(new):
        left,right=old[cid],new[cid]
        # Separate bare-body counterfactual, never a substituted whole-card score.
        proxy=unified.score(dict(cards[cid],effect_readable=''),reference,include_rows=False)
        delta=value(right)-value(left) if value(right) is not None and value(left) is not None else None
        row={'card_id':cid,'name':right['name'],'cost':cards[cid]['cost'],
             'attack':cards[cid]['attack'],'health':cards[cid]['health'],
             'old_status':left['support_status'],'new_status':right['support_status'],
             'old_margin':value(left),'new_margin':value(right),'delta_margin':delta,
             'new_reservation_quote':right['value_quote_model_gold'],
             'known_terms_margin_not_lower_bound':right['supported_terms_margin'],
             'body_only_counterfactual_margin':value(proxy),
             'unsupported':' | '.join(right['unsupported']),'printed_effect':cards[cid]['effect_readable']}
        rows.append(row)
        if delta is not None and abs(delta)>1e-9 or left['support_status']!=right['support_status']:
            changes.append(row)
    with (directory/'pool-comparison.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    counterfactuals=[]
    for cid,right in new.items():
        if value(right) is None: continue
        for field,amount in (('attack',1),('health',1),('cost',-1)):
            card=dict(cards[cid],**{field:cards[cid][field]+amount})
            candidate=unified.score(card,reference,include_rows=False)
            counterfactuals.append({'card_id':cid,'name':cards[cid]['name'],
                                   'intervention':field,'amount':amount,'base_margin':value(right),
                                   'counterfactual_margin':value(candidate),
                                   'delta_margin':value(candidate)-value(right) if value(candidate) is not None else None,
                                   'counterfactual_status':candidate['support_status']})
    with (directory/'numeric-counterfactuals.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(counterfactuals[0])); writer.writeheader(); writer.writerows(counterfactuals)
    scenarios={}
    for q in (0,.4):
        weights={}
        for role,current in combat.RESPONSE_WEIGHTS.items():
            rest=1-current['silence']
            weights[role]={event:q if event=='silence' else v*(1-q)/rest for event,v in current.items()}
        scenarios['silence_weight_'+str(q)]={'growth_response_weights':weights}
    for hand in (0,7):
        scenarios['opponent_hand_'+str(hand)]={'draw_state_assumptions':dict(ledger.DEFAULT_DRAW_STATE,opponent_hand_size=hand)}
    for prior in (.3,.9):
        scenarios['opponent_option_'+str(prior)]={'draw_state_assumptions':dict(ledger.DEFAULT_DRAW_STATE,opponent_net_option_value=prior)}
    scenarios['half_available_income']={'future_income_available_fraction':.5}
    sensitivity=[]
    for name,profile in {'default':{},**scenarios}.items():
        for cid in (49,174,44,199,243):
            result=unified.score(cards[cid],reference,profile,include_rows=False)
            sensitivity.append({'scenario':name,**brief(result)})
    summary={
        'before_version':before['version'],'after_version':after['version'],
        'before_ledger':before['ledger_version'],'after_ledger':after['ledger_version'],
        'pool_size':404,'common_context_count':72,
        'supported_before':sum(value(r) is not None for r in old.values()),
        'supported_after':sum(value(r) is not None for r in new.values()),
        'new_supported_ids':[cid for cid in new if value(old[cid]) is None and value(new[cid]) is not None],
        'lost_supported_ids':[cid for cid in new if value(old[cid]) is not None and value(new[cid]) is None],
        'changes':changes,'counterfactual_count':len(counterfactuals),
        'negative_attack_marginals':[r for r in counterfactuals if r['intervention']=='attack' and r['delta_margin'] is not None and r['delta_margin']<-1e-9],
        'negative_health_marginals':[r for r in counterfactuals if r['intervention']=='health' and r['delta_margin'] is not None and r['delta_margin']<-1e-9],
        'cheaper_card_worse':[r for r in counterfactuals if r['intervention']=='cost' and r['delta_margin'] is not None and r['delta_margin']<-1e-9],
        'sensitivity':sensitivity,
        'assumptions':unified.LIMITATIONS,
        'provenance':{'baseline_sha256':digest(directory/'baseline-pool.json'),
                      'current_sha256':digest(directory/'current-pool.json'),
                      'source_sha256':{p.name:digest(p) for p in sorted(HERE.glob('*.py'))},
                      'snapshot_sha256':digest(base.DEFAULT_SNAPSHOT)},
        'scope':'Matched synthetic reservation margins in model-G; partial known terms and body-only counterfactuals are not whole-card scores or lower bounds.'}
    write(directory/'comparison.json',summary)
    lines=['# 本轮评分比较','',
           f'同一404张池、72共同状态。受限完整启发式支持 {summary["supported_before"]} → {summary["supported_after"]}；新增ID {summary["new_supported_ids"]}，失去支持ID {summary["lost_supported_ids"]}。',
           '', '下面数值是报价减费用的 model-G margin，正值不是实战盈利或胜率。', '',
           '| 卡牌 | 旧 margin | 新 margin | 差值 |','|---|---:|---:|---:|']
    for row in sorted(changes,key=lambda r:(r['delta_margin'] is None,-abs(r['delta_margin'] or 0))):
        lines.append(f'| {row["name"]} #{row["card_id"]} | {fmt(row["old_margin"])} | {fmt(row["new_margin"])} | {fmt(row["delta_margin"])} |')
    lines+=['','## 共同参数敏感度','',
            '| 场景 | Glyde | Diamond Receptionist | Gyftrot | Manticore | Bench |',
            '|---|---:|---:|---:|---:|---:|']
    for name in {'default':{},**scenarios}:
        lookup={r['card_id']:r for r in sensitivity if r['scenario']==name}
        lines.append('| '+name+' | '+' | '.join(fmt(value(lookup[c])) for c in (49,174,44,199,243))+' |')
    lines+=['','## 数值反事实与限制','',
            f'对 {summary["supported_after"]} 张已支持卡分别执行 ATK+1、HP+1、费用−1，共 {len(counterfactuals)} 项；记录于 numeric-counterfactuals.csv。',
            f'负ATK边际 {len(summary["negative_attack_marginals"])}；负HP边际 {len(summary["negative_health_marginals"])}；降费反而更差 {len(summary["cheaper_card_worse"])}。这些是待解释诊断，不能仅因符号异常就强制修分。',
            '', 'pool-comparison.csv 有全部404张的旧/新完整报价、已知项与裸身体反事实；partial 的后两者不能作为完整卡排名或下界。',
            '', '固定grown参照已被完全沉默反事实淘汰；事件参照只在声明的新鲜modifier清除假设下成立。未验证的受伤HP清除保持partial。',
            '', '新支持的抽牌报价以双方剩余库20、对手手数4、对手净option先验0.553125为共同默认，公开测试其敏感度。未来牌库耗尽、Turbo和对手新手牌的反制能力没有完整定价。',
            '', '根身体F仍弱于真实场面兑现：与窗口兑现替代诊断一起比较，不把本轮覆盖提升当作全池强度评价完成。']
    (directory/'comparison.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({k:summary[k] for k in ('pool_size','supported_before','supported_after','new_supported_ids','counterfactual_count','negative_attack_marginals','negative_health_marginals','cheaper_card_worse')},ensure_ascii=False))


if __name__=='__main__': main()