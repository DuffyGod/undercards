"""Full ordinary 4-8G inventory with the same-entity standing purpose.

Unresolved cards block whole-bucket champion claims. HP optimizers and body
feasibility are separate policies; never combine their endpoint columns.
"""
import hashlib
import json
from pathlib import Path

import build_paid_standing_comparison as prior
import compare_monster_purposes as compare
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/single-body-pool-v01'
PURPOSE=dict(min_own_player_hp=1,min_own_body_attack=4,min_own_body_health=3)


def main():
    cards=score_cards.load_cards();rows=[];results={};checks=[]
    for horizon in ('enemy_attack','next_enemy_attack'):
        config=prior.config(horizon)
        config['purposes']={'live_and_keep_single_attacker':PURPOSE}
        result=compare.compare(config,cards)
        results[horizon]=result
        for bucket in result['buckets']:
            subset=[r for r in result['cards'] if r['printed_cost']==bucket['printed_cost']]
            feasible=[r['card_id'] for r in subset if r['purposes']['live_and_keep_single_attacker']['guaranteed'] is True]
            unknown=[r['card_id'] for r in subset if r['purposes']['live_and_keep_single_attacker']['guaranteed'] is None]
            rows.append(dict(horizon=horizon,cost=bucket['printed_cost'],candidates=len(subset),
                supported_subset_hp_best=bucket['supported_subset_best_guaranteed_hp'],
                hp_best_ids=bucket['supported_subset_best_card_ids'],single_body_feasible_ids=feasible,
                unresolved_single_body_ids=unknown,whole_bucket_champion_certified=False))
        for cid in (44,8,14,21):
            r=next(r for r in result['cards'] if r['card_id']==cid)
            scene=dict(r['input'],purpose_constraints=PURPOSE,objectives=['purpose'])
            direct=paid.evaluate(scene,cards)
            exhaustive=paid.evaluate(dict(scene,search_algorithm='exhaustive'),cards)
            assert direct['complete_in_declared_scope']==exhaustive['complete_in_declared_scope']
            assert [o['objective_vector'] for o in direct['objectives']]==[o['objective_vector'] for o in exhaustive['objectives']]
            checks.append(dict(horizon=horizon,card_id=cid,full_vector_equal=True))
    document=dict(paid_version=paid.VERSION,purpose_constraints=PURPOSE,summary=rows,
        results=results,independent_search_checks=checks,
        source_hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in
            ('build_single_body_pool_comparison.py','build_paid_standing_comparison.py',
             'compare_monster_purposes.py','paid_board_tactics.py','board_tactics.py','alpha_beta_search.py')},
        limitations=['Complete 404 ordinary4-8G inventory, not all candidates mechanically closed.',
            'One native candidate and its printed-cost budget; no extra background Tiny/own ally or future own Play.',
            'Short horizon enemy library unspecified, long horizon explicitly empty with fatigue1; Manticore coverage differs for this input reason.',
            'Independent HP maximum and single-body feasibility must not be combined into one strategy guarantee.',
            'No whole-bucket champion, empirical frequencies, calibrated card Gold or match win rate.'])
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'comparison.json').write_text(json.dumps(document,ensure_ascii=False,indent=2)+'\n')
    lines=['# 全404候选的同一攻击者条件筛选','',
        '同旧付费面板：己7/30HP空场，敌Aaron6/5+Tiny1/1，敌已持P3G，候选单张且现金为本费用桶原生价；当前至多一Play，无未来己Play。新目的同一活体ATK≥4且HP≥3、玩家存活。短/长共404普通候选全部保留；未知阻断全桶冠军。',
        '', '| 窗口 | 费用 | HP最佳已支持子集（独立策略） | 可保证单体4/3的已支持候选 | 未闭合数 |', '|---|---|---|---|---|']
    for r in rows:
        lines.append(f"| {r['horizon']} | {r['cost']} | {r['supported_subset_hp_best']} / {r['hp_best_ids']} | {r['single_body_feasible_ids']} | {len(r['unresolved_single_body_ids'])} |")
    lines+=['','HP最佳策略与单体可行策略分别求解，不意味着表中最大HP和单体保证可同时实现。长窗会接受下一敌方合法付费回应，强制持有身体的路线也要支付真实代价。八个原生卡/窗口完整目的向量另与穷举相同。',
        '', '短窗未提供敌库，Manticore未知；长窗显式空敌库和fatigue1才闭合，覆盖差异不能单归因于窗口。候选费用不同，只在同费用桶内比较预算；不能把不同桶HP当单位Gold。']
    (OUT/'comparison.md').write_text('\n'.join(lines)+'\n')
    print([{k:r[k] for k in ('horizon','cost','single_body_feasible_ids')} for r in rows])


if __name__=='__main__':main()