"""Four native event families, same-cash competitors and causal controls."""
import argparse
import copy
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import survival_pressure as pressure

P = Path(__file__).parent
cards = pressure.score.score_cards.load_cards()
by = {c['id']: c for c in cards}
NEW = (17, 163, 291, 526)
DECK = [9, 1, 2, 4]
DECLARED = dict(damage_measure='effective', lethal_received='trigger', zero_received='no_trigger',
                attack_paralyze_it='self', dead_attacker='trigger')


def scene(cid, key):
    def body(card_id=2, **changes):
        c = by[card_id]
        return dict(dict(card_id=card_id, attack=c['attack'], health=c['health'], max_health=c['health'],
                         ready=True, current_card_cost=c['cost'], base_cost=c['cost']), **changes)
    boards = dict(open=[], small=[body()], wide=[body(), body(), body()],
                  tall=[body(270, attack=6, health=8, max_health=8)])
    return dict(hand_ids=[cid], gold_before_play=by[cid]['cost'], max_plays='all_physical',
                next_max_plays='all_physical', own_player_hp=15, own_player_max_hp=30,
                enemy_player_hp=30, enemy_player_max_hp=30, ally_bodies_before_play=[],
                enemy_bodies=boards[key], opponent_hand_ids=[], opponent_hand_known=True,
                opponent_gold_before_response=0, own_deck_ids=DECK, opponent_deck_ids=[],
                own_fatigue_next=1, opponent_fatigue_next=1,
                condition_known_state=dict(remaining_deck=[dict(by[i], generated=False, identity=i) for i in DECK]),
                horizon='next_enemy_attack', next_own_gold_income=5, next_natural_draw_count=1,
                next_opponent_gold_income=0, next_opponent_natural_draw_count=0, node_limit=20000)


def stripped(c):
    import combat_event_extensions as events
    text = c['effect_readable'].strip()
    prefix = text[:events.PREFIX.match(text).end()].strip()
    return dict(c, id=1000000+c['id'], name=c['name']+' [no combat callback]', effect_readable=prefix,
                effect_raw=prefix, card_references=[], keyword_mentions=[])


def run(pilot):
    binding = pressure.score.source_bindings(ROOT/'survival_pressure.py')
    inventory = []
    for c in cards:
        if c['card_type'] != 'monster' or c['pool_category'] != 'ordinary_non_token' or not 1 <= c['cost'] <= 10:
            continue
        e = pressure.score.paid.PaidSearch(cards, scene(c['id'], 'open'))
        spec = e.hand[0][1]
        inventory.append(dict(card_id=c['id'], name=c['name'], cost=c['cost'],
                              full_text_compile_supported=not spec['unknown'], unknown=spec['unknown']))
    (P/'inventory.json').write_text(json.dumps(inventory, ensure_ascii=False, indent=2)+'\n')
    old = json.loads((P.parent/'generated-hand-v01/inventory.json').read_text())
    old_ids = {r['card_id'] for r in old if r['full_text_compile_supported']}
    supported = {r['card_id'] for r in inventory if r['full_text_compile_supported']}
    assert not old_ids-supported
    (P/'static-delta.json').write_text(json.dumps(dict(old_count=len(old_ids), new_count=len(supported),
        gained=sorted(supported-old_ids), lost=sorted(old_ids-supported), denominator=len(inventory),
        scope='Actual complete-text static compile; no battle or whole-pool ranking claim.'), indent=2)+'\n')
    out = P/('pilot' if pilot else 'main'); out.mkdir(exist_ok=True)
    selected = [r for r in inventory if r['full_text_compile_supported'] and r['cost'] in (4, 5, 6, 9)
                and (not pilot or r['card_id'] in NEW)]
    configs = []
    for row in selected:
        cid = row['card_id']
        for key in ('open', 'small', 'wide', 'tall'):
            configs.append((cid, key, 'unresolved', cards, scene(cid, key), None))
    for cid in NEW:
        for key in ('open', 'small', 'wide', 'tall'):
            data = scene(cid, key); data['combat_event_rules'] = DECLARED
            configs.append((cid, key, 'declared', cards, data, None))
            if not pilot:
                clone = stripped(by[cid]); data = scene(cid, key); data['hand_ids'] = [clone['id']]
                configs.append((cid, key, 'removed', cards+[clone], data, None))
                # A focal attack deadline exposes the real cost of NPC's
                # self-Paralyze; pure HP is allowed to hold the card forever.
                task = dict(kind='joint', body_scope='focal', constraints=dict(
                    min_own_body_attack=1, min_own_body_health=1, min_own_body_attack_actions_since_root=1))
                data = scene(cid, key); data['combat_event_rules'] = DECLARED
                configs.append((cid, key, 'declared_attack_body', cards, data, task))
                data = scene(cid, key); data['hand_ids'] = [clone['id']]
                configs.append((cid, key, 'removed_attack_body', cards+[clone], data, task))
    rows = []; calls = 0; start = time.time()
    for cid, key, variant, source, data, task in configs:
        r = pressure.evaluate(data, floors=[1, 11, 15], cards=source, task=task, focal_index=0)
        file = f'card{cid}-{key}-{variant}.json.gz'
        with gzip.open(out/file, 'wt') as f:
            json.dump(dict(card_id=cid, situation=key, variant=variant, scenario=data, task=task,
                           result=r), f)
        rows.append(dict(card_id=cid, name=by[cid]['name'], cost=by[cid]['cost'], situation=key,
            variant=variant, task=r['task'], artifact=file, frontier=r['frontier'],
            complete_sampled_floors=r['complete_sampled_floors'], maximum_survival={k:r['maximum_survival'][k]
                for k in ('known', 'feasible', 'guaranteed_player_hp', 'unknown')},
            unknown=sorted(set(x for row in r['rows'] for x in row['discovery'].get('unknown', []))),
            core_search_calls=r['core_search_calls']))
        calls += r['core_search_calls']
        print(len(rows), cid, key, variant, r['frontier'], r['complete_sampled_floors'], flush=True)
    assert binding == pressure.score.source_bindings(ROOT/'survival_pressure.py')
    result = dict(source_hashes=binding, rows=rows, measured_native_candidates=len(selected),
                  actual_core_calls=calls, seconds=time.time()-start, explicit_rule_hypothesis=DECLARED,
                  rule_hypotheses_server_verified=False,
                  scope='Default unresolved and explicitly declared rule hypotheses are separate. '
                        'Same native fee/cash, same public resource frame within each cost group; '
                        'no whole-pool best, frequency or true-match strength inferred.')
    (out/'index.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--pilot', action='store_true')
    run(parser.parse_args().pilot)