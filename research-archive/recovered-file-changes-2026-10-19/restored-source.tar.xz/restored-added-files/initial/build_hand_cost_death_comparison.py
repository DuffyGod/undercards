"""Real physical hand discounts, timing, cash cliffs and lost copies."""
import copy
import hashlib
import json
from pathlib import Path
import paid_board_tactics as paid
import score_cards

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/hand-cost-death-v01'


def scene(income=2,cash=3):
    return dict(hand_ids=[43,22],gold_before_play=6,own_player_hp=10,
        own_player_max_hp=30,max_plays=1,next_max_plays=1,next_own_gold_income=income,
        current_turn_gold_spent_on_spells=0,
        enemy_bodies=[dict(card_id=15,attack=6,health=5),dict(card_id=196,attack=1,health=1)],
        opponent_hand_ids=[96],opponent_gold_before_response=cash,
        horizon='next_enemy_attack',next_opponent_gold_income=0,
        next_opponent_natural_draw_count=0,next_natural_draw_count=0,
        objectives=['guaranteed_hp'],node_limit=20000)


def canonical_sha(cards):
    return hashlib.sha256(json.dumps(cards,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def edit(cards,**changes):
    altered=copy.deepcopy(cards);source=next(c for c in altered if c['id']==43)
    intervention=dict(synthetic_source_change=True,card_id=43,
        before={k:source[k] for k in changes},after=changes)
    source.update(changes)
    return altered,intervention


def build():
    cards=score_cards.load_cards();rows=[];checks=[]
    without_dust,ablation=edit(cards,effect_readable='')
    lower_atk,atk_change=edit(cards,attack=4)
    def run(name,data,sources,expected,change=None):
        output=paid.evaluate(data,sources)
        if not output['complete_in_declared_scope']:raise AssertionError((name,output['unknown']))
        result=output['objectives'][0]
        if result['metrics']['own_player_hp']!=expected:raise AssertionError((name,result['metrics']))
        exhaustive=paid.evaluate(dict(data,search_algorithm='exhaustive'),sources)
        if not exhaustive['complete_in_declared_scope'] or exhaustive['objectives'][0]['objective_vector']!=result['objective_vector']:
            raise AssertionError('Independent exhaustive mismatch: '+name)
        rows.append(dict(case=name,input=data,source_change=change,
            cards_canonical_sha256=canonical_sha(sources),result=output))
        checks.append(dict(case=name,full_objective_vector_matches_exhaustive=True,
            exhaustive_states=exhaustive['objectives'][0]['visited_states']))
    for income,native,removed in ((1,0,0),(2,2,0),(3,2,2)):
        run('income_%d_native'%income,scene(income),cards,native)
        run('income_%d_remove_dust'%income,scene(income),without_dust,removed,ablation)
    run('unpayable_punishment_native_atk_5',scene(cash=2),cards,6)
    run('unpayable_punishment_remove_dust_atk_5',scene(cash=2),without_dust,2,ablation)
    run('unpayable_punishment_native_atk_4',scene(cash=2),lower_atk,0,atk_change)
    only_dog=scene();only_dog['hand_ids']=[43]
    run('same_scene_without_held_heal_copy',only_dog,cards,0)

    # Trace a held coupon and a later same-ID physical draw without using
    # opponent cooperation or inferring spell payment from printed COST.
    observation=dict(hand_ids=[598,598,582],hand_costs=[0,1,4],gold_before_play=0,
        own_player_hp=30,max_plays=3,next_max_plays=1,next_own_gold_income=3,
        horizon='next_own_attack',current_turn_gold_spent_on_spells=0,
        condition_known_state={'last_turn_gold_spent_on_spells':1},
        next_natural_draw_count=1,own_deck_ids=[598],
        ally_bodies_before_play=[dict(card_id=43,attack=5,health=1,max_health=5)],
        objectives=['guaranteed_hp'])
    engine=paid.PaidSearch(cards,observation);root=engine.root()
    action,after=next((a,s) for a,s in engine.casts(root,'own') if a['hand_index']==0 and a['targets']==[('own',0)])
    second,next_state=next((a,s) for a,s in engine.casts(after,'own') if a['hand_index']==1 and a['targets']==[('enemy_player',None)])
    future=engine.boundary(engine.boundary(next_state))
    book,state=next((a,s) for a,s in engine.deploys(future) if a['card_id']==582)
    if future.own_hand_costs!=((2,3),(3,1)) or book['paid_gold']!=3 or state.own[-1].taunt or state.own[-1].attack!=2:
        raise AssertionError('Late copy or free-spell Need bookkeeping changed')
    trace=dict(input=observation,forced_legal_own_intervention=True,
        actions=[action,second,dict(kind='end_turn',phase=0),dict(kind='end_turn',phase=1),book],
        initial_held=engine.describe_hand_costs(root,'own'),after_death=engine.describe_hand_costs(after,'own'),
        after_natural_draw=engine.describe_hand_costs(future,'own'),
        actual_current_spell_payment=next_state.own_spell_spend_since_root,
        next_previous_spell_payment=future.previous_own_spell_spend,
        book_body=dict(attack=state.own[-1].attack,health=state.own[-1].health,taunt=state.own[-1].taunt),
        interpretation='Forced own causal trace, not an optimal-policy claim. Enemy hand/board empty in this trace.')
    return dict(version='physical-death-hand-cost-comparison-0.1.0',client_date='2026-10-13',cases=rows,
        held_vs_late_same_id_trace=trace,independent_algorithm_checks=checks,
        cards_canonical_sha256=canonical_sha(cards),
        snapshot_sha256=hashlib.sha256(score_cards.DEFAULT_SNAPSHOT.read_bytes()).hexdigest(),
        source_hashes={f:hashlib.sha256((HERE/f).read_bytes()).hexdigest() for f in
            ('build_hand_cost_death_comparison.py','paid_board_tactics.py','board_tactics.py',
             'alpha_beta_search.py','finite_conditions.py','score_cards.py')},
        source_card={k:next(c for c in cards if c['id']==43)[k] for k in
            ('id','name','cost','attack','health','effect_readable','rarity','pool_category')},
        limitations=['Declared physical hand, perfect-information response menu and two enemy windows, not a whole-game or whole-pool card value.',
            'The zero cost floor remains a source-unverified rule hypothesis; coupon and dynamic dust discount share one actual cost ledger.',
            'No assumed willingness to kill Lesser Dog; the enemy can stop or ignore it, and own attacks can sacrifice it.',
            'Multiple competing Dust callbacks and modified-cost death-zone retention remain unknown.',
            'No hidden-hand probabilities, SOUL, artifacts, empirical frequency or fitted Gold reward.',
            'Natural draw is disabled in the survival panels; the separate same-ID trace declares one known draw.'])


def main():
    result=build();OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    report='''# Lesser Dog：死亡减费的实际兑现（2026-10-13）

原牌为6G、5/5、Dust令当时手中所有卡COST−1。费用以每个物理副本的当前账本参与可支付判断、实际付款及回合施法历史；之后才抽到的牌没有过去的折扣。不是给关键词固定加1Gold。

共同局面：己10/30HP、6G、手Lesser Dog与Shyren；敌Aaron6/5＋Tiny1/1、已知一张Punishment与3G；当前和下一己方各至多一次Play，包含第二敌回应，双方自然抽牌0、敌下次收入0。敌方可以选择停止、忽略Dog、先用法术或先攻击。

| 下一己方收入 | native最终HP保证 | 移除Dog Dust | 结论 |
|---:|---:|---:|---|
| 1G | 0 | 0 | Shyren降到2G仍买不起 |
| 2G | 2 | 0 | 死亡折扣跨过治疗付款门槛，改变存活 |
| 3G | 2 | 2 | 原价已经付得起，减费没有额外HP收益 |

2G面板的一个最坏路径：敌Punishment将Dog打到1HP，Tiny撞死Dog并同死，Aaron打脸6；手中Shyren成为2G，下一回合治疗4，第二次Aaron打脸6后剩2HP。这个保证来自敌方所有已实现回复的最小值，不仅来自该打印路径。若移除手里的Shyren，同一局面Dog只能保证0；手牌结构决定折扣能否兑现。

将敌余额改为2G，使Punishment不可支付，其余保持相同：Dog原5ATK保证6HP，移除Dust只保2，原牌ATK5→4反事实却保0。下一己方可以主动用Dog与Aaron交换，5攻正好击杀Aaron并兑现手里Shyren的减费；4攻留下Aaron，敌后续伤害足以致死。减费不是单独的资源奖励，它必须和交换阈值、格子、剩余目标、治疗付款一起计算。

另一条明确强制的合法己方因果路线保存为held_vs_late_same_id_trace：站场Dog剩1HP；手中两个Gemstone当前成本0/1与Bookshelf4；免费Gem杀Dog后，仍在手Gem降至0、Book降至3。两次免费施法实际支出均0；下一自然抽到同ID第三Gem仍1G，Book虽然付3G，上一回合实际施法支出0使Need为假，仍2/7且无Taunt。它既检查不按ID全局减费，也检查不按印刷费用伪造历史。Gemstone是声明已持有的TOKEN，不能直接用于构筑携带建议。

当前规则仍有边界：COST下限0没有服务器实测裁定，以rule_hypotheses公开；本报告2G治疗门槛不依赖负费裁定。多Dust竞争队列和减费后死亡COST跨区保留未知。完整源码、实际传入卡池SHA、原始物理付款/死亡折扣轨迹和10项独立穷举目标向量比较保存在comparison.json。算法一致是计算验证，不是实战频率校准。

```sh
python analysis/monster-value-heuristic/build_hand_cost_death_comparison.py
python -m unittest discover -s analysis/monster-value-heuristic -p test_hand_cost_death.py
```
'''
    (OUT/'comparison.md').write_text(report)
    print([(r['case'],r['result']['objectives'][0]['metrics']['own_player_hp']) for r in result['cases']])


if __name__=='__main__':main()