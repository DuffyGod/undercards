# 伤害模板的可比较评分

2026-10-15（北京时间）。paid0.23 / board0.5 / API0.25 / conditional score0.3。直接打开[交互表](score-explorer.html)、[CSV](scores.csv)、[验证](verification.json)。本批12个声明场景、16个候选与条件组合，13个保命评分闭合、3个保留未知；不是全池抽样准确率。

## 同费用的真实排名翻转

共同条件：当前3G、玩家15/30HP、敌玩家30HP、无敌手；敌体都是当前观察4攻，截止一次完整敌回应。当前只能实际支付一张候选，既有友军不能攻击。下表数值为己方选择打法后、面对所有合法敌攻击/停止的最坏玩家HP。

| 当前敌场与配合 | Jumping Frog | Allergic Temmie | Fox Head |
|---|---:|---:|---:|
| 一只1血敌，无其他Tem | 15 | 11 | 未在此组比较 |
| 一只2血敌，两名其他Tem | 11 | 15 | 未在此组比较 |
| 两端各一只1血敌，无其他Tem | 11 | 7 | 15 |

Jumping Frog采样实际施放者的有效ATK，选择一个可选择的敌体；Fox Head按真实格子选择左右最边缘活体；Allergic按原始TRIBE标识数其他友方Tem，不能从英文名字猜族群。它们共用付款、伤害、防护、死亡与物理副本核心，没有按卡名加分。七个HP值另由不导入搜索/付款/战斗原语的上下界程序证明：所有剩余敌体各打脸一次给上界，敌总可用攻击量给同值下界。

同一Frog真实手持Instant Noodles时，8G+3G支付顺序可让其攻击1→2，击杀2血目标并保15。不能把手牌加攻当免费既有Buff，也不能只按印刷攻击读取Magic。

## 对数值相同的规则分歧保留未知

Fox面对单个3血敌，“两端是同一怪物时命中一次或两次”会留下不同敌体，尽管两种解释的玩家HP都为13。Allergic面对Armor时，聚合伤害与逐Tem伤害包也可能有同样玩家HP而不同敌体。未确认的解释不能给施放者自由选择；默认比较完整最终物理状态，不一致则unknown。显式`same_extreme_twice`或`allergic_damage_packets`只是具名反事实，不是服务器事实。0个Tem时的零伤害事件若触发Bowll不同状态，也保留unknown。

这类未知可以进一步按用途求可靠界，但必须跨解释使用同一可执行打法。另见[共同策略程序与原生反例](../../research-runs/rule-ambiguity-v01/README.md)，不能对每种解释分别求最优后，把最差最优值冒充未知规则时的保证。

## 覆盖与运行

原14条件149组合、治疗/空间/容量23条件215组合均在新生产核心下实际复算。同一全106普通3G输入现17闭合/89未知；明确几何与前方规则的输入20/86。这是特定输入的整卡评分数，编译成功数量和104条件画像另计。未知继续阻断全池最佳认证。

```sh
python analysis/monster-value-heuristic/build_literal_magic_scores.py
python analysis/monster-value-heuristic/verify_literal_magic_scores.py
python analysis/monster-value-heuristic/build_conditional_score_view.py --directory analysis/monster-value-heuristic/experiments/literal-magic-v01 --default-case single-hp1-no-tem
python analysis/monster-value-heuristic/conditional_card_score.py --input analysis/monster-value-heuristic/experiments/literal-magic-v01/single-hp2-two-tem.input.json --output /tmp/tem-score.json
```

实际执行32次alpha/穷举查询：13组完整目标向量一致、3组unknown原因一致；3个公共API/direct/实际CLI完整JSON一致，含未知案例。受影响41模块426项测试实际通过236.17s；5模块59项的全部递归依赖与此前通过版本逐项相同，明确复用，没有称485项都重新运行。原48历史报告固定在已实际验证的paid0.22来源快照，本轮只重算受影响的当前比较。视图做120次选择切换与数据核对，DOM替身不当作浏览器布局验证。

早期失败保存于`research-runs/literal-magic-v01/`：运行时tuple/JSON list假差异、私有`opponent_hand_known`误塞公共参数、API测试误用不存在的role。修正输入与验证接口后重跑，不删除失败或削弱机制守卫。没有新Gold、真实局面频率、服务器裁定或全局实战胜率。