import unittest
import build_delay_history_comparison as scenes
import prove_idle_reply_bound as bound
import paid_board_tactics as paid


class IdleReplyBoundTests(unittest.TestCase):
    def test_idle_counterstrategy_excludes_four_play_clear_without_reply_brute_force(self):
        data=scenes.scene(spell=True,horizon='next_own_attack');data['max_plays']=4
        r=bound.prove(data)
        self.assertTrue(r['bound_complete'],r['unknown'])
        self.assertFalse(r['any_policy_can_guarantee_clear'])
        self.assertLess(r['max_eligible_attack_upper'],r['min_enemy_health_required'])

    def test_insufficient_bound_does_not_masquerade_as_failure(self):
        data=dict(hand_ids=[438],gold_before_play=4,own_player_hp=3,
            enemy_bodies=[dict(card_id=15,attack=6,health=5)],max_plays=1,
            condition_known_state={'last_turn_gold_spent_on_spells':1},horizon='next_own_attack')
        r=bound.prove(data)
        self.assertFalse(r['bound_complete'])
        self.assertIsNone(r['any_policy_can_guarantee_clear'])

    def test_hp_extension_requires_same_inputs_and_no_future_hp_event(self):
        current=dict(hand_ids=[1],gold_before_play=1,own_player_hp=3,
            enemy_bodies=[dict(card_id=15,attack=6,health=5)],max_plays=1,
            own_deck_ids=[196],horizon='enemy_attack',objectives=['guaranteed_hp'])
        record=dict(input=current,result=paid.evaluate(current))
        future=dict(current,horizon='next_own_attack',next_natural_draw_count=1)
        r=bound.extend_guaranteed_hp(future,record)
        self.assertEqual(r['guaranteed_hp_at_next_own_attack'],3)
        with self.assertRaises(ValueError):bound.extend_guaranteed_hp(dict(future,own_player_hp=1),record)
        fatigue=dict(current,own_deck_ids=[],own_fatigue_next=1)
        rec=dict(input=fatigue,result=paid.evaluate(fatigue))
        self.assertFalse(bound.extend_guaranteed_hp(dict(fatigue,horizon='next_own_attack',next_natural_draw_count=1),rec)['hp_invariance_proved'])