"""A common-API current policy that cannot select a card after seeing the hand."""
import hashlib
import json
from pathlib import Path
import evaluate_situation
import hidden_reply_policy

HERE=Path(__file__).resolve().parent
OUT=HERE/'experiments/hidden-reply-v01'


def main():
    OUT.mkdir(exist_ok=True)
    data=dict(hand_ids=[1,22],role='midrange',own_turn=3,gold_before_play=3,
        opponent_gold_before_response=3,own_player_hp=3,enemy_player_hp=30,
        ally_bodies_before_play=[],enemy_bodies=[dict(card_id=15,attack=6,health=5)],
        callback_state={'own_player_max_hp':30,'enemy_player_max_hp':30},
        response_weights={'enemy_face':1},
        hidden_reply_scenario=dict(opponent_hands=[{'ids':[96]},{'ids':[598]}],
            panel_names=['Punishment','TOKEN Gem'],max_plays=1,objective='guaranteed_hp'))
    output=evaluate_situation.evaluate(data)
    hidden=output['hidden_reply_policy']
    direct=hidden_reply_policy.evaluate(hidden['input'])
    if json.loads(json.dumps(hidden))!=json.loads(json.dumps(direct)):
        raise AssertionError('Common API differs from standalone hidden current policy')
    if hidden['objective_vector'][0]!=0 or hidden['oracle_minimum_vector'][0]!=1:
        raise AssertionError('Oracle leakage counterexample changed')
    if output['authoritative_tactical_recommendation']['guaranteed_survival']:
        raise AssertionError('False survival recommendation')
    for name,document in (('current.input.json',data),('current.result.json',output)):
        (OUT/name).write_text(json.dumps(document,ensure_ascii=False,indent=2)+'\n')
    verification=dict(api_matches_standalone=True,shared_policy_hp_guarantee=0,
        independently_optimized_panel_minimum=1,guaranteed_survival=False,
        source_hashes={f:hashlib.sha256((HERE/f).read_bytes()).hexdigest() for f in
            ('build_hidden_reply_api.py','evaluate_situation.py','hidden_reply_policy.py',
             'paid_board_tactics.py','board_tactics.py','alpha_beta_search.py')})
    (OUT/'api-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    print('Shared-policy API HP0; oracle diagnostic HP1; standalone equal')


if __name__=='__main__':main()