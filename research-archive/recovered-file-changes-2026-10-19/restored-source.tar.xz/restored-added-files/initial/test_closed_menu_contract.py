"""An explicitly unknown hand must not receive an empty-menu guarantee."""
import unittest
import alternative_goal_score as alt
import conditional_card_score as score
import paid_board_tactics as paid
import evaluate_situation as api


class ClosedMenuTests(unittest.TestCase):
    def data(self):
        return dict(hand_ids=[],gold_before_play=0,own_player_hp=15,enemy_player_hp=30,
            opponent_gold_before_response=6,opponent_hand_ids=[],max_plays=0,
            horizon='enemy_attack',objectives=['guaranteed_hp'])

    def test_explicit_unknown_and_nonboolean_are_rejected_at_foundation(self):
        for value in (False,None,0,1,'unknown'):
            with self.subTest(value=value),self.assertRaises(ValueError):paid.evaluate(dict(self.data(),opponent_hand_known=value))

    def test_legacy_omission_is_declared_menu_and_true_is_accepted(self):
        for data in (self.data(),dict(self.data(),opponent_hand_known=True)):
            self.assertTrue(paid.evaluate(data)['complete_in_declared_scope'])

    def test_both_task_entries_reject_unknown(self):
        data=dict(self.data(),opponent_hand_known=False)
        with self.assertRaises(ValueError):score.task_score(data,dict(kind='hp'))
        task=dict(kind='any',clauses=[dict(constraints=dict(min_own_player_hp=1)),dict(constraints=dict(max_enemy_living_count=0))])
        with self.assertRaises(ValueError):alt.evaluate(data,task)

    def test_public_paid_wrapper_does_not_drop_unknown_flag(self):
        data=dict(role='midrange',own_turn=10,hand_ids=[],hand_costs=[],gold_before_play=0,own_player_hp=15,
            enemy_player_hp=30,opponent_gold_before_response=6,opponent_hand_known=False,
            ally_bodies_before_play=[],enemy_bodies=[],paid_board_scenario=dict(max_plays=0,horizon='enemy_attack',
                opponent_hand_ids=[],objectives=['guaranteed_hp']))
        with self.assertRaises(ValueError):api.evaluate(data)


if __name__=='__main__':unittest.main()