我把现有资料按“**可以当规则书使用**”的标准重新整理了一遍。先给一个判断：你缺的三块信息里，**最难获得的不是卡组表，而是规则裁定与玩家对局模型**。Undercards 的官方信息高度碎片化，社区的真正竞技知识又主要沉淀在 Hub、TrueHub Discord 和玩家经验中，而不是 Wiki。

截至 **2026 年 10 月、Season 123**，比较合理的知识结构应该是：

> **Rules / Rulings → Archetypes → Deck skeletons → Pilot model → Matchups**

而不是简单的“卡牌数据库 + 推荐卡组”。

---

# 一、先建立规则信息的可信度层级

我建议你以后整理 Undercards 时使用下面这个优先级：

1. **最新官方 patch note**
2. **游戏内当前卡牌文本 / Soul 文本 / keyword tooltip**
3. **当前 Wiki 的具体卡牌页**
4. **Wiki 的 Abilities / FAQ**
5. **Wiki Beginner Guide**
6. **Reddit / Discord 玩家实测**
7. **旧攻略**

这是有实际必要的。例如：

- Beginner Guide 至今仍写“每回合一分钟”，但官方 Season 106 已把 timer 从 **1:00 改成 1:30**。[Undercards](https://undercards.fandom.com/wiki/Welcome%21?utm_source=chatgpt.com)
- Wiki Abilities 仍写 `Shock` 在法术效果**之前**触发，但 Season 106 官方明确将其改成法术**结算以后**触发。[Undercards](https://undercards.fandom.com/wiki/Abilities?utm_source=chatgpt.com)

所以 Wiki 非常有用，但**不能被视为规则权威文本**。

---

# 二、Undercards“规则书”重建版

下面我省略你已经知道的卡池信息，重点写容易产生裁定问题的部分。

## 2.1 构筑规则

一个合法牌组：

| 项目 | 规则 |
|---|---|
| 主牌组 | 25 张 |
| Common / Base | 同名最多 3 |
| Rare | 同名最多 3 |
| Epic | 同名最多 2 |
| Legendary | 同名最多 1 |
| DT | 同名最多 1；**Ranked 整副牌只能带 1 张 DT** |
| Spell | 只能加入对应 SOUL |
| Artifact | 两个普通 Artifact，或一个 Legendary Artifact |

FAQ 当前仍明确给出 25 卡、2 Artifact / 1 Legendary Artifact，以及各稀有度数量限制；DT 页确认 Ranked 只能携带一张 DT。[Undercards](https://undercards.fandom.com/wiki/FAQ?utm_source=chatgpt.com)

这其实产生了 Undercards 构筑中很重要的一条隐性规则：

> **DT slot 类似一个牌组级资源。**

因此讨论“哪张 DT 最强”通常不如讨论：

> **我的 deck skeleton 最值得把唯一 DT slot 花在哪里？**

这一点会直接影响后面的 meta。

---

# 三、资源系统：它和 Hearthstone 最大的结构差异之一

双方起手 3 张，并进行 mulligan；双方初始有 1G。正常情况下每回合开始抽一张。

更重要的是：

> **G 不会在回合结束清零。**

每回合开始获得等同于 turn number 的 G，增长到通常的 10G 上限；已经积累的 G 会保留。[Undercards](https://undercards.fandom.com/wiki/Welcome%21?utm_source=chatgpt.com)

所以 Undercards 的资源决策不能简单理解成 Hearthstone 的“curve”。

真正的问题是：

\[
\text{现在花 G 获得 tempo}
\quad vs \quad
\text{保存 G 获得未来爆发}
\]

这也解释了为什么玩家经常讨论：

- “economy management”
- “funnel G into value”
- “-3G tempo”
- 某张牌“太贵导致失去 tempo”
- 20G Roaring Knight 是否值得

例如玩家评价 control finisher 时，会直接把 DT Extractor 描述为把多余 G 快速转换成 value 的工具；Roaring Knight 的问题同样经常围绕它高达 20G 的经济代价讨论。[Reddit](https://www.reddit.com/r/UnderCards/comments/1skz7qv/best_cards_for_finishers_in_control_decks/?utm_source=chatgpt.com)

因此我建议把 **G bank** 单独作为一个游戏状态变量记录，而不是只记录“本回合有多少 mana”。

---

# 四、手牌、牌库、疲劳

正常手牌上限为 **7**。

手牌满时抽牌会 overdraw，该卡直接丢失；将怪物返回满手牌也会导致其丢失。[Undercards](https://undercards.fandom.com/wiki/Cards?utm_source=chatgpt.com)

牌库为空后的失败抽牌会逐次造成：

\[
1,2,3,4,\ldots
\]

疲劳伤害。[Undercards](https://undercards.fandom.com/wiki/Welcome%21?utm_source=chatgpt.com)

这使 Undercards 里的“无限资源”并不单纯是 card advantage：

- 生成卡可以绕过牌库资源；
- shuffle / refill 可以改变 fatigue clock；
- 大规模 generation 又会产生 hand-space 问题；
- Soulless Kris 甚至可能因为一次性填满手牌导致 overdraw。

Soulless Kris 的 Dark Fountain 本身就是典型案例：其核心奖励是持续制造大量 Deltarune cards，但 Wiki 也特别提醒其可能塞满自己的手牌。[Undercards](https://undercards.fandom.com/wiki/Soulless_Kris?utm_source=chatgpt.com)

---

# 五、场面与战斗

双方各有 **4 个 monster slot**。

通常怪物进入场上以后需要等待一回合才能攻击。

### Charge

进入场面的当回合可以正常攻击，包括攻击玩家。

### Haste

进入场面的当回合可以攻击怪物，但不能攻击玩家；之后恢复正常。[Undercards](https://undercards.fandom.com/wiki/Abilities?utm_source=chatgpt.com)

攻击怪物时双方按 ATK 同时造成伤害，即通常意义上的 counterattack。

这里产生一个很重要的竞技概念：

> **Immediate board interaction = initiative**

2026 年的一位 Master 玩家甚至直接把：

- Haste minion
- 可以立即处理 monster 的 spell

统称为 **initiative**。[Reddit](https://www.reddit.com/r/UnderCards/comments/1vyawau/i_seriously_need_help_winning_more_i_dont_even/)

这个术语很适合加入你的知识库。

---

# 六、Played ≠ Summoned：这是最应该写进规则书的一条

### Magic

只有怪物**从手牌被 play 到场上**时触发。

如果通过 Lamp 等效果直接 `Summon` 到场上：

> **不会触发 Magic。** [Undercards](https://undercards.fandom.com/wiki/Abilities?utm_source=chatgpt.com)


因此规则语义上至少要明确区分：

- Play
- Summon
- Add to hand
- Draw
- Return
- Kill
- Erase

这比很多初级说明书重要得多。

---

# 七、死亡、Dustpile、Bounce、Erase

正常 monster HP 到 0 后：

> die → 进入 Dustpile → Dust 条件成立。

但：

### Return

返回 hand 或 deck **不算死亡**，因此正常不会触发 Dust。

而且怪物从场上 / Dustpile 被送回 hand 或 deck 后，其 stats 与修改会重置。[Undercards](https://undercards.fandom.com/wiki/Tips_and_Tricks?utm_source=chatgpt.com)

### Erase

则是另一种完全不同的 zone transition：

> Remove card，并且**不进入 Dustpile**。 [Undercards](https://undercards.fandom.com/wiki/Abilities?utm_source=chatgpt.com)


所以严格规则层面应该把：

\[
Kill \neq Return \neq Erase
\]

写死。

这也是构筑分析里必须区分的——尤其是 Royal Papyrus、Dust synergy、resurrection 等牌组。

---

# 八、关键 trigger 的严格含义

当前 Wiki 可以比较可靠地确认：

| Keyword | 实际含义 |
|---|---|
| Magic | 从手牌 Play 时触发 |
| Dust | 死亡时触发 |
| Turn start | 自己回合开始触发 |
| Turn end | 自己回合结束触发 |
| Need | Magic 的额外启动条件 |
| Synergy | 本回合已 play 同 tribe ally 后，play 此牌时触发 |
| Delay | play 当回合结束时触发；牌提前离场也照样发生 |
| Turbo | **被抽到**时触发，包括 overdraw |
| Support | 其他友方怪物攻击时触发 |
| Program(x) | 有 x G 时消耗 G 执行 |
| Bullseye | 将怪物正好打到 0 HP 时触发 |
| Loop(x) | play 后复制自身，并减少 Loop | :chatgpt-content-reference{index="13"}


其中三个尤其容易误判。

### Delay 不依赖留场

牌被杀掉、bounce 等以后，已经设置的 Delay 仍然会发生。

### Turbo 在 overdraw 时也触发

所以“烧掉一张 Turbo 卡”并不等于没有触发它。

### Shock 已经修改过

旧 Wiki 描述：

> spell → Shock → spell effect

已经过时。

Season 106 后应理解为：

> **cast spell → spell resolves → Shock**

而且 effect cast 出来的 spell 不会正常再次触发 Shock。[Undercards](https://undercards.fandom.com/wiki/Abilities?utm_source=chatgpt.com)

---

# 九、Silence 是“重置”而不只是失去文本

Undercards 的 Silence 比很多卡牌游戏更强。

Silence 会：

- 移除 abilities；
- 移除 status；
- 移除 stat changes；
- 恢复 base stats。

DT monster 天生 immune to Silence。[Undercards](https://undercards.fandom.com/wiki/Abilities?utm_source=chatgpt.com)

因此 buff deck 对 Silence 的 vulnerability 是结构性的，不只是“失去一个效果”。

---

# 十、Taunt / Transparency 有特殊交互

Taunt 通常强制敌人先处理 Taunt monster。

但 Transparency：

> monster 无法成为 target。

而且 Transparency 会使 Taunt / Invulnerable 暂时失效。[Undercards](https://undercards.fandom.com/wiki/Abilities?utm_source=chatgpt.com)

这是典型的“客户端视觉上可能不够直观，但引擎裁定明确”的规则。

---

# 十一、当前七 Soul 应该如何理解

这里我反而不建议把 Soul 当成 Hearthstone 的“职业”。

更合理的模型是：

> **Soul = passive + spell package + 对某种 game plan 的偏置。**

因为大量 archetype 实际上可以换 Soul。

当前被动大致是：[Undercards](https://undercards.fandom.com/wiki/Decks/Previous_Versions?utm_source=chatgpt.com)

| Soul | 当前功能 | 更合理的竞技理解 |
|---|---|---|
| Determination | 首次死亡保命 + Save/Lost Soul 系统 | attrition / sacrifice / long game |
| Patience | 偶数回合条件性 topdeck Change of Winds | consistency / selection / combo-control |
| Bravery | 每 3 回合生成 Recruitment；低手牌时额外获得 | aggro / low-hand fuel |
| Integrity | +1 G cap，并周期性增加经济 | economy / expensive engines |
| Perseverance | 攻击敌怪后施加 KR | board trading / combat value |
| Kindness | 持续恢复自身，并强化右侧怪物 HP | sticky board / buff / tempo-midrange |
| Justice | 回合末随机伤害敌方 monster | board control / damage spell shells |

社区长期以来也是这样理解 Soul 的：不是“某 Soul 必须玩某 deck”，而是**某种 deck 更适合哪个 Soul 的经济、spell package 与 passive**。2025 年的玩家讨论仍然明确把 Integrity 与 expensive cards、Justice 与 removal、Patience 与 consistency 联系起来。[Reddit](https://www.reddit.com/r/UnderCards/comments/1msm94z?utm_source=chatgpt.com)

---

# 十二、2026 环境：目前可以确认的常见 archetype

这里要特别说明：

**Undercards 没有 HSReplay 一类公开统计站。**

当前环境最好的公开资料，是：

- Hub；
- TrueHub Discord；
- 高段位玩家讨论；
- Reddit deck help；
- 官方 patch。

而 Hub 本身没有良好的公开网页索引，Discord 也不能作为开放网页完整检索。

因此下面不是精确 tier list，而是 **2026 年中到 Season 123 附近可观察到的 archetype map**。

---

## 12.1 Soulless Kris / unique-card generation

这是当前最值得首先理解的牌组之一。

Soulless Kris 的 Dark Fountain：

> 每次 play 本局此前没 play 过的 card，累计 counter；达到条件后制造大量 DR monsters。 [Undercards](https://undercards.fandom.com/wiki/Soulless_Kris?utm_source=chatgpt.com)


因此典型构筑逻辑不是“放很多最强卡”，而是：

> **最大化 unique card density。**

2026 年 9 月社区给出的构筑建议甚至非常直接：

- Librarian
- Library Loox
- 其余卡尽量全部不同

从而快速触发 Soulless Kris。[Reddit](https://www.reddit.com/r/UnderCards/comments/1wts90d/what_dt_should_i_get/?utm_source=chatgpt.com)

七月的 top-ladder 观察则提到两类 SK：

1. **spell-heavy / post-Kris value**
2. **Monster Kid、Migosp Lord 等便宜牌提供 early pressure 的 SK** [Reddit](https://www.reddit.com/r/UnderCards/comments/1v2cg0b/new_player_advice/)


所以它不是纯 control。

真正 game plan 是：

\[
\text{survive/tempo}
\rightarrow
\text{activate Fountain}
\rightarrow
\text{resource inevitability}
\]

它是理解现代 Undercards“生成资源体系”的最好范例。

---

# 12.2 Roaring Knight shells

如果说 SK 代表 resource inevitability，那么 2026 年最显眼的另一端就是 **Roaring Knight**。

社区在 2026 年多次把它描述成通用强力 finisher，甚至出现：

> “When in doubt, Roaring Knight.” [Reddit](https://www.reddit.com/r/UnderCards/comments/1utskrs/which_dt_should_i_add_if_any/?utm_source=chatgpt.com)


July top ladder 的公开观察中也出现：

- Gold Widow rush + Roaring Knight
- Roaring Knight control

而八月玩家直接讨论 Knight 如何压制 mid/late-game board control。[Reddit](https://www.reddit.com/r/UnderCards/comments/1v2cg0b/new_player_advice/)

其关键并不是单纯“大怪”。

玩家对它的理解是：

> **它惩罚对手进入某些 board state。**

所以面对 Knight 时存在典型 counterplay：

> **不要过度铺场。**

这正是 Undercards 高水平游戏中“play around known payoff”的案例。

---

# 12.3 Underground Army / Royal Papyrus

这是非常典型的 **greedy control / reanimation-value** deck。

核心是把大量昂贵且高 utility 的怪物送进 Dustpile，然后通过 Royal Papyrus 获得 **Underground Army**。

玩家对它的描述非常形象：

> survival until the end → Royal Papyrus → 持续产生巨大 value。

当前社区解释的构筑思路包括：

- 9+ cost monsters；
- board clear；
- utility bodies；
- Crazy Bun + Asgore；
- Mettaton NEO 等。 [Reddit](https://www.reddit.com/r/UnderCards/comments/1v2cg0b/new_player_advice/?utm_source=chatgpt.com)


它甚至被 2026 年 6 月的一位玩家认为是当时“两种最强策略”之一，另一种是 spell generation。[Reddit](https://www.reddit.com/r/UnderCards/comments/1uk0v7g/what_is_strongest/?utm_source=chatgpt.com)

其核心弱点也非常明确：

> **early tempo。**

三月的实际 R-Paps 玩家讨论反复提到：对手如果有很强的 early-game tempo，很可能在 engine 上线之前杀死你。[Reddit](https://www.reddit.com/r/UnderCards/comments/1rlnqvv/opinions_on_this_deck/?utm_source=chatgpt.com)

所以这是很标准的：

\[
\text{Tempo debt}
\rightarrow
\text{Survival threshold}
\rightarrow
\text{Inevitability}
\]

型 deck。

---

# 12.4 Spell-generation / Good Food / shelf shells

2026 年公开讨论中，**spell generation** 多次被认为是环境顶层策略之一。

六月讨论直接称：

> Royal Papyrus Underground Army 与 spell generation 是当时最强的两种 strategy。

并特别提到：

- Bone Box
- shelf
- Good Food [Reddit](https://www.reddit.com/r/UnderCards/comments/1uk0v7g/what_is_strongest/?utm_source=chatgpt.com)


七月另一篇讨论则把：

- Plant
- Spell
- Generation

称为当时最强的一批 deck 类型。[Reddit](https://www.reddit.com/r/UnderCards/comments/1v2cg0b/new_player_advice/)

这里的关键不是“Spell tribal”，而是：

> **把有限 deck resource 转化为开放式 answer/value pool。**

所以它与 SK 属于同一种现代 Undercards 趋势：

### 传统 card advantage
抽自己的牌。

### Generation economy
**创造 deck 中原本不存在的牌。**

后者一旦效率足够高，就会改变疲劳和长期资源模型。

---

# 12.5 Spamton

Spamton 是一个非常好的“真正 deck synergy”教学案例。

目标通常围绕：

- Pipis
- Flying Heads
- Spamton Shop / Spamequin
- `[HYPERLINK BLOCKED]`
- Broken NEO / Pipis Cannon 等 payoff。

最近的 deck critique 非常值得作为教材：有玩家做出“Spamton deck”，但放了 **Spamton Poster 却几乎没 spell**，于是整个 engine 根本无法运转。[Reddit](https://www.reddit.com/r/UnderCards/comments/1wlfvof/i_would_like_to_know_your_thoughts_on_my_decks/)

更成熟的玩家给出的思路是：

> 不要因为名字里有 Spamton 就全塞进去。

例如普通 Pipis 本身甚至可能只是 clog hand；更重要的是：

- 让 Pipis 被 generate；
- 让它们死亡；
- stack `[HYPERLINK BLOCKED]`；
- 重复 Spamton Shop / Flying Heads 等真正的 engine piece。 [Reddit](https://www.reddit.com/r/UnderCards/comments/1wlfvof/i_would_like_to_know_your_thoughts_on_my_decks/)


而 Integrity 能通过：

- Investment
- Cloning
- Silly Strings

同时支持 spell casting、draw、copy 与 G economy，因此比“主题纯度”更重要。

这揭示了 Undercards 构筑最关键的玩家共识：

> **Card belongs to a deck because of function, not because of tag/theme.**

---

# 12.6 Plants / Vine

Plants 是长期存在、容易理解、仍能打的 tribe shell。

但它在 2026 年的环境定位有争议。

七月有人把 Plants 视为强势 value strategy；八月更新后又有人认为它：

> viable，但不是 top 5。

高段位公开观察中仍能看到：

- Vine
- Flower Can
- Ficus

等组合。[Reddit](https://www.reddit.com/r/UnderCards/comments/1v2cg0b/new_player_advice/)

所以我会将当前 Plants 定义为：

> **established competitive archetype，而不是明确 T1。**

它通常通过 stat growth / cheap Vine / board snowball 获胜。

---

# 12.7 Zoo / early-tempo

这个 archetype 可能反而最能说明当前 meta 为什么形成。

七月一个 Seam/Frog Zoo 玩家发现：

> **只要在 turn 12 以前结束比赛，就可以绕过各种 infinite-resource control。**

其策略是：

- early board
- efficient trades
- 快速压低 HP
- punish 前 3–4 回合不做事的 greedy decks。 [Reddit](https://www.reddit.com/r/UnderCards/comments/1v2cg0b/new_player_advice/?utm_source=chatgpt.com)


这就是标准的：

\[
\text{Inevitability meta}
\Rightarrow
\text{Tempo counter-meta}
\]

所以当前 Undercards 并不是单纯“谁 generation 多谁赢”。

---

# 十三、Pieces / Chess、Amalgamate 等次级成熟 archetype

Pieces 在 2026 年仍有人构筑，而且玩家已经形成很明确的 engine 认知。

例如 Pieces deck 的讨论中，社区会直接指出：

- **Pawn Man Statue 是核心**
- Mr Society 应该高密度携带
- unrelated value card 会削弱 deck plan [Reddit](https://www.reddit.com/r/UnderCards/comments/1qfsygz/any_advice_on_how_to_improve_my_deck/?utm_source=chatgpt.com)


Amalgamate 同样仍有玩家使用，当前社区经验更倾向 Perseverance，并特别警告：

> 不要为了 Lemon Bread 过度贪 greed。 [Reddit](https://www.reddit.com/r/UnderCards/comments/1vhx4l3/im_new/?utm_source=chatgpt.com)


这些不一定是当前最高 Tier，但都是已经形成成熟 pilot knowledge 的 archetype。

---

# 十四、玩家真正如何理解一个 deck

这一部分，我认为比 deck list 更值得你整理。

Undercards 社区优秀玩家的思维并不是：

> “我这回合能打什么？”

而是三个问题：

\[
\boxed{
\text{What is my role?}
}
\]

\[
\boxed{
\text{What is my opponent's role?}
}
\]

\[
\boxed{
\text{What state am I trying to create 1–2 turns later?}
}
\]

2026 年一位把自己的 deck 打上 Master 的玩家把这个过程讲得非常清楚。[Reddit](https://www.reddit.com/r/UnderCards/comments/1vyawau/i_seriously_need_help_winning_more_i_dont_even/)

---

# 十五、Trade vs Face：Undercards 的基础决策树

该玩家给出的 heuristics 很有价值，可以抽象成下面这张表：

| 状态 | 通常选择 |
|---|---|
| 双方怪物互相杀不掉 | Face |
| 能杀对方且自己的怪能活 | Trade |
| 对方可以用它的怪换掉你的怪 | 不替对方 trade，Face |
| 对方下一回合能 buff | 提前 Trade |
| 对方一个大怪需要你两个怪才能杀 | 常常 Face + develop |
| 小怪能换昂贵大怪 | Trade |
| 对方是 snowball/support engine | 立即杀 |
| trade 可以保护自己的高价值 attacker | Trade |
| 已经有下一回合 guaranteed lethal | Face |
| 对方正在争夺 board | Trade |
| 对方只是在 stall | Face | :chatgpt-content-reference{index="36"}


它不是绝对规则，但这是目前我找到的最好的一份现代 Undercards **pilot model**。

---

# 十六、Burn、Reach、Initiative：很有必要统一术语

同一个玩家进一步区分了三个非常有用的概念。

### Burn

不依赖 board attack、对手难以阻止的 face damage。

例如 spell / Magic damage。

### Reach

虽然不是 guaranteed direct damage，但能从当前 board state 以外制造额外 lethal range，例如：

- Charge
- buff
- surprise attacker。

### Initiative

能立即影响 board：

- Haste monster
- monster-targeting spell。 [Reddit](https://www.reddit.com/r/UnderCards/comments/1vyawau/i_seriously_need_help_winning_more_i_dont_even/)


如果你在建立卡牌知识库，我强烈建议给每张牌额外标三个非官方属性：

> **Reach / Initiative / Value**

这比简单的“Aggro Card / Control Card”信息量大得多。

---

# 十七、Mulligan 不是找低费，而是识别对面 archetype

较老但高水平的 Legend 攻略提出了一件仍然非常适用的事情：

> 通过 **Soul + Artifacts** 在 mulligan 阶段猜对方 deck。

高手会把对手缩窄到一两个可能 archetype，然后决定留牌。[Reddit](https://www.reddit.com/r/UnderCards/comments/ty3r37)

因此实际上：

\[
P(\text{deck archetype} \mid \text{Soul, Artifacts})
\]

本身就是一种竞技知识。

也就是说，一个真正好用的 Undercards 数据库不应该只有：

> Deck → Cards

还应该有：

> **Soul + Artifact → likely Deck**

这是 opponent modelling。

---

# 十八、Play around：知道什么牌存在，比牌表本身重要

同一篇攻略举出的例子包括：

- 面对 Patience 时考虑 Melt；
- 根据 Lancer 的 board clear 调整 monster HP 分布；
- 追踪 Gemstone 数量；
- 判断对方特定 turn 可以爆发什么；
- 不要无脑铺进 board clear。 [Reddit](https://www.reddit.com/r/UnderCards/comments/ty3r37)


这说明 Undercards 的高水平技能核心之一是：

> **range construction。**

也就是：

\[
\text{Opponent's possible hand}
\]

而不是单纯计算当前场面。

---

# 十九、主动逼 removal

Control matchup 里一个很重要的社区概念是：

> **Threat layering。**

不是“把手全部铺下去”，而是：

1. 制造一个必须处理的 threat；
2. 尽量少投入 hand resource；
3. 逼出 opponent clear；
4. 再建立下一层 threat。

社区特别用 Tombstone 这种“一卡产生多个实体”的牌解释这一点，因为它可以用较少 hand commitment 制造必须回答的 board。[Reddit](https://www.reddit.com/r/UnderCards/comments/ty3r37)

所以针对 control，不能简单归结为：

> “不要 overextend”。

真正原则是：

> **让对方不得不用 removal，但让 removal 不赚。**

---

# 二十、现代 Undercards 最重要的三个战略轴

综合当前资料，我认为可以把 deck 全部放进一个三维空间：

### 1. Tempo

现在的 board / HP / initiative。

### 2. Value

每张牌能产生多少资源。

### 3. Inevitability

如果比赛无限延长，谁最终必胜。

于是典型 deck：

| Deck | Tempo | Value | Inevitability |
|---|---:|---:|---:|
| Zoo | 极高 | 低 | 极低 |
| Plants | 中高 | 中 | 中 |
| Spamton | 中低 | 高 | 高 |
| SK generation | 中 | 极高 | 极高 |
| Spell generation | 中 | 极高 | 高 |
| Royal Papyrus | 低 | 极高 | 极高 |
| RK control | 中 | 高 | 高 + burst |

因此 matchup 的本质不是：

> “我的牌比他的强不强？”

而是：

> **我在哪个轴上必须赢？**

例如 Zoo 打 Royal Papyrus：

> 不应该尝试比 value。

而应该在对方 engine 上线以前结束游戏。

这正好就是 2026 年玩家公开描述的实际经验。[Reddit](https://www.reddit.com/r/UnderCards/comments/1v2cg0b/new_player_advice/?utm_source=chatgpt.com)

---

# 二十一、构筑上最常见的新手错误：Goodstuff soup

2026 年的 deck review 中反复出现一个模式：

> 搜一个 keyword → 全放进去 → 再把自己最强的 Legendary 全塞进去。

Spamton 玩家被直接这样批评过。[Reddit](https://www.reddit.com/r/UnderCards/comments/1wlfvof/i_would_like_to_know_your_thoughts_on_my_decks/)

这通常导致：

- engine density 不够；
- payoff 没有 activator；
- 太多 expensive cards；
- curve/G economy 崩坏；
- support card 没 target；
- 多个半成品 win condition 互相竞争。

因此判断一张牌是否应该进 deck，应该问：

\[
\text{Does this advance the primary game plan?}
\]

而不是：

\[
\text{Is this card individually strong?}
\]

这也是为什么某玩家会说：

> Legendary 很强，但你不一定想要它擅长做的事情。 [Reddit](https://www.reddit.com/r/UnderCards/comments/1wlfvof/i_would_like_to_know_your_thoughts_on_my_decks/)


---

# 二十二、我建议你给卡组建立这样的“Deck Knowledge Schema”

如果你的目标之后是让人或 AI **真正理解 Undercards deck**，我建议每个 archetype 不要只存 card list，而存：

| 字段 | 意义 |
|---|---|
| Archetype | SK / Spamton / RPaps / Zoo… |
| Primary plan | 最主要的胜法 |
| Secondary plan | 第一胜法失败后的路线 |
| Engine | 让牌组运转的卡 |
| Payoff | engine 转换出的收益 |
| Enabler | 满足 Need / Synergy / Dust 等条件 |
| Interaction | removal / silence / paralyze |
| Initiative | 立即影响 board |
| Reach | 潜在额外 face damage |
| Burn | 无法通过普通 Taunt 防御的 damage |
| Value engine | 长期资源来源 |
| Inevitability | 长局为什么赢 |
| Tempo liabilities | 哪些牌会亏节奏 |
| G breakpoints | 关键回合/资源阈值 |
| Mulligan | 通用与 matchup mulligan |
| Artifact tell | artifact 暴露了什么 deck 信息 |
| Soul tell | Soul 暗示什么 |
| Core | 通常不能替换 |
| Flex | meta-dependent slots |
| Tech | 针对环境的牌 |
| Fail state | 这副牌通常怎么输 |
| Counterplay | 对手应如何破坏它 |
| Role vs Aggro | 对快攻时自己的身份 |
| Role vs Control | 对控制时自己的身份 |
| Role vs Combo | 对 combo 时自己的身份 |

这会比传统 deck database 有用很多。

---

# 二十三、目前我对 2026 Undercards 环境的总体理解

如果压缩成一句话：

> **当前 Undercards 是一个“高 generation/value 上限”推动出来的环境，因此一端发展出了 Soulless Kris、spell-generation、Royal Papyrus 之类超高 inevitability deck，另一端则发展出 Zoo / fast tempo 去惩罚这些牌组；Roaring Knight 处在中间，既是高价值 deck 的终结手段，也本身成为玩家必须围绕其改变 board management 的 meta-defining threat。**

六月至九月的公开玩家讨论基本与这个模型吻合：Royal Papyrus 和 spell generation 被列作顶层策略；七月高段位出现 SK、RK、Gold Widow 等；快速 Zoo 又被认为非常适合攻击这些慢速牌组。[Reddit](https://www.reddit.com/r/UnderCards/comments/1uk0v7g/what_is_strongest/?utm_source=chatgpt.com)

而 9 月 30 日的最新 DT 讨论里，社区仍把 **Soulless Kris、Roaring Knight、Lost Noelle、Flowery、Frisk、DT Ceroba** 列为值得构筑的强力 DT，说明这一基本格局到 Season 123 前夕仍然存在。[Reddit](https://www.reddit.com/r/UnderCards/comments/1wts90d/what_dt_should_i_get/?utm_source=chatgpt.com)

---

接下来最值得做的不是继续泛搜，而是我可以以你已经整理好的卡池为底，进一步构建一份真正可用的 **《Undercards Competitive Compendium》**：把 **当前常见的约 15–25 个 archetype 逐个还原为 Core / Flex / Game Plan / Mulligan / Matchup / Counterplay**，同时再单独整理一份 **“规则裁定表”**，专门记录 `Play/Summon/Dust/Erase/Overdraw/Delay/Shock/slot/trigger ordering` 这种容易出问题的边界情况。这样最终就会接近一套可直接用于分析牌局或训练 Agent 的领域知识库。

---
