# Undercards model bundle V4

This isolated behavior sensitivity extends frozen V3. The engine adds `Settings.opponent_cash_weights`, an optional four-entry immutable tuple in aggro/control/combo/midrange order. JSON lists normalize to tuples for policy caches. `None` inherits the global `cash_weight` exactly; an explicit override affects only `leaf(side=1)` for the corresponding opposing role. The own cash preference and real gold payments do not change.

The suggested public preference `[0.5,1,0.5,0.5]` gives the control opponent a greater reason to preserve cash/answer opportunities. With hand_weight=0, the bare Scarf Mouse body has B=2.445989 and costs 3G, so its control marginal is approximately -0.554011. It is retained with no useful Silence target, while a real fresh 7/7 Glyde still invites a paid 3G Silence response. Headshot is retained against a plain 2/2 body. This is a declared normative preference sensitivity, not optimal/empirically fitted behavior or a card-name penalty. Deterministic lethal ordering remains superior to all nonterminal cash preferences.

All V3 policy templates and execution mechanisms, including the common hold-root-entire-window and diagnostic sampling, remain unchanged. Only V4 engine Settings/leaf definitions and portfolio version/description metadata differ among the copied implementation files. V2, V3 and top-level frozen files remain protected by hashes. Samples report min_sampled_hp, not a continuous HP minimum.

Run from E:/NoScan/Codex/Undercards:

```powershell
python -X utf8 analysis/monster-value-dynamic/model-versions/v4/analysis/verify_opponent_cash_v4.py
python -X utf8 analysis/monster-value-dynamic/model-versions/v4/analysis/verify_dynamic_portfolio_v3.py
python -X utf8 analysis/monster-value-dynamic/model-versions/v4/analysis/run_dynamic_matrix.py --tag v4-cash-next-experiment --suite full --seed 20261006 --cards 49,984,418,138,847,243 --donor-cards=2,4,602,187,15,7,9,20,22,3,6,11,13,49,243,138,236,225,311,418,847,984,21,62 --budget 80 --horizon 3 --train-worlds 8 --tune-worlds 16 --eval-worlds 24 --workers 6 --settings-json '{"hand_weight":0,"cash_weight":0.5,"bullseye_on_simultaneous_death":false,"opponent_cash_weights":[0.5,1,0.5,0.5]}'
```

The matrix command is a runnable new-experiment example, not a report of computed values; use a fresh tag. The synthetic baseline is automatically included in the common donor cohort. To reproduce the V3 behavioral branch, omit opponent_cash_weights or set it to null. Outputs remain inside this bundle and record full Settings plus V4 engine/portfolio source hashes and behavior metadata. TRAIN fits trees, TUNE selects a fixed policy ID, and FINAL evaluates only that frozen ID. Previous FINAL diagnostics are not primary V4 results.

Verification covers exact None-versus-V3 leaf/public prior/legal actions/own and opposing actions/complete physical rounds, role isolation, hashable JSON configurations, illegal-shape/nonfinite rejection, real payments and lethal priorities. The unchanged inherited portfolio contract checker is verify_dynamic_portfolio_v3.py (149 checks); copied engine and information checkers remain applicable. The byte-preserved verify_hold_entire_window.py remains a historical V3 source-protection checker; V4 source protection is handled by verify_opponent_cash_v4.py, which also proves all portfolio execution function ASTs remain identical to V3. Source-protection checks assume the sibling V2/V3 bundles and original workspace remain accessible.

Python, NumPy and SciPy are runtime dependencies; Matplotlib is used by the renderer. No install or network sync is performed. The SHA manifest excludes itself and generated outputs.
