# Undercards model bundle V3

V3 preserves all copied V2 implementation files except its own dynamic_policy_portfolio.py. Every actual, baseline and donor-as-actual receives the same additional hold-root-entire-window option. The existing hold-root-current-window behavior stays unchanged. Runtime paths resolve inside this bundle.

The new option masks only the marked original hand entity via a temporary high fee in a decision clone, uses the configured two-step public greedy rule, checks actual legality, then applies only to the real state. It keeps card identity, hand count and real costs; return/redraw of the original is re-masked. Same-name other copies remain playable.

Diagnostic fields include final_turns, real resource/board boundary_samples, and min_sampled_hp. Samples cover the initial own window, own atomic actions, completed opposing replies or early terminal, and optional next own starts. They do not cover opponent internal action minima. Round splitting was compared against unchanged V2 results; objective and physical transitions stay identical for all old policies.

Run from E:/NoScan/Codex/Undercards:

```powershell
python -X utf8 analysis/monster-value-dynamic/model-versions/v3/analysis/verify_hold_entire_window.py
python -X utf8 analysis/monster-value-dynamic/model-versions/v3/analysis/verify_dynamic_portfolio_v3.py
python -X utf8 analysis/monster-value-dynamic/model-versions/v3/analysis/dynamic_policy_portfolio.py --cards 49,984 --donor-cards=49,984 --roots aggro-t3-high-open --budget 8 --horizon 2 --train-worlds 2 --tune-worlds 2 --eval-worlds 2 --tag v3-example --settings-json '{"hand_weight":0,"bullseye_on_simultaneous_death":false}'
python -X utf8 analysis/monster-value-dynamic/model-versions/v3/analysis/run_dynamic_matrix.py --tag v3-next-experiment --suite full --cards 49,984,418,138,847,243 --donor-cards=2,4,602,187,15,7,9,20,22,3,6,11,13,49,243,138,236,225,311,418,847,984,21,62 --budget 80 --horizon 4 --train-worlds 8 --tune-worlds 16 --eval-worlds 24 --workers 1 --settings-json '{"hand_weight":0,"bullseye_on_simultaneous_death":false}'
```

The matrix command is a runnable example for a new experiment, not a report of computed values; use fresh tags and freeze requested parameters/sources. Outputs stay inside this bundle. Actual results record V3 source SHA, policy version and common template list. TRAIN/TUNE/FINAL remain separate; old FINAL diagnostic counterexamples are not retroactively primary results.

The copied verify_dynamic_portfolio.py preserves the historical V2 checker byte for byte. verify_dynamic_portfolio_v3.py retains all its contract checks and adjusts only changed template-count expectations (with a distinct output file); it passes 149/149. verify_hold_entire_window.py covers the new policy surface and old-policy physical equivalence, passing 104/104. Copied engine/information verifiers pass 268/268 and 14/14. Both direct portfolio smoke and runner smoke completed; their artifacts pass the unchanged bundled results auditor. The source-protection verifier assumes this workspace and the sibling V2 bundle remain accessible.

Python, NumPy and SciPy are runtime dependencies; Matplotlib is used by the renderer. No network sync or installation is performed. The source manifest excludes itself and generated outputs.
