# Undercards model bundle V2

This is an exact byte copy of the frozen V2 implementation and card snapshot. It includes the common donor portfolio, current-turn hold template, runner, auditor, renderer, and original verifiers. Runtime paths resolve within this bundle.

Run from E:/NoScan/Codex/Undercards:

```powershell
python -X utf8 analysis/monster-value-dynamic/model-versions/v2/analysis/dynamic_policy_portfolio.py --cards 49,984 --donor-cards=49,984 --roots aggro-t3-high-open --budget 8 --horizon 2 --train-worlds 2 --tune-worlds 2 --eval-worlds 2 --tag v2-example --settings-json '{"hand_weight":0,"bullseye_on_simultaneous_death":false}'
python -X utf8 analysis/monster-value-dynamic/model-versions/v2/analysis/verify_dynamic_portfolio.py
```

Output stays inside this bundle's analysis/monster-value-dynamic directory. Python, NumPy and SciPy are runtime dependencies; Matplotlib is used by the renderer. No network sync or package installation is performed. The manifest lists every immutable source/data/document file, excluding itself and generated outputs.
