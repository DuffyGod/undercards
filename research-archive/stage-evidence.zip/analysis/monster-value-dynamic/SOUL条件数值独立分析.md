# 最小 SOUL 条件数值对照

2026-10-07。冻结 V3；实测候选为 Glyde、Terakota Archer，合成 6G 6/7 为共同基准。三组都使用固定 24 实卡 donor 加基准、h4、budget40、TRAIN4/TUNE8/FINAL12、seed20261007、normal25、hand_weight=0、同死 Bullseye=False。根为快攻 t3 高手牌开放场面、常规 t5 高手牌开放场面；JUSTICE 与 KINDNESS 两组分别 workers1，无新增全卡实验。

NONE 对照来自 `v3-h4-h0-four-s20261007`，只选匹配的两根和两候选。它虽然另测四张卡，donor 集合与顺序、逐候选可用策略、搜索/分割参数完全相同。只读分析脚本已核对所有非标签/选根/actual 子集/worker/SOUL 参数、源哈希、根模板和逐世界 FINAL 事件种子，并从实际结果重算差值。没有在 FINAL 选择策略。三组完整数据均通过冻结 V3 审计：NONE 28 项、JUSTICE 6 项、KINDNESS 6 项 candidate/root checks。

## 结果

单位为 **100×截断效用差**；G−A 是同世界直接配对的 Glyde 减 Archer，与共同基准相消。下表不汇总为四类通用评分。

| 根 | 我方 SOUL | Glyde 相对基准 | Archer 相对基准 | G−A | Archer 实体打出率 | Archer 未终局率 |
|---|---|---:|---:|---:|---:|---:|
| 快攻 t3 | NONE | +9.0636 | +5.7378 | +3.3258 | 66.7% | 91.7% |
| 快攻 t3 | JUSTICE | +16.8371 | −2.6116 | +19.4487 | 50.0% | 83.3% |
| 快攻 t3 | KINDNESS | +14.6175 | +2.2725 | +12.3451 | 58.3% | 100% |
| 常规 t5 | NONE | −8.4969 | +17.5575 | −26.0544 | 100% | 16.7% |
| 常规 t5 | JUSTICE | +50.0000 | −14.2323 | +64.2323 | 100% | 75.0% |
| 常规 t5 | KINDNESS | +50.0000 | −37.5920 | +87.5920 | 100% | 91.7% |

常规根的两 SOUL 组中，Glyde 在 12 个设计世界全部胜出，基准为 9 胜 3 负；因此其相对增量确为 +50。Archer 的 JUSTICE 组为 3 胜 9 未终局，KINDNESS 组为 1 胜 11 未终局。这既包含已终局改变，也包含速度与截断代理的差，不能读成 Archer 最终必败或职业天梯胜率。

## 能说明什么

**卡牌关系确实受 SOUL 条件和策略适应影响；这组数据不支持给两张牌一个跨 SOUL 固定先后。** 常规根的直接差从 NONE 的 −26.05 翻到 JUSTICE 的 +64.23、KINDNESS 的 +87.59。两个根不足以推导四任务三阶段的通用质量，也不足以断言 SOUL 对某卡天然有利或不利。

每个 SOUL 都重新执行 TRAIN/TUNE，使用其自行冻结的策略，所以这是一项「知道 SOUL 后如何持牌与操作」的条件敏感性，并非保持动作不变的纯被动因果效应。例如常规根 Archer 的 NONE 策略为 donor-13，两个 SOUL 组为 donor--6。相同 FINAL 世界 0 中，NONE 先 Bench 再 Archer，SOUL 组先 Archer 再 Shyren/Froggit；三组当时均实际精确击杀并得到 Clover，但后续攻击、补牌和交换路线不同。这个例子帮助定位策略差异，不能替代全部世界的因果归因。

快攻根的基准也发生策略变化：NONE 为 donor-15，JUSTICE 为立即打出，KINDNESS 为全窗口留牌（基准实体打出率0）。因此候选相对基准的增量变化不是简单增加同一项 SOUL 身材奖励。直接 G−A 已去掉基准项，仍保留两张卡各自的策略变化。

根是我方本回合收入/抽牌后的固定动作窗口，SOUL 切换不重放之前历史。JUSTICE 从下一次我方开始回合起生效；KINDNESS 从当前结束回合起生效。它们不是两职业从真实开局到该局面的完整比较。最低 HP 并列目标采用 left、回合开始队列采用 soul_first，均为已公开规则假设。

可靠报告应把 SOUL 作为条件变量，列出收益、兑现、未终局与冻结策略；不能将上述变化转换成每卡固定的「职业加分」。这次对照已经足以证明相关条件需要显式保留，无需为所有卡追加 SOUL 全排列。若将来要解释被动本身，可另作相同固定策略回放，但本次没有据 FINAL 选择新策略，也未发布这类因果量。

复算脚本：[independent_soul_condition_analysis.py](independent_soul_condition_analysis.py)。数值、逐世界配对差、资源指标与匹配参数：[independent-soul-condition-analysis.json](independent-soul-condition-analysis.json)。

审计文件：[NONE](independent-soul-none-combined-audit.json)、[JUSTICE](independent-soul-justice-combined-audit.json)、[KINDNESS](independent-soul-kindness-combined-audit.json)。原始数据位于冻结 V3 的 `analysis/monster-value-dynamic/runs/` 对应运行标签中。
